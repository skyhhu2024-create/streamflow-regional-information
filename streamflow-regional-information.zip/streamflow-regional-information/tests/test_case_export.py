"""Explicit-path case export without access to provider observations."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

SPEC = importlib.util.spec_from_file_location(
    'case_export', Path(__file__).resolve().parents[1]/'examples/export_registered_case.py')
EXPORT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(EXPORT)


class CaseExportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.config = self.root/'inputs.json'
        paths = {
            'cases': 'cases.csv', 'streamflow': 'q.npy',
            'source_ids': 'sources.npy', 'source_exclusions': 'exclusions.csv',
            'station_metadata': 'metadata.csv', 'physical_identity': 'identity.csv',
            'precipitation_features': 'p.npz',
        }
        self.config.write_text(json.dumps(paths), encoding='utf-8')
        (self.root/'cases.csv').write_text(
            'station_id,row,raw_index,history_start,history_end,gap_start,gap_end,latitude,longitude\n'
            'synthetic,0,0,0,60,60,180,0,0\n', encoding='utf-8')
        self.q = np.arange(540, dtype=float).reshape(3,180)+1.
        np.save(self.root/'q.npy', self.q)
        np.save(self.root/'sources.npy', np.arange(3))
        (self.root/'exclusions.csv').write_text('raw_index\n', encoding='utf-8')
        (self.root/'metadata.csv').write_text(
            'raw_index,latitude,longitude\n0,0,0\n1,0,0\n2,1,1\n', encoding='utf-8')
        (self.root/'identity.csv').write_text(
            'raw_index,physical_group_raw_index\n0,0\n1,0\n2,2\n', encoding='utf-8')
        self.p = dict(p_h=np.arange(240.).reshape(1,60,4),
                      p_g=np.arange(480.).reshape(1,120,4),
                      p_g_climatology=np.ones((1,120,4)),
                      p_calendar_logmean=np.arange(12.).reshape(1,12),
                      p_available=np.array([True]), p_reason=np.array(['synthetic']))
        np.savez(self.root/'p.npz', **self.p)

    def run_export(self, include_truth=False):
        destination = self.root/'out'/'case.npz'
        with contextlib.redirect_stdout(io.StringIO()):
            EXPORT.export(EXPORT.load_inputs(self.config), 'synthetic', destination, include_truth)
        return destination

    def test_relative_inputs_and_identity_isolation(self):
        path = self.run_export()
        with np.load(path) as data:
            self.assertNotIn('target_gap_truth',data.files)
            np.testing.assert_array_equal(data['target_history'], self.q[0,:60])
            self.assertTrue(np.isnan(data['source_flows'][:2,60:]).all())
            np.testing.assert_array_equal(data['source_flows'][2],self.q[2])
            np.testing.assert_array_equal(data['target_physical_ids'],[0,1])
            for key,value in self.p.items():
                np.testing.assert_array_equal(data[key],value[0])

    def test_truth_export_is_explicit_and_reported(self):
        path = self.run_export(include_truth=True)
        with np.load(path) as data:
            np.testing.assert_array_equal(data['target_gap_truth'],self.q[0,60:])
        self.assertTrue(json.loads(path.with_suffix('.json').read_text())['target_gap_truth_exported'])

    def test_missing_input_key_is_named(self):
        self.config.write_text('{}',encoding='utf-8')
        with self.assertRaisesRegex(ValueError,'cases'):
            EXPORT.load_inputs(self.config)

    def test_missing_file_is_named(self):
        (self.root/'p.npz').unlink()
        with self.assertRaisesRegex(FileNotFoundError,'precipitation_features'):
            EXPORT.load_inputs(self.config)


if __name__ == '__main__':
    unittest.main()
