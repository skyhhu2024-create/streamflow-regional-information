"""Synthetic-only scientific and boundary tests for metrics.py; no data-array reads."""
import hashlib
import itertools
import json
from pathlib import Path
import unittest
import warnings
import importlib.util
import subprocess
import tempfile

import numpy as np
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from streamflow_info import water_metrics as wm

HERE = Path(__file__).resolve().parent
CLI_PATH = HERE.parent / 'scripts/evaluate_water.py'
SPEC = importlib.util.spec_from_file_location('water_cli', CLI_PATH)
cli = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(cli)


class WaterCliTests(unittest.TestCase):
    def setUp(self):
        import pandas as pd
        self.hd = np.arange('1980-01', '1985-01', dtype='datetime64[M]')
        self.gd = np.arange('1985-01', '1995-01', dtype='datetime64[M]')
        rng = np.random.default_rng(14)
        self.h = rng.lognormal(4, .6, (2, 60))
        self.o = rng.lognormal(4, .6, (2, 120))
        self.p = np.stack([self.o, self.o*1.2], axis=1)
        records = []
        for i in range(2):
            for j, arm in enumerate(['perfect', 'biased']):
                records.append(pd.DataFrame(dict(case_id=str(i), arm=arm,
                    date=np.concatenate([self.hd, self.gd]).astype(str),
                    phase=['history']*60+['gap']*120,
                    observed=np.concatenate([self.h[i], self.o[i]]),
                    predicted=np.concatenate([np.full(60, np.nan), self.p[i,j]]),
                    spatial_cell=f'block{i}', meta_fallback_months=0)))
        self.frame = pd.concat(records, ignore_index=True)

    def test_bootstrap_matches_literal_block_resampling(self):
        draws = np.array([[2,0],[0,2],[1,1]])
        e = cli.SpatialBootstrap(['a','b'], draws)
        v, ix = np.array([2., 4., 10.]), np.array([0,0,1])
        samples = [np.repeat(v, draw[ix]) for draw in draws]
        np.testing.assert_allclose(e.median(v,ix), [np.median(x) for x in samples])
        np.testing.assert_allclose(e.mean(v,ix), [np.mean(x) for x in samples])
        np.testing.assert_allclose(e.median([9.],[0]), [9., np.nan, 9.], equal_nan=True)
        np.testing.assert_allclose(e.mean([9.],[0]), [9., np.nan, 9.], equal_nan=True)

    def test_bootstrap_rejects_invalid_weights(self):
        for draws in ([[1.5,.5],[1,1]], [[-1,3],[1,1]], [[1,0],[1,1]]):
            with self.assertRaises(ValueError):
                cli.SpatialBootstrap(['a','b'], draws)
        with self.assertRaises(ValueError):
            cli.SpatialBootstrap(['a','a'], [[1,1],[1,1]])

    def test_csv_and_npz_have_same_metrics(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp)/'case.npz'
            np.savez(path, case_id=np.array(['0','1']), arm_names=np.array(['perfect','biased']),
                spatial_cell=np.array(['block0','block1']), history=self.h, observed=self.o,
                predicted=self.p, history_dates=self.hd, gap_dates=self.gd)
            a, b = cli.score_frame(self.frame), cli.score_frame(cli.load_npz(path))
            for col in wm.FLOAT_FIELDS:
                np.testing.assert_allclose(a[col], b[col], equal_nan=True)
            self.assertEqual(a.meta_fallback_months.tolist(), [0]*8)

    def test_pair_intersection_retains_registered_denominator(self):
        f = self.frame.copy()
        f.loc[(f.case_id=='1') & (f.arm=='biased') & (f.phase=='gap'), 'predicted'] = np.nan
        scored = cli.score_frame(f)
        e = cli.SpatialBootstrap(['block0','block1'], [[1,1],[2,0],[0,2]])
        summary, paired = cli.summarize(scored,e,[dict(arm='biased',reference='perfect')])
        s = summary[(summary.arm=='biased') & (summary.percentile==20) & (summary.metric=='water_abs_rel_error')].iloc[0]
        p = paired[(paired.percentile==20) & (paired.metric=='water_abs_rel_error')].iloc[0]
        self.assertEqual((s.registered_n,s.valid_n,s.unevaluated_n),(2,1,1))
        self.assertEqual((p.registered_n,p.paired_n,p.valid_bootstrap_draws),(2,1,2))
        self.assertAlmostEqual(p.estimate,.2)

    def test_rejects_truth_mismatch_and_missing_arm(self):
        f = self.frame.copy()
        f.loc[(f.case_id=='0') & (f.arm=='biased') & (f.phase=='gap'), 'observed'] += 1
        with self.assertRaisesRegex(ValueError,'identical across arms'):
            cli.score_frame(f)
        with self.assertRaisesRegex(ValueError,'every arm'):
            cli.score_frame(self.frame[~((self.frame.case_id=='0') & (self.frame.arm=='biased'))])

    def test_cli_end_to_end_and_frozen_draws(self):
        import pandas as pd
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.frame.to_csv(root/'input.csv',index=False)
            (root/'contrast.json').write_text(json.dumps([dict(arm='biased',reference='perfect')]))
            base = [sys.executable,'-X','utf8',str(CLI_PATH),'--input',str(root/'input.csv'),
                    '--contrasts',str(root/'contrast.json'),'--resamples','20']
            p = subprocess.run(base+['--output',str(root/'first')],capture_output=True,text=True)
            self.assertEqual(p.returncode,0,p.stdout+p.stderr)
            p = subprocess.run(base+['--output',str(root/'second'),'--bootstrap-draws',
                str(root/'first/bootstrap_draws.npz')],capture_output=True,text=True)
            self.assertEqual(p.returncode,0,p.stdout+p.stderr)
            for name in ['water_summary.csv','paired_water_effects.csv','per_target_water_metrics.csv']:
                pd.testing.assert_frame_equal(pd.read_csv(root/'first'/name),pd.read_csv(root/'second'/name))
            receipt = json.loads((root/'first/run.json').read_text())
            self.assertEqual(receipt['registered_targets'],2)
            self.assertTrue(receipt['no_refit'])
            p = subprocess.run(base+['--output',str(root/'first')],capture_output=True,text=True)
            self.assertNotEqual(p.returncode,0)


class WaterMetricsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.hd = np.arange('1980-01', '1985-01', dtype='datetime64[M]').astype('datetime64[D]')
        cls.gd = np.arange('1985-01', '1995-01', dtype='datetime64[M]').astype('datetime64[D]')
        cls.hm = cls.hd.astype('datetime64[M]').astype(int) % 12
        cls.gm = cls.gd.astype('datetime64[M]').astype(int) % 12
        rng = np.random.default_rng(20261029)
        cls.h = (100 + 30*np.sin(2*np.pi*cls.hm/12)) * np.exp(rng.normal(0, .4, 60))
        cls.o = (100 + 30*np.sin(2*np.pi*cls.gm/12)) * np.exp(rng.normal(0, .4, 120))

    def ev(self, h=None, o=None, p=None, hd=None, gd=None, pct=20):
        h = self.h if h is None else h
        o = self.o if o is None else o
        return wm.evaluate_case(h, self.hd if hd is None else hd, o,
                                o.copy() if p is None else p,
                                self.gd if gd is None else gd, pct)

    def test_01_perfect_predictions(self):
        r = self.ev()
        self.assertTrue(r['drought_hss_valid'])
        self.assertEqual(r['drought_hss'], 1)
        self.assertAlmostEqual(r['drought_hss_excess'], 1-r['drought_hss_chance'])
        self.assertEqual(r['deficit_ratio'], 1)
        self.assertEqual(r['deficit_abs_error_hmean_normalized'], 0)
        self.assertEqual(r['water_rel_error'], 0)
        self.assertEqual(r['change_category_10pct'], 'correct')

    def test_02_exact_conditional_expectation(self):
        o = np.array([1,1,0,1,0,0], bool)
        p = np.array([1,0,0,1,1,0], bool)
        m = np.repeat([0,1],3)
        brute = []
        for a in itertools.permutations(p[:3]):
            for b in itertools.permutations(p[3:]):
                q=np.array(a+b)
                tp=np.sum(o&q); fp=np.sum(~o&q); fn=np.sum(o&~q); tn=np.sum(~o&~q)
                brute.append(2*(tp*tn-fp*fn)/((tp+fn)*(fn+tn)+(tp+fp)*(fp+tn)))
        raw,chance,excess,expected=wm.conditional_hss(o,p,m)
        self.assertAlmostEqual(chance,np.mean(brute), places=14)
        self.assertAlmostEqual(excess,raw-chance,places=14)
        self.assertAlmostEqual(expected,4/3)

    def test_03_calendar_only_zero_excess_and_perfect_not_one(self):
        o=(self.gm==0) | ((self.gm==1)&(np.arange(120)<60))
        p=self.gm<=1
        raw, chance, excess, _=wm.conditional_hss(o,p,self.gm)
        self.assertGreater(raw,0)
        self.assertEqual(excess,0)
        self.assertEqual(raw,chance)
        raw,chance,excess,_=wm.conditional_hss(o,o,self.gm)
        self.assertEqual(raw,1)
        self.assertLess(excess,1)

    def test_04_transform_matches_original_definition(self):
        x=np.log1p(self.h)
        mu=np.array([np.mean(x[self.hm==m]) for m in range(12)])
        s=np.std(x-mu[self.hm],ddof=0)
        c=np.percentile((x-mu[self.hm])/s,20,method='linear')
        threshold,s2,c2=wm.seasonal_threshold(self.h,self.hm,self.gm,20)
        direct_cutoff=np.percentile(x-mu[self.hm],20,method='linear')
        np.testing.assert_allclose(threshold,np.maximum(np.expm1(mu[self.gm]+direct_cutoff),0),rtol=0,atol=0)
        # The direct path is mathematically equivalent to the standardized
        # formula while avoiding a spurious positive epsilon at exact zeros.
        np.testing.assert_allclose(threshold,np.maximum(np.expm1(mu[self.gm]+s*c),0),rtol=1e-13,atol=1e-13)
        self.assertEqual(s,s2);self.assertEqual(c,c2)
        observed_flags=(np.log1p(self.o)-mu[self.gm])/s<c
        np.testing.assert_array_equal(observed_flags,self.o<threshold)

    def test_05_event_and_deficit_same_threshold(self):
        t,_,_=wm.seasonal_threshold(self.h,self.hm,self.gm,20)
        o=np.where(np.arange(120)<60,t*.5,t+1)
        p=t+1
        r=self.ev(o=o,p=p)
        self.assertEqual(r['drought_observed_count'],60)
        self.assertEqual(r['drought_predicted_count'],0)
        self.assertEqual(r['drought_misses'],60)
        self.assertEqual(r['deficit_ratio'],0)
        self.assertEqual(r['deficit_complete_miss'],1)
        self.assertEqual(r['drought_hss'],0)
        days=((self.gd.astype('datetime64[M]')+1).astype('datetime64[D]')-self.gd).astype(float)
        self.assertAlmostEqual(r['deficit_observed_m3'],np.sum(np.maximum(t-o,0)*days*86400))

    def test_06_no_events_keeps_false_alarms(self):
        t,_,_=wm.seasonal_threshold(self.h,self.hm,self.gm,20)
        r=self.ev(o=t+1,p=t*.5)
        self.assertTrue(r['drought_paired_valid'])
        self.assertFalse(r['drought_hss_valid'])
        self.assertEqual(r['drought_observed_none'],1)
        self.assertEqual(r['drought_false_alarms'],120)
        self.assertTrue(np.isnan(r['drought_count_ratio']))
        self.assertEqual(r['deficit_false_positive'],1)
        self.assertFalse(r['deficit_ratio_valid'])
        self.assertTrue(r['deficit_normalized_error_valid'])

    def test_07_all_events_keeps_count_ratio(self):
        t,_,_=wm.seasonal_threshold(self.h,self.hm,self.gm,20)
        r=self.ev(o=t*.5)
        self.assertEqual(r['drought_observed_all'],1)
        self.assertEqual(r['drought_count_ratio'],1)
        self.assertEqual(r['drought_hits'],120)
        self.assertFalse(r['drought_hss_valid'])
        self.assertEqual(r['deficit_ratio'],1)

    def test_08_days_leap_and_relative_volume(self):
        o=np.zeros(120);p=np.zeros(120);o[0]=10;p[1]=10
        r=self.ev(o=o,p=p)
        self.assertEqual(r['history_days'],1827) # 1980 and 1984 are leap years.
        self.assertEqual(r['gap_days'],3652)
        self.assertEqual(r['water_observed_volume_m3'],10*31*86400)
        self.assertEqual(r['water_predicted_volume_m3'],10*28*86400)
        self.assertAlmostEqual(r['water_rel_error'],28/31-1)
        self.assertNotEqual(r['water_rel_error'],0)

    def test_09_constant_positive_history_valid_water(self):
        r=self.ev(h=np.full(60,10.),o=np.full(120,10.))
        self.assertFalse(r['event_definition_valid'])
        self.assertTrue(r['water_relative_error_valid'])
        self.assertEqual(r['water_rel_error'],0)
        self.assertEqual(r['history_flow_constant'],1)
        self.assertEqual(r['truth_flow_constant'],1)
        self.assertEqual(r['change_category_10pct'],'correct')

    def test_10_zero_history_and_zero_truth(self):
        r=self.ev(h=np.zeros(60),o=np.zeros(120))
        self.assertEqual(r['history_mean_zero'],1)
        self.assertTrue(r['water_paired_valid'])
        self.assertFalse(r['water_relative_error_valid'])
        self.assertEqual(r['water_both_zero'],1)
        self.assertFalse(r['period_change_paired_valid'])
        self.assertEqual(r['change_category_10pct'],'undefined')
        r=self.ev(o=np.zeros(120),p=np.ones(120))
        self.assertEqual(r['water_false_positive'],1)
        self.assertFalse(r['water_relative_error_valid'])
        self.assertGreater(r['water_abs_error_m3'],0)

    def test_11_negative_prediction_not_clipped(self):
        p=self.o.copy();p[0]=-1
        r=self.ev(p=p)
        self.assertEqual(r['prediction_status'],'negative')
        self.assertEqual(r['prediction_negative_months'],1)
        self.assertFalse(r['prediction_input_valid'])
        self.assertFalse(r['water_paired_valid'])
        self.assertTrue(r['drought_observed_valid'])
        self.assertFalse(r['drought_predicted_valid'])
        self.assertTrue(np.isnan(r['drought_predicted_count']))
        self.assertTrue(np.isfinite(r['drought_observed_count']))

    def test_12_nan_prediction_retains_observed_values(self):
        p=self.o.copy();p[0]=np.nan
        r=self.ev(p=p)
        self.assertFalse(r['water_paired_valid'])
        self.assertEqual(r['prediction_nonfinite_months'],1)
        self.assertTrue(np.isfinite(r['water_observed_volume_m3']))
        self.assertTrue(np.isnan(r['water_predicted_volume_m3']))
        self.assertEqual(r['change_category_10pct'],'undefined')

    def test_13_bad_history_does_not_erase_water(self):
        h=self.h.copy();h[0]=np.nan
        r=self.ev(h=h)
        self.assertFalse(r['event_definition_valid'])
        self.assertTrue(r['water_relative_error_valid'])
        self.assertEqual(r['water_abs_rel_error'],0)
        self.assertFalse(r['period_change_paired_valid'])

    def test_14_date_shape_sequence_adjacency(self):
        altered=self.gd.copy();altered[1]=altered[0]
        r=self.ev(gd=altered)
        self.assertFalse(r['dates_valid'])
        self.assertEqual(r['dates_status'],'gap:nonconsecutive_months')
        shifted=(self.gd.astype('datetime64[M]')+1).astype('datetime64[D]')
        self.assertEqual(self.ev(gd=shifted)['dates_status'],'history_gap_not_adjacent')
        self.assertFalse(self.ev(hd=self.hd[:59])['dates_valid'])
        self.assertFalse(self.ev(hd=np.arange(60))['dates_valid'])
        self.assertFalse(self.ev(o=self.o[:119])['truth_input_valid'])

    def test_15_boundary_tolerance(self):
        for tol in (.10,.20,.25,.50):
            self.assertEqual(wm.within_tolerance(tol,tol),1)
            self.assertEqual(wm.within_tolerance(tol*(1+5e-13),tol),1)
            self.assertEqual(wm.within_tolerance(tol*(1+2e-12),tol),0)
        for band in (.10,.20):
            self.assertEqual(wm.period_change_class((1+band)-1,band),0)
            self.assertEqual(wm.period_change_class(-band,band),0)
        r=self.ev(h=np.full(60,100.),o=np.full(120,110.))
        self.assertEqual(r['change_observed_10pct'],0)

    def test_16_exhaustive_four_direction_categories(self):
        expected={(-1,-1):'correct',(-1,0):'false_stable',(-1,1):'reversed',
                  (0,-1):'false_change',(0,0):'correct',(0,1):'false_change',
                  (1,-1):'reversed',(1,0):'false_stable',(1,1):'correct'}
        for classes,cat in expected.items():
            self.assertEqual(wm.direction_category(*classes),cat)
        self.assertEqual(wm.direction_category(np.nan,0),'undefined')

    def test_17_mean_change_not_trend(self):
        # Reverse around identical day-weighted means to retain opposite trends.
        days=((self.gd.astype('datetime64[M]')+1).astype('datetime64[D]')-self.gd).astype(float)
        up=np.linspace(80,160,120)
        down=up[::-1].copy()
        down+=np.average(up,weights=days)-np.average(down,weights=days)
        r=self.ev(h=np.full(60,100.),o=up,p=down)
        self.assertEqual(r['change_category_10pct'],'correct')
        self.assertGreater(np.polyfit(np.arange(120),up,1)[0],0)
        self.assertLess(np.polyfit(np.arange(120),down,1)[0],0)

    def test_18_two_percentiles_and_no_array_mutation(self):
        before=[a.copy() for a in (self.h,self.o,self.hd,self.gd)]
        a=self.ev(pct=20);b=self.ev(pct=10)
        self.assertLess(b['history_anomaly_threshold'],a['history_anomaly_threshold'])
        self.assertLessEqual(b['drought_observed_count'],a['drought_observed_count'])
        for old,new in zip(before,(self.h,self.o,self.hd,self.gd)):
            np.testing.assert_array_equal(old,new)
        with self.assertRaises(ValueError):self.ev(pct=15)

    def test_19_fixed_schema_all_edge_cases(self):
        expected=set(wm.empty_result(20))
        scenarios=[self.ev(),self.ev(h=np.zeros(60)),self.ev(o=np.zeros(120)),
                   self.ev(p=np.full(120,np.nan)),self.ev(hd=np.arange(60)),
                   self.ev(h=np.full(60,10.)),self.ev(pct=10)]
        for r in scenarios:
            self.assertEqual(set(r),expected)
            self.assertTrue(all(np.isscalar(v) for v in r.values()))
            self.assertFalse(any(v=='not_evaluated' for v in r.values() if isinstance(v,str)))

    def test_20_equivalence_fullvolume_and_weightedmean_relative_error(self):
        p=self.o*np.linspace(.75,1.25,120)
        r=self.ev(p=p)
        self.assertAlmostEqual(r['water_rel_error'],r['gap_predicted_mean_flow']/r['gap_observed_mean_flow']-1,places=14)
        t,_,_=wm.seasonal_threshold(self.h,self.hm,self.gm,20)
        # The H normalizer is a rate times G duration, not observed G deficit.
        expected=abs(r['deficit_predicted_m3']-r['deficit_observed_m3'])/(r['history_mean_flow']*r['gap_days']*86400)
        self.assertAlmostEqual(r['deficit_abs_error_hmean_normalized'],expected,places=14)

    def test_21_exact_zero_threshold_no_spurious_low_months(self):
        # Entirely synthetic H: each month has [0,0,1,2,4] over its five years.
        # Both declared quantiles lie on the zero-flow residual plateau.
        h=np.repeat([0.,0.,1.,2.,4.],12)
        x=np.log1p(h)
        mu=np.array([x[self.hm==m].mean() for m in range(12)])
        residual=x-mu[self.hm]
        scale=np.std(residual,ddof=0)
        for pct in (20,10):
            roundtrip_threshold=mu[self.gm]+scale*np.percentile(residual/scale,pct,method='linear')
            self.assertTrue(np.any(roundtrip_threshold>0)) # A standardization round trip can produce spurious positive thresholds.
            threshold,_,_=wm.seasonal_threshold(h,self.hm,self.gm,pct)
            np.testing.assert_array_equal(threshold,np.zeros(120))
            r=self.ev(h=h,o=np.zeros(120),pct=pct)
            self.assertEqual(r['drought_observed_count'],0)
            self.assertEqual(r['drought_predicted_count'],0)
            self.assertEqual(r['deficit_observed_m3'],0)
            self.assertEqual(r['deficit_predicted_m3'],0)
            self.assertEqual(r['deficit_both_zero'],1)
            self.assertFalse(r['drought_hss_valid'])

    def test_22_real_small_positive_threshold_not_clipped(self):
        # No ad-hoc positive tolerance is introduced by the stability fix.
        h=np.repeat([1e-14,1e-14,1.,2.,4.],12)
        for pct in (20,10):
            threshold,_,_=wm.seasonal_threshold(h,self.hm,self.gm,pct)
            self.assertTrue(np.all(threshold>0))
            self.assertTrue(np.all(threshold<1e-12))
            r=self.ev(h=h,o=np.zeros(120),pct=pct)
            self.assertEqual(r['drought_observed_count'],120)
            self.assertGreater(r['deficit_observed_m3'],0)


