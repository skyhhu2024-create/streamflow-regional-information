# 全球径流重构中的区域观测信息

本仓库对应论文 **Global data availability does not make nearby streamflow gauges dispensable**，提供核心计算、按功能划分的分析流程，以及可运行案例。

研究关注：全球档案中的其他观测，能否替代目标附近的径流记录；降雨和新增参考记录能够补充什么；这些差异对低流量识别、累计水量亏缺和区间总水量有什么影响。

## 目录

| 位置 | 内容 |
|---|---|
| `src/streamflow_info/` | 历史变换、参考站选择、逐月合成、传递模型及评价指标 |
| `workflows/` | 按档案诊断、受控对比、区域依赖、降雨、观测布局、真实缺口验证和水资源评价组织的完整分析 |
| `examples/` | 合成案例、自己的数组输入、Paraná 河注册案例导出器 |
| `scripts/evaluate_water.py` | 对已有预测计算低流量、累计亏缺和区间总水量指标 |
| `tests/` | 数值、目标身份排除和信息隔离检查 |
| `docs/` | 流程、输入格式、论文分析对应表、数据来源和验证说明 |

目录按功能命名；正文分析与程序的对应关系见 [EXPERIMENT_MAP.csv](docs/EXPERIMENT_MAP.csv)，具体流程见 [WORKFLOWS.md](docs/WORKFLOWS.md)。

## 运行一个不需要真实资料的案例

Python 3.10 以上，在仓库根目录运行：

```sh
python -m pip install -e .
python -m unittest discover -s tests -v
python examples/run_synthetic_case.py --output-dir outputs/synthetic_case
```

该例使用合成数据，仅用于理解和检查程序；不是论文中的全球结果。

## 运行注册河流案例

案例为阿根廷 Paraná 河 Posadas 站 `AR_0000001`：历史为1982年2月至1987年1月，缺口为1987年2月至1997年1月。它按注册顺序选取，不是按预测效果选取。

先复制 `examples/case_inputs.example.json`，按 [案例说明](examples/README.md) 填写自己持有的七个输入文件路径：

```sh
python examples/export_registered_case.py --inputs my_case_inputs.json --output outputs/posadas_inputs.npz
python examples/run_array_case.py outputs/posadas_inputs.npz outputs/posadas_predictions.npz
```

导出器默认不输出缺口真值，并排除参考输入中目标物理站及其别名的缺口观测。真实观测不随本仓库分发；本地导出文件应遵守原数据来源的使用条件。

## 读结果时需要区分

- 候选池是全球的；800 km 是撤除附近参考记录的压力试验条件。
- 自然缺口的可用性统计包含全部合格同期站；传递试验最多每月四站；固定八站的单侧对照是另一套试验。
- 主判据 `nse_success` 是 NSE≥0.5、超过目标季节气候态，且确实有拟合及参考支持。`r07_pass` 是另一个时序相关性诊断，不能混用。
- 参考可用、实际有拟合支撑和重构达标是不同统计量。
- 水量评价覆盖整个缺口区间，不应改称年度水量误差。

完整全球复现需要研究注册的输入矩阵、物理站身份、时段与样本、降雨预处理和空间重抽样文件，详见 [复现说明](docs/REPRODUCTION.md)。本仓库提供代码、格式和案例，不附带受限观测、完整生产缓存或稿件。
