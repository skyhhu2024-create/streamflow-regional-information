# Regional information in global streamflow reconstruction

Calculation and reproduction code for **Global data availability does not make nearby streamflow gauges dispensable**.

The study asks whether a global streamflow archive can compensate for the loss of regional observations. It distinguishes reference availability from successful reconstruction, tests precipitation and additional gauge records, and evaluates low-flow timing, cumulative deficits and interval water volume.

## Quick start

Python 3.10 or later is required. From the repository root:

```sh
python -m venv .venv
# Windows: .venv\Scripts\Activate.ps1
# Linux/macOS: source .venv/bin/activate
python -m pip install -e .
python -m unittest discover -s tests -v
python examples/run_synthetic_case.py --output-dir outputs/synthetic_case
```

This deterministic example runs the reconstruction core on synthetic arrays. It needs no credentials or downloads; its results are examples, not empirical findings from the paper.

## Find code by function

| Directory | Purpose |
|---|---|
| `src/streamflow_info/` | Reusable transformations, reference selection, composites, transfer processors and evaluation metrics |
| `workflows/` | Complete analysis scripts, organized by scientific function; see the [workflow guide](docs/WORKFLOWS.md) |
| `examples/` | Synthetic demonstration, observational-array interface and registered river-case exporter |
| `scripts/evaluate_water.py` | Low-flow, cumulative-deficit and interval-volume evaluation of supplied predictions |
| `tests/` | Numerical, identity-exclusion and input-isolation tests |
| `docs/` | Input contracts, protocols, experiment mapping and data access |

The workflow groups cover archive diagnosis, matched benchmarks, regional reference dependence, precipitation, observation locations, genuine-gap validation and water-resource evaluation. These are functional groups rather than manuscript subsection numbers.

## Run a registered river case

The supplied case description identifies the **Paraná at Posadas, Argentina** (`AR_0000001`): 60 visible months (February 1982–January 1987), followed by 120 evaluation months (February 1987–January 1997). It is the first registered case, selected by registration order rather than performance.

Copy `examples/case_inputs.example.json` to a local configuration and fill in the seven input paths described in [examples/README.md](examples/README.md). Then run:

```sh
python examples/export_registered_case.py --inputs my_case_inputs.json --station-id AR_0000001 --output outputs/posadas_inputs.npz
python examples/run_array_case.py outputs/posadas_inputs.npz outputs/posadas_predictions.npz
```

The exporter removes target aliases from gap-period reference inputs and omits target gap truth by default. The array predictor never receives target gap truth. Provider observations are not bundled in this repository.

For your own compatible arrays:

```sh
python examples/run_array_case.py my_case.npz outputs/my_case_predictions.npz
python scripts/evaluate_water.py --input cases.csv --output outputs/water
```

## Scientific conventions

- The global candidate pool is not restricted to 800 km. The 0/100/300/800 km experiments remove nearby reference reports; zero means no withdrawal.
- The natural-gap availability census considers **all qualified reporting references**. Reconstruction combines up to four reporting references per month. The fixed-eight one-sided benchmark is a separate controlled design.
- Primary success, named `nse_success`, requires **NSE ≥ 0.5 and NSE above the target-history seasonal baseline**, plus actual fitted/reference support. The supplementary `r07_pass` diagnostic uses r > 0.7. Availability and success have different denominators.
- History-only transformations, reference qualification, physical-identity exclusion and fixed evaluation cohorts are retained. Precipitation climatology is evaluated using the same fitted QP processor.
- Water-volume error concerns the complete evaluation interval. It is not annual-volume error.

## Reproduction and data

Start with [REPRODUCTION.md](docs/REPRODUCTION.md) and [EXPERIMENT_MAP.csv](docs/EXPERIMENT_MAP.csv). Exact global reproduction requires the registered monthly matrices, station identities, cohort/windows, prepared precipitation and spatial resampling records. The public package supplies code and input contracts, not licensed observations or the complete prepared-data snapshot.

Data sources are [GSIM monthly indices](https://doi.org/10.1594/PANGAEA.887470), [GSIM metadata](https://doi.org/10.1594/PANGAEA.887477), [GRDC](https://portal.grdc.bafg.de/), [ERA5-Land monthly means](https://cds.climate.copernicus.eu/datasets/reanalysis-era5-land-monthly-means) and [Caravan](https://github.com/kratzert/Caravan). See [DATA_ACCESS.md](docs/DATA_ACCESS.md) for roles, preparation and provider terms.

The [water-metric guide](docs/WATER_METRICS.md) specifies formulas, invalid cases and paired spatial summaries. Release checks are documented in [VERIFICATION.md](docs/VERIFICATION.md); case-level and synthetic checks are distinct from a full global rerun.

No open-source licence or software DOI has yet been assigned. Dataset terms remain those of their providers. See [中文说明](README_zh.md) for Chinese navigation.
