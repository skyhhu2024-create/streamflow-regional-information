# Runnable case examples

From the repository root after `python -m pip install -e .`:

```sh
python examples/run_synthetic_case.py --output-dir outputs/synthetic_case
python -m unittest discover -s tests -v
```

The example is **SYNTHETIC**, generated deterministically with seed 20261030.
It contains one target, 18 source rows (including two forbidden target aliases),
60 historical months, 120 future gap months and 183 precipitation months.
The history starts in August to exercise calendar indexing. It deliberately
contains missing source reports and distant-source decorrelation after history.
None of these values or performance numbers are manuscript results.

Outputs are a provenance JSON, compressed synthetic inputs and predictions,
and 24 scored arms (4 distance masks × 2 processors × 3 information arms).
The scorer is separate from reconstruction. The predictor never receives target
gap truth. A seasonal fallback is retained when actual predictors cannot be used;
its numerical output does not automatically count as supported reconstruction.

## Your own arrays

```sh
python examples/run_array_case.py my_case.npz outputs/my_case_predictions.npz
```

The NPZ must use numeric arrays (no pickled objects):

| Key | Shape / type | Meaning |
| --- | --- | --- |
| `target_history` | `(H,)` float | Target observed monthly streamflow before the gap. |
| `source_flows` | `(S,H+G)` float | Candidate source monthly streamflow, aligned to the same H then G. Finite nonnegative values are reports; NaN or negative values are unavailable. |
| `source_ids` | `(S,)` integer | Stable, unique nonnegative IDs below 2³¹; used for identity exclusion and rank tie breaks. |
| `source_distances_km` | `(S,)` float | Great-circle distances from the target, in kilometres; use `reconstruction.distances` for latitude/longitude inputs. |
| `target_physical_ids` | `(A,)` integer | All IDs belonging to the target's physical site, including known aliases. At least the target ID is mandatory, even if absent from the source matrix. |
| `history_start_month` | scalar integer | Calendar index, with 0 = January. Absolute year is immaterial; indices may exceed 11. |
| `precipitation` | optional `(3+H+G,)` float | Target precipitation in the source experiment's consistently defined units (mm/month); three antecedent months plus H and G. Missing/incompatible data cause QP to fall back to Q. |
| `excluded_source_ids` | optional 1-D integer | Sources removed by an upstream safety/identity audit before qualification. |

All discharge series must use the same physical unit (the study uses m³/s).
Because of `log1p`, arbitrary rescaling is not an invariant transformation.
The registered experiment used H=60 and G=120; other lengths accepted by the API
are software inputs, not newly validated scientific settings.

The wrapper does not resolve station identity, perform metadata QC, download
GSIM/GRDC/ERA5, extract basin precipitation, or choose a globally representative
validation cohort. Those upstream choices must be reproduced separately from
the registered protocol. In particular, passing aliases as distinct targets would
invalidate a leakage-free comparison.

## Prediction arrays

`predictions`, `model_z`, `support` have shape `(4,2,3,G)`, in this order:

- Distances: 0 (all candidate distances), 100, 300, 800 km. Nonzero masks remove
  sources at or inside the cutoff; these are diagnostic withdrawals.
- Processors: fixed ridge, fixed RBF kernel ridge.
- Arms: Q, QP, QP_Gclim. The last uses the **same fitted QP model** with only
  G-dated precipitation replaced by H calendar means; H-dated boundary lags stay actual.

`selected_ids`, `selected_distance`, `selected_r` have shape `(4,H+G,4)`;
`counts` and `composites` are `(4,H+G)`. The nearest-reporter diagnostic considers
all H-qualified reporters, not just the selected four. NaN means no reporter.
`flags` are `(4,2,3,7)` and their order is stored in `flag_names`.
`seasonal_baseline` is the target's raw-flow H calendar mean for each G month.
`reasons` records estimation/fallback reasons as JSON strings.

Qualification and ranking use H alone: at least 12 valid common H anomalies,
positive H correlation, finite seasonal scale, correlation-plus-distance ranks,
and up to four reporting sources per month weighted by H correlation.
Withdrawing sources does not rerank survivors, but their H composite is rebuilt
and the processor refitted. There is no target-truth selection or P-only model.

The manuscript's main success metric is NSE ≥ 0.5 and better than the
target-history seasonal NSE, with an actual fit, at least one supported gap
month, valid nonconstant truth and complete nonnegative predictions. The output field is `nse_success`. `r07_pass` is the supplementary temporal-correlation criterion r > 0.7 with the same operational eligibility requirements. All G months are evaluated, including fallback months. Failed/undefined cases stay in fixed cohort denominators as failures.

## Registered observational case (local licensed data required)

`registered_case_AR_0000001.json` identifies the first frozen case: Paraná at
Posadas, Argentina (H February 1982–January 1987; G February 1987–January 1997).
It was selected by registration order, not by reconstruction performance. It
uses 24,714 safety-screened global source candidates, with physical target
aliases excluded. Observational arrays are not bundled with the repository.

With the registered study inputs available locally, copy `case_inputs.example.json` and edit its seven paths:

```sh
python examples/export_registered_case.py --inputs my_case_inputs.json --station-id AR_0000001 --output outputs/local_case.npz
python examples/run_array_case.py outputs/local_case.npz outputs/local_case_predictions.npz
```

The exporter reads the registered cohort, QC20 GSIM matrix, source identity and
safety exclusions, and frozen H-only precipitation features. By default it
does **not** export target G truth and actively removes G values of target
aliases from the source matrix. `--include-truth` is available for separate
local scoring; the prediction command ignores that field. Do not upload the
exported observations without complying with their source terms.

The prepared-precipitation keys `p_h`, `p_g`, `p_g_climatology`,
`p_calendar_logmean`, `p_available`, `p_reason` preserve the original float values.
They replace the raw `precipitation` key. This path avoids inverting log features
only to transform them again. It is intended for audited, previously prepared
inputs; the standard raw-P entry point computes its own H-only controls.

## Case input configuration

Paths can be absolute or relative to the JSON configuration file. No particular research directory layout is required.

| Key | File / required fields |
|---|---|
| `cases` | CSV containing `station_id`, `row`, `raw_index`, H/G start/end indices, `latitude`, `longitude`. |
| `streamflow` | QC20 NumPy discharge matrix, catalogue rows × monthly columns. |
| `source_ids` | NumPy integer array of admitted source catalogue rows. |
| `source_exclusions` | CSV containing the additional excluded `raw_index` values. |
| `station_metadata` | Catalogue-ordered CSV with `raw_index`, `latitude`, `longitude`. |
| `physical_identity` | CSV with `raw_index` and `physical_group_raw_index`; must include the target. |
| `precipitation_features` | NPZ with the six prepared-precipitation keys above, indexed by registered case row. |

This explicit configuration changes file location only. Scientific filtering, H/G indexing, reference identities and prepared float values remain unchanged. The exporter validates required files before reading data. See [verification](../docs/VERIFICATION.md) for the scope of the case replay and numerical checks.
