"""Run a deterministic SYNTHETIC case; no observational data are used."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from streamflow_info.case import run_forward_case
from streamflow_info.metrics import metrics
from streamflow_info.reconstruction import DLEVELS, METHODS, ARMS


def make_case(seed=20261030):
    """Generate one target, 18 candidates, H=60, G=120, with target aliases."""
    rng = np.random.default_rng(seed)
    h, g, n = 60, 120, 18
    start = 7  # August: the interface does not require January windows.
    months = start+np.arange(h+g)
    season = 0.35*np.sin(2*np.pi*months/12)
    precipitation = rng.gamma(2.0, 25.0, 3+h+g)
    event = (np.log1p(precipitation[3:])-3.5)*0.23
    regional = rng.normal(0, 0.20, h+g)
    local = rng.normal(0, 0.09, h+g)
    target = np.expm1(2.8+season+regional+event+local)
    sources = np.empty((n, h+g))
    sources[0] = target  # Forbidden physical target, including hidden G.
    sources[1] = target*1.001  # Another ID for that physical target.
    for j in range(2, n):
        shared = regional.copy()
        if j >= 12:
            # Synthetic distant-reference temporal decorrelation after H.
            shared[h:] = rng.normal(0, 0.20, g)
        sources[j] = np.expm1(2.5+0.03*j+season+shared+0.3*event
                               +rng.normal(0, 0.08+0.006*j, h+g))
    sources[2:6, h+15:h+22] = np.nan  # Month-specific reporting subsets.
    return dict(target_history=target[:h], source_flows=sources,
                source_ids=np.arange(n, dtype=np.int32),
                source_distances_km=np.array([0, 0, 20, 40, 70, 100, 150, 250,
                    300, 450, 650, 800, 950, 1200, 1600, 2000, 3000, 5000.]),
                target_physical_ids=np.array([0, 1], dtype=np.int32),
                history_start_month=np.asarray(start), precipitation=precipitation,
                target_gap_truth=target[h:], provenance=np.asarray('SYNTHETIC'))


def run(data, out):
    out.mkdir(parents=True, exist_ok=True)
    # Truth is removed before reconstruction and used only by the scorer.
    inputs = {k: data[k] for k in ('target_history', 'source_flows', 'source_ids',
        'source_distances_km', 'target_physical_ids', 'precipitation')}
    inputs['history_start_month'] = int(data['history_start_month'])
    result = run_forward_case(**inputs)
    np.savez_compressed(out/'synthetic_inputs.npz', **data)
    np.savez_compressed(out/'synthetic_predictions.npz', **result)
    rows = []
    for di, distance in enumerate(DLEVELS):
        for mi, method in enumerate(METHODS):
            for ai, arm in enumerate(ARMS):
                score = metrics(data['target_gap_truth'][None],
                    result['predictions'][di, mi, ai][None],
                    result['seasonal_baseline'][None],
                    result['flags'][di, mi, ai, 0:1],
                    result['support'][di, mi, ai][None])
                row = dict(provenance='SYNTHETIC', distance_km=distance,
                           method=method, arm=arm)
                row.update({k: score[k][0].item() for k in
                    ('r', 'alpha', 'delta', 'NSE', 'seasonal_NSE', 'r07_pass',
                     'nse_success', 'support_months')})
                rows.append(row)
    with (out/'synthetic_scores.csv').open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    record = dict(provenance='SYNTHETIC', seed=20261030,
        purpose='Execution and leakage/control checks only; not a paper result.',
        target_history_months=60, gap_months=120, source_rows=18,
        target_aliases_excluded=[0, 1], distance_levels_km=list(DLEVELS),
        methods=list(METHODS), arms=list(ARMS),
        target_gap_truth_used_for_prediction=False,
        prediction_shape=list(result['predictions'].shape),
        primary_success='NSE >= 0.5 and NSE > seasonal baseline, actual fit and source support',
        supplementary_success='r > 0.7 with actual fit and at least one supported G month')
    (out/'SYNTHETIC_CASE.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=Path('outputs/synthetic_case'))
    args = parser.parse_args()
    run(make_case(), args.output_dir)
