"""Fixed H-only ridge/RBF processors and lagged precipitation controls.

These processors do not receive target gap observations or tune against them.
"""
from dataclasses import dataclass
from typing import Sequence
import numpy as np

LAMBDA = 0.1
MIN_TRAINING_ROWS = 12
SCALE_FLOOR = 1e-12
METHODS = ('ridge', 'rbf_ridge')

@dataclass
class RainInputs:
    """H/G predictors; climatology is estimated from H and substituted in G."""
    h: np.ndarray
    g: np.ndarray
    g_climatology: np.ndarray
    calendar_logmean: np.ndarray
    available: bool
    reason: str
    first_precip_month_index: int


@dataclass
class FittedTransfer:
    method: str
    feature_mean: np.ndarray
    feature_scale: np.ndarray
    target_mean: float
    coefficients: np.ndarray
    standardized_training_x: np.ndarray
    n_training: int

    def predict(self, x: np.ndarray) -> np.ndarray:
        """Predict finite feature rows; no evaluation outcome is accepted."""
        x = _matrix(x, 'prediction predictors')
        p = len(self.feature_mean)
        if x.shape[1] != p:
            raise ValueError('Prediction feature count differs from the H fit.')
        out = np.full(len(x), np.nan)
        ok = np.isfinite(x).all(1)
        if not ok.any():
            return out
        with np.errstate(over='ignore', invalid='ignore', divide='ignore'):
            standardized = (x[ok]-self.feature_mean)/self.feature_scale
            if self.method == 'ridge':
                values = standardized@self.coefficients+self.target_mean
            else:
                train = self.standardized_training_x
                distance = np.maximum(np.sum(standardized*standardized, 1)[:, None]
                    + np.sum(train*train, 1)[None, :]-2*standardized@train.T, 0)
                values = np.exp(-distance/p)@self.coefficients+self.target_mean
        values[~np.isfinite(values)] = np.nan
        out[ok] = values
        return out


def _vector(value: np.ndarray, name: str) -> np.ndarray:
    x = np.asarray(value, dtype=np.float64)
    if x.ndim != 1:
        raise ValueError(f'{name} must be a one-dimensional array.')
    return x


def _matrix(value: np.ndarray, name: str) -> np.ndarray:
    x = np.asarray(value, dtype=np.float64)
    if x.ndim != 2:
        raise ValueError(f'{name} must be a two-dimensional array.')
    return x


def _methods(values: Sequence[str]) -> tuple[str, ...]:
    values = tuple(values)
    if not values or len(set(values)) != len(values) or any(m not in METHODS for m in values):
        raise ValueError(f'Only the prespecified methods {METHODS} are supported.')
    return values


def prepare_precipitation_lags(raw_precipitation: np.ndarray, *, history_start_month: int,
                               h_length: int = 60, g_length: int = 120) -> RainInputs:
    """Prepare log1p P lag0..3, using three antecedent months plus H and G.

    Month index zero is January; its absolute year is immaterial. H and G must
    be the contiguous forward-extension windows represented by these lengths.
    Only underlying G months are replaced in the climate control. Antecedent
    lag values dated in H remain observed, including the first three G rows.
    A failed input check records unavailable; it never fabricates actual P.
    """
    raw = _vector(raw_precipitation, 'raw_precipitation')
    if h_length < 1 or g_length < 1 or len(raw) != 3+h_length+g_length:
        raise ValueError('Raw precipitation length must be 3 + H length + G length.')
    finite_nonnegative = np.isfinite(raw) & (raw >= 0)
    logp = np.full(raw.shape, np.nan)
    logp[finite_nonnegative] = np.log1p(raw[finite_nonnegative])
    hmonths = history_start_month+np.arange(h_length)
    calendar = np.full(12, np.nan)
    for month in range(12):
        values = logp[3:3+h_length][hmonths % 12 == month]
        if len(values) and np.isfinite(values).all():
            calendar[month] = values.mean()
    controlled = logp.copy()
    gmonths = history_start_month+h_length+np.arange(g_length)
    controlled[3+h_length:] = calendar[gmonths % 12]
    length = h_length+g_length
    actual_lags = np.stack([logp[3-lag:3-lag+length] for lag in range(4)], axis=1)
    controlled_lags = np.stack([controlled[3-lag:3-lag+length] for lag in range(4)], axis=1)
    available = bool(finite_nonnegative.all() and np.isfinite(calendar).all())
    reason = 'available' if available else ('precipitation_missing_or_invalid'
        if not finite_nonnegative.all() else 'H_calendar_background_unavailable')
    return RainInputs(actual_lags[:h_length], actual_lags[h_length:],
        controlled_lags[h_length:], calendar, available, reason, history_start_month-3)


def fit_transfer(x_h: np.ndarray, y_h: np.ndarray, *, method: str,
                 target_estimable: bool = True) -> tuple[FittedTransfer | None, str]:
    """Fit the same fixed H-only processors as the preceding rainfall trial.

    Caller supplies already-selected common H rows. Nonfinite rows are an
    invalid fit, rather than silently selecting different rows by model/arm.
    """
    _methods((method,))
    x, y = _matrix(x_h, 'H predictors'), _vector(y_h, 'H response')
    if len(x) != len(y) or x.shape[1] < 1:
        raise ValueError('H predictor/response dimensions are inconsistent.')
    if not target_estimable:
        return None, 'target_H_transform_unestimable'
    if len(y) < MIN_TRAINING_ROWS:
        return None, 'fewer_than_12_common_H_rows'
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        return None, 'nonfinite_common_H_input'
    with np.errstate(over='ignore', invalid='ignore', divide='ignore'):
        mean = x.mean(0)
        scale = x.std(0)
        scale = np.where(scale > SCALE_FLOOR, scale, 1.0)
        standardized = (x-mean)/scale
        ymean = float(y.mean())
        yc = y-ymean
        n, p = x.shape
        try:
            if method == 'ridge':
                coefficients = np.linalg.solve(standardized.T@standardized+n*LAMBDA*np.eye(p),
                                               standardized.T@yc)
            else:
                distance = np.maximum(np.sum(standardized*standardized, 1)[:, None]
                    + np.sum(standardized*standardized, 1)[None, :]
                    - 2*standardized@standardized.T, 0)
                coefficients = np.linalg.solve(np.exp(-distance/p)+n*LAMBDA*np.eye(n), yc)
        except np.linalg.LinAlgError:
            return None, 'numerical_linear_solve_failure'
    if not (np.isfinite(mean).all() and np.isfinite(scale).all()
            and np.isfinite(standardized).all() and np.isfinite(coefficients).all()
            and np.isfinite(ymean)):
        return None, 'nonfinite_fitted_parameters'
    return FittedTransfer(method, mean.copy(), scale.copy(), ymean, coefficients.copy(),
                          standardized.copy(), n), 'estimated'
