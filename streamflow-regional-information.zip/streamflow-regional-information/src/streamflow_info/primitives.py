"""Historical seasonal transforms, reference selection, and inverse transfer.

Numerical primitives shared by reference qualification and reconstruction.
See docs/REPRODUCTION.md. All qualification uses supplied historical arrays.
"""
import numpy as np
from scipy.stats import rankdata

def prep(raw,months):
 raw=np.asarray(raw,float);valid=np.isfinite(raw)&(raw>=0);x=np.full_like(raw,np.nan);x[valid]=np.log1p(raw[valid])
 cl=np.stack([np.nanmean(x[:,months%12==m],axis=1) for m in range(12)],axis=1)
 a=x-cl[:,months%12];sd=np.nanstd(a,axis=1);sd[sd<=1e-12]=np.nan
 z=a/sd[:,None]
 return cl,sd,z


def relation(x,y):
 ok=np.isfinite(x)&np.isfinite(y)[None,:];n=ok.sum(1);xx=np.where(ok,x,0);yy=np.where(ok,y[None,:],0);nn=np.maximum(n,1)
 sx=xx.sum(1);sy=yy.sum(1);vx=(xx*xx).sum(1)-sx*sx/nn;vy=(yy*yy).sum(1)-sy*sy/nn;cv=(xx*yy).sum(1)-sx*sy/nn
 good=(n>=12)&(vx>1e-24)&(vy>1e-24);r=np.full(len(n),np.nan);r[good]=np.clip(cv[good]/np.sqrt(vx[good]*vy[good]),-1,1)
 return n,r


def ordering(raw,q,r,dist):
 rr=rankdata(-r[q],method='average');dd=rankdata(dist[q],method='average')
 return q[np.lexsort((raw[q],rr,rr+dd))]


def combine(f,q,r,cl,sd,months,excluded=None):
 count=np.zeros(len(months),np.int8);num=np.zeros(len(months));den=np.zeros(len(months));ids=np.full((len(months),4),-1,np.int32)
 for j in q:
  if excluded is not None and excluded[j]:continue
  raw=f['Q'][j,months];cc=cl[j,months%12]
  take=np.isfinite(raw)&(raw>=0)&np.isfinite(cc)&(count<4)
  if take.any():
   ii=np.flatnonzero(take);z=(np.log1p(raw[take])-cc[take])/sd[j];w=r[j]
   ids[ii,count[ii]]=f['raw'][j];count[ii]+=1;den[ii]+=w;num[ii]+=w*z
  if (count==4).all():break
 return np.divide(num,den,out=np.full(len(months),np.nan),where=den>0),count,ids


def transfer(comp,tz,cl,sd,gap,base,estimable):
 if not estimable:return base.copy(),np.zeros(len(gap),bool)
 supported=np.isfinite(comp)&np.isfinite(cl[gap%12]);vals=tz[np.isfinite(tz)]
 z=np.where(supported,np.clip(comp,vals.min()-3,vals.max()+3),0.)
 pp=np.maximum(np.expm1(np.minimum(z*sd+cl[gap%12],50)),0);pp[~supported]=base[~supported]
 return pp,supported
