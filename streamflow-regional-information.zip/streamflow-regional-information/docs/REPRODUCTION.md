# Reproduction guide

Use the portable core for a single case and the functional workflows for complete study analyses. Both use the same scientific definitions. Functional grouping does not merge experiments with different target cohorts, calendars or qualification rules.

## Installation and local paths

Run `python -m pip install -e .` from the repository root. The core requires NumPy, SciPy and pandas. Workflow dependencies additionally include scikit-learn; neural benchmarks require PyTorch. Basin precipitation preparation requires netCDF4, pyshp, shapely and pyproj. See the workflow requirements and the recorded [test environment](TESTED_ENVIRONMENT.json).

Supply locally held inputs explicitly. The registered-case exporter uses a JSON file of seven input paths, with relative paths resolved from that configuration file. It does not require a particular research-folder name. Full workflows use the path conventions documented in [WORKFLOWS.md](WORKFLOWS.md). Preserve source identifiers and row order when preparing arrays.

## What the examples reproduce

`examples/run_synthetic_case.py` exercises the reconstruction, information controls and evaluation using invented arrays. `examples/run_array_case.py` uses supplied monthly arrays. `examples/export_registered_case.py` exports one registered H60/G120 case from licensed local inputs while withholding gap truth by default.

These checks establish execution and numerical consistency, not representative global performance. Exact study reproduction also requires the input snapshot and registrations below. The entire global analysis has not been rerun merely to reorganize the code.

## Required scientific inputs

| Input | Required representation |
|---|---|
| Native GSIM observations | Monthly `.mon` series with `MEAN`, `n.available`, source IDs, catalogue metadata and the raw-file manifest. Retain January 1980–December 2015 for the main audit. |
| Global matrices | Raw and QC20 discharge arrays with 30,959 catalogue rows and 432 monthly columns; station IDs and metadata in identical row order. QC20 requires at least 20 observed days in a month. Missing values remain NaN. |
| Station roles and cases | Target/source admission, registered H/G index bounds, spatial-fold membership, source IDs and source safety exclusions. Do not reuse frozen arrays with reordered rows. |
| Physical station identities | Reviewed components linking catalogue aliases to physical sites. Every alias of the target is excluded from reference inputs. |
| Prepared target history | H-only log calendar means, anomaly scales, standardized history, raw seasonal baseline and admission metadata. |
| Precipitation | Registered full-basin monthly mm/month, current and three antecedent months, geometry/weights, exact dates, coverage and admission ledger. H-only prepared features preserve the same Q-only fallback when precipitation is rejected. |
| Archive support audit | Standardized series, fixed station lists, reference edges and registered real/artificial gap-event tables. This local-rule census differs from the global source-pool audit. |
| Controlled benchmarks | Deduplicated QC20 monthly data, daily Caravan data, dates/IDs, original split and gap masks, and target-only/classical predictions. Training, validation and evaluation masks retain their separate roles. |
| Genuine-gap validation | Independently registered actual gaps, identity exclusions, frozen predictions and GRDC evaluation truth. Retrieved target truth is accessed only by the evaluator. |
| Paired summaries | Registered case IDs, all arm predictions/flags, precipitation admission, spatial cells and common bootstrap draw files. The paired sample must not change between arms. |

Provider links alone do not recreate the exact input snapshot. Record data versions, preprocessing decisions and checksums before running; [DATA_ACCESS.md](DATA_ACCESS.md) identifies the sources.

## Calculation order

1. Prepare streamflow matrices, physical identities and frozen station/case roles.
2. Diagnose missingness and reference availability; apply real/artificial gap conditions separately.
3. Run matched information and processor benchmarks with their isolation masks.
4. Audit natural-gap global availability, then run registered regional-withdrawal comparisons and seasonal information tests.
5. Prepare precipitation independently; compare Q, QP and the same-fit precipitation-climatology control on identical admitted cases.
6. Run the independently registered observation-location and genuine-gap experiments.
7. Score frozen predictions, then compute paired spatial summaries, including all water-resource contrasts.

Detailed entry points are listed by function in [WORKFLOWS.md](WORKFLOWS.md) and by scientific result in [EXPERIMENT_MAP.csv](EXPERIMENT_MAP.csv). Input manifests, registration, identity checks and scoring authorization are part of the calculation. Do not manufacture approval receipts or bypass a failed input audit to run a later step.

## Fixed comparisons and denominators

The withdrawal experiment uses H60/G120 and 8,083 precipitation-admitted cases from an 8,898-case mother cohort. It removes references at 0/100/300/800 km from the global pool and refits the surviving H composite. The natural forward-gap audit uses 19,418 targets and 2,612,522 missing months, counting all qualified reports. The seasonal test uses 5,811 targets and target H36/source H60; the fixed-eight one-sided benchmark has 691 targets. These samples must not be interchanged.

Primary reconstruction success is NSE≥0.5 and greater than target-history seasonal NSE, with actual fitted reference support. Undefined or failed cases remain failures in fixed-cohort success denominators. Continuous metrics have their own validity masks; these are recorded separately from eligibility and precipitation admission.

The water-resource evaluation uses 11 arms, 16 paired contrasts and q20/q10 thresholds. It scores complete G intervals without refitting; see [WATER_METRICS.md](WATER_METRICS.md). The current water panels are Fig. 3f–h and their supporting material is Note 11/Tables S21A–D.

The genuine-gap experiment distinguishes 141 registered cases, 102 fully history-qualified cases and the 101 metric-evaluable cases. The separate archive-retrieval inventory has 596 identity/overlap-checked gauges; it is not the genuine-gap reconstruction cohort.

## Verification scope

Unit tests, synthetic guards, import/path checks and registered-case replay are documented separately in [VERIFICATION.md](VERIFICATION.md). Neural training also depends on device and library state; it should not be claimed as bit-for-bit reproduced without an appropriate rerun. No provider observations, production arrays, manuscript files, credentials or installed third-party libraries are distributed.
