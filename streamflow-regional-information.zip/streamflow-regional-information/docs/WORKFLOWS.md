# Functional workflow guide

Run from an installed checkout. The exact entry points, scientific input contracts and cohorts are indexed in [EXPERIMENT_MAP.csv](EXPERIMENT_MAP.csv). Source paths here identify functional modules; file locations do not determine manuscript numbering.

Workflow runs require their prepared data and registered manifests. A missing registration or failed input audit must be resolved before scoring; do not substitute invented approval receipts. The portable examples provide the data-free starting point.

## Archive diagnosis

Missing-record structure, real/artificial gap comparison, all-qualified support and qualification sensitivities.

Location: `workflows/archive_diagnosis/`.

| Analysis | Entry point | Evidence |
|---|---|---|
| archive | [`analyze_support_task_composition.py`](../workflows/archive_diagnosis/support/analysis/analyze_support_task_composition.py) | Results 1; Fig1; S11-S14; FigS3 |
| mask comparability | [`recompute_all_qualified.py`](../workflows/archive_diagnosis/support/recompute_all_qualified.py) | Results 1; S10; FigS2 |
| history scope | [`run_history_scope.py`](../workflows/archive_diagnosis/history_scope/run_history_scope.py) | Discussion; S12B |
| correlation sensitivity | [`run_threshold_audit.py`](../workflows/archive_diagnosis/correlation_threshold/run_threshold_audit.py) | Results 3; S16D |

## Matched benchmarks

Classical and neural processor comparisons, strict input isolation, reference-count/selection controls and fixed-reference one-sided tests.

Location: `workflows/benchmarks/`.

| Analysis | Entry point | Evidence |
|---|---|---|
| isolated neural | [`run_isolated_inputs.py`](../workflows/benchmarks/input_isolation/run_isolated_inputs.py) | Results 2; Fig2a-b; S2-S4 and S9 |
| SI transformation sensitivity | [`evaluate_strata.py`](../workflows/benchmarks/evaluate_strata.py) | Methods; S5 transformation sensitivity |
| selection grid | [`run_selection_grid.py`](../workflows/benchmarks/reference_selection/run_selection_grid.py) | Results 2; Fig2d; S7-S8A,B; FigS1 |
| one sided | [`run_transfer_K8.py`](../workflows/benchmarks/reference_transfer/run_transfer_K8.py) | Results 2; Fig2c; S15A-B |
| reference count | [`run_reference_count.py`](../workflows/benchmarks/reference_count/run_reference_count.py) | Methods; S8C; FigS4 |
| sync coverage | [`run_sync_coverage.py`](../workflows/benchmarks/synchronous_coverage/run_sync_coverage.py) | Results 2; S15C; FigS5a |

## Regional reference dependence

Registered withdrawal experiments, historical/gap agreement, correlation-only ranking and seasonal-information tests.

Location: `workflows/regional_dependence/`.

| Analysis | Entry point | Evidence |
|---|---|---|
| global matrix | [`build_global_inputs.py`](../workflows/regional_dependence/global_design/data_source/build_global_inputs.py) | Shared input preparation for Results 3-5 |
| natural global | [`run_distance_fast.py`](../workflows/regional_dependence/confirmation/natural/run_distance_fast.py) | Results 3 and 5; Fig3a; Fig4c-d natural population; S16A-B |
| full gradient | [`run_engine.py`](../workflows/regional_dependence/source_distance/src/run_engine.py) | Results 3-5; Fig3b-c and Fig4a-d controlled population; S17A-B and S18A-E |
| seasonal confirmation | [`run_confirmation.py`](../workflows/regional_dependence/confirmation/confirmation/run_confirmation.py) | Results 4; S17E-F; FigS6b-c |
| spatial exclusion | [`run_outage.py`](../workflows/regional_dependence/conditional_support/source_outage/run_outage.py) | Results 3; S17C-D |
| five configurations | [`audit_cached_and_reranked.py`](../workflows/regional_dependence/ranking/audit_cached_and_reranked.py) | Results 3; S17G |
| history gap agreement | [`audit_cached_and_reranked.py`](../workflows/regional_dependence/ranking/audit_cached_and_reranked.py) | Results 3-4; Fig3d-e; S17H |
| correlation only ranking | [`pure_correlation_sensitivity.py`](../workflows/regional_dependence/ranking/pure_correlation_sensitivity.py) | Results 3-4; Fig3b,d; S17I; waterL-Corr800 |

## Precipitation inputs and context

Basin precipitation preparation, fixed transfer processors and reference-abundance associations.

Location: `workflows/rainfall/`.

| Analysis | Entry point | Evidence |
|---|---|---|
| rain reference context | [`build_source_abundance.py`](../workflows/rainfall/observation_density/exposures/build_source_abundance.py) | Results 5; S18F |

## Observation-location experiments

External common-record duration, withheld-site restoration, shared layouts and independently selected single locations.

Location: `workflows/monitoring/`.

| Analysis | Entry point | Evidence |
|---|---|---|
| network gain | [`run_selection.py`](../workflows/monitoring/network_gain_H60/source/run_selection.py) | Results 5; Fig4f shared layout; S20C |
| single site | [`run_experiment.py`](../workflows/monitoring/single_location/run_experiment.py) | Results 5; Fig4f single location; S20D |
| external location duration | [`run_trial.py`](../workflows/monitoring/external_locations/trial_source/run_trial.py) | Results 5; Fig4e; S20A |
| nearest restoration | [`run_trial.py`](../workflows/monitoring/location_selection/source/run_trial.py) | Results 5; Fig4f nearest design; S20B |

## Genuine-gap and observation retrieval validation

Identity checks, actual-gap registration, independent truth evaluation and the separate archive-retrieval inventory.

Location: `workflows/validation/`.

| Analysis | Entry point | Evidence |
|---|---|---|
| SI GRDC real forward | [`run_real_forward.py`](../workflows/validation/natural_gaps/source/run_real_forward.py) | Results 2; FigS5b; Note10; S19A-C |
| current score summaries | [`extract_full_metrics.py`](../workflows/validation/common_metrics/extract_full_metrics.py) | Results 3 and 5; S17B; S18C-D; FigS6a |
| SI location and real gap NSE | [`harmonize_location_and_real_gap_metrics.py`](../workflows/validation/common_metrics/harmonize_location_and_real_gap_metrics.py) | Results 2 and 5; FigS5b; S19 and S20 |
| observation retrieval | [`analyze_observation_retrieval.py`](../workflows/validation/grdc/analyze_observation_retrieval.py) | Discussion; S16C |

## Water-resource consequences

Frozen prediction input preparation, q20/q10 scoring, interval water volume and all registered paired summaries.

Location: `workflows/water_resources/`.

| Analysis | Entry point | Evidence |
|---|---|---|
| water registered inputs | [`build_inputs.py`](../workflows/water_resources/data/build_inputs.py) | Results 4-5; Fig3f-h; S21A-D |

## Shared implementations

Streamflow reading, features, geodesic distance, training models, metric functions and common validation utilities.

Location: `workflows/shared/`.

Shared modules are dependencies rather than standalone experiments. The reusable single-case public API is `streamflow_info`, in `src/streamflow_info/`.

## Execution rules

- Preserve station/physical identities, source safety exclusions and registered date bounds before reconstruction.
- Target gap truth belongs to evaluation only; it must not enter reference qualification or transfer fitting.
- Run paired arms on identical registered target sets and retain explicit validity masks.
- Exported source observations and production arrays stay local and are not part of this package.
- Input and output directories are functional counterparts of each workflow. Use explicit external-data configuration; never point a new run at a sole copy of valuable observations.

See [REPRODUCTION.md](REPRODUCTION.md) for calculation order and [WATER_METRICS.md](WATER_METRICS.md) for the standalone water evaluator.
