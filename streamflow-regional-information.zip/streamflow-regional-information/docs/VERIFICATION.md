# Verification

The distributed package was checked at three levels: source dependencies, numerical behavior and a registered observational case.

| Check | Result |
|---|---|
| Portable unit and case-export tests | 37 passed |
| Core computational definitions | 37 functions/classes matched after excluding documentation, import locations and the explicit success-field rename |
| Benchmark numerical definitions | 16 retained functions/classes matched |
| Synthetic original-versus-organized workflow comparisons | 1,860 array/scalar comparisons were exactly equal across 12 input conditions, four withdrawal distances, two processors and three input arms |
| Registered Paraná / Posadas inputs | 15 arrays exactly equal |
| Registered Paraná / Posadas outputs | 25 arrays exactly equal, including 2,880 predictions |
| Source-identity and input-isolation controls | Passed synthetic checks |
| Training orchestration | Monthly/daily rewritten entry points compiled; continuation, early stopping and checkpoint behavior passed controlled lightweight checks |
| GSIM catalogue path configuration | Eight default/environment-override checks passed |

The numerical comparisons covered missing reference reports, unavailable precipitation, incomplete calibration inputs and no-fit fallbacks. Physical aliases of the target were excluded from gap-period source access. The success field is `nse_success`: NSE ≥ 0.5, above the target-history seasonal baseline, and actual fitted/reference support.

These checks verify the distributed implementation and the registered case. They do not constitute new global model training or a new global analysis. Full study reproduction requires the input snapshots, identities and registration records described in `REPRODUCTION.md`.

Run the portable checks with:

```sh
python -m unittest discover -s tests -v
python examples/run_synthetic_case.py --output-dir outputs/synthetic_case
python -m workflows.regional_dependence.source_distance.src.test_engine_synthetic
```

The package manifest records current source hashes. Provider observation arrays and local migration evidence are not distributed.
