# Manuscript analysis mapping

Code for **Global data availability does not make nearby streamflow gauges dispensable**. Function-based entry points are listed in [EXPERIMENT_MAP.csv](EXPERIMENT_MAP.csv). The manuscript has five Results subsections and four main figures.

| Current Results subsection | Principal evidence |
| --- | --- |
| 1. Most gaps extend beyond the record | Fig. 1; S10–S14; Figs S2–S3 |
| 2. Skill comes from synchronous nearby observations | Fig. 2; S3–S9; S15; S19; Figs S1, S4, S5 |
| 3. Available references do not substitute for nearby ones | Fig. 3a–d; S16A,B,D; S17A–D,G–I |
| 4. Distant references add error, not information | Fig. 3e–h; S17H; S17E,F and Fig. S6; S21A–D |
| 5. Rainfall and new gauges recover little | Fig. 4a–f; Fig. 3f–h; S18A–F; S20A–D; S21A–D |

## Current panel and table references

Fig. 2c is the synchronous-input versus history-length comparison; Fig. 2d is the reference-selection comparison. Fig. 3c contains the withdrawal transitions, Fig. 3d the reference history/gap correlations, and Fig. 3e reconstruction NSE against the target-history seasonal baseline. **Water-resource panels are Fig. 3f–h**: low-flow HSS, deficit within ±25%, and absolute relative ten-year volume error. Fig. 4d compares natural-gap distant dependence with controlled rainfall gains using two distinct populations. Fig. 4e is external-location duration; Fig. 4f compares three separately registered location designs.

Fig. 3e summarizes the prediction and baseline scores in S17H. Its finite-NSE cohort has 8,073 targets. It must not be replaced with the 8,068 supported-transfer cohort or with a correlation statistic.

| Current SI evidence | Meaning |
| --- | --- |
| S8A / S8B / S8C | Signed selection/combination contrasts; direct selector comparisons; same-rule reference-count sensitivity |
| S16A / S16B | Natural global support and regional reliance on distant reports |
| S16C | Observation-existence audit at 596 matched gauges |
| S16D | Natural-support correlation-threshold sensitivity |
| S17G | Five transfer/candidate-pool configurations on 8,898 registrations |
| S17H | Reference history/gap agreement and reconstruction agreement/NSE against seasonality |
| S17I | Ranking solely by historical anomaly correlation |
| S18F | Remaining-reference conditions and retrospective rainfall-gain associations |
| S19A–C | Genuine-gap accounting, predictions and geography |
| S20A / S20B / S20C / S20D | External-location duration; nearest restoration; shared layouts; single-location selection/use |
| S21A / S21B / S21C / S21D | Eleven conditions and validity; low-flow/deficit; interval volume; sixteen paired contrasts |

## Reference pools and denominators

The initial archive audit uses 24,934 gauges, including 22,934 incomplete gauges and 4,598,259 missing station-months. Its regional shortlist contains at most 200 gauges within 800 km; the monthly qualification rule requires 24 common observations and anomaly correlation at least 0.2. All-qualified support accounting is distinct from the fixed-eight inputs used in controlled comparisons.

The natural forward-gap audit covers 19,418 targets and 2,612,522 missing months. It searches the global candidate domain **without a maximum distance and counts all qualifying reporting references without a four-reference cap**. Qualification uses up to 60 preceding calendar months, at least 12 common anomalies and positive correlation. Raw reporting availability and transformable support remain separate. This audit has no hidden truth and does not measure reconstruction accuracy. Its changed history, correlation and candidate rules mean that comparison with the initial regional audit does not isolate search distance alone.

Global reconstruction uses at most four reporting references per month, with positive-correlation weights. The main ranking combines past-agreement and distance ranks. The correlation-only sensitivity changes ranking alone. Withdrawal distances of 0, 100, 300 and 800 km remove references from the global pool; zero means no additional withdrawal. The eligible pool contains 24,714 candidates before per-target physical-identity exclusions. The primary 8,083 rainfall-admitted targets are a fixed subset of 8,898 registrations, with H = 60 and G = 120 months.

| Quantity | Denominator |
| --- | --- |
| Primary success and failure accounting | All 8,083 registrations, including unsupported or unevaluable cases |
| Complete-gap fitted reference input | 8,074 targets |
| Eligible supported reconstructions / reference history-gap correlation pairs | 8,068 targets |
| Finite raw prediction correlations | 8,069 targets |
| Finite deseasonalized prediction correlations | 8,068 targets |
| Finite reconstruction NSE and relative total-volume error | 8,073 targets |
| Water HSS, q20 / q10 | 8,059 / 7,995 targets |
| Water deficit ratios, q20 / q10 | 8,060 / 7,996 targets |

Success requires NSE ≥ 0.5, improvement over the target-history seasonal baseline, an actual fitted transfer and reference contribution. The output key is `nse_success`. Finite seasonal fallback values may enter continuous and water metrics where those metrics are defined; they do not thereby become successful supported reconstructions. Pearson r > 0.7 is a separate supplementary diagnostic.

Reference–target composite correlations use history-derived standardized log-flow anomalies. Reconstruction deseasonalization instead subtracts the history-derived raw-flow seasonal baseline from both prediction and truth. These are different quantities. Paired changes summarize within-target differences, not differences of separately summarized medians.

The seasonal-history experiment is separate: 5,811 targets, H36 target history, H60 reference history and G120, with the target spatial fold excluded and 12 omission rotations averaged per target. It compares transfer formulations with differing representation, regularization and bounds; it is not an isolated seasonal-component intervention or a test of distant-reference substitution.

Genuine-gap validation retains 141 registrations, 102 history-estimable targets and 101 score pairs. Retrieved truth is partial; it is not a full 120-month replication. The 596-gauge record-existence audit in S16C is a different population. Location additions likewise retain four separate target populations: 80 South African targets with external-location duration, 8,898 nearest restorations, 5,905 shared-layout targets and 5,229 single-location targets. Their budgets, calendars and selection rules differ.

## Water-resource reporting

Note 11 and S21A–D include all eleven conditions, sixteen paired contrasts, q20/q10 thresholds and both fixed processors. Their reporting fields are specified in [WATER_MANUSCRIPT_PROFILE.json](WATER_MANUSCRIPT_PROFILE.json). Volume error is calendar-day-weighted across all 120 months. Uncertainty uses 2,000 shared draws over 274 occupied 5° cells, equal target weights and metric-specific valid intersections.
