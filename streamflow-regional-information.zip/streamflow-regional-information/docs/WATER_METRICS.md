# Water-resource diagnostics for frozen monthly reconstructions

`src/streamflow_info/water_metrics.py` is the study's corrected metric implementation, copied byte for byte. `scripts/evaluate_water.py` is a portable batch interface for predictions supplied by a user. It does not fit a reconstruction model, retrieve observations, select references, or infer missing predictions. It evaluates a fixed **60-month target history followed immediately by a 120-month evaluation gap**. This is the water-resource experiment's contract, not a general claim about other history or gap lengths.

The source and tests contain no empirical discharge records. The tests generate synthetic data. Running this interface on another cohort does not reproduce the manuscript's global percentages; reproducing those requires its registered cohort, observation arrays, frozen predictions, metadata and spatial bootstrap draws.

## Current manuscript scope

The 8 November 2026 main text reports water-resource consequences in **Fig. 3f–h**; Fig. 3e reports NSE. Supporting results are **Supplementary Note 11 and Tables S21A–D**. The fixed study comparison includes 11 arms, 16 paired contrasts, both q20 and q10, the seasonal baseline, correlation-only ranking, rainfall climatology and the fixed kernel processor. The explicit arm/contrast configuration is in [WATER_MANUSCRIPT_PROFILE.json](WATER_MANUSCRIPT_PROFILE.json). It records the study design; it does not select a subset based on performance.

The metric core also exposes optional diagnostics: calendar-conditional expected/excess HSS, historical-mean-normalized deficit error and period-mean change categories. These are separate from the paper reporting profile. Use [WATER_MANUSCRIPT_PROFILE.json](WATER_MANUSCRIPT_PROFILE.json) and [manuscript mapping](MANUSCRIPT_ALIGNMENT.md) for paper tables.

The generic CLI is a reusable scorer, not a replacement for the study-specific production summaries. The `workflows/water_resources/` group provides the water-metric computation and summary chain, including its registered 11 arms, 16 contrasts and dependency on frozen spatial bootstrap draws. Source entry points are listed in [EXPERIMENT_MAP.csv](EXPERIMENT_MAP.csv).

## Run

From the repository root, after installing the repository's dependencies:

```bash
python scripts/evaluate_water.py --input inputs/water_cases.csv --output outputs/water --contrasts inputs/contrasts.json
```

The output directory must be empty or absent. Define arms, cohort and contrasts before inspecting evaluation outcomes. A contrast file is a JSON list:

```json
[
  {"arm": "with_precipitation", "reference": "streamflow_only"},
  {"arm": "withdrawn", "reference": "regional_references"}
]
```

Arm names are labels provided by the caller; they do not trigger model fitting. An output effect is always **arm minus reference**, not a direction-adjusted improvement. Positive HSS changes are improvements; positive absolute-error changes are deterioration. A change in `deficit_ratio` or `drought_count_ratio` is not intrinsically beneficial: those ratios should be near one.

## Input contracts

Discharge must be **monthly mean flow in m³/s**, not monthly volume or depth. Each case is one target/evaluation window. For the paper's station-level estimand there is one case per target; supplying several windows per station gives each window equal weight and changes that estimand. Every registered case must be represented in every arm, even when predictions are missing or invalid.

### Long CSV

Required columns:

| Column | Meaning |
| --- | --- |
| `case_id` | Stable case identifier; read as text |
| `arm` | Frozen reconstruction or baseline name |
| `date` | ISO monthly date, e.g. `2000-01` or `2000-01-01` |
| `phase` | `history` for 60 rows; `gap` for 120 rows |
| `observed` | Target history or independently withheld target truth |
| `predicted` | Frozen prediction in gap rows; blank in history rows |
| `spatial_cell` | Prespecified spatial block label, identical across all arms of a case |

Each case/arm has exactly 180 unique monthly rows. Dates, history and gap truth must be identical across arms. Dates are sorted before scoring. Nonconsecutive or nonadjacent windows are retained with invalid-date status by the metric engine; malformed registry fields, duplicate dates, wrong row counts or inconsistent arm truth stop the run. Numerical missing values and negative flows are retained and flagged, not silently dropped or clipped.

Optional columns beginning `meta_` are passed into the per-case output. Each must be constant within a case/arm; examples include `meta_fitted`, `meta_supported_months` and `meta_fallback_months`. Other columns are ignored. Preserve provenance separately if it varies month by month. A finite seasonal fallback may be scored but **is not thereby classified as a supported reconstruction**; the metric engine does not make that classification.

### Dense NPZ

The same CLI accepts `--input inputs/water_cases.npz`. Arrays must load with `allow_pickle=False`; use Unicode string arrays, never object arrays.

| Array | Shape | Meaning |
| --- | --- | --- |
| `case_id` | `(n,)` | Unique case IDs |
| `arm_names` | `(a,)` | Unique arm names |
| `spatial_cell` | `(n,)` | Block label per case |
| `history` | `(n,60)` | Visible target history |
| `observed` | `(n,120)` | Independent evaluation truth |
| `predicted` | `(n,a,120)` | Frozen predictions in arm order |
| `history_dates` | `(n,60)` or `(60,)` | Per-case or shared monthly dates |
| `gap_dates` | `(n,120)` or `(120,)` | Per-case or shared monthly dates |

Dates may be NumPy dates or ISO strings. The NPZ interface contains only these fields; use CSV when retaining optional case/arm provenance columns.

## Metric definitions and units

The direct API is:

```python
from streamflow_info.water_metrics import evaluate_case

result = evaluate_case(history_q, history_dates, observed_q,
                       predicted_q, gap_dates, drought_percentile=20)
```

It returns a stable dictionary of numeric values, Boolean validity fields and status strings. Both `drought_percentile=20` (primary) and `10` (sensitivity) are evaluated by the CLI. No percentile is selected from evaluation-period performance.

1. **Historical low-flow threshold.** Transform the 60 historical values with `log1p`, subtract their calendar-month means and estimate the pooled residual standard deviation with `ddof=0`. The historical residual percentile is transferred to each gap calendar month and inverted with `expm1`, with a physical floor of zero. Low flow means **strictly `Q < threshold`**. The implementation avoids a divide/multiply round trip at exact zero boundaries; it does not clip genuinely positive tiny thresholds. A constant residual history leaves this definition unevaluable. Five years provide an experiment-specific reference, not a long-term climate normal.
2. **Low-flow occurrence.** Counts and the full confusion matrix are retained. Ordinary Heidke skill score (`drought_hss`) is undefined when observed events are absent or universal. Optional diagnostic outputs additionally retain an exact calendar-month-conditional expected HSS and the excess over that expectation; these are not reported in the final supplement, and expected HSS is not itself a performance score. The observed event count need not be 20% or 10% of the gap because the threshold comes exclusively from history.
3. **Accumulated deficit volume.** Sum `max(threshold − Q,0) × calendar_days × 86400` over all gap months. `deficit_ratio` is predicted/observed deficit. Zero predicted deficit with positive observed deficit remains a ratio of zero; zero observed deficit gives an undefined ratio, with its state retained. `deficit_abs_ratio_error` is `abs(ratio − 1)`. An optional normalized error uses historical mean flow times the full gap duration; it is not part of the final supplement.
4. **Total interval water volume.** Sum `Q × calendar_days × 86400` over the complete 120-month interval, using actual month lengths including leap years. This is **ten-year total-volume error, not the mean of annual errors**. `water_rel_error` is predicted/observed volume minus one; `water_abs_rel_error` is its absolute value. Values are fractional: `0.154` means **15.4%**. Zero observed volume makes relative error undefined while retaining volume and zero-flow states.
5. **Period mean change (optional diagnostic outside the paper reporting profile).** Compare the day-weighted gap mean with the day-weighted historical mean and classify change using predeclared ±10% and ±20% bands. This is a comparison of period means, **not a temporal slope or trend test**. These diagnostic fields are in the per-case table, not in the convenience summary.

Tolerance flags use inclusive bounds: deficit ratio within 25% or 50%, total-volume error within 10% or 20%. A fixed relative floating-point tolerance of `1e-12` and zero absolute tolerance is used at these boundaries. Invalid history does not automatically erase valid total-volume diagnostics; denominators are specific to each metric.

## Summaries and paired spatial uncertainty

`water_summary.csv` reports median continuous metrics and binary tolerance pass percentages among valid cases. Every row includes `registered_n`, `valid_n` and `unevaluated_n`. `known_pass_registered_percent` separately divides known passes by all registered cases; it does not label unknown cases as failures. Fractional continuous metrics remain fractional in these tables. Binary estimates and intervals are already percentages.

For paired effects, first intersect the valid cases for each metric in the two arms, calculate each case's difference, and then aggregate. A median within-case difference is generally not the difference between two marginal medians. Binary effects are net percentage-point changes, with separate new/lost-pass counts. The per-case file includes all scientific fields; the convenience tables summarize nine continuous and four binary metrics and do not recreate all manuscript supplementary tables or continental subsets automatically.

The CLI samples the registered spatial cells with replacement and applies the same draw matrix to every metric, percentile and arm contrast. Targets have equal weight; a cell selected twice duplicates all its targets twice. This is not a cell-equal average of cell medians. A metric-specific draw containing no valid targets is unevaluable; its count is reported as `valid_bootstrap_draws`. Intervals are the 2.5th and 97.5th percentiles of finite bootstrap statistics.

Supply the **original frozen draws** to reproduce manuscript intervals. A seed alone cannot guarantee identical intervals if the cohort, cells, cell ordering or random-number procedure differs:

```bash
python scripts/evaluate_water.py --input inputs/water_cases.npz --output outputs/water_frozen --contrasts inputs/contrasts.json --bootstrap-draws inputs/bootstrap_draws.npz
```

The frozen file must contain `spatial_cells` (sorted unique Unicode labels in registered order) and `draws` (at least two rows, one column per cell). Draw values must be nonnegative integer counts and each row must sum to the number of registered cells. Otherwise the CLI generates 2,000 draws with seed `20261029`; both can be explicitly set. The CLI does not invent coordinates or assign spatial blocks. A different scientific design requires a justified, prespecified block definition.

Outputs are `per_target_water_metrics.csv`, `water_summary.csv`, optional `paired_water_effects.csv`, `bootstrap_draws.npz`, and `run.json`. The run receipt records input SHA-256, cohort size, arms, contrast definitions, percentile settings and bootstrap settings. All have local destinations chosen by the user; no upload occurs.

## Numerical checks

The metric implementation is shared with `workflows/water_resources/metrics.py`. Test cases cover zero thresholds, invalid/constant series, calendar-day weighting, paired denominators, block-resampling equivalence, CSV/NPZ inputs and CLI round trips with frozen draws.

```sh
python -m unittest discover -s tests -p test_water_metrics.py -v
```

The wrapper accepts explicit input paths and validates consistent arm registration. Tests use synthetic values only. These software checks do not replace empirical evaluation of a new cohort or processor.
