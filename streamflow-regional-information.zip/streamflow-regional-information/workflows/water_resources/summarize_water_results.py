"""Fixed descriptive and paired summaries of independently computed water metrics.

Does not compute streamflow predictions or water metrics from monthly arrays.
Use `freeze` before receiving new metrics, then `summarize` only after metric QA.
"""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import sys
import warnings
for variable in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[variable] = '1'
sys.dont_write_bytecode = True
HERE = _PROJECT_ROOT / 'workflows/water_resources'
CODE = _PROJECT_ROOT
pass
import numpy as np
import pandas as pd
DRAW_PATH = _PROJECT_ROOT / 'workflows/rainfall/observation_density/primary/bootstrap_draws.npz'
CASE_PATH = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/cases.csv'
P_PATH = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/P_available.npy'
ARMS = ('ridge_Q_D0', 'ridge_Q_D100', 'ridge_Q_D300', 'ridge_Q_D800', 'ridge_QP_D800', 'ridge_QP_Gclim_D800', 'corr_only_ridge_Q_D800', 'seasonal_baseline', 'rbf_Q_D0', 'rbf_Q_D800', 'rbf_QP_D800')
MAIN_ARMS = ARMS[:8]
CONTINENT_CI_ARMS = {'ridge_Q_D0', 'ridge_Q_D800', 'ridge_QP_D800', 'ridge_QP_Gclim_D800', 'seasonal_baseline'}
CONTRASTS = [(f'ridge_Q_D{d}', 'ridge_Q_D0', 'withdrawal', d == 800) for d in (100, 300, 800)] + [('ridge_QP_D800', 'ridge_Q_D800', 'added_rainfall', True), ('corr_only_ridge_Q_D800', 'ridge_Q_D800', 'ranking_sensitivity', False), ('ridge_QP_Gclim_D800', 'ridge_Q_D800', 'rainfall_climatology', False), ('ridge_QP_D800', 'ridge_QP_Gclim_D800', 'actual_vs_climatological_rainfall', False)] + [(arm, 'seasonal_baseline', 'versus_seasonal_baseline', False) for arm in MAIN_ARMS if arm != 'seasonal_baseline'] + [('rbf_Q_D800', 'rbf_Q_D0', 'processor_withdrawal_sensitivity', False), ('rbf_QP_D800', 'rbf_Q_D800', 'processor_rainfall_sensitivity', False)]
assert len(CONTRASTS) == 16
CONTINUOUS = {'drought_hss': ('higher', 'ordinary HSS'), 'drought_hss_chance': ('not_performance', 'conditional seasonal expected HSS'), 'drought_hss_excess': ('higher', 'HSS minus conditional seasonal expectation'), 'drought_count_ratio': ('closer_to_one', 'predicted/observed drought-month count'), 'deficit_ratio': ('closer_to_one', 'predicted/observed drought-deficit volume'), 'deficit_abs_ratio_error': ('lower', 'absolute deficit-ratio departure from one'), 'deficit_abs_error_hmean_normalized': ('lower', 'absolute deficit error normalized by H-mean discharge times G duration'), 'water_rel_error': ('closer_to_zero', 'signed G120 total-volume relative error'), 'water_abs_rel_error': ('lower', 'absolute G120 total-volume relative error')}
BINARY = {'deficit_within_25pct': 'Deficit ratio within [0.75,1.25]', 'deficit_within_50pct': 'Deficit ratio within [0.5,1.5]', 'water_within_10pct': 'G120 total-volume absolute relative error <=0.10', 'water_within_20pct': 'G120 total-volume absolute relative error <=0.20'}
AUXILIARY = ('drought_observed_count', 'drought_predicted_count', 'drought_hits', 'drought_misses', 'drought_false_alarms', 'drought_correct_negatives')
NUMERIC_STATE_FLAGS = ('history_mean_zero', 'history_flow_constant', 'truth_flow_constant', 'prediction_flow_constant', 'drought_observed_none', 'drought_observed_all', 'deficit_observed_zero', 'deficit_predicted_zero', 'deficit_both_zero', 'deficit_false_positive', 'deficit_complete_miss', 'water_observed_zero', 'water_predicted_zero', 'water_both_zero', 'water_false_positive')
VOLUME_DESCRIPTORS = ('deficit_observed_m3', 'deficit_predicted_m3', 'deficit_abs_error_m3', 'water_observed_volume_m3', 'water_predicted_volume_m3', 'water_abs_error_m3')
CHANGE_CATEGORIES = ('correct', 'false_stable', 'false_change', 'reversed')

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (tuple, list, np.ndarray)):
        return [clean(v) for v in value]
    if isinstance(value, np.generic):
        return clean(value.item())
    if isinstance(value, float) and (not np.isfinite(value)):
        return None
    return value

def save_json(path, value):
    Path(path).write_text(json.dumps(clean(value), indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')

def read(path, **kwargs):
    return pd.read_csv(path, keep_default_na=False, na_values=[''], low_memory=False, float_precision='round_trip', **kwargs)

def numeric(series):
    return pd.to_numeric(series.replace({'True': 1, 'False': 0, True: 1, False: 0}), errors='coerce').to_numpy(float)

def quantiles(values):
    values = np.asarray(values, float)
    values = values[np.isfinite(values)]
    if not len(values):
        return dict(median=np.nan, q25=np.nan, q75=np.nan)
    a, b, c = np.quantile(values, [0.25, 0.5, 0.75])
    return dict(median=b, q25=a, q75=c)

class SpatialBootstrap:

    def __init__(self, cells, draws):
        self.cells = np.asarray(cells, str)
        self.draws = np.asarray(draws, np.int32)
        self.cache = {}

    def key(self, kind, values, indices):
        h = hashlib.sha256()
        h.update(np.ascontiguousarray(values, dtype=np.float64).tobytes())
        h.update(np.ascontiguousarray(indices, dtype=np.int32).tobytes())
        return (kind, h.hexdigest())

    def median(self, values, indices):
        values, indices = (np.asarray(values, float), np.asarray(indices, int))
        key = self.key('median', values, indices)
        if key in self.cache:
            return self.cache[key]
        out = np.full(len(self.draws), np.nan)
        if len(values):
            assert np.isfinite(values).all()
            order = np.argsort(values, kind='stable')
            v, ix = (values[order], indices[order])
            for start in range(0, len(self.draws), 100):
                weights = self.draws[start:start + 100, ix]
                n = weights.sum(1)
                cumulative = weights.cumsum(1)
                lo = np.maximum((n - 1) // 2, 0) + 1
                hi = n // 2 + 1
                lower = np.argmax(cumulative >= lo[:, None], axis=1)
                upper = np.argmax(cumulative >= hi[:, None], axis=1)
                out[start:start + len(weights)] = np.where(n > 0, (v[lower] + v[upper]) / 2, np.nan)
        self.cache[key] = out
        return out

    def mean(self, values, indices):
        values, indices = (np.asarray(values, float), np.asarray(indices, int))
        key = self.key('mean', values, indices)
        if key in self.cache:
            return self.cache[key]
        assert np.isfinite(values).all()
        sums = np.bincount(indices, weights=values, minlength=len(self.cells))
        counts = np.bincount(indices, minlength=len(self.cells))
        denominator = self.draws @ counts
        out = np.divide(self.draws @ sums, denominator, out=np.full(len(self.draws), np.nan), where=denominator > 0)
        self.cache[key] = out
        return out

def self_test():
    rng = np.random.default_rng(982739)
    checks = 0
    for n in (1, 2, 5, 30):
        values = rng.integers(-10, 12, size=n).astype(float)
        indices = rng.integers(0, 6, size=n)
        draws = rng.multinomial(6, np.full(6, 1 / 6), size=80)
        engine = SpatialBootstrap(np.arange(6).astype(str), draws)
        med = engine.median(values, indices)
        mean = engine.mean(values, indices)
        for j, weights in enumerate(draws):
            expanded = np.repeat(values, weights[indices])
            expected_med = np.median(expanded) if len(expanded) else np.nan
            expected_mean = np.mean(expanded) if len(expanded) else np.nan
            np.testing.assert_allclose(med[j], expected_med, rtol=0, atol=0, equal_nan=True)
            np.testing.assert_allclose(mean[j], expected_mean, rtol=1e-14, atol=1e-14, equal_nan=True)
            checks += 2
    assert set(CHANGE_CATEGORIES) == {'correct', 'false_stable', 'false_change', 'reversed'}
    return {'status': 'PASS', 'literal_integer_replication_checks': checks, 'empty_block_draws_retained_as_nan': True}

def registry():
    cases = read(CASE_PATH)
    admitted = np.load(P_PATH, mmap_mode='r').astype(bool)
    assert len(cases) == 8898 and admitted.shape == (8898,) and (admitted.sum() == 8083)
    assert np.array_equal(cases.row.to_numpy(), np.arange(8898))
    cohort = cases[admitted].copy()
    archive = np.load(DRAW_PATH)
    cells, draws = (archive['spatial_cells'].astype(str), archive['draws'])
    assert draws.shape == (2000, 274)
    assert np.array_equal(cells, np.sort(cohort.spatial_cell.unique()))
    assert np.all(draws.sum(1) == 274) and np.all(draws >= 0)
    replay = np.random.default_rng(20261029).multinomial(274, np.full(274, 1 / 274), size=2000)
    assert np.array_equal(draws, replay)
    return (cohort, cells, draws)

def freeze():
    cohort, cells, draws = registry()
    result = dict(created_utc=datetime.now(timezone.utc).isoformat(), files={str(p): sha(p) for p in [_PROJECT_ROOT / 'workflows/water_resources/summarize_water_results.py', _PROJECT_ROOT / 'workflows/water_resources/analysis_plan.md', _PROJECT_ROOT / 'workflows/water_resources/PROTOCOL.md', _PROJECT_ROOT / 'workflows/water_resources/SCHEMA.json', DRAW_PATH, CASE_PATH, P_PATH]}, self_test=self_test(), registry_targets=8898, primary_targets=8083, primary_rows=cohort.row.tolist(), spatial_cells=cells.tolist(), bootstrap_shape=draws.shape, seed=20261029, arms=ARMS, contrasts=[dict(arm=a, reference=b, family=f, continent_ci=c) for a, b, f, c in CONTRASTS], continuous=CONTINUOUS, binary=BINARY, auxiliary=AUXILIARY, numeric_state_flags=NUMERIC_STATE_FLAGS, volume_descriptors=VOLUME_DESCRIPTORS, no_new_water_metrics_read=True, retrospective_frozen_prediction_evaluation=True)
    save_json(_PROJECT_ROOT / 'workflows/water_resources/ANALYSIS_PLAN_FROZEN.json', result)
    print('ANALYSIS_PLAN_FROZEN_AND_SYNTHETIC_QA_PASS', flush=True)

def summarize(input_path, schema_path=None, field_map_path=None, authorized=False):
    if not authorized:
        raise RuntimeError('Explicit parent authorization after metric QA is required.')
    frozen = json.loads((_PROJECT_ROOT / 'workflows/water_resources/ANALYSIS_PLAN_FROZEN.json').read_text(encoding='utf-8'))
    for p, expected in frozen['files'].items():
        assert sha(p) == expected, f'Frozen file changed: {p}'
    cohort, cells, draws = registry()
    expected_rows = np.sort(cohort.row.to_numpy(int))
    data = read(input_path)
    if field_map_path:
        field_map = json.loads(Path(field_map_path).read_text(encoding='utf-8'))
        data = data.rename(columns={v: k for k, v in field_map.items()})
    required = ['row', 'arm', 'drought_percentile', 'station_id', 'continent', 'country', 'spatial_cell']
    required += list(CONTINUOUS) + list(BINARY) + list(AUXILIARY) + list(NUMERIC_STATE_FLAGS) + list(VOLUME_DESCRIPTORS)
    required += [f'change_{part}_{pct}pct' for pct in (10, 20) for part in ('observed', 'predicted', 'category')]
    absent = [c for c in required if c not in data]
    if absent:
        raise ValueError('Missing frozen metric fields: ' + ', '.join(absent))
    assert len(data) == 8083 * 11 * 2
    assert set(data.arm.unique()) == set(ARMS)
    assert set(data.drought_percentile.unique()) == {10, 20}
    assert not data.duplicated(['row', 'arm', 'drought_percentile']).any()
    for key, group in data.groupby(['arm', 'drought_percentile']):
        assert np.array_equal(np.sort(group.row.to_numpy(int)), expected_rows), key
    originals = cohort.set_index('row')
    for field in ('station_id', 'continent', 'country', 'spatial_cell'):
        assert np.array_equal(data[field].astype(str).to_numpy(), originals.loc[data.row, field].astype(str).to_numpy()), field
    if 'primary_P8083' in data:
        assert data.primary_P8083.eq(True).all()
    data['cell_index'] = data.spatial_cell.map({c: i for i, c in enumerate(cells)})
    assert data.cell_index.notna().all()
    for name in list(CONTINUOUS) + list(BINARY) + list(AUXILIARY) + list(NUMERIC_STATE_FLAGS) + list(VOLUME_DESCRIPTORS):
        data[name] = numeric(data[name])
    schema = json.loads(Path(schema_path or _PROJECT_ROOT / 'workflows/water_resources/SCHEMA.json').read_text(encoding='utf-8'))
    for flag, fields in schema['validity_groups'].items():
        assert data[flag].dtype == bool, flag
        for field in fields:
            if field not in CONTINUOUS and field not in BINARY and (field not in AUXILIARY):
                continue
            assert np.array_equal(np.isfinite(data[field]), data[flag].to_numpy()), (flag, field)
    binary = dict(BINARY)
    for band in (10, 20):
        observed = numeric(data[f'change_observed_{band}pct'])
        predicted = numeric(data[f'change_predicted_{band}pct'])
        valid = np.isin(observed, [-1, 0, 1]) & np.isin(predicted, [-1, 0, 1])
        categories = data[f'change_category_{band}pct'].fillna('undefined').astype(str).to_numpy()
        expected = np.full(len(data), 'undefined', dtype=object)
        expected[valid & (observed == predicted)] = 'correct'
        expected[valid & (observed != 0) & (predicted == 0)] = 'false_stable'
        expected[valid & (observed == 0) & (predicted != 0)] = 'false_change'
        expected[valid & (observed * predicted == -1)] = 'reversed'
        assert np.array_equal(categories, expected), f'Nonexhaustive direction classes at {band}%'
        for cat in CHANGE_CATEGORIES:
            name = f'change_{cat}_{band}pct'
            expected_indicator = np.where(valid, (categories == cat).astype(float), np.nan)
            if name in data:
                np.testing.assert_allclose(numeric(data[name]), expected_indicator, rtol=0, atol=0, equal_nan=True)
            data[name] = expected_indicator
            binary[name] = f'{cat} under a +/-{band}% period-mean band'
    for name in binary:
        values = data[name].to_numpy(float)
        assert np.isin(values[np.isfinite(values)], [0, 1]).all(), name
    out = _PROJECT_ROOT / 'workflows/water_resources/analysis'
    out.mkdir(exist_ok=True)
    engine = SpatialBootstrap(cells, draws)
    continuous_rows, binary_rows, auxiliary_rows = ([], [], [])
    direction_rows, status_rows, pair_continuous, pair_binary, volume_rows = ([], [], [], [], [])
    bootstrap_rows = []

    def ci(values, meta, enabled, estimator):
        if not enabled:
            return dict(ci025=np.nan, ci975=np.nan, bootstrap_valid=0, ci_status='not_computed_by_plan', ci_estimand=estimator)
        valid = np.asarray(values, float)
        valid = valid[np.isfinite(valid)]
        q = np.quantile(valid, [0.025, 0.25, 0.5, 0.75, 0.975]) if len(valid) else np.full(5, np.nan)
        bootstrap_rows.append(dict(**meta, estimator=estimator, bootstrap_valid=len(valid), q025=q[0], q25=q[1], q50=q[2], q75=q[3], q975=q[4]))
        return dict(ci025=q[0], ci975=q[4], bootstrap_valid=len(valid), ci_status='computed' if len(valid) else 'no_valid_resamples', ci_estimand=estimator)

    def regions(frame):
        yield ('Global', frame)
        for continent in sorted(frame.continent.unique()):
            yield (continent, frame[frame.continent.eq(continent)])
    explicit_status = [c for c in data if c == 'status' or c.endswith('_status')]
    boolean_fields = [c for c in data if data[c].dtype == bool and c != 'primary_P8083']
    for (arm, q), original in data.groupby(['arm', 'drought_percentile'], sort=False):
        for region, frame in regions(original):
            common = dict(arm=arm, drought_percentile=int(q), region=region, n_registered=len(frame), n_registered_cells=frame.spatial_cell.nunique(), arm_family='main' if arm in MAIN_ARMS else 'processor_sensitivity')
            enabled = region == 'Global' or arm in CONTINENT_CI_ARMS
            ix = frame.cell_index.to_numpy(int)
            for name, (direction, description) in CONTINUOUS.items():
                values = frame[name].to_numpy(float)
                valid = np.isfinite(values)
                n = int(valid.sum())
                meta = dict(**common, metric=name)
                boot_values = engine.median(values[valid], ix[valid]) if enabled else None
                continuous_rows.append(dict(**meta, n_valid=n, n_unevaluated=len(frame) - n, n_valid_cells=frame.loc[valid, 'spatial_cell'].nunique(), **quantiles(values[valid]), better_direction=direction, description=description, **ci(boot_values, meta, enabled, 'station_median')))
            for name in AUXILIARY:
                values = frame[name].to_numpy(float)
                valid = np.isfinite(values)
                auxiliary_rows.append(dict(**common, metric=name, n_valid=int(valid.sum()), n_unevaluated=int((~valid).sum()), **quantiles(values[valid]), sum_events_over_targets=float(values[valid].sum()) if valid.any() else np.nan, note='Counts describe target-month classifications; months are not independent replicates.'))
            for name in VOLUME_DESCRIPTORS:
                values = frame[name].to_numpy(float)
                valid = np.isfinite(values)
                volume_rows.append(dict(**common, metric=name, n_valid=int(valid.sum()), n_unevaluated=int((~valid).sum()), **quantiles(values[valid]), units='m3', note='Station distribution only; no sum across potentially nested catchments.'))
            for name, description in binary.items():
                values = frame[name].to_numpy(float)
                valid = np.isfinite(values)
                n = int(valid.sum())
                passed = int(values[valid].sum())
                meta = dict(**common, metric=name)
                boot_valid = 100 * engine.mean(values[valid], ix[valid]) if enabled else None
                registered = np.where(valid, values, 0.0)
                boot_registered = 100 * engine.mean(registered, ix) if enabled else None
                primary_ci = ci(boot_valid, meta, enabled, 'percent_among_metric_valid')
                registered_ci = ci(boot_registered, meta, enabled, 'known_pass_percent_registered')
                binary_rows.append(dict(**meta, description=description, n_valid=n, n_unevaluated=len(frame) - n, n_pass=passed, pct_valid=100 * passed / n if n else np.nan, pct_known_pass_registered=100 * passed / len(frame), **primary_ci, registered_ci025=registered_ci['ci025'], registered_ci975=registered_ci['ci975'], registered_bootstrap_valid=registered_ci['bootstrap_valid'], missing_policy='Unevaluated is unknown, not observed failure.'))
            for band in (10, 20):
                observed = numeric(frame[f'change_observed_{band}pct'])
                predicted = numeric(frame[f'change_predicted_{band}pct'])
                valid = np.isin(observed, [-1, 0, 1]) & np.isin(predicted, [-1, 0, 1])
                count_sum = 0
                for observed_class in (-1, 0, 1):
                    for predicted_class in (-1, 0, 1):
                        n = int((valid & (observed == observed_class) & (predicted == predicted_class)).sum())
                        count_sum += n
                        direction_rows.append(dict(**common, stable_band_pct=band, observed_class=observed_class, predicted_class=predicted_class, n=n, n_valid=int(valid.sum()), n_unevaluated=int((~valid).sum()), pct_valid=100 * n / valid.sum() if valid.any() else np.nan, pct_registered=100 * n / len(frame)))
                assert count_sum == valid.sum()
            for field in boolean_fields:
                for value in (False, True):
                    status_rows.append(dict(**common, field=field, value=str(value), n=int(frame[field].eq(value).sum()), record_type='boolean_state'))
            for field in explicit_status:
                for value, n in frame[field].fillna('missing').astype(str).value_counts(dropna=False).items():
                    status_rows.append(dict(**common, field=field, value=value, n=int(n), record_type='status'))
            for field in NUMERIC_STATE_FLAGS:
                values = frame[field].to_numpy(float)
                assert np.isin(values[np.isfinite(values)], [0, 1]).all(), field
                for value in (0, 1):
                    status_rows.append(dict(**common, field=field, value=str(value), n=int((values == value).sum()), record_type='numeric_state_flag'))
                status_rows.append(dict(**common, field=field, value='unknown', n=int((~np.isfinite(values)).sum()), record_type='numeric_state_flag'))
        print(f'SINGLE_ARM_DONE {arm} q{q}', flush=True)
    for q in (20, 10):
        tables = {arm: data[data.arm.eq(arm) & data.drought_percentile.eq(q)].set_index('row').loc[expected_rows] for arm in ARMS}
        for arm, ref, family, continent_ci in CONTRASTS:
            a, b = (tables[arm], tables[ref])
            for region, aa in regions(a):
                bb = b.loc[aa.index]
                enabled = region == 'Global' or continent_ci
                ix = aa.cell_index.to_numpy(int)
                common = dict(arm=arm, reference=ref, contrast=arm + '__minus__' + ref, contrast_family=family, drought_percentile=q, region=region, n_registered=len(aa), n_registered_cells=aa.spatial_cell.nunique())
                for name, (direction, description) in CONTINUOUS.items():
                    av, bv = (aa[name].to_numpy(float), bb[name].to_numpy(float))
                    valid_a, valid_b = (np.isfinite(av), np.isfinite(bv))
                    valid = valid_a & valid_b
                    delta = av[valid] - bv[valid]
                    meta = dict(**common, metric=name)
                    boot_values = engine.median(delta, ix[valid]) if enabled else None
                    qa, qb, qd = (quantiles(av[valid]), quantiles(bv[valid]), quantiles(delta))
                    pair_continuous.append(dict(**meta, n_valid_arm=int(valid_a.sum()), n_valid_reference=int(valid_b.sum()), n_pairs=int(valid.sum()), n_unpaired=len(aa) - int(valid.sum()), n_arm_only=int((valid_a & ~valid_b).sum()), n_reference_only=int((valid_b & ~valid_a).sum()), n_pair_cells=aa.loc[valid, 'spatial_cell'].nunique(), arm_median_paired=qa['median'], reference_median_paired=qb['median'], paired_delta_median=qd['median'], paired_delta_q25=qd['q25'], paired_delta_q75=qd['q75'], n_delta_positive=int((delta > 1e-12).sum()), n_delta_negative=int((delta < -1e-12).sum()), n_delta_numerically_equal=int((np.abs(delta) <= 1e-12).sum()), better_direction=direction, **ci(boot_values, meta, enabled, 'median_of_within_target_differences')))
                for name, description in binary.items():
                    av, bv = (aa[name].to_numpy(float), bb[name].to_numpy(float))
                    valid_a, valid_b = (np.isfinite(av), np.isfinite(bv))
                    valid = valid_a & valid_b
                    delta = av[valid] - bv[valid]
                    new = int(((av == 1) & (bv == 0) & valid).sum())
                    lost = int(((av == 0) & (bv == 1) & valid).sum())
                    meta = dict(**common, metric=name)
                    boot_values = 100 * engine.mean(delta, ix[valid]) if enabled else None
                    registered_delta = np.zeros(len(aa))
                    registered_delta[valid] = delta
                    registered_boot = 100 * engine.mean(registered_delta, ix) if enabled else None
                    intervals = ci(boot_values, meta, enabled, 'net_percentage_points_among_paired_valid')
                    reg_intervals = ci(registered_boot, meta, enabled, 'known_paired_net_percentage_points_registered')
                    pair_binary.append(dict(**meta, description=description, n_valid_arm=int(valid_a.sum()), n_valid_reference=int(valid_b.sum()), n_pairs=int(valid.sum()), n_unpaired=int((~valid).sum()), n_arm_only=int((valid_a & ~valid_b).sum()), n_reference_only=int((valid_b & ~valid_a).sum()), new_pass=new, lost_pass=lost, both_pass=int(((av == 1) & (bv == 1) & valid).sum()), neither_pass=int(((av == 0) & (bv == 0) & valid).sum()), net_pp_paired_valid=100 * (new - lost) / valid.sum() if valid.any() else np.nan, known_paired_net_pp_registered=100 * (new - lost) / len(aa), **intervals, registered_ci025=reg_intervals['ci025'], registered_ci975=reg_intervals['ci975'], missing_policy='Unpaired outcomes excluded from paired effect, retained and enumerated in registry.'))
            print(f'PAIRED_DONE {arm} minus {ref} q{q}', flush=True)
    outputs = {'continuous_by_arm.csv': continuous_rows, 'binary_proportions_by_arm.csv': binary_rows, 'event_counts_by_arm.csv': auxiliary_rows, 'volume_descriptors_by_arm.csv': volume_rows, 'period_mean_direction_confusion.csv': direction_rows, 'state_counts_by_arm.csv': status_rows, 'paired_continuous_effects.csv': pair_continuous, 'paired_binary_effects.csv': pair_binary, 'bootstrap_quantiles.csv': bootstrap_rows}
    for filename, rows in outputs.items():
        pd.DataFrame(rows).to_csv(out / filename, index=False)
    save_json(_PROJECT_ROOT / 'workflows/water_resources/analysis/SUMMARY_QA.json', dict(status='PASS', created_utc=datetime.now(timezone.utc).isoformat(), metric_table_sha256=sha(input_path), analysis_plan_freeze_sha256=sha(_PROJECT_ROOT / 'workflows/water_resources/ANALYSIS_PLAN_FROZEN.json'), schema_sha256=sha(schema_path) if schema_path else None, mapping_sha256=sha(field_map_path) if field_map_path else None, registered_source_mother=8898, evaluated_primary=8083, unassessed_rainfall=815, rows=len(data), arms=ARMS, drought_percentiles=[20, 10], bootstrap_replicates=2000, occupied_cells=274, seed=20261029, self_test=self_test(), all_fixed_contrasts_retained=True, finite_fallback_predictions_not_filtered=True, no_prediction_or_water_metric_recomputation=True, undefined_values_not_set_to_failure=True, outputs={name: dict(rows=len(rows), sha256=sha(out / name)) for name, rows in outputs.items()}))
    print('WATER_RESOURCE_SUMMARIES_COMPLETE', flush=True)
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('step', choices=['self-test', 'freeze', 'summarize'])
    parser.add_argument('--input', type=Path)
    parser.add_argument('--schema', type=Path)
    parser.add_argument('--field-map', type=Path)
    parser.add_argument('--authorized-after-metric-qa', action='store_true')
    args = parser.parse_args()
    if args.step == 'self-test':
        print(json.dumps(self_test()))
    elif args.step == 'freeze':
        freeze()
    else:
        if args.input is None:
            parser.error('--input is required for summarize')
        summarize(args.input, args.schema, args.field_map, args.authorized_after_metric_qa)
