"""Independent vectorized all-case audit; does not import production metrics.py."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import sys, os, json, hashlib, calendar
from datetime import datetime, timezone
for k in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '1'
HERE = _PROJECT_ROOT / 'workflows/water_resources/audit'
ROOT = _PROJECT_ROOT / 'workflows/water_resources'
DATA = _PROJECT_ROOT / 'workflows/water_resources/data'
RESULT = _PROJECT_ROOT / 'workflows/water_resources/results'
CODE = _PROJECT_ROOT
pass
import numpy as np
import pandas as pd

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(2 ** 23), b''):
            h.update(b)
    return h.hexdigest()

def load(n):
    return np.load(DATA / (n + '.npy'), mmap_mode='r')
checks = []
issues = []

def check(g, field, expected, arm, q, exact=False, roundoff_scale=None):
    a = g[field].to_numpy()
    b = np.asarray(expected)
    if b.dtype.kind == 'b':
        ok = a.astype(bool) == b
        finite = np.ones(len(b), bool)
        err = np.zeros(len(b))
    elif b.dtype.kind in 'USO':
        ok = a.astype(str) == b.astype(str)
        finite = np.ones(len(b), bool)
        err = np.zeros(len(b))
    else:
        a = a.astype(float)
        b = b.astype(float)
        finite = np.isfinite(a) & np.isfinite(b)
        if exact:
            ok = (a == b) | np.isnan(a) & np.isnan(b)
        else:
            bound = 1e-12 + 5e-12 * np.abs(b)
            if roundoff_scale is not None:
                bound = bound + 128 * np.finfo(float).eps * np.nan_to_num(np.abs(roundoff_scale), nan=0.0, posinf=0.0, neginf=0.0)
            ok = (np.abs(a - b) <= bound) | np.isnan(a) & np.isnan(b)
        err = np.abs(a[finite] - b[finite])
    record = {'arm': arm, 'percentile': q, 'field': field, 'n': len(b), 'finite_pairs': int(finite.sum()), 'mismatches': int((~ok).sum()), 'max_abs_difference': float(err.max()) if len(err) else 0.0, 'roundoff_scale_used': roundoff_scale is not None}
    checks.append(record)
    if not ok.all():
        bad = np.flatnonzero(~ok)
        issues.append({**record, 'examples': [{'row': int(g.row.iloc[j]), 'actual': str(a[j]), 'independent': str(b[j])} for j in bad[:10]]})

def nanwhere(mask, value):
    return np.where(mask, value, np.nan)

def within(x, t):
    return np.where(np.isfinite(x), (x <= t * (1 + 1e-12)).astype(float), np.nan)

def main():
    receipt = json.loads((_PROJECT_ROOT / 'workflows/water_resources/results/PER_TARGET_COMPLETE.json').read_text())
    assert receipt['status'] == 'PASS_ALL_PREDECLARED_ARMS_SCORED'
    assert receipt['metrics_sha256'] == sha(_PROJECT_ROOT / 'workflows/water_resources/metrics.py'), 'Production results are not current.'
    path = _PROJECT_ROOT / 'workflows/water_resources/results/per_target_water_metrics.csv.gz'
    assert sha(path) == receipt['output_sha256']
    df = pd.read_csv(path, keep_default_na=False, na_values=[''], low_memory=False)
    assert df.metrics_version.eq('1.0.1').all()
    meta = pd.read_csv(_PROJECT_ROOT / 'workflows/water_resources/data/case_metadata.csv', keep_default_na=False, na_values=[''])
    ix = np.flatnonzero(load('P_available'))
    assert len(ix) == 8083
    assert len(df) == len(ix) * 11 * 2 and (not df.duplicated(['row', 'arm', 'drought_percentile']).any())
    assert np.array_equal(np.sort(df.row.unique()), ix)
    assert df[df.country == 'NA'].row.nunique() == 16
    hd = load('H_dates')[ix]
    gd = load('G_dates')[ix]
    hm = hd.astype('datetime64[M]').astype(int) % 12
    gm = gd.astype('datetime64[M]').astype(int) % 12
    axis = load('source_dates')
    date_to_days = {str(dt): calendar.monthrange(int(str(dt)[:4]), int(str(dt)[5:7]))[1] for dt in axis}
    hday = np.array([[date_to_days[str(x)] for x in r] for r in hd])
    gday = np.array([[date_to_days[str(x)] for x in r] for r in gd])
    assert np.array_equal(hday, load('H_days')[ix]) and np.array_equal(gday, load('G_days')[ix])
    assert np.all(np.diff(hd.astype('datetime64[M]').astype(int), axis=1) == 1)
    assert np.all(np.diff(gd.astype('datetime64[M]').astype(int), axis=1) == 1)
    assert np.all(gd[:, 0].astype('datetime64[M]').astype(int) == hd[:, -1].astype('datetime64[M]').astype(int) + 1)
    h = load('H_flow')[ix]
    o = load('G_truth')[ix]
    allp = load('predictions')
    hv = np.isfinite(h).all(1) & (h >= 0).all(1)
    ov = np.isfinite(o).all(1) & (o >= 0).all(1)
    hmean = nanwhere(hv, (h * hday).sum(1) / hday.sum(1))
    omean = nanwhere(ov, (o * gday).sum(1) / gday.sum(1))
    ovol = nanwhere(ov, np.sum(o * gday, axis=1) * 86400.0)
    x = np.log1p(np.where(hv[:, None], h, 0.0))
    mu = np.array([[np.mean(xx[mm == m]) for m in range(12)] for xx, mm in zip(x, hm)])
    frozen_mu = load('target_H_log_calendar')[ix]
    assert np.array_equal(mu[hv], frozen_mu[hv])
    residual = x - np.take_along_axis(mu, hm, axis=1)
    scale = np.sqrt((residual ** 2).mean(1))
    scale[~hv] = np.nan
    eventvalid = hv & np.isfinite(scale) & (scale > 1e-12)
    z = np.divide(residual, scale[:, None], out=np.full_like(residual, np.nan), where=eventvalid[:, None])
    names = json.loads((_PROJECT_ROOT / 'workflows/water_resources/data/ARM_REGISTRY.json').read_text())['arm_names']
    states = []
    for percentile in [20, 10]:
        pos = (60 - 1) * percentile / 100
        lo = int(np.floor(pos))
        frac = pos - lo
        ordered = np.sort(z, axis=1)
        cut = ordered[:, lo] + frac * (ordered[:, lo + 1] - ordered[:, lo])
        ordered_raw = np.sort(residual, axis=1)
        cut_raw = ordered_raw[:, lo] + frac * (ordered_raw[:, lo + 1] - ordered_raw[:, lo])
        threshold = np.maximum(np.expm1(np.take_along_axis(mu, gm, axis=1) + cut_raw[:, None]), 0)
        threshold[~eventvalid] = np.nan
        ev_o = o < threshold
        O = ev_o.sum(1)
        obs_event_valid = eventvalid & ov
        obsdef = np.sum(np.maximum(threshold - o, 0) * gday, axis=1) * 86400.0
        obsdef = nanwhere(obs_event_valid, obsdef)
        for ai, arm in enumerate(names):
            g = df[(df.arm == arm) & (df.drought_percentile == percentile)].sort_values('row').reset_index(drop=True)
            assert np.array_equal(g.row.to_numpy(), ix)
            p = np.asarray(allp[ix, ai])
            pv = np.isfinite(p).all(1) & (p >= 0).all(1)
            for fi, fname in enumerate(json.loads((_PROJECT_ROOT / 'workflows/water_resources/data/ARM_REGISTRY.json').read_text())['flags']):
                check(g, 'original_' + fname, load('original_model_flags')[ix, ai, fi], arm, percentile, exact=True)
            sup = load('original_month_support')[ix, ai]
            fall = load('derived_seasonal_fallback_month')[ix, ai]
            for fld, v in [('original_supported_months', np.where((sup >= 0).any(1), (sup == 1).sum(1), -1)), ('original_unsupported_months', np.where((sup >= 0).any(1), (sup == 0).sum(1), -1)), ('derived_seasonal_fallback_months', np.where((fall >= 0).any(1), (fall == 1).sum(1), -1))]:
                check(g, fld, v, arm, percentile, exact=True)
            for fld in ['station_id', 'gsim_id', 'raw_index', 'continent', 'country', 'spatial_cell']:
                check(g, fld, meta.iloc[ix][fld].to_numpy(), arm, percentile, exact=True)
            for name, qq, vv in [('history', h, hv), ('truth', o, ov), ('prediction', p, pv)]:
                check(g, name + '_nonfinite_months', (~np.isfinite(qq)).sum(1), arm, percentile, exact=True)
                check(g, name + '_negative_months', (qq < 0).sum(1), arm, percentile, exact=True)
                check(g, name + '_flow_constant', nanwhere(vv, np.all(qq == qq[:, :1], axis=1)), arm, percentile, exact=True)
            pmean = nanwhere(pv, (p * gday).sum(1) / gday.sum(1))
            pvol = nanwhere(pv, (p * gday).sum(1) * 86400.0)
            water_valid = np.isfinite(ovol) & np.isfinite(pvol)
            water_rel_valid = water_valid & (ovol > 0)
            wr = np.divide(pvol - ovol, ovol, out=np.full(len(ix), np.nan), where=water_rel_valid)
            check(g, 'dates_valid', np.ones(len(ix), bool), arm, percentile)
            for fld, v in [('history_input_valid', hv), ('truth_input_valid', ov), ('prediction_input_valid', pv), ('history_mean_flow', hmean), ('history_days', hday.sum(1)), ('gap_days', gday.sum(1)), ('gap_observed_mean_flow', omean), ('gap_predicted_mean_flow', pmean), ('water_observed_volume_m3', ovol), ('water_predicted_volume_m3', pvol), ('water_paired_valid', water_valid), ('water_relative_error_valid', water_rel_valid), ('water_rel_error', wr), ('water_abs_rel_error', np.abs(wr)), ('water_abs_error_m3', nanwhere(water_valid, np.abs(pvol - ovol))), ('water_within_10pct', within(np.abs(wr), 0.1)), ('water_within_20pct', within(np.abs(wr), 0.2)), ('water_observed_zero', nanwhere(ov, ovol == 0)), ('water_predicted_zero', nanwhere(pv, pvol == 0)), ('water_both_zero', nanwhere(water_valid, (ovol == 0) & (pvol == 0))), ('water_false_positive', nanwhere(water_valid, (ovol == 0) & (pvol > 0))), ('history_mean_zero', nanwhere(hv, hmean == 0)), ('event_definition_valid', eventvalid), ('history_log_residual_scale', scale), ('history_anomaly_threshold', cut), ('threshold_flow_min', nanwhere(eventvalid, np.min(threshold, axis=1))), ('threshold_flow_max', nanwhere(eventvalid, np.max(threshold, axis=1)))]:
                physical_scale = np.abs(ovol) + np.abs(pvol) if fld.endswith('_m3') else None
                check(g, fld, v, arm, percentile, roundoff_scale=physical_scale)
            ev_p = p < threshold
            P = ev_p.sum(1)
            A = (ev_o & ev_p).sum(1)
            B = (~ev_o & ev_p).sum(1)
            C = (ev_o & ~ev_p).sum(1)
            D = (~ev_o & ~ev_p).sum(1)
            pred_event_valid = eventvalid & pv
            pair = obs_event_valid & pred_event_valid
            EA = np.zeros(len(ix))
            for m in range(12):
                ob = np.where(gm == m, ev_o, False).sum(1)
                pr = np.where(gm == m, ev_p, False).sum(1)
                EA += ob * pr / np.sum(gm == m, axis=1)
            chance_agreement = (O * P + (120 - O) * (120 - P)) / 120 ** 2
            observed_accuracy = (A + D) / 120
            null_accuracy = (120 - O - P + 2 * EA) / 120
            hssvalid = pair & (O > 0) & (O < 120)
            raw = np.divide(observed_accuracy - chance_agreement, 1 - chance_agreement, out=np.full(len(ix), np.nan), where=hssvalid)
            null = np.divide(null_accuracy - chance_agreement, 1 - chance_agreement, out=np.full(len(ix), np.nan), where=hssvalid)
            for fld, v in [('drought_observed_valid', obs_event_valid), ('drought_predicted_valid', pred_event_valid), ('drought_paired_valid', pair), ('drought_observed_count', nanwhere(obs_event_valid, O)), ('drought_predicted_count', nanwhere(pred_event_valid, P)), ('drought_hits', nanwhere(pair, A)), ('drought_false_alarms', nanwhere(pair, B)), ('drought_misses', nanwhere(pair, C)), ('drought_correct_negatives', nanwhere(pair, D)), ('drought_observed_none', nanwhere(obs_event_valid, O == 0)), ('drought_observed_all', nanwhere(obs_event_valid, O == 120)), ('drought_observed_frequency', nanwhere(obs_event_valid, O / 120)), ('drought_predicted_frequency', nanwhere(pred_event_valid, P / 120)), ('drought_frequency_error', nanwhere(pair, (P - O) / 120)), ('drought_count_ratio', np.divide(P, O, out=np.full(len(ix), np.nan), where=pair & (O > 0))), ('drought_hss_valid', hssvalid), ('drought_hss', raw), ('drought_hss_chance', null), ('drought_hss_excess', raw - null), ('drought_hss_expected_hits', nanwhere(pair, EA))]:
                check(g, fld, v, arm, percentile)
            pdef = nanwhere(pred_event_valid, np.sum(np.maximum(threshold - p, 0) * gday, axis=1) * 86400.0)
            dv = np.isfinite(obsdef) & np.isfinite(pdef)
            rv = dv & (obsdef > 0)
            ratio = np.divide(pdef, obsdef, out=np.full(len(ix), np.nan), where=rv)
            normalizer = hmean * gday.sum(1) * 86400.0
            nv = dv & np.isfinite(normalizer) & (normalizer > 0)
            norm = np.divide(pdef - obsdef, normalizer, out=np.full(len(ix), np.nan), where=nv)
            for fld, v in [('deficit_observed_m3', obsdef), ('deficit_predicted_m3', pdef), ('deficit_paired_valid', dv), ('deficit_ratio_valid', rv), ('deficit_ratio', ratio), ('deficit_abs_ratio_error', np.abs(ratio - 1)), ('deficit_abs_error_m3', nanwhere(dv, np.abs(pdef - obsdef))), ('deficit_normalized_error_valid', nv), ('deficit_signed_error_hmean_normalized', norm), ('deficit_abs_error_hmean_normalized', np.abs(norm)), ('deficit_within_25pct', within(np.abs(ratio - 1), 0.25)), ('deficit_within_50pct', within(np.abs(ratio - 1), 0.5)), ('deficit_observed_zero', nanwhere(obs_event_valid, obsdef == 0)), ('deficit_predicted_zero', nanwhere(pred_event_valid, pdef == 0)), ('deficit_both_zero', nanwhere(dv, (obsdef == 0) & (pdef == 0))), ('deficit_false_positive', nanwhere(dv, (obsdef == 0) & (pdef > 0))), ('deficit_complete_miss', nanwhere(dv, (obsdef > 0) & (pdef == 0)))]:
                physical_scale = np.abs(ovol) + np.abs(pvol) + np.sum(threshold * gday, axis=1) * 86400 if fld.endswith('_m3') else None
                check(g, fld, v, arm, percentile, roundoff_scale=physical_scale)
            oc = np.divide(omean - hmean, hmean, out=np.full(len(ix), np.nan), where=hv & ov & (hmean > 0))
            pc = np.divide(pmean - hmean, hmean, out=np.full(len(ix), np.nan), where=hv & pv & (hmean > 0))
            for fld, v in [('period_mean_change_observed', oc), ('period_mean_change_predicted', pc), ('period_change_paired_valid', np.isfinite(oc) & np.isfinite(pc)), ('period_change_observed_valid', np.isfinite(oc)), ('period_change_prediction_valid', np.isfinite(pc))]:
                check(g, fld, v, arm, percentile)
            for band, suf in [(0.1, '10pct'), (0.2, '20pct')]:
                obc = np.where(np.abs(oc) <= band * (1 + 1e-12), 0, np.sign(oc))
                prc = np.where(np.abs(pc) <= band * (1 + 1e-12), 0, np.sign(pc))
                cp = np.isfinite(obc) & np.isfinite(prc)
                cat = np.full(len(ix), 'undefined', object)
                cat[cp] = 'reversed'
                cat[cp & (obc == 0)] = 'false_change'
                cat[cp & (prc == 0)] = 'false_stable'
                cat[cp & (obc == prc)] = 'correct'
                check(g, 'change_observed_' + suf, obc, arm, percentile)
                check(g, 'change_predicted_' + suf, prc, arm, percentile)
                check(g, 'change_category_' + suf, cat, arm, percentile)
                for kind in ['correct', 'false_stable', 'false_change', 'reversed']:
                    check(g, 'change_' + kind + '_' + suf, nanwhere(cp, cat == kind), arm, percentile)
            states.append({'arm': arm, 'percentile': percentile, 'registered_n': len(ix), 'history_valid_n': int(hv.sum()), 'truth_valid_n': int(ov.sum()), 'prediction_valid_n': int(pv.sum()), 'history_event_threshold_valid_n': int(eventvalid.sum()), 'observed_event_valid_n': int(obs_event_valid.sum()), 'observed_no_events_n': int((obs_event_valid & (O == 0)).sum()), 'observed_all_events_n': int((obs_event_valid & (O == 120)).sum()), 'hss_valid_n': int(hssvalid.sum()), 'deficit_ratio_valid_n': int(rv.sum()), 'water_relative_valid_n': int(water_rel_valid.sum()), 'observed_zero_water_n': int((ov & (ovol == 0)).sum()), 'period_change_valid_n': int(cp.sum())})
        print('INDEPENDENT_ALL_CASE_AUDIT', percentile, 'checks', len(checks), 'issues', len(issues), flush=True)
    edge = meta.iloc[ix][['row', 'station_id', 'continent', 'country']].copy()
    edge['H_negative'] = (h < 0).any(1)
    edge['G_negative'] = (o < 0).any(1)
    edge['H_constant'] = np.all(h == h[:, :1], axis=1)
    edge['G_constant'] = np.all(o == o[:, :1], axis=1)
    edge['H_all_zero'] = np.all(h == 0, axis=1)
    edge['G_all_zero'] = np.all(o == 0, axis=1)
    edge['H_anomaly_scale_unusable'] = ~eventvalid
    edge[edge.iloc[:, 4:].any(axis=1)].to_csv(_PROJECT_ROOT / 'workflows/water_resources/audit/edge_state_case_membership.csv', index=False)
    pd.DataFrame(checks).to_csv(_PROJECT_ROOT / 'workflows/water_resources/audit/independent_metric_checks.csv', index=False)
    pd.DataFrame(states).to_csv(_PROJECT_ROOT / 'workflows/water_resources/audit/independent_metric_validity_counts.csv', index=False)
    result = {'status': 'PASS' if not issues else 'FAIL', 'created_utc': datetime.now(timezone.utc).isoformat(), 'independent_method': 'No import or calls to metrics.py; vectorized raw-input water integrals, manual linear-percentile interpolation directly in residual units, independent accuracy/kappa HSS formula and calendar-conditional expected accuracy. Five-sample H calendar groups exactly match frozen means.', 'floating_QA_tolerance': 'All scalars: 1e-12 + 5e-12*abs(expected); dimensional volume quantities additionally permit 128*machine_epsilon*(observed + predicted + applicable threshold total volume), because subtraction and summation order can differ. This is comparison tolerance, not any scientific scoring threshold.', 'prior_bug_evidence': 'initial_scalar_threshold_audit retains original FAIL; zero_threshold_diagnostic.json and direct_threshold_allcase_changes.json establish six exact-zero physical thresholds through 80-digit Decimal arithmetic. No production metric imported or altered by this audit.', 'n_targets': len(ix), 'n_arms': len(names), 'percentiles': [20, 10], 'all_target_arm_percentile_rows': len(df), 'field_checks': len(checks), 'issues': issues, 'dates_verified_against_python_calendar_all_months': True, 'new_metrics_changed': False, 'H_negative_targets': int((h < 0).any(1).sum()), 'G_negative_targets': int((o < 0).any(1).sum()), 'negative_H_G_overlap': int(((h < 0).any(1) & (o < 0).any(1)).sum()), 'H_constant_targets': int(np.all(h == h[:, :1], axis=1).sum()), 'G_constant_targets': int(np.all(o == o[:, :1], axis=1).sum()), 'inputs': {'production_metrics_csv_sha256': sha(path), 'production_receipt_sha256': sha(_PROJECT_ROOT / 'workflows/water_resources/results/PER_TARGET_COMPLETE.json'), 'data_receipt_sha256': sha(_PROJECT_ROOT / 'workflows/water_resources/data/DATA_COMPLETE.json'), 'protocol_sha256': sha(_PROJECT_ROOT / 'workflows/water_resources/PROTOCOL.md'), 'audit_script_sha256': sha(__file__)}, 'validity_counts': states}
    (_PROJECT_ROOT / 'workflows/water_resources/audit/INDEPENDENT_METRICS_QA.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf8')
    print('AUDIT', result['status'], 'issues', len(issues), flush=True)
    if issues:
        print(json.dumps(issues[:12], ensure_ascii=False), flush=True)
if __name__ == '__main__':
    with np.errstate(invalid='ignore', divide='ignore', over='ignore'):
        main()
