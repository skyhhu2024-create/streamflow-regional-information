"""Independent point/CI audit from the frozen per-target table only.

Does not import the producer's metrics or summary implementation. Production
files are read-only. Integer bootstrap replications use separate sorted-vector
search logic, and points are recomputed directly from target records.
"""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
for variable in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[variable] = '1'
import numpy as np
import pandas as pd
HERE = _PROJECT_ROOT / 'workflows/water_resources/audit'
ROOT = _PROJECT_ROOT / 'workflows/water_resources'
CODE = _PROJECT_ROOT
OUT = _PROJECT_ROOT / 'workflows/water_resources/analysis'
INPUT = _PROJECT_ROOT / 'workflows/water_resources/results/per_target_water_metrics.csv.gz'
DRAW = _PROJECT_ROOT / 'workflows/rainfall/observation_density/primary/bootstrap_draws.npz'
ERRORS = []
COUNTS = {}

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def read(path):
    return pd.read_csv(path, keep_default_na=False, na_values=[''], float_precision='round_trip', low_memory=False)

def check(label, actual, expected, exact=False):
    COUNTS[label.split(':')[0]] = COUNTS.get(label.split(':')[0], 0) + 1
    if isinstance(expected, str):
        ok = str(actual) == expected
    elif exact:
        ok = actual == expected
    else:
        ok = bool(np.isclose(actual, expected, rtol=1e-12, atol=1e-11, equal_nan=True))
    if not ok and len(ERRORS) < 50:
        ERRORS.append({'label': label, 'actual': str(actual), 'expected': str(expected)})

def values(frame, name):
    return pd.to_numeric(frame[name], errors='coerce').to_numpy(float)

def q3(v):
    return np.quantile(v, [0.25, 0.5, 0.75]) if len(v) else [np.nan] * 3

def main():
    if not (_PROJECT_ROOT / 'workflows/water_resources/analysis/SUMMARY_QA.json').exists():
        raise RuntimeError('Await production SUMMARY_QA.json; no partial-output audit.')
    input_receipt = json.loads((_PROJECT_ROOT / 'workflows/water_resources/results/PER_TARGET_COMPLETE.json').read_text())
    summary_receipt = json.loads((_PROJECT_ROOT / 'workflows/water_resources/analysis/SUMMARY_QA.json').read_text())
    assert input_receipt['metrics_sha256'] == sha(_PROJECT_ROOT / 'workflows/water_resources/metrics.py'), 'Do not audit superseded metric results.'
    assert sha(INPUT) == input_receipt['output_sha256'] == summary_receipt['metric_table_sha256']
    for name, meta in summary_receipt['outputs'].items():
        assert sha(OUT / name) == meta['sha256']
    d = read(INPUT)
    current_schema = json.loads((_PROJECT_ROOT / 'workflows/water_resources/SCHEMA.json').read_text())
    assert set(d.metrics_version.unique()) == {current_schema['version']}
    meta = read(_PROJECT_ROOT / 'workflows/water_resources/data/case_metadata.csv')
    expected = meta.loc[meta.P_available.astype(bool), 'row'].to_numpy(int)
    assert len(expected) == 8083 and len(d) == 8083 * 11 * 2
    assert not d.duplicated(['row', 'arm', 'drought_percentile']).any()
    tables = {key: g.set_index('row').loc[expected] for key, g in d.groupby(['arm', 'drought_percentile'])}
    assert len(tables) == 22
    for frame in tables.values():
        assert np.array_equal(frame.index.to_numpy(int), expected)
    archive = np.load(DRAW)
    cells = archive['spatial_cells'].astype(str)
    draws = archive['draws'].astype(np.int32)
    assert draws.shape == (2000, 274) and (draws.sum(1) == 274).all()
    assert np.array_equal(cells, np.sort(d.spatial_cell.unique()))
    regenerated = np.random.default_rng(20261029).multinomial(274, np.full(274, 1 / 274), size=2000)
    assert np.array_equal(draws, regenerated)
    cellmap = {c: i for i, c in enumerate(cells)}

    def frame_for(arm, q, region):
        f = tables[arm, int(q)]
        return f if region == 'Global' else f[f.continent == region]
    single_cont = read(_PROJECT_ROOT / 'workflows/water_resources/analysis/continuous_by_arm.csv')
    single_bin = read(_PROJECT_ROOT / 'workflows/water_resources/analysis/binary_proportions_by_arm.csv')
    paired_cont = read(_PROJECT_ROOT / 'workflows/water_resources/analysis/paired_continuous_effects.csv')
    paired_bin = read(_PROJECT_ROOT / 'workflows/water_resources/analysis/paired_binary_effects.csv')
    confusion = read(_PROJECT_ROOT / 'workflows/water_resources/analysis/period_mean_direction_confusion.csv')
    states = read(_PROJECT_ROOT / 'workflows/water_resources/analysis/state_counts_by_arm.csv')
    event_counts = read(_PROJECT_ROOT / 'workflows/water_resources/analysis/event_counts_by_arm.csv')
    volumes = read(_PROJECT_ROOT / 'workflows/water_resources/analysis/volume_descriptors_by_arm.csv')
    for r in single_cont.itertuples(index=False):
        f = frame_for(r.arm, r.drought_percentile, r.region)
        v = values(f, r.metric)
        good = np.isfinite(v)
        vq = q3(v[good])
        tag = f'single_cont:{r.arm}:{r.drought_percentile}:{r.region}:{r.metric}'
        for field, x in [('n_registered', len(f)), ('n_valid', int(good.sum())), ('n_unevaluated', int((~good).sum())), ('q25', vq[0]), ('median', vq[1]), ('q75', vq[2])]:
            check(tag + ':' + field, getattr(r, field), x)
    for r in single_bin.itertuples(index=False):
        f = frame_for(r.arm, r.drought_percentile, r.region)
        v = values(f, r.metric)
        good = np.isfinite(v)
        n = int(good.sum())
        passed = int(np.sum(v[good]))
        assert np.isin(v[good], [0, 1]).all()
        tag = f'single_binary:{r.arm}:{r.drought_percentile}:{r.region}:{r.metric}'
        for field, x in [('n_registered', len(f)), ('n_valid', n), ('n_unevaluated', len(f) - n), ('n_pass', passed), ('pct_valid', 100 * passed / n if n else np.nan), ('pct_known_pass_registered', 100 * passed / len(f))]:
            check(tag + ':' + field, getattr(r, field), x)
    for r in paired_cont.itertuples(index=False):
        a = frame_for(r.arm, r.drought_percentile, r.region)
        b = frame_for(r.reference, r.drought_percentile, r.region).loc[a.index]
        av, bv = (values(a, r.metric), values(b, r.metric))
        ga = np.isfinite(av)
        gb = np.isfinite(bv)
        g = ga & gb
        dv = av[g] - bv[g]
        qa, qb, qd = (q3(av[g]), q3(bv[g]), q3(dv))
        tag = f'paired_cont:{r.contrast}:{r.drought_percentile}:{r.region}:{r.metric}'
        expected_values = {'n_valid_arm': ga.sum(), 'n_valid_reference': gb.sum(), 'n_pairs': g.sum(), 'n_unpaired': len(a) - g.sum(), 'n_arm_only': np.sum(ga & ~gb), 'n_reference_only': np.sum(gb & ~ga), 'arm_median_paired': qa[1], 'reference_median_paired': qb[1], 'paired_delta_median': qd[1], 'paired_delta_q25': qd[0], 'paired_delta_q75': qd[2], 'n_delta_positive': np.sum(dv > 1e-12), 'n_delta_negative': np.sum(dv < -1e-12), 'n_delta_numerically_equal': np.sum(abs(dv) <= 1e-12)}
        for field, x in expected_values.items():
            check(tag + ':' + field, getattr(r, field), x)
    for r in paired_bin.itertuples(index=False):
        a = frame_for(r.arm, r.drought_percentile, r.region)
        b = frame_for(r.reference, r.drought_percentile, r.region).loc[a.index]
        av, bv = (values(a, r.metric), values(b, r.metric))
        ga = np.isfinite(av)
        gb = np.isfinite(bv)
        g = ga & gb
        new = np.sum(g & (av == 1) & (bv == 0))
        lost = np.sum(g & (av == 0) & (bv == 1))
        tag = f'paired_binary:{r.contrast}:{r.drought_percentile}:{r.region}:{r.metric}'
        expected_values = {'n_valid_arm': ga.sum(), 'n_valid_reference': gb.sum(), 'n_pairs': g.sum(), 'n_unpaired': len(a) - g.sum(), 'n_arm_only': np.sum(ga & ~gb), 'n_reference_only': np.sum(gb & ~ga), 'new_pass': new, 'lost_pass': lost, 'both_pass': np.sum(g & (av == 1) & (bv == 1)), 'neither_pass': np.sum(g & (av == 0) & (bv == 0)), 'net_pp_paired_valid': 100 * (new - lost) / g.sum() if g.any() else np.nan, 'known_paired_net_pp_registered': 100 * (new - lost) / len(a)}
        for field, x in expected_values.items():
            check(tag + ':' + field, getattr(r, field), x)
    for r in confusion.itertuples(index=False):
        f = frame_for(r.arm, r.drought_percentile, r.region)
        o = values(f, f'change_observed_{r.stable_band_pct}pct')
        p = values(f, f'change_predicted_{r.stable_band_pct}pct')
        g = np.isfinite(o) & np.isfinite(p)
        n = int(np.sum(g & (o == r.observed_class) & (p == r.predicted_class)))
        tag = f'confusion:{r.arm}:{r.drought_percentile}:{r.region}:{r.stable_band_pct}:{r.observed_class}:{r.predicted_class}'
        for field, x in [('n', n), ('n_valid', g.sum()), ('n_unevaluated', len(f) - g.sum()), ('pct_valid', 100 * n / g.sum() if g.any() else np.nan), ('pct_registered', 100 * n / len(f))]:
            check(tag + ':' + field, getattr(r, field), x)
    for keys, g in confusion.groupby(['arm', 'drought_percentile', 'region', 'stable_band_pct']):
        assert len(g) == 9 and g.n.sum() == g.n_valid.iloc[0]
    for r in states.itertuples(index=False):
        f = frame_for(r.arm, r.drought_percentile, r.region)
        if r.record_type == 'boolean_state':
            n = int(np.sum(f[r.field].to_numpy(bool) == (r.value == 'True')))
        elif r.record_type == 'numeric_state_flag':
            v = values(f, r.field)
            n = int(np.sum(~np.isfinite(v))) if r.value == 'unknown' else int(np.sum(v == float(r.value)))
        else:
            n = int(np.sum(f[r.field].fillna('missing').astype(str) == str(r.value)))
        check(f'states:{r.arm}:{r.drought_percentile}:{r.region}:{r.field}:{r.value}', r.n, n, exact=True)
    for table, groupname in [(event_counts, 'event_counts'), (volumes, 'volume_descriptors')]:
        for r in table.itertuples(index=False):
            f = frame_for(r.arm, r.drought_percentile, r.region)
            v = values(f, r.metric)
            g = np.isfinite(v)
            vq = q3(v[g])
            for field, x in [('n_valid', g.sum()), ('n_unevaluated', len(f) - g.sum()), ('q25', vq[0]), ('median', vq[1]), ('q75', vq[2])]:
                check(f'{groupname}:{r.arm}:{r.drought_percentile}:{r.region}:{r.metric}:{field}', getattr(r, field), x)
            if groupname == 'event_counts':
                check(f'{groupname}:sum', r.sum_events_over_targets, v[g].sum() if g.any() else np.nan)
    print('ALL_POINT_ESTIMATES_RECOMPUTED', flush=True)
    cache = {}

    def bootstrap(v, ix, kind):
        v = np.asarray(v, float)
        ix = np.asarray(ix, int)
        key = (kind, hashlib.sha256(v.tobytes() + ix.tobytes()).hexdigest())
        if key in cache:
            return cache[key]
        out = np.full(2000, np.nan)
        if len(v):
            order = np.argsort(v, kind='stable') if kind == 'median' else np.arange(len(v))
            vs, ids = (v[order], ix[order])
            for j, cellweights in enumerate(draws):
                w = cellweights[ids]
                total = int(w.sum())
                if not total:
                    continue
                if kind == 'mean':
                    out[j] = np.dot(vs, w) / total
                else:
                    cw = np.cumsum(w)
                    lo = np.searchsorted(cw, (total - 1) // 2, side='right')
                    hi = np.searchsorted(cw, total // 2, side='right')
                    out[j] = (vs[lo] + vs[hi]) / 2
        cache[key] = out
        return out
    bq = read(_PROJECT_ROOT / 'workflows/water_resources/analysis/bootstrap_quantiles.csv')
    b_lookup = {}
    for br in bq.itertuples(index=False):
        ref = br.reference if isinstance(br.reference, str) else None
        key = (br.arm, ref, int(br.drought_percentile), br.region, br.metric, br.estimator)
        assert key not in b_lookup
        b_lookup[key] = br
    for table, paired, continuous in [(single_cont, False, True), (single_bin, False, False), (paired_cont, True, True), (paired_bin, True, False)]:
        for rr in table.itertuples(index=False):
            ref = rr.reference if paired else None
            if rr.ci_status == 'not_computed_by_plan':
                assert np.isnan(rr.ci025) and np.isnan(rr.ci975) and (rr.bootstrap_valid == 0)
                continue
            if continuous:
                estimators = [('median_of_within_target_differences' if paired else 'station_median', 'ci025', 'ci975')]
            elif paired:
                estimators = [('net_percentage_points_among_paired_valid', 'ci025', 'ci975'), ('known_paired_net_percentage_points_registered', 'registered_ci025', 'registered_ci975')]
            else:
                estimators = [('percent_among_metric_valid', 'ci025', 'ci975'), ('known_pass_percent_registered', 'registered_ci025', 'registered_ci975')]
            for estimator, lowfield, highfield in estimators:
                key = (rr.arm, ref, int(rr.drought_percentile), rr.region, rr.metric, estimator)
                br = b_lookup[key]
                check(f'ci_table_linkage:{key}:low', getattr(rr, lowfield), br.q025)
                check(f'ci_table_linkage:{key}:high', getattr(rr, highfield), br.q975)
    core_pairs = {('ridge_Q_D800', 'ridge_Q_D0'), ('ridge_QP_D800', 'ridge_Q_D800'), ('ridge_Q_D0', 'seasonal_baseline'), ('ridge_Q_D800', 'seasonal_baseline'), ('ridge_QP_D800', 'seasonal_baseline')}
    core = bq.region.eq('Global') & pd.Series([(a, b) in core_pairs for a, b in zip(bq.arm, bq.reference)], index=bq.index)
    remaining = bq.index[~core].to_numpy()
    extra = np.random.default_rng(2026102907).choice(remaining, size=min(20, len(remaining)), replace=False)
    selected = bq.loc[np.r_[bq.index[core], extra]]
    checks = []
    for r in selected.itertuples(index=False):
        a = frame_for(r.arm, r.drought_percentile, r.region)
        v = values(a, r.metric)
        ix = a.spatial_cell.map(cellmap).to_numpy(int)
        if isinstance(r.reference, str):
            b = frame_for(r.reference, r.drought_percentile, r.region).loc[a.index]
            other = values(b, r.metric)
            valid = np.isfinite(v) & np.isfinite(other)
            if r.estimator == 'known_paired_net_percentage_points_registered':
                z = np.zeros(len(a))
                z[valid] = v[valid] - other[valid]
                kind = 'mean'
                factor = 100
            else:
                z = v[valid] - other[valid]
                ix = ix[valid]
                kind = 'median' if r.estimator == 'median_of_within_target_differences' else 'mean'
                factor = 1 if kind == 'median' else 100
        else:
            valid = np.isfinite(v)
            if r.estimator == 'known_pass_percent_registered':
                z = np.where(valid, v, 0)
                kind = 'mean'
                factor = 100
            else:
                z = v[valid]
                ix = ix[valid]
                kind = 'median' if r.estimator == 'station_median' else 'mean'
                factor = 1 if kind == 'median' else 100
        bv = bootstrap(z, ix, kind) * factor
        good = np.isfinite(bv)
        qq = np.quantile(bv[good], [0.025, 0.25, 0.5, 0.75, 0.975]) if good.any() else np.full(5, np.nan)
        tag = f'bootstrap:{r.arm}:{r.reference}:{r.drought_percentile}:{r.region}:{r.metric}:{r.estimator}'
        check(tag + ':valid', r.bootstrap_valid, int(good.sum()), exact=True)
        for field, x in zip(['q025', 'q25', 'q50', 'q75', 'q975'], qq):
            check(tag + ':' + field, getattr(r, field), x)
        checks.append({'arm': r.arm, 'reference': r.reference if isinstance(r.reference, str) else None, 'percentile': int(r.drought_percentile), 'region': r.region, 'metric': r.metric, 'estimator': r.estimator, 'replicates': int(good.sum())})
    print('INDEPENDENT_SPATIAL_CI_CHECKS_COMPLETE', len(checks), flush=True)
    raw = values(d, 'drought_hss')
    chance = values(d, 'drought_hss_chance')
    excess = values(d, 'drought_hss_excess')
    g = np.isfinite(raw)
    assert np.array_equal(g, np.isfinite(chance)) and np.array_equal(g, np.isfinite(excess))
    np.testing.assert_allclose(raw[g], chance[g] + excess[g], rtol=1e-12, atol=1e-12)
    ratio = values(d, 'deficit_ratio')
    miss = values(d, 'deficit_complete_miss')
    assert np.array_equal(ratio == 0, miss == 1)
    baseline = d[d.arm == 'seasonal_baseline']
    xb = values(baseline, 'drought_hss_excess')
    gb = np.isfinite(xb)
    assert np.all(np.abs(xb[gb]) < 1e-12)
    flags = {name: int(pd.to_numeric(d[name], errors='coerce').eq(1).sum()) for name in ['drought_observed_none', 'drought_observed_all', 'deficit_complete_miss', 'deficit_false_positive', 'water_observed_zero', 'history_mean_zero']}
    q20 = d[d.drought_percentile == 20].set_index(['row', 'arm']).sort_index()
    q10 = d[d.drought_percentile == 10].set_index(['row', 'arm']).sort_index()
    for name in [c for c in d if c.startswith('water_') or c.startswith('change_') or c.startswith('period_mean_change_')]:
        if name.endswith('status') or name.startswith('change_category'):
            assert q20[name].fillna('NA').astype(str).equals(q10[name].fillna('NA').astype(str))
        else:
            np.testing.assert_allclose(pd.to_numeric(q20[name], errors='coerce'), pd.to_numeric(q10[name], errors='coerce'), rtol=0, atol=0, equal_nan=True)
    report = {'status': 'PASS' if not ERRORS else 'FAIL', 'created_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Read-only independent statistical summary audit, no prediction/metric recomputation; all point rows and fixed core paired CIs plus 20 random reported CIs.', 'hashes': {'per_target': sha(INPUT), 'summary_receipt': sha(_PROJECT_ROOT / 'workflows/water_resources/analysis/SUMMARY_QA.json'), 'draws': sha(DRAW), 'metrics': sha(_PROJECT_ROOT / 'workflows/water_resources/metrics.py'), 'schema': sha(_PROJECT_ROOT / 'workflows/water_resources/SCHEMA.json'), 'audit_script': sha(_PROJECT_ROOT / 'workflows/water_resources/audit/audit_summary.py')}, 'metrics_version': current_schema['version'], 'output_hashes': {p.name: sha(p) for p in OUT.glob('*.csv')}, 'primary_targets': 8083, 'per_target_rows': len(d), 'arms': 11, 'percentiles': [20, 10], 'bootstrap': {'draws': 2000, 'cells': 274, 'seed': 20261029, 'exact_replay': True, 'selected_rows': len(checks), 'core_rows': int(core.sum()), 'additional_random_rows': len(extra), 'checking_logic': 'Integer cell weights replicated per station, independently sorted and searched for the two central order statistics; mean separately weighted.'}, 'checks_per_family': COUNTS, 'errors': ERRORS, 'checked_ci_rows': checks, 'state_counts_across_all_arms_percentiles_not_unique_targets': flags, 'verified_reporting_rules': ['All planned single-arm and paired point estimates, both denominators, counts and every 3x3 direction cell were independently recomputed.', 'Paired medians summarize within-target differences, not differences of arm medians.', 'Ordinary HSS, conditional chance and excess are separate fields; excess is not relabelled ordinary HSS.', 'Zero deficit ratios remain; no-event/all-event and zero denominators remain explicit state counts.', 'Known-pass registered proportions and paired-valid proportions are distinct, without treating unknown outcomes as observed failures.', 'Identical spatial draw weights used across arms, metrics and calendar-percentile sensitivities.', 'All 3x3 direction cases and all four categories retained; q10/q20 do not alter water or mean-change results.']}
    (_PROJECT_ROOT / 'workflows/water_resources/audit/INDEPENDENT_SUMMARY_QA.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')
    print(json.dumps({'status': report['status'], 'checks': sum(COUNTS.values()), 'ci_rows': len(checks), 'errors': ERRORS}, ensure_ascii=False), flush=True)
    if ERRORS:
        raise SystemExit(1)
if __name__ == '__main__':
    main()
