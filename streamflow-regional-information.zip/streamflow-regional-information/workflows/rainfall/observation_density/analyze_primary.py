from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[k] = '1'
ROOT = _PROJECT_ROOT / 'workflows/rainfall/observation_density'
CODE = _PROJECT_ROOT
pass
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
OUT = _PROJECT_ROOT / 'workflows/rainfall/observation_density/primary'
OUT.mkdir(exist_ok=True)
IN = _PROJECT_ROOT / 'workflows/rainfall/observation_density/data/paired_rainfall_density_cases.csv.gz'
assert (_PROJECT_ROOT / 'workflows/rainfall/observation_density/PROTOCOL.md').exists()
data = pd.read_csv(IN, keep_default_na=False, na_values=[''])
data = data[data.P_available].copy()
data.loc[~np.isfinite(data.official_estimated_area_km2) | (data.official_estimated_area_km2 <= 0), 'official_estimated_area_km2'] = np.nan
assert data.groupby(['D', 'method']).size().eq(8083).all()
data['delta_success_NSE'] = data.QP_nse_success.astype(int) - data.Q_nse_success.astype(int)
data['new_success_NSE'] = data.QP_nse_success & ~data.Q_nse_success
data['lost_success_NSE'] = data.Q_nse_success & ~data.QP_nse_success
cells = np.sort(data.spatial_cell.unique())
mapping = {v: i for i, v in enumerate(cells)}
data['cell_index'] = data.spatial_cell.map(mapping)
assert len(cells) == 274
rng = np.random.default_rng(20261029)
draws = rng.multinomial(len(cells), np.repeat(1 / len(cells), len(cells)), size=2000).astype(np.int16)
np.savez_compressed(_PROJECT_ROOT / 'workflows/rainfall/observation_density/primary/bootstrap_draws.npz', spatial_cells=cells.astype(str), draws=draws)

def interval(x):
    a = np.asarray(x)
    return tuple(np.nanquantile(a, [0.025, 0.975])) if np.isfinite(a).any() else (np.nan, np.nan)

def medboot(v, ix):
    v = np.asarray(v, float)
    ix = np.asarray(ix, int)
    order = np.argsort(v)
    v = v[order]
    ix = ix[order]
    z = np.full(len(draws), np.nan)
    for st in range(0, len(draws), 100):
        w = draws[st:st + 100, ix].astype(np.int32)
        n = w.sum(1)
        c = w.cumsum(1)
        lo = ((n - 1) // 2 + 1)[:, None]
        hi = (n // 2 + 1)[:, None]
        a = np.argmax(c >= lo, axis=1)
        b = np.argmax(c >= hi, axis=1)
        z[st:st + len(w)] = np.where(n > 0, (v[a] + v[b]) / 2, np.nan)
    return z

def meanboot(v, ix):
    su = np.bincount(ix, weights=v, minlength=len(cells))
    ct = np.bincount(ix, minlength=len(cells))
    n = draws @ ct
    return np.divide(draws @ su, n, out=np.full(len(draws), np.nan), where=n > 0)

def corrboot(x, y, ix):
    x = np.asarray(x)
    y = np.asarray(y)
    ix = np.asarray(ix, int)
    if len(x) < 3 or np.unique(x).size < 2 or np.unique(y).size < 2:
        return np.full(len(draws), np.nan)
    out = np.full(len(draws), np.nan)
    orders = []
    for a in (x, y):
        o = np.argsort(a, kind='stable')
        starts = np.r_[0, np.flatnonzero(np.diff(a[o]) != 0) + 1]
        group = np.repeat(np.arange(len(starts)), np.diff(np.r_[starts, len(a)]))
        inv = np.argsort(o)
        orders.append((o, starts, group, inv))
    for st in range(0, len(draws), 100):
        w = draws[st:st + 100, ix].astype(float)
        n = w.sum(1)
        ranks = []
        for o, starts, group, inv in orders:
            gw = np.add.reduceat(w[:, o], starts, axis=1)
            rr = gw.cumsum(1) - gw * 0.5 + 0.5
            ranks.append(rr[:, group][:, inv] - (n[:, None] + 1) * 0.5)
        a, b = ranks
        num = (w * a * b).sum(1)
        den = np.sqrt((w * a * a).sum(1) * (w * b * b).sum(1))
        out[st:st + len(w)] = np.divide(num, den, out=np.full(len(w), np.nan), where=den > 0)
    return out

def group_summary(df, label, meta=None):
    meta = meta or {}
    out = []
    for metric in ('NSE', 'r'):
        ok = df.Q_valid_truth & df.QP_valid_truth & np.isfinite(df['Q_' + metric]) & np.isfinite(df['QP_' + metric])
        d = df.loc[ok]
        v = d['delta_' + metric].to_numpy()
        ix = d.cell_index.to_numpy(int)
        if len(d):
            bs = medboot(v, ix)
            lo, hi = interval(bs)
            row = dict(group=label, metric=metric, n_registered=len(df), n_pairs=len(d), n_cells=d.spatial_cell.nunique(), Q_median=d['Q_' + metric].median(), QP_median=d['QP_' + metric].median(), delta_median=np.median(v), ci025=lo, ci975=hi, improved=int((v > 1e-12).sum()), worsened=int((v < -1e-12).sum()), **meta)
            out.append(row)
    bs = meanboot(df.delta_success_NSE.to_numpy(float), df.cell_index.to_numpy(int)) * 100
    lo, hi = interval(bs)
    out.append(dict(group=label, metric='NSE_success_pp', n_registered=len(df), n_pairs=len(df), n_cells=df.spatial_cell.nunique(), Q_median=100 * df.Q_nse_success.mean(), QP_median=100 * df.QP_nse_success.mean(), delta_median=100 * df.delta_success_NSE.mean(), ci025=lo, ci975=hi, new_success=int(df.new_success_NSE.sum()), lost_success=int(df.lost_success_NSE.sum()), **meta))
    return out
regions = ['Global', 'Europe', 'Asia', 'Africa', 'NorthAmerica', 'SouthAmerica', 'Oceania', 'Other']
summary = []
for (method, D), df in data.groupby(['method', 'D']):
    for reg in regions:
        g = df if reg == 'Global' else df[df.continent == reg]
        if len(g):
            summary += group_summary(g, reg, dict(D=D, method=method))
pd.DataFrame(summary).to_csv(_PROJECT_ROOT / 'workflows/rainfall/observation_density/primary/region_distance_paired_effects.csv', index=False)
print('REGION_DISTANCE_DONE', flush=True)
features = ['eligible_near800', 'eligible_remaining800', 'selected_G_distance_median_km', 'selected_G_historical_r_weighted_mean', 'p_H_mean_mm_per_month', 'p_H_cv', 'p_H_seasonality_cv', 'official_estimated_area_km2']
extra = _PROJECT_ROOT / 'workflows/rainfall/observation_density/exposures/exposure_summary.csv'
if extra.exists():
    ex = pd.read_csv(extra, keep_default_na=False, na_values=[''])
    assert ex.row.is_unique
    ex = ex.rename(columns={'within800_mean': 'reporters_near800_mean', 'annulus800_1500_mean': 'reporters_ring800_1500_mean', 'beyond800_mean': 'reporters_far800_mean'})
    data = data.merge(ex.drop(columns=[x for x in ex if x != 'row' and x in data]), on='row', how='left', validate='many_to_one')
    features += [x for x in ['reporters_near800_mean', 'reporters_ring800_1500_mean', 'reporters_far800_mean'] if x in data]
cuts = []
quartiles = []
corr = []
compositions = []
base = data[(data.D == 800) & (data.method == 'ridge')].copy()
for f in features:
    v = pd.to_numeric(base[f], errors='coerce')
    finite = np.isfinite(v)
    q = np.unique(np.quantile(v[finite], [0.25, 0.5, 0.75]))
    cuts.append(dict(feature=f, cutpoints=q.tolist(), n_finite=int(finite.sum())))
    labels = np.where(finite, np.searchsorted(q, v, side='left') + 1, 0)
    base['bin_' + f] = labels
    for b in sorted(np.unique(labels)):
        g = base[labels == b]
        quartiles += group_summary(g, f'Q{b}' if b else 'Unknown', dict(feature=f, minimum=g[f].min(), maximum=g[f].max()))
        for reg, n in g.continent.value_counts().items():
            compositions.append(dict(feature=f, bin=int(b), region=reg, n=int(n), pct=100 * n / len(g)))
    for reg in ['Global', 'Europe', 'Asia', 'Africa', 'NorthAmerica', 'SouthAmerica', 'Oceania']:
        d = base if reg == 'Global' else base[base.continent == reg]
        for met in ['NSE', 'r']:
            ok = d.Q_valid_truth & d.QP_valid_truth & np.isfinite(d['Q_' + met]) & np.isfinite(d['QP_' + met]) & np.isfinite(d[f])
            g = d[ok]
            x = g[f].to_numpy()
            y = g['delta_' + met].to_numpy()
            if len(g) > 2 and np.unique(x).size > 1 and (np.unique(y).size > 1):
                value = spearmanr(x, y).statistic
                lo, hi = interval(corrboot(x, y, g.cell_index.to_numpy(int)))
                corr.append(dict(feature=f, region=reg, metric=met, n=len(g), n_cells=g.spatial_cell.nunique(), spearman=value, ci025=lo, ci975=hi))
    print('FEATURE_DONE', f, flush=True)
pd.DataFrame(quartiles).to_csv(_PROJECT_ROOT / 'workflows/rainfall/observation_density/primary/D800_quartile_effects.csv', index=False)
pd.DataFrame(corr).to_csv(_PROJECT_ROOT / 'workflows/rainfall/observation_density/primary/D800_feature_spearman.csv', index=False)
pd.DataFrame(compositions).to_csv(_PROJECT_ROOT / 'workflows/rainfall/observation_density/primary/D800_quartile_region_composition.csv', index=False)
(_PROJECT_ROOT / 'workflows/rainfall/observation_density/primary/D800_quartile_cutpoints.json').write_text(json.dumps(cuts, indent=2), encoding='utf8')
inter = []
intercorr = []
for method, dm in data.groupby('method'):
    z = dm[dm.D == 0].set_index('row')
    for D in [100, 300, 800]:
        g = dm[dm.D == D].set_index('row').loc[z.index].copy()
        g['change_selected_distance'] = g.selected_G_distance_median_km - z.selected_G_distance_median_km
        g['removed_eligible'] = z['eligible_N_D0'] - g['eligible_N_D' + str(D)]
        for met in ['NSE', 'r']:
            g['interaction_' + met] = g['delta_' + met] - z['delta_' + met]
        g['interaction_success'] = g.delta_success_NSE - z.delta_success_NSE
        for reg in regions:
            w = g if reg == 'Global' else g[g.continent == reg]
            if not len(w):
                continue
            iz = z.loc[w.index]
            for met in ['NSE', 'r']:
                ok = w.Q_valid_truth & w.QP_valid_truth & iz.Q_valid_truth & iz.QP_valid_truth & np.isfinite(w['interaction_' + met]) & np.isfinite(w['Q_' + met]) & np.isfinite(w['QP_' + met]) & np.isfinite(iz['Q_' + met]) & np.isfinite(iz['QP_' + met])
                a = w[ok]
                v = a['interaction_' + met].to_numpy()
                ix = a.cell_index.to_numpy(int)
                if not len(a):
                    continue
                lo, hi = interval(medboot(v, ix))
                inter.append(dict(method=method, D=D, region=reg, metric=met, n_registered=len(w), n_pairs=len(a), paired_interaction_median=np.median(v), ci025=lo, ci975=hi))
                if D == 800 and method == 'ridge':
                    for f in ['removed_eligible', 'change_selected_distance']:
                        finite = np.isfinite(a[f])
                        aa = a[finite]
                        xx = aa[f].to_numpy()
                        yy = aa['interaction_' + met].to_numpy()
                        if len(aa) > 2 and np.unique(xx).size > 1:
                            l, h = interval(corrboot(xx, yy, aa.cell_index.to_numpy(int)))
                            intercorr.append(dict(region=reg, metric=met, feature=f, n=len(aa), spearman=spearmanr(xx, yy).statistic, ci025=l, ci975=h))
            lo, hi = interval(100 * meanboot(w.interaction_success.to_numpy(float), w.cell_index.to_numpy(int)))
            inter.append(dict(method=method, D=D, region=reg, metric='NSE_success_pp', n_registered=len(w), n_pairs=len(w), paired_interaction_median=100 * w.interaction_success.mean(), ci025=lo, ci975=hi))
pd.DataFrame(inter).to_csv(_PROJECT_ROOT / 'workflows/rainfall/observation_density/primary/within_target_rainfall_interaction.csv', index=False)
pd.DataFrame(intercorr).to_csv(_PROJECT_ROOT / 'workflows/rainfall/observation_density/primary/within_target_interaction_density_relationship.csv', index=False)
if 'P_geometry_warning_mask' in base:
    clean = base[~base.P_geometry_warning_mask.fillna(True).astype(bool)]
    rows = []
    for reg in regions:
        d = clean if reg == 'Global' else clean[clean.continent == reg]
        if len(d):
            rows += group_summary(d, reg, dict(sensitivity='without_existing_geometry_warning'))
    pd.DataFrame(rows).to_csv(_PROJECT_ROOT / 'workflows/rainfall/observation_density/primary/geometry_warning_sensitivity.csv', index=False)
unit = np.array([1.0, 2.0, 7.0, 11.0])
assert np.median(unit) == 4.5
t = np.array([0.0, 0.0, 1.0, 3.0, 4.0])
y = np.array([3.0, 2.0, 2.0, 1.0, 0.0])
ix = np.arange(5)
old = draws.copy()
draws = np.ones((1, len(cells)), dtype=np.int16)
assert abs(corrboot(t, y, ix)[0] - spearmanr(t, y).statistic) < 1e-12
assert medboot(unit, np.arange(4))[0] == np.median(unit)
draws = old
globalref = pd.DataFrame(summary)
check = globalref[(globalref.method == 'ridge') & (globalref.D == 800) & (globalref.metric == 'NSE_success_pp')]
assert int(check.loc[check.group == 'Europe', 'new_success'].iloc[0]) - int(check.loc[check.group == 'Europe', 'lost_success'].iloc[0]) == 268
assert abs(check.loc[check.group == 'Global', 'delta_median'].iloc[0] - 609 / 8083 * 100) < 1e-12
qa = dict(status='PASS', input_sha256=hashlib.sha256(IN.read_bytes()).hexdigest(), bootstrap_seed=20261029, replicates=2000, spatial_cells=len(cells), cohort=8083, retrospective=True, no_refitting=True, preserves_all_finite_valid_truth_pairs=True, rank_bootstrap='Exact integer-weighted ranks with ties recomputed under each block draw', no_cloud_or_manuscript_changes=True)
(_PROJECT_ROOT / 'workflows/rainfall/observation_density/primary/PRIMARY_QA.json').write_text(json.dumps(qa, indent=2), encoding='utf8')
print('PRIMARY_DONE', flush=True)
