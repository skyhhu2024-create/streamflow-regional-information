"""Compute original-GSIM basin rainfall candidates without automatic scientific admission."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))

def _release_path(kind, relative):
    import os as _release_os
    from pathlib import Path as _ReleasePath
    code_root = _PROJECT_ROOT
    root = code_root if kind == 'code' else _ReleasePath(_release_os.environ.get('STREAMFLOW_DATA_ROOT', str(code_root.parent / 'inputs')))
    return str(root / relative)
from pathlib import Path
import math, json, hashlib, warnings
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import pandas as pd
import shapefile
import shapely
from shapely.geometry import shape
from shapely.ops import transform
from scipy import sparse
from pyproj import Transformer
from workflows.rainfall.global_inputs.precipitation_inventory.extract_available_early_precipitation import extract
OUT = _PROJECT_ROOT / 'workflows/rainfall/global_inputs/precipitation_inventory'
P = _PROJECT_ROOT / 'data'
W = _PROJECT_ROOT / 'data/meteorology'
FWD = Transformer.from_crs(4326, 6933, always_xy=True).transform

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def build_one(args):
    i, r = args
    rec = {'station_id': r.station_id, 'original_quality': r.original_GSIM_quality, 'priority199': bool(r.late_period_priority199), 'native_polygon_path': r.native_GSIM_polygon_path, 'admission': 'NOT_ADMITTED_original_GSIM_boundary_uncertainty_retained'}
    try:
        reader = shapefile.Reader(r.native_GSIM_polygon_path)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            geoms = [shape(s.__geo_interface__) for s in reader.iterShapes()]
        geo = shapely.union_all(geoms)
        rec['original_geometry_valid'] = bool(geo.is_valid)
        rec['geometry_repair_applied'] = not geo.is_valid
        if not geo.is_valid:
            geo = shapely.make_valid(geo)
        if geo.geom_type == 'GeometryCollection':
            geo = shapely.union_all([g for g in geo.geoms if g.geom_type in ['Polygon', 'MultiPolygon']])
        minx, miny, maxx, maxy = geo.bounds
        if maxx - minx > 180 or miny < -85.9 or maxy > 85.9 or (minx < -180) or (maxx > 180):
            raise ValueError('dateline_or_polar_geometry_requires_separate_exact_processing')
        geom = transform(FWD, geo)
        xx = np.arange(math.ceil((minx - 0.05) * 10 - 1e-08), math.floor((maxx + 0.05) * 10 + 1e-08) + 1)
        yy = np.arange(max(0, math.ceil((90 - maxy - 0.05) * 10 - 1e-08)), min(1800, math.floor((90 - miny + 0.05) * 10 + 1e-08)) + 1)
        if len(xx) * len(yy) > 4000000:
            raise ValueError('large_exact_geometry_requires_chunked_weight_build')
        gy, gx = np.meshgrid(yy, xx, indexing='ij')
        ix = gx.ravel()
        iy = gy.ravel()
        lon = ix / 10
        lat = 90 - iy / 10
        x0, y0 = FWD(np.maximum(lon - 0.05, -180), np.maximum(lat - 0.05, -90))
        x1, y1 = FWD(np.minimum(lon + 0.05, 180), np.minimum(lat + 0.05, 90))
        cells = shapely.box(x0, y0, x1, y1)
        hit = shapely.intersects(cells, geom)
        areas = shapely.area(shapely.intersection(cells[hit], geom))
        cols = iy[hit] * 3600 + ix[hit] % 3600
        keep = areas > 0
        areas = areas[keep]
        cols = cols[keep]
        coverage = float(areas.sum() / geom.area)
        assert abs(coverage - 1) < 1e-05, coverage
        rec.update({'status': 'EXACT_NATIVE_POLYGON_GRID_WEIGHTS_COMPUTED_not_physical_certification', 'equal_area_polygon_km2': geom.area / 1000000.0, 'geometric_grid_coverage': coverage, 'grid_cells': len(cols), 'source_shp_sha256': sha(r.native_GSIM_polygon_path)})
        return (i, rec, cols.astype(np.int32), (areas / areas.sum()).astype(np.float32))
    except Exception as e:
        rec.update({'status': 'PENDING_GEOMETRY_PROCESSING', 'error_type': type(e).__name__, 'error': str(e)[:200]})
        return (i, rec, np.array([], np.int32), np.array([], np.float32))

def main():
    q = pd.read_csv(_PROJECT_ROOT / 'workflows/rainfall/global_inputs/precipitation_inventory/missing_cache1072_boundary_queue.csv')
    wp = _PROJECT_ROOT / 'workflows/rainfall/global_inputs/precipitation_inventory/native1072_weights_NOT_ADMITTED.npz'
    if not wp.exists():
        rows = []
        cols = []
        vals = []
        recs = []
        with ThreadPoolExecutor(max_workers=4) as pool:
            for i, rec, c, v in pool.map(build_one, enumerate(q.itertuples(index=False))):
                rows.append(np.full(len(c), i, np.int32))
                cols.append(c)
                vals.append(v)
                recs.append(rec)
                if (i + 1) % 200 == 0:
                    print('native weights', i + 1, flush=True)
        mat = sparse.coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(len(q), 1801 * 3600)).tocsr()
        sparse.save_npz(wp, mat)
        pd.DataFrame(recs).to_csv(_PROJECT_ROOT / 'workflows/rainfall/global_inputs/precipitation_inventory/native1072_weight_QA_NOT_ADMITTED.csv', index=False, encoding='utf-8-sig')
    mat = sparse.load_npz(wp).astype(np.float64)
    wh = sha(wp)
    annual = _PROJECT_ROOT / 'workflows/rainfall/global_inputs/precipitation_inventory/annual_native1072_NOT_ADMITTED'
    annual.mkdir(exist_ok=True)
    paths = []
    rawroot = _PROJECT_ROOT / 'workflows/rainfall/global_inputs/acquisition/era5_land_early'
    for folder in sorted(rawroot.iterdir()):
        state = folder / 'request_state.json'
        if not state.is_file():
            continue
        st = json.loads(state.read_text(encoding='utf8'))
        if st.get('status') == 'validated':
            p = folder / f'era5_land_monthly_tp_{folder.name}.nc'
            if p.exists():
                paths.append((folder.name, p, st['validation']['sha256']))
    for year in range(1994, 2016):
        p = W / f'收到的数据/ERA5_Land/{year}/era5_land_monthly_{year}.nc'
        paths.append((str(year), p, None))
    x = np.full((len(q), 435), np.nan, np.float32)
    ps = pd.period_range('1979-10', '2015-12', freq='M').astype(str).to_numpy()
    pos = {m: i for i, m in enumerate(ps)}
    for year, p, expected in paths:
        target = annual / f'tp_{year}.npz'
        if target.exists():
            z = np.load(target, allow_pickle=False)
            assert str(z['weight_sha256']) == wh
            months = z['periods'].astype(str)
            v = z['tp_mm_month']
            z.close()
        else:
            rh = sha(p)
            if expected:
                assert rh == expected
            months, v, c = extract(p, mat)
            np.savez_compressed(target, station_ids=q.station_id.to_numpy(dtype=str), periods=months.astype(str), tp_mm_month=v, valid_area_fraction=c, units=np.array('mm/month'), weight_sha256=np.array(wh), raw_sha256=np.array(rh), admission=np.array('NOT_ADMITTED_original_GSIM_boundary_uncertainty_retained'))
            print('native extracted', year, 'finite stationmonths', int(np.isfinite(v).sum()), flush=True)
        for j, m in enumerate(months):
            if m in pos:
                x[:, pos[m]] = v[:, j]
    np.savez_compressed(_PROJECT_ROOT / 'workflows/rainfall/global_inputs/precipitation_inventory/native1072_tp197910_201512_PARTIAL_NOT_ADMITTED.npz', station_ids=q.station_id.to_numpy(dtype=str), periods=ps.astype(str), tp_mm_month=x, units=np.array('mm/month'), admission=np.array('NOT_ADMITTED_original_GSIM_boundary_uncertainty_retained'))
    complete = []
    for i, r in q.iterrows():
        a = int(r.required_start_index_1980) + 3
        b = int(r.gap_end) + 3
        complete.append(bool(np.isfinite(x[i, a:b]).all()))
    late = np.isfinite(x[:, 171:]).all(axis=1)
    report = {'candidate_native_polygons': len(q), 'nonzero_weight_rows': int((np.asarray(mat.sum(axis=1)).ravel() > 0).sum()), 'complete_1994_2015_tp_candidates': int(late.sum()), 'priority199_complete_tp_candidates': int((late & q.late_period_priority199.to_numpy()).sum()), 'current_required_window_complete_candidates': sum(complete), 'raw_years_extracted': [y for y, _, _ in paths], 'admitted_primary_cases': 0, 'all_boundary_quality_flags_retained': True, 'source_products_mixed': False, 'target_flow_or_scores_read': False}
    (_PROJECT_ROOT / 'workflows/rainfall/global_inputs/precipitation_inventory/NATIVE1072_PRECIPITATION_CANDIDATES.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
