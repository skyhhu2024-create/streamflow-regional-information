"""
Quantile mapping / CDF matching (thesis 5.5.2).

Correct mapping:  x_corr = F_obs^{-1}( F_mod(x) )
  - F_obs : empirical distribution of the target station's visible (non-gap) observations
            (target; provided by fit; leakage-safe).
  - F_mod : empirical distribution of the model's own predictions (source; provided to
            transform via pred_ref).
Re-maps the model prediction's relative rank onto the observed distribution, restoring
compressed variance and distribution tails (flood highs + low flows).

NOTE: pred_ref (the model's predicted distribution at this station) MUST be supplied,
otherwise F_mod is undefined and the mapping degenerates to identity. In practice
pred_ref = all imputed-month model predictions at the station.
"""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import numpy as np

def _ecdf_rank(x, sorted_ref):
    idx = np.searchsorted(sorted_ref, x, side='right')
    return (idx + 0.5) / (len(sorted_ref) + 1.0)

class StationQuantileMapper:

    def __init__(self, by_month=True, min_samples_month=24, min_samples_global=12):
        self.by_month = by_month
        self.min_m = min_samples_month
        self.min_g = min_samples_global
        self.obs_global_ = None
        self.obs_month_ = {}
        self.fitted_ = False

    def fit(self, obs_flow, months):
        obs = np.asarray(obs_flow, dtype=np.float64)
        months = np.asarray(months)
        ok = np.isfinite(obs)
        g = np.sort(obs[ok])
        self.obs_global_ = g if g.size >= self.min_g else None
        if self.by_month:
            for m in range(1, 13):
                v = np.sort(obs[ok & (months == m)])
                if v.size >= self.min_m:
                    self.obs_month_[m] = v
        self.fitted_ = True
        return self

    def transform(self, pred_flow, months, pred_ref=None, pred_ref_months=None):
        if not self.fitted_ or self.obs_global_ is None:
            return np.asarray(pred_flow, dtype=np.float64)
        pred = np.asarray(pred_flow, dtype=np.float64)
        ref = np.asarray(pred_ref if pred_ref is not None else pred_flow, dtype=np.float64)
        ref = ref[np.isfinite(ref)]
        if ref.size < self.min_g:
            return pred
        ref_sorted_global = np.sort(ref)
        ref_month_sorted = {}
        if self.by_month and pred_ref_months is not None:
            prm = np.asarray(pred_ref_months)
            if ref.size == prm.size:
                for m in range(1, 13):
                    v = np.sort(ref[prm == m])
                    if v.size >= self.min_m:
                        ref_month_sorted[m] = v
        out = pred.copy()
        for i in range(len(pred)):
            x = pred[i]
            m = int(months[i])
            if not np.isfinite(x):
                continue
            obs_ref = self.obs_month_.get(m) if self.by_month else None
            mod_ref = ref_month_sorted.get(m) if self.by_month else None
            if obs_ref is None:
                obs_ref = self.obs_global_
            if mod_ref is None:
                mod_ref = ref_sorted_global
            p = _ecdf_rank(x, mod_ref)
            out[i] = np.quantile(obs_ref, min(max(p, 0.0), 1.0))
        return out
