"""
Deep baselines for monthly streamflow gap imputation, under the SAME leakage-safe
protocol and per-station evaluation across the three architectures.

All models consume the collate batch and output {"z_hat": [B,L]} in anomaly space,
plus a native heteroscedastic {"log_var": [B,L]} head (used only when trained with the
Gaussian-NLL term via --uncertainty; harmless otherwise). A shared timeline
[pre-context | gap | post-context] of width W = P + L + P is built; gap positions carry
value 0 with mask 0 (to be imputed). use_donor toggles whether donor synchronous
information is fed (single-station vs multi-station variants).

Models: lstm (bidirectional seq2seq), brits (bi-RNN imputation), saits (self-attention
imputation).
"""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import torch
import torch.nn as nn
import torch.nn.functional as F

def build_timeline(batch, use_donor):
    """Return per-step features over W=P+L+P and the gap slice indices.

    feats: [B, W, F]  with F = 4 (+1 if use_donor)
    gap slice: [P : P+L]
    """
    pre = batch['ctx_pre_z']
    prem = batch['ctx_pre_mask']
    post = batch['ctx_post_z']
    postm = batch['ctx_post_mask']
    phase = batch['gap_phase']
    B, P = pre.shape
    L = phase.shape[1]
    z = torch.zeros(B, L, device=pre.device, dtype=pre.dtype)
    val = torch.cat([pre, z, post], dim=1)
    mask = torch.cat([prem, z, postm], dim=1)
    ph = torch.zeros(B, P + L + P, 2, device=pre.device, dtype=pre.dtype)
    ph[:, P:P + L, :] = phase
    feats = [val.unsqueeze(-1), mask.unsqueeze(-1), ph]
    if use_donor:
        dg = batch['donor_gap_z']
        dm = batch['donor_mask']
        dw = batch['donor_weight']
        wexp = dw.unsqueeze(-1) * dm
        denom = wexp.sum(1).clamp(min=1e-06)
        donor_agg_gap = (wexp * dg).sum(1) / denom
        donor_agg = torch.zeros(B, P + L + P, device=pre.device, dtype=pre.dtype)
        donor_agg[:, P:P + L] = donor_agg_gap
        feats.append(donor_agg.unsqueeze(-1))
    return (torch.cat(feats, dim=-1), P, L)

class LSTMSeq2Seq(nn.Module):
    """Bidirectional LSTM seq2seq imputer."""

    def __init__(self, hidden=64, use_donor=False):
        super().__init__()
        self.use_donor = use_donor
        in_dim = 5 if use_donor else 4
        self.lstm = nn.LSTM(in_dim, hidden, num_layers=2, batch_first=True, bidirectional=True, dropout=0.0)
        self.head = nn.Linear(2 * hidden, 1)
        self.head_lv = nn.Linear(2 * hidden, 1)

    def forward(self, batch):
        feats, P, L = build_timeline(batch, self.use_donor)
        h, _ = self.lstm(feats)
        z = self.head(h).squeeze(-1)
        lv = self.head_lv(h).squeeze(-1)
        return {'z_hat': z[:, P:P + L], 'log_var': lv[:, P:P + L]}

class BRITS(nn.Module):
    """Compact bidirectional RNN imputation (forward + backward, averaged)."""

    def __init__(self, hidden=64, use_donor=False):
        super().__init__()
        self.use_donor = use_donor
        in_dim = 5 if use_donor else 4
        self.fwd = nn.LSTM(in_dim, hidden, batch_first=True)
        self.bwd = nn.LSTM(in_dim, hidden, batch_first=True)
        self.hf = nn.Linear(hidden, 1)
        self.hb = nn.Linear(hidden, 1)
        self.lv = nn.Linear(2 * hidden, 1)

    def forward(self, batch):
        feats, P, L = build_timeline(batch, self.use_donor)
        hf, _ = self.fwd(feats)
        hb, _ = self.bwd(torch.flip(feats, dims=[1]))
        hb = torch.flip(hb, dims=[1])
        zf = self.hf(hf).squeeze(-1)
        zb = self.hb(hb).squeeze(-1)
        z = 0.5 * (zf + zb)
        lv = self.lv(torch.cat([hf, hb], dim=-1)).squeeze(-1)
        out = {'z_hat': z[:, P:P + L], 'log_var': lv[:, P:P + L]}
        out['z_self_f'] = zf[:, P:P + L]
        out['z_self_b'] = zb[:, P:P + L]
        return out

class SAITS(nn.Module):
    """Compact self-attention imputation (transformer encoder over the timeline)."""

    def __init__(self, hidden=64, heads=4, layers=2, use_donor=False):
        super().__init__()
        self.use_donor = use_donor
        in_dim = 5 if use_donor else 4
        self.proj = nn.Linear(in_dim, hidden)
        enc = nn.TransformerEncoderLayer(d_model=hidden, nhead=heads, dim_feedforward=2 * hidden, batch_first=True)
        self.enc = nn.TransformerEncoder(enc, num_layers=layers)
        self.head = nn.Linear(hidden, 1)
        self.head_lv = nn.Linear(hidden, 1)
        self.pos = nn.Parameter(torch.zeros(1, 512, hidden))

    def forward(self, batch):
        feats, P, L = build_timeline(batch, self.use_donor)
        W = feats.shape[1]
        x = self.proj(feats) + self.pos[:, :W, :]
        h = self.enc(x)
        z = self.head(h).squeeze(-1)
        lv = self.head_lv(h).squeeze(-1)
        return {'z_hat': z[:, P:P + L], 'log_var': lv[:, P:P + L]}

def get_model(name, hidden=64, use_donor=False):
    name = name.lower()
    if name == 'lstm':
        return LSTMSeq2Seq(hidden, use_donor)
    if name == 'brits':
        return BRITS(hidden, use_donor)
    if name == 'saits':
        return SAITS(hidden, use_donor=use_donor)
    raise ValueError('unknown model: %s' % name)
