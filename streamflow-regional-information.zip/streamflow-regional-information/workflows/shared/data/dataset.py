"""站点-缺口单元 + donor + 特征 → 可训练样本。无泄漏：transformer 仅用缺口外可见观测拟合。"""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import numpy as np
from .features import StationTransformer, season_phase, season_index
from .pseudo_gap import generate_pseudo_gaps
from .donors import DonorSelector, build_coords

class GapImputationDataset:

    def __init__(self, flow_df, static_df, cfg, gaps=None, split_stations=None):
        self.flow_df = flow_df
        self.static_df = static_df
        self.cfg = cfg
        self.station_ids = list(flow_df.columns)
        self.sid2idx = {s: i for i, s in enumerate(self.station_ids)}
        self.index = flow_df.index
        self.season_period = cfg['features'].get('season_period', 12)
        self.months = season_index(self.index, self.season_period)
        self.T = len(self.index)
        self.seq_pad = cfg['train'].get('seq_pad', 6)
        self.gaps = gaps if gaps is not None else generate_pseudo_gaps(flow_df, cfg['pseudo_gap'])
        if split_stations is not None:
            keep = set(split_stations)
            self.gaps = [g for g in self.gaps if g.station_id in keep]
        self.flow = flow_df.values.astype(np.float64)
        self.valid = np.isfinite(self.flow)
        self.is_gap_month = np.zeros_like(self.flow, dtype=bool)
        for g in self.gaps:
            self.is_gap_month[g.start:g.end + 1, self.sid2idx[g.station_id]] = True
        self.transformers = {}
        self.z = np.full_like(self.flow, np.nan)
        for j, sid in enumerate(self.station_ids):
            tr = StationTransformer(use_log1p=cfg['features'].get('use_log1p', True), deseasonalize=cfg['features'].get('deseasonalize', True), standardize=cfg['features'].get('per_station_standardize', True), n_season=self.season_period, leak_mode=cfg['features'].get('leak_mode', 'none'))
            vis = self.valid[:, j] & ~self.is_gap_month[:, j]
            tr.fit(self.flow[:, j], self.months, vis)
            self.transformers[sid] = tr
            self.z[:, j] = tr.transform(self.flow[:, j], self.months)
        self.coords = build_coords(static_df, self.station_ids)
        self.donor_selector = DonorSelector(self.z, self.station_ids, self.coords, cfg['donors'])
        self.donor_cache = {}

    def __len__(self):
        return len(self.gaps)

    def _donors(self, gap):
        key = (gap.station_id, gap.start, gap.end)
        if key not in self.donor_cache:
            self.donor_cache[key] = self.donor_selector.select(gap)
        return self.donor_cache[key]

    def __getitem__(self, i):
        gap = self.gaps[i]
        j = self.sid2idx[gap.station_id]
        pad = self.seq_pad
        g0, g1 = (gap.start, gap.end)
        L = gap.length
        pre0, pre1 = (max(0, g0 - pad), g0)
        post0, post1 = (g1 + 1, min(self.T, g1 + 1 + pad))
        target_z = self.z[:, j]
        sample = {'station_id': gap.station_id, 'gap_start': g0, 'gap_end': g1, 'length': L, 'stratum': gap.stratum, 'ctx_pre_z': target_z[pre0:pre1].astype(np.float32), 'ctx_post_z': target_z[post0:post1].astype(np.float32), 'gap_months': self.months[g0:g1 + 1].astype(np.int64), 'gap_dates': [d.strftime('%Y-%m-%d') for d in self.index[g0:g1 + 1]], 'gap_phase': season_phase(self.months[g0:g1 + 1], self.season_period), 'gap_truth_flow': self.flow[g0:g1 + 1, j].astype(np.float64), 'transformer': self.transformers[gap.station_id]}
        donors = self._donors(gap)
        D = len(donors)
        donor_ctx = np.zeros((D, pad + L + pad), dtype=np.float32)
        donor_gap = np.zeros((D, L), dtype=np.float32)
        donor_w = np.zeros((D,), dtype=np.float32)
        donor_mask = np.zeros((D, L), dtype=np.float32)
        win0 = pre0
        for k, dn in enumerate(donors):
            di = self.sid2idx[dn['donor_id']]
            seg = self.z[win0:post1, di]
            donor_ctx[k, :len(seg)] = np.nan_to_num(seg, nan=0.0)
            dg = self.z[g0:g1 + 1, di]
            donor_gap[k] = np.nan_to_num(dg, nan=0.0)
            donor_mask[k] = np.isfinite(dg).astype(np.float32)
            donor_w[k] = dn['weight']
        sample.update({'donor_gap_z': donor_gap, 'donor_ctx_z': donor_ctx, 'donor_weight': donor_w, 'donor_mask': donor_mask, 'n_donors': D})
        return sample

def split_stations(station_ids, cfg_split):
    rng = np.random.default_rng(cfg_split.get('seed', 7))
    ids = list(station_ids)
    rng.shuffle(ids)
    n = len(ids)
    n_test = int(n * cfg_split.get('test_station_frac', 0.15))
    n_val = int(n * cfg_split.get('val_station_frac', 0.15))
    test = set(ids[:n_test])
    val = set(ids[n_test:n_test + n_val])
    train = set(ids[n_test + n_val:])
    return (train, val, test)
