"""
无信息泄漏的伪缺口生成。

从完整/近完整的观测序列中人工挖去内部缺口，作为有监督插补样本。
被挖去的目标月份在训练与推断时均不可见；缺口必须是"内部"缺口（两侧都有上下文记忆）。
缺口长度按短/中/长分层采样，以匹配真实档案的缺失形态。
"""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import numpy as np

class GapSpec:
    """一个站点-缺口单元的描述。"""
    __slots__ = ('station_id', 'start', 'end', 'length', 'stratum')

    def __init__(self, station_id, start, end, stratum):
        self.station_id = station_id
        self.start = int(start)
        self.end = int(end)
        self.length = int(end - start + 1)
        self.stratum = stratum

    def slice(self):
        return slice(self.start, self.end + 1)

    def __repr__(self):
        return f'GapSpec({self.station_id}, [{self.start},{self.end}], L={self.length}, {self.stratum})'

def _contiguous_observed_runs(valid):
    """返回所有连续观测段的 (start, end_inclusive)。valid: [T] bool。"""
    runs = []
    T = len(valid)
    i = 0
    while i < T:
        if valid[i]:
            j = i
            while j + 1 < T and valid[j + 1]:
                j += 1
            runs.append((i, j))
            i = j + 1
        else:
            i += 1
    return runs

def sample_gaps_for_station(station_id, valid, rng, length_strata, gaps_per_station=3, min_context=12, edge_margin=6):
    """
    在单个站点的观测序列上采样伪缺口。

    valid : [T] bool（True=有真实观测，可被挖；缺口将落在这些位置上）
    返回 : list[GapSpec]
    """
    runs = _contiguous_observed_runs(np.asarray(valid, dtype=bool))
    gaps = []
    strata = list(length_strata)
    attempts = 0
    max_attempts = gaps_per_station * 20
    while len(gaps) < gaps_per_station and attempts < max_attempts:
        attempts += 1
        lo, hi = strata[len(gaps) % len(strata)]
        L = int(rng.integers(lo, hi + 1))
        feasible = [(a, b) for a, b in runs if b - a + 1 >= 2 * min_context + L]
        if not feasible:
            continue
        a, b = feasible[int(rng.integers(0, len(feasible)))]
        s_lo = max(a + min_context, edge_margin)
        s_hi = min(b - min_context - L + 1, len(valid) - edge_margin - L)
        if s_hi < s_lo:
            continue
        start = int(rng.integers(s_lo, s_hi + 1))
        end = start + L - 1
        if any((not (end < g.start - 1 or start > g.end + 1) for g in gaps if g.station_id == station_id)):
            continue
        stratum = f'{lo}-{hi}'
        gaps.append(GapSpec(station_id, start, end, stratum))
    return gaps

def generate_pseudo_gaps(flow_df, cfg_gap):
    """
    对宽表 flow_df [T x N] 生成所有站点的伪缺口。

    Returns
    -------
    gaps : list[GapSpec]
    """
    rng = np.random.default_rng(cfg_gap.get('seed', 42))
    length_strata = cfg_gap.get('length_strata', [[1, 3], [4, 12], [13, 36]])
    gaps = []
    for sid in flow_df.columns:
        valid = np.isfinite(flow_df[sid].values)
        gaps.extend(sample_gaps_for_station(sid, valid, rng, length_strata, gaps_per_station=cfg_gap.get('gaps_per_station', 3), min_context=cfg_gap.get('min_context', 12), edge_margin=cfg_gap.get('edge_margin', 6)))
    return gaps
