"""
统一读取月尺度径流序列。

自动识别三种格式：
  1) 原始 GSIM   : 注释头(#) + 数据表 `date,MEAN,SD,...,n.missing,n.available`，日期 1967/1/31，缺失 NA
  2) Enhanced_v2 : `date,MEAN,is_interpolated`，日期 1986-01-01
  3) GRDC        : `data,MEAN`，日期 1973/10/1

输出统一为：以月初为索引(DatetimeIndex, freq='MS')、单位 m³/s 的 pandas.Series。
"""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import os
import glob
import warnings
import numpy as np
import pandas as pd

def _to_month_start(idx) -> pd.DatetimeIndex:
    """把任意日期（月末/月中/月初）统一对齐到月初。接受 Series/array/Index。"""
    di = pd.DatetimeIndex(pd.to_datetime(np.asarray(idx)))
    return di.to_period('M').to_timestamp(how='start')

def _read_raw_gsim(path: str, min_days_available: int=0) -> pd.Series:
    """读取带 # 注释头的原始 GSIM 文件。"""
    header_row = None
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        for i, line in enumerate(f):
            s = line.strip().lower().replace('"', '').replace('\t', '')
            if s.startswith('date,'):
                header_row = i
                break
    if header_row is None:
        raise ValueError(f'未找到数据表头: {path}')
    df = pd.read_csv(path, skiprows=header_row, na_values=['NA', 'na', 'NaN', ''])
    import re as _re
    df.columns = [_re.sub('[\\s"]', '', str(c)) for c in df.columns]
    date_col = df.columns[0]
    df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
    df = df.dropna(subset=[date_col])

    def _num(col):
        ser = df[col].astype(str).str.replace('[\\s"]', '', regex=True)
        return pd.to_numeric(ser, errors='coerce')
    if 'MEAN' not in df.columns:
        raise ValueError('未找到 MEAN 列, 列名=%s' % list(df.columns)[:6])
    mean = _num('MEAN')
    if min_days_available and 'n.available' in df.columns:
        navail = _num('n.available').fillna(0)
        mean = mean.where(navail >= min_days_available, other=np.nan)
    s = pd.Series(mean.values, index=_to_month_start(df[date_col]))
    s = s[~s.index.duplicated(keep='first')].sort_index()
    return s

def _read_enhanced(path: str) -> pd.Series:
    df = pd.read_csv(path, na_values=['NA', 'na', 'NaN', ''])
    df.columns = [c.strip() for c in df.columns]
    df['date'] = pd.to_datetime(df['date'], errors='coerce')
    df = df.dropna(subset=['date'])
    s = pd.Series(pd.to_numeric(df['MEAN'], errors='coerce').values, index=_to_month_start(df['date']))
    s = s[~s.index.duplicated(keep='first')].sort_index()
    return s

def _read_grdc(path: str) -> pd.Series:
    df = pd.read_csv(path, na_values=['NA', 'na', 'NaN', ''])
    df.columns = [c.strip().lower() for c in df.columns]
    date_col = 'data' if 'data' in df.columns else df.columns[0]
    mean_col = 'mean' if 'mean' in df.columns else df.columns[1]
    df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
    df = df.dropna(subset=[date_col])
    s = pd.Series(pd.to_numeric(df[mean_col], errors='coerce').values, index=_to_month_start(df[date_col]))
    s = s[~s.index.duplicated(keep='first')].sort_index()
    return s

def _sniff_format(path: str) -> str:
    """嗅探文件格式。"""
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        head = [next(f, '') for _ in range(3)]
    first = head[0].strip().lower()
    if first.startswith('#') or 'gsim indices' in ''.join(head).lower():
        return 'raw_gsim'
    if first.startswith('date,mean') and 'is_interpolated' in first:
        return 'enhanced'
    if first.startswith('data,') or first.startswith('data,mean'):
        return 'grdc'
    if first.startswith('date,'):
        return 'raw_gsim'
    return 'grdc'

def read_series(path: str, min_days_available: int=0) -> pd.Series:
    """读取单个文件为统一月序列（m³/s）。"""
    fmt = _sniff_format(path)
    if fmt == 'raw_gsim':
        return _read_raw_gsim(path, min_days_available=min_days_available)
    if fmt == 'enhanced':
        return _read_enhanced(path)
    return _read_grdc(path)

def read_meta(path):
    """从 GSIM/.mon 注释头解析 (lat, lon, country)；解析不到返回 None。"""
    lat = lon = country = None
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            t = line.strip()
            if not t.startswith('#'):
                if lat is not None or lon is not None:
                    break
                continue
            low = t.lower()
            if 'latitude' in low:
                lat = _meta_val(t)
            elif 'longitude' in low:
                lon = _meta_val(t)
            elif 'country' in low:
                country = _meta_val(t, num=False)
    try:
        return (float(lat), float(lon), country)
    except (TypeError, ValueError):
        return (None, None, country)

def _meta_val(line, num=True):
    parts = line.lstrip('#').split(':')
    if len(parts) < 2:
        return None
    v = parts[1].strip()
    return v if v else None

def station_id_from_path(path: str) -> str:
    return os.path.splitext(os.path.basename(path))[0]

def load_station_matrix(series_dirs, start_date, end_date, enhanced_dir=None, min_valid_months=120, min_days_available=20, limit=None):
    """
    批量读取目录下所有站点，对齐到统一月时间轴，返回宽表 DataFrame。

    Returns
    -------
    flow : DataFrame  [T x N]，index=月初时间轴，columns=station_id，单位 m³/s（缺失为 NaN）
    """
    if isinstance(series_dirs, str):
        series_dirs = [series_dirs]
    paths = {}
    for d in series_dirs:
        for ext in ('*.csv', '*.mon'):
            for p in sorted(glob.glob(os.path.join(d, ext))):
                paths.setdefault(station_id_from_path(p), p)
    if enhanced_dir and os.path.isdir(enhanced_dir):
        for p in sorted(glob.glob(os.path.join(enhanced_dir, '*.csv'))):
            paths[station_id_from_path(p)] = p
    full_index = pd.date_range(start_date, end_date, freq='MS')
    cols, sid_list = ([], [])
    for k, (sid, p) in enumerate(sorted(paths.items())):
        if limit and len(sid_list) >= limit:
            break
        try:
            s = read_series(p, min_days_available=min_days_available)
        except Exception as e:
            warnings.warn(f'跳过 {sid}: {e}')
            continue
        s = s.reindex(full_index)
        if s.notna().sum() < min_valid_months:
            continue
        cols.append(s.values.astype(np.float32))
        sid_list.append(sid)
    if not sid_list:
        raise RuntimeError('没有任何站点满足纳入条件，请检查路径/时间窗/阈值。')
    flow = pd.DataFrame(np.column_stack(cols), index=full_index, columns=sid_list)
    return flow

def load_static(static_csv, id_col='gsim.no'):
    """读取静态属性表，按站点ID索引。"""
    df = pd.read_csv(static_csv)
    df.columns = [c.strip() for c in df.columns]
    if id_col not in df.columns:
        for alt in ['station_id', 'gsim.no', 'gsim_no', 'id']:
            if alt in df.columns:
                id_col = alt
                break
    df = df.dropna(subset=[id_col]).drop_duplicates(subset=[id_col])
    df = df.set_index(id_col)
    return df
