"""
donor 站点筛选（无信息泄漏）+ 向量化加速。

对每个目标站点-缺口单元，从其它站点中挑选 donor，要求：
  - 空间距离 <= max_distance_km
  - 在缺口期内 donor 自身有观测（同步信息）
  - donor 与目标的相关性只用缺口之前的窗口计算（无泄漏）
  - 缺口前重叠观测月数 >= min_overlap_months

DonorSelector：空间候选按"目标站点"预计算并缓存一次（距离只与目标有关，与具体缺口无关），
每个缺口只在小的空间候选集上做同步性与相关性筛选 → 将 O(gaps × N) 降为
O(N² once, 向量化) + O(gaps × 候选数)。全量(上万站点)可行。
"""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import numpy as np

def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    p = np.pi / 180.0
    a = np.sin((lat2 - lat1) * p / 2) ** 2 + np.cos(lat1 * p) * np.cos(lat2 * p) * np.sin((lon2 - lon1) * p / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(np.clip(a, 0, 1)))

def haversine_vec(lat0, lon0, lat_arr, lon_arr):
    """目标(lat0,lon0) 到一组点的距离(km)，向量化。"""
    R = 6371.0
    p = np.pi / 180.0
    dlat = (lat_arr - lat0) * p
    dlon = (lon_arr - lon0) * p
    a = np.sin(dlat / 2) ** 2 + np.cos(lat0 * p) * np.cos(lat_arr * p) * np.sin(dlon / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(np.clip(a, 0, 1)))

def _precorr(target_z, donor_z, gap_start, window):
    lo = max(0, gap_start - window)
    t = target_z[lo:gap_start]
    d = donor_z[lo:gap_start]
    m = np.isfinite(t) & np.isfinite(d)
    if m.sum() < 6 or t[m].std() < 1e-09 or d[m].std() < 1e-09:
        return (np.nan, int(m.sum()))
    return (float(np.corrcoef(t[m], d[m])[0, 1]), int(m.sum()))

def build_coords(static_df, station_ids):
    lat_col = next((c for c in ['latitude', 'lat', 'Latitude'] if c in static_df.columns), None)
    lon_col = next((c for c in ['longitude', 'lon', 'Longitude'] if c in static_df.columns), None)
    coords = {}
    if lat_col is None or lon_col is None:
        return coords
    for sid in station_ids:
        if sid in static_df.index:
            try:
                coords[sid] = (float(static_df.at[sid, lat_col]), float(static_df.at[sid, lon_col]))
            except (ValueError, TypeError):
                continue
    return coords

class DonorSelector:
    """向量化 donor 选择；空间候选按目标站点缓存。"""

    def __init__(self, z_matrix, station_ids, coords, cfg_donor, spatial_cap=200):
        self.z = z_matrix
        self.station_ids = station_ids
        self.idx = {s: i for i, s in enumerate(station_ids)}
        self.cfg = cfg_donor
        self.spatial_cap = spatial_cap
        N = len(station_ids)
        self.lat = np.full(N, np.nan)
        self.lon = np.full(N, np.nan)
        for s, i in self.idx.items():
            if s in coords:
                self.lat[i], self.lon[i] = coords[s]
        self.has_coord = np.isfinite(self.lat) & np.isfinite(self.lon)
        self._spatial_cache = {}

    def _spatial_candidates(self, ti):
        if ti in self._spatial_cache:
            return self._spatial_cache[ti]
        if not self.has_coord[ti]:
            self._spatial_cache[ti] = (np.array([], int), np.array([]))
            return self._spatial_cache[ti]
        dist = haversine_vec(self.lat[ti], self.lon[ti], self.lat, self.lon)
        maxd = self.cfg.get('max_distance_km', 500)
        ok = self.has_coord & (dist <= maxd)
        ok[ti] = False
        cand = np.where(ok)[0]
        d = dist[cand]
        if len(cand) > self.spatial_cap:
            keep = np.argsort(d)[:self.spatial_cap]
            cand, d = (cand[keep], d[keep])
        self._spatial_cache[ti] = (cand, d)
        return self._spatial_cache[ti]

    def select(self, gap):
        if gap.station_id not in self.idx:
            return []
        ti = self.idx[gap.station_id]
        cand, dists = self._spatial_candidates(ti)
        if len(cand) == 0:
            return []
        target_z = self.z[:, ti]
        g0, g1 = (gap.start, gap.end)
        maxd = self.cfg.get('max_distance_km', 500)
        win = self.cfg.get('precorr_window', 60)
        min_ov = self.cfg.get('min_overlap_months', 36)
        min_pc = self.cfg.get('min_precorr', 0.3)
        out = []
        for di, dist in zip(cand, dists):
            donor_z = self.z[:, di]
            sync = int(np.isfinite(donor_z[g0:g1 + 1]).sum())
            if sync == 0:
                continue
            pc, ov = _precorr(target_z, donor_z, g0, win)
            if ov < min_ov or not np.isfinite(pc) or pc < min_pc:
                continue
            out.append({'donor_id': self.station_ids[di], 'precorr': pc, 'dist_km': float(dist), 'sync_months': sync, 'weight': pc * np.exp(-dist / maxd)})
        if not out:
            return []
        out.sort(key=lambda c: c['weight'], reverse=True)
        out = out[:self.cfg.get('max_donors', 8)]
        wsum = sum((c['weight'] for c in out)) + 1e-09
        for c in out:
            c['weight'] = float(c['weight'] / wsum)
        return out

def select_donors_for_gap(gap, z_matrix, station_ids, coords, cfg_donor):
    """兼容旧接口：单次调用（内部用 DonorSelector）。批量请直接用 DonorSelector。"""
    return DonorSelector(z_matrix, station_ids, coords, cfg_donor).select(gap)
