"""Summarize observed GSIM missing-run lengths for the Nature Water audit cohort.

The analysis uses the same 22,934 incomplete gauges and 1980--2015 monthly
matrix as main Fig. 3. It reports both event-weighted and missing-month-weighted
distributions because long runs contribute many months even when they are not
the most frequent event type.
"""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
ROOT = _PROJECT_ROOT
OUT = _PROJECT_ROOT / 'workflows/archive_diagnosis/support/source_data'
IDS_PATH = _PROJECT_ROOT / 'data/recoverability/ids.npy'
MATRIX_PATH = _PROJECT_ROOT / 'data/recoverability/Z.mm'
COHORT_PATH = _PROJECT_ROOT / 'data/archive_support/Fig3c_station_dynamic_support.csv'
INDEX = pd.date_range('1980-01-01', '2015-12-01', freq='MS')
EXPECTED_GAUGES = 22934
EXPECTED_MISSING_MONTHS = 4598259

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def run_bounds(mask: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    padded = np.r_[False, mask, False].astype(np.int8)
    changes = np.diff(padded)
    return (np.flatnonzero(changes == 1), np.flatnonzero(changes == -1) - 1)

def length_bin(length: int) -> str:
    if length <= 3:
        return '1-3'
    if length <= 11:
        return '4-11'
    if length == 12:
        return '12'
    if length <= 24:
        return '13-24'
    if length <= 36:
        return '25-36'
    return '>36'

def contains_full_calendar_year(start: pd.Timestamp, end: pd.Timestamp) -> bool:
    for year in range(start.year, end.year + 1):
        if start <= pd.Timestamp(year=year, month=1, day=1) and end >= pd.Timestamp(year=year, month=12, day=1):
            return True
    return False

def summarize(events: pd.DataFrame, scope: str) -> pd.DataFrame:
    subset = events if scope == 'all' else events.loc[events['position'] == scope]
    order = ['1-3', '4-11', '12', '13-24', '25-36', '>36']
    rows = []
    event_total = len(subset)
    month_total = int(subset['gap_length'].sum())
    for label in order:
        group = subset.loc[subset['gap_length_bin'] == label]
        n_events = len(group)
        n_months = int(group['gap_length'].sum())
        rows.append({'scope': scope, 'gap_length_months': label, 'gap_events': n_events, 'event_share_pct': 100.0 * n_events / event_total if event_total else np.nan, 'missing_months': n_months, 'missing_month_share_pct': 100.0 * n_months / month_total if month_total else np.nan})
    return pd.DataFrame(rows)

def special_summary(events: pd.DataFrame, scope: str) -> pd.DataFrame:
    subset = events if scope == 'all' else events.loc[events['position'] == scope]
    definitions = [('gap_length_ge_4', subset['gap_length'] >= 4), ('gap_length_ge_12', subset['gap_length'] >= 12), ('gap_length_eq_12', subset['gap_length'] == 12), ('gap_length_multiple_of_12', subset['gap_length'] % 12 == 0), ('jan_to_dec_aligned', subset['jan_to_dec_aligned']), ('contains_full_calendar_year', subset['contains_full_calendar_year'])]
    event_total = len(subset)
    month_total = int(subset['gap_length'].sum())
    rows = []
    for label, selector in definitions:
        group = subset.loc[selector]
        n_events = len(group)
        n_months = int(group['gap_length'].sum())
        rows.append({'scope': scope, 'statistic': label, 'gap_events': n_events, 'event_share_pct': 100.0 * n_events / event_total if event_total else np.nan, 'missing_months': n_months, 'missing_month_share_pct': 100.0 * n_months / month_total if month_total else np.nan})
    return pd.DataFrame(rows)

def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    ids = np.load(IDS_PATH, allow_pickle=True).astype(str)
    id_to_row = {station_id: i for i, station_id in enumerate(ids)}
    matrix = np.memmap(MATRIX_PATH, dtype=np.float32, mode='r', shape=(len(ids), len(INDEX)))
    cohort = pd.read_csv(COHORT_PATH)
    if len(cohort) != EXPECTED_GAUGES:
        raise AssertionError((len(cohort), EXPECTED_GAUGES))
    row_index = np.asarray([id_to_row[s] for s in cohort['gsim_no'].astype(str)], dtype=int)
    visible = np.isfinite(matrix[row_index])
    observed_counts = visible.sum(axis=1)
    if not np.array_equal(observed_counts, cohort['n_valid'].to_numpy(dtype=int)):
        raise AssertionError('Cohort observation counts do not match the frozen Fig. 3 source data')
    rows: list[dict[str, object]] = []
    for station_id, station_visible in zip(cohort['gsim_no'].astype(str), visible):
        observed = np.flatnonzero(station_visible)
        if len(observed) == 0:
            raise AssertionError(f'Active cohort contains an observation-free gauge: {station_id}')
        first_observed = int(observed[0])
        last_observed = int(observed[-1])
        starts, ends = run_bounds(~station_visible)
        for sequence, (start_idx, end_idx) in enumerate(zip(starts, ends), 1):
            length = int(end_idx - start_idx + 1)
            if end_idx < first_observed:
                position = 'before'
            elif start_idx > last_observed:
                position = 'after'
            else:
                position = 'internal'
            start = INDEX[int(start_idx)]
            end = INDEX[int(end_idx)]
            rows.append({'station_id': station_id, 'gap_id': f'{station_id}_real_{sequence}', 'position': position, 'start': start.strftime('%Y-%m'), 'end': end.strftime('%Y-%m'), 'gap_length': length, 'gap_length_bin': length_bin(length), 'exact_12_months': length == 12, 'multiple_of_12': length % 12 == 0, 'jan_to_dec_aligned': start.month == 1 and end.month == 12, 'contains_full_calendar_year': contains_full_calendar_year(start, end)})
    events = pd.DataFrame(rows)
    if int(events['gap_length'].sum()) != EXPECTED_MISSING_MONTHS:
        raise AssertionError((int(events['gap_length'].sum()), EXPECTED_MISSING_MONTHS))
    distributions = pd.concat([summarize(events, scope) for scope in ['all', 'internal', 'before', 'after']], ignore_index=True)
    special = pd.concat([special_summary(events, scope) for scope in ['all', 'internal', 'before', 'after']], ignore_index=True)
    events.to_csv(_PROJECT_ROOT / 'workflows/archive_diagnosis/support/source_data/observed_gap_events.csv', index=False)
    distributions.to_csv(_PROJECT_ROOT / 'workflows/archive_diagnosis/support/source_data/TableS28_gap_length_distribution.csv', index=False)
    special.to_csv(_PROJECT_ROOT / 'workflows/archive_diagnosis/support/source_data/gap_length_headline_statistics.csv', index=False)
    position = events.groupby('position', sort=False).agg(gap_events=('gap_id', 'size'), missing_months=('gap_length', 'sum')).reset_index()
    position['event_share_pct'] = 100.0 * position['gap_events'] / len(events)
    position['missing_month_share_pct'] = 100.0 * position['missing_months'] / EXPECTED_MISSING_MONTHS
    position.to_csv(_PROJECT_ROOT / 'workflows/archive_diagnosis/support/source_data/gap_position_distribution.csv', index=False)
    audit = {'period': ['1980-01', '2015-12'], 'cohort': 'same 22,934 incomplete gauges as main Fig. 3', 'n_gauges': int(len(cohort)), 'n_gap_events': int(len(events)), 'n_missing_months': int(events['gap_length'].sum()), 'checks': {'gauge_count_matches': len(cohort) == EXPECTED_GAUGES, 'missing_month_denominator_matches': int(events['gap_length'].sum()) == EXPECTED_MISSING_MONTHS, 'all_runs_positive': bool((events['gap_length'] > 0).all()), 'bin_months_close': int(distributions.loc[distributions['scope'] == 'all', 'missing_months'].sum()) == EXPECTED_MISSING_MONTHS}, 'input_sha256': {'ids.npy': sha256(IDS_PATH), 'Z.mm': sha256(MATRIX_PATH), 'Fig3c_station_dynamic_support.csv': sha256(COHORT_PATH)}}
    (_PROJECT_ROOT / 'workflows/archive_diagnosis/support/source_data/gap_length_distribution_audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    print(distributions.to_string(index=False))
    print()
    print(special.to_string(index=False))
    print()
    print(position.to_string(index=False))
    print()
    print(json.dumps(audit, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
