"""Audit the 26% baseline archive-unsupported share.

Every missing station-month is assigned to one mutually exclusive state:
S: at least one fixed top-eight reference reports;
U1: no reference qualifies under the baseline screen;
U2: qualifying references exist but none reports in that month;
U3: the top eight are silent but a lower-ranked qualifying reference reports.

No reconstruction model is fitted or scored.  The selected top-eight pools
come from the versioned manuscript audit; full eligible sets are independently
rebuilt only where more than eight references qualified.
"""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
ROOT = _PROJECT_ROOT
pass
from workflows.archive_diagnosis.support.diagnostics import chord, correlations, great_circle_km, prepare_matrix, xyz
OUT = _PROJECT_ROOT / 'workflows/archive_diagnosis/unsupported_conditions'
REC = _PROJECT_ROOT / 'data/recoverability'
REV = _PROJECT_ROOT / 'data/recoverability/condition_audit'
TAG = 'strict_calibration'
BASE = REV / f'baseline_exact_stations_{TAG}.csv'
ACTIVE = REV / f'global_recoverability_strict_{TAG}.csv'
EDGES = REV / f'baseline_pool_edges_{TAG}.csv'
META = _PROJECT_ROOT / 'data/global_station_meta_kg.csv'
IDS = _PROJECT_ROOT / 'data/recoverability/ids.npy'
MATRIX = _PROJECT_ROOT / 'data/recoverability/Z.mm'
RADIUS_KM = 800.0
SEARCH_RADIUS_KM = 1600.0
MIN_OVERLAP = 24
MIN_CORR = 0.2
CANDIDATE_CAP = 200
POOL_K = 8
EXPECTED_MISSING = 4598259
EXPECTED_UNSUPPORTED = 1196027
CATS = ['S', 'U1', 'U2', 'U3']
LABELS = {'S': 'Supported by fixed top-eight pool', 'U1': 'No qualifying reference gauge', 'U2': 'Qualifying references exist but all are silent', 'U3': 'Observed qualifying reference exists below rank eight'}

def file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def aggregate(frame: pd.DataFrame, by: str | None) -> pd.DataFrame:
    groups = [('Global', frame)] if by is None else list(frame.groupby(by, dropna=False, sort=True))
    rows = []
    for region, g in groups:
        total = int(g.n_missing.sum())
        unsupported = int(g[['U1', 'U2', 'U3']].to_numpy().sum())
        for cat in CATS:
            count = int(g[cat].sum())
            rows.append({'region': str(region), 'category': cat, 'category_label': LABELS[cat], 'station_months': count, 'total_missing_station_months': total, 'total_unsupported_station_months': unsupported, 'share_of_all_missing_pct': 100 * count / total if total else np.nan, 'share_of_unsupported_pct': 100 * count / unsupported if cat in {'U1', 'U2', 'U3'} and unsupported else np.nan, 'n_target_gauges': int((g[cat] > 0).sum())})
    return pd.DataFrame(rows)

def reconcile(frame: pd.DataFrame, by: str | None) -> pd.DataFrame:
    """Contrast fixed-pool and all-eligible availability definitions."""
    groups = [('Global', frame)] if by is None else list(frame.groupby(by, dropna=False, sort=True))
    rows = []
    for region, g in groups:
        total = int(g.n_missing.sum())
        u1, u2, u3 = (int(g[c].sum()) for c in ['U1', 'U2', 'U3'])
        fixed = u1 + u2 + u3
        all_eligible = u1 + u2
        rows.append({'region': str(region), 'total_missing_station_months': total, 'fixed_top8_unsupported_months': fixed, 'fixed_top8_unsupported_pct': 100 * fixed / total if total else np.nan, 'all_eligible_unsupported_months': all_eligible, 'all_eligible_unsupported_pct': 100 * all_eligible / total if total else np.nan, 'recoverable_by_rank_gt8_fallback_months': u3, 'recoverable_by_rank_gt8_fallback_pct': 100 * u3 / total if total else np.nan, 'fixed_pool_limitation_share_pct': 100 * u3 / fixed if fixed else np.nan})
    return pd.DataFrame(rows)

def main() -> None:
    start = time.time()
    messages = []
    for stale in [_PROJECT_ROOT / 'workflows/archive_diagnosis/unsupported_conditions/eligibility_count_mismatches.csv', _PROJECT_ROOT / 'workflows/archive_diagnosis/unsupported_conditions/published_vs_top8_diagnostic.csv']:
        if stale.exists():
            stale.unlink()

    def log(message: str) -> None:
        messages.append(message)
        print(message, flush=True)
    log('Baseline unsupported decomposition: U1 / U2 / U3 / S')
    log('Protocol: 800 km; overlap >=24; r >=0.2; nearest 200; fixed top eight')
    required = [BASE, ACTIVE, EDGES, META, IDS, MATRIX]
    absent = [str(p) for p in required if not p.exists()]
    if absent:
        raise FileNotFoundError(absent)
    ids = np.load(IDS, allow_pickle=True).astype(str)
    id_pos = {sid: i for i, sid in enumerate(ids)}
    baseline = pd.read_csv(BASE)
    active = pd.read_csv(ACTIVE)
    edges = pd.read_csv(EDGES)
    meta = pd.read_csv(META).rename(columns={'gsim.no': 'gsim_no'})
    raw, z, z0, visible = prepare_matrix(ids)
    del raw
    n_valid = visible.sum(1).astype(int)
    n_missing = (~visible).sum(1).astype(int)
    active_idx = np.asarray([id_pos[s] for s in active.gsim_no.astype(str)], dtype=int)
    total_missing = int(n_missing[active_idx].sum())
    published_unsupported = int((active.mm_no_info + active.mm_uncov).sum())
    assert total_missing == EXPECTED_MISSING, (total_missing, EXPECTED_MISSING)
    assert published_unsupported == EXPECTED_UNSUPPORTED, (published_unsupported, EXPECTED_UNSUPPORTED)
    log(f'[OK] missing denominator reproduced: {total_missing:,}')
    log(f'[OK] published unsupported reproduced: {published_unsupported:,}')
    pos = meta.set_index('gsim_no').reindex(ids)
    lat = pos.latitude.to_numpy(float)
    lon = pos.longitude.to_numpy(float)
    spatial_ok = np.isfinite(lat) & np.isfinite(lon)
    vectors = np.full((len(ids), 3), np.nan)
    vectors[spatial_ok] = xyz(lat[spatial_ok], lon[spatial_ok])
    tree_idx = np.where(spatial_ok)[0]
    tree = cKDTree(vectors[tree_idx])
    stored = baseline.set_index('gsim_no')
    selected = {}
    for target_id, g in edges.groupby('target_id', sort=False):
        selected[str(target_id)] = np.asarray([id_pos[str(x)] for x in g.sort_values('donor_rank').donor_id], dtype=int)
    rows = []
    mismatches = []
    rebuilt = 0
    for seq, target in enumerate(active_idx, 1):
        sid = ids[target]
        missing = ~visible[target]
        nm = int(missing.sum())
        nelig = int(stored.loc[sid, 'n_elig'])
        pool = selected.get(sid, np.empty(0, dtype=int))
        pool_available = visible[pool].any(0) if len(pool) else np.zeros(432, bool)
        s_mask = missing & pool_available
        u_mask = missing & ~pool_available
        s = int(s_mask.sum())
        unavailable = int(u_mask.sum())
        u1 = u2 = u3 = 0
        rebuilt_nelig = np.nan
        if unavailable and nelig == 0:
            u1 = unavailable
        elif unavailable and nelig <= POOL_K:
            u2 = unavailable
        elif unavailable:
            q = tree.query_ball_point(vectors[target], r=chord(SEARCH_RADIUS_KM))
            cand = tree_idx[np.asarray(q, dtype=int)]
            cand = cand[cand != target]
            if len(cand):
                distance = great_circle_km(vectors[target], vectors[cand])
                keep = distance <= SEARCH_RADIUS_KM + 1e-08
                cand, distance = (cand[keep], distance[keep])
                if len(cand) > CANDIDATE_CAP:
                    near = np.argsort(distance)[:CANDIDATE_CAP]
                    cand, distance = (cand[near], distance[near])
            if len(cand):
                overlap, corr = correlations(target, cand, z0, visible)
                eligible = cand[(distance <= RADIUS_KM + 1e-08) & (overlap >= MIN_OVERLAP) & np.isfinite(corr) & (corr >= MIN_CORR)]
            else:
                eligible = np.empty(0, dtype=int)
            rebuilt_nelig = int(len(eligible))
            rebuilt += 1
            if rebuilt_nelig != nelig:
                mismatches.append({'gsim_no': sid, 'stored_n_eligible': nelig, 'rebuilt_n_eligible': rebuilt_nelig})
            pool_set = set(pool.tolist())
            lower = np.asarray([x for x in eligible if x not in pool_set], dtype=int)
            lower_available = visible[lower].any(0) if len(lower) else np.zeros(432, bool)
            u3 = int((u_mask & lower_available).sum())
            u2 = unavailable - u3
        continent = pos.loc[sid, 'continent'] if 'continent' in pos.columns else np.nan
        country = pos.loc[sid, 'country'] if 'country' in pos.columns else np.nan
        row = {'gsim_no': sid, 'continent': continent, 'country': country, 'n_valid': int(n_valid[target]), 'n_missing': nm, 'stored_n_eligible': nelig, 'rebuilt_n_eligible': rebuilt_nelig, 'selected_pool_size': int(len(pool)), 'S': s, 'U1': u1, 'U2': u2, 'U3': u3}
        assert s + u1 + u2 + u3 == nm, sid
        rows.append(row)
        if seq % 2500 == 0:
            log(f'[progress] {seq:,}/{len(active_idx):,}; rebuilt={rebuilt:,}')
    station = pd.DataFrame(rows)
    if mismatches:
        pd.DataFrame(mismatches).to_csv(_PROJECT_ROOT / 'workflows/archive_diagnosis/unsupported_conditions/eligibility_count_mismatches.csv', index=False)
        raise AssertionError(f'eligible-count mismatch at {len(mismatches)} gauges')
    decomposed = int(station[['U1', 'U2', 'U3']].to_numpy().sum())
    supported = int(station.S.sum())
    assert supported + decomposed == total_missing
    if decomposed != published_unsupported:
        diagnostic = active[['gsim_no', 'mm_no_info', 'mm_uncov']].merge(station[['gsim_no', 'U1', 'U2', 'U3']], on='gsim_no')
        diagnostic['published'] = diagnostic.mm_no_info + diagnostic.mm_uncov
        diagnostic['fixed_top8'] = diagnostic.U1 + diagnostic.U2 + diagnostic.U3
        diagnostic = diagnostic[diagnostic.published != diagnostic.fixed_top8]
        diagnostic.to_csv(_PROJECT_ROOT / 'workflows/archive_diagnosis/unsupported_conditions/published_vs_top8_diagnostic.csv', index=False)
        raise AssertionError((decomposed, published_unsupported))
    global_table = aggregate(station, None)
    continent_table = aggregate(station, 'continent')
    availability = pd.concat([reconcile(station, None).assign(scope='Global'), reconcile(station, 'continent').assign(scope='Continent')], ignore_index=True)
    fig3 = pd.concat([global_table.assign(scope='Global'), continent_table.assign(scope='Continent')], ignore_index=True)
    fig3['display_order'] = fig3.category.map({c: i + 1 for i, c in enumerate(CATS)})
    fig3 = fig3[['scope', 'region', 'display_order', 'category', 'category_label', 'station_months', 'total_missing_station_months', 'total_unsupported_station_months', 'share_of_all_missing_pct', 'share_of_unsupported_pct', 'n_target_gauges']]
    station.to_csv(_PROJECT_ROOT / 'workflows/archive_diagnosis/unsupported_conditions/station_decomposition.csv', index=False)
    global_table.to_csv(_PROJECT_ROOT / 'workflows/archive_diagnosis/unsupported_conditions/global_decomposition.csv', index=False)
    continent_table.to_csv(_PROJECT_ROOT / 'workflows/archive_diagnosis/unsupported_conditions/continent_decomposition.csv', index=False)
    availability.to_csv(_PROJECT_ROOT / 'workflows/archive_diagnosis/unsupported_conditions/availability_definition_reconciliation.csv', index=False)
    fig3.to_csv(_PROJECT_ROOT / 'workflows/archive_diagnosis/unsupported_conditions/Fig3_unsupported_decomposition_source.csv', index=False)
    gi = global_table.set_index('category')
    global_reconciliation = json.loads(availability[availability.scope == 'Global'].drop(columns='scope').iloc[0].to_json())
    summary = {'run_id': 'unsupported_decomposition', 'source_baseline_run_id': TAG, 'protocol': {'period': ['1980-01', '2015-12'], 'radius_km': RADIUS_KM, 'minimum_visible_overlap_months': MIN_OVERLAP, 'minimum_historical_flow_correlation': MIN_CORR, 'maximum_nearest_candidates': CANDIDATE_CAP, 'fixed_selected_pool_size': POOL_K}, 'checks': {'expected_total_missing': EXPECTED_MISSING, 'reproduced_total_missing': total_missing, 'expected_published_unsupported': EXPECTED_UNSUPPORTED, 'reproduced_fixed_top8_unsupported': decomposed, 'partition_closes': supported + decomposed == total_missing, 'eligible_count_mismatch_gauges': len(mismatches)}, 'global': {cat: {'label': LABELS[cat], 'station_months': int(gi.loc[cat, 'station_months']), 'share_of_all_missing_pct': float(gi.loc[cat, 'share_of_all_missing_pct']), 'share_of_unsupported_pct': None if pd.isna(gi.loc[cat, 'share_of_unsupported_pct']) else float(gi.loc[cat, 'share_of_unsupported_pct'])} for cat in CATS}, 'global_reconciliation': global_reconciliation, 'runtime_seconds': time.time() - start, 'input_sha256': {str(path.relative_to(ROOT)): file_hash(path) for path in [BASE, ACTIVE, EDGES, META, IDS, MATRIX]}}
    (_PROJECT_ROOT / 'workflows/archive_diagnosis/unsupported_conditions/audit_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    log('[OK] S + U1 + U2 + U3 closes exactly')
    for cat in CATS:
        q = summary['global'][cat]
        suffix = '' if q['share_of_unsupported_pct'] is None else f"; {q['share_of_unsupported_pct']:.3f}% of unsupported"
        log(f"  {cat}: {q['station_months']:,} ({q['share_of_all_missing_pct']:.3f}% of all missing{suffix})")
    log(f'[DONE] runtime={time.time() - start:.1f}s; outputs={OUT}')
    (_PROJECT_ROOT / 'workflows/archive_diagnosis/unsupported_conditions/audit.log').write_text('\n'.join(messages) + '\n', encoding='utf-8')
if __name__ == '__main__':
    main()
