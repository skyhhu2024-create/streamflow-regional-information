"""Frozen R2 monthly reference-count sensitivity, independent of old outputs.

Only the monthly maximum reference count changes from the authoritative
 rule-comparison implementation. Observations are read-only and all
results are written beside this entry point. The protocol is frozen before
constructing transformations or generating/scoring predictions.
"""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
import sys, json, time, hashlib, gzip, csv
from pathlib import Path
sys.dont_write_bytecode = True
HERE = _PROJECT_ROOT / 'workflows/benchmarks/reference_count'
CODE = _PROJECT_ROOT
pass
pass
import numpy as np
import pandas as pd
from workflows.shared.data.dataset import GapImputationDataset, split_stations
from workflows.shared.data.gsim_io import load_static
from workflows.benchmarks.reference_selection.run_selection_grid import build_config
BASE = _PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison'
MODELS = [('monthly1', 1), ('monthly2', 2), ('monthly4', 4), ('monthly8', 8), ('monthly16', 16), ('all_qualified', None)]

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for buf in iter(lambda: f.read(1 << 20), b''):
            h.update(buf)
    return h.hexdigest()

def write(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=lambda a: a.item() if isinstance(a, np.generic) else str(a)), encoding='utf-8')

def bootstrap_row(frame, metric, rng, n_draws=2000):
    finite = frame[np.isfinite(frame[metric])]
    blocks = [group[metric].to_numpy() for _, group in finite.groupby('block')]
    values = finite[metric].to_numpy()
    draws = np.array([np.median(np.concatenate([blocks[k] for k in rng.integers(0, len(blocks), len(blocks))])) for _ in range(n_draws)])
    return dict(metric=metric, n=len(values), n_blocks=len(blocks), median=float(np.median(values)), ci_low=float(np.quantile(draws, 0.025)), ci_high=float(np.quantile(draws, 0.975)), win_pct=float(100 * np.mean(values > 0)), tie_pct=float(100 * np.mean(values == 0)), q05=float(np.quantile(values, 0.05)), q95=float(np.quantile(values, 0.95)))

def main():
    t0 = time.time()
    assert not (_PROJECT_ROOT / 'workflows/benchmarks/reference_count/protocol.json').exists(), 'No overwrite of a frozen run'
    dp = _PROJECT_ROOT / 'workflows/benchmarks/internal_gaps/data'
    source_paths = [_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/compare_selection.py', _PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/station_scores.csv', _PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/monthly_predictions.csv.gz', _PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/gap_manifest.csv', _PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/model_summary.csv', _PROJECT_ROOT / 'workflows/shared/data/dataset.py', _PROJECT_ROOT / 'workflows/shared/data/features.py', _PROJECT_ROOT / 'workflows/shared/data/donors.py', _PROJECT_ROOT / 'workflows/shared/data/pseudo_gap.py', _PROJECT_ROOT / 'workflows/shared/data/gsim_io.py', _PROJECT_ROOT / 'workflows/benchmarks/reference_selection/run_selection_grid.py', _PROJECT_ROOT / 'data/global_station_meta_kg.csv', _PROJECT_ROOT / 'data/benchmarks/selection_evidence/selection_vs_proximity_equal_stations.csv', _PROJECT_ROOT / 'workflows/benchmarks/internal_gaps/data/station_ids.npy', _PROJECT_ROOT / 'workflows/benchmarks/internal_gaps/data/dates.npy', _PROJECT_ROOT / 'workflows/benchmarks/internal_gaps/data/flow_qc20_dedup.npy']
    sources = [dict(path=str(p), size_bytes=p.stat().st_size, sha256=sha(p)) for p in source_paths]
    write(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/source_hashes.json', sources)
    protocol = dict(created_utc=pd.Timestamp.now(tz='UTC').isoformat(), stage='Protocol frozen before dataset transformations, predictions and scoring', authoritative_baseline=str(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/compare_selection.py'), script_sha256=sha(__file__), source_manifest_sha256=sha(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/source_hashes.json'), cohort='Original complete-case 2,990 stations from operational selection/combination audit; L>=2 original pseudo-gaps', expected_n_stations=2990, expected_n_gaps=9410, expected_n_months=94242, candidate_pool='Nearest 200 other gauges within 800 km, as original DonorSelector spatial candidates', qualification='At least 24 common months and Pearson r>=0.2 in 60 calendar months preceding each gap', ranking='r * exp(-distance/800), descending stable order; identical qualified pool for all K', selection='Each month independently select the first K qualified gauges with actual finite observed values; all uses every reporting qualified gauge', models=[dict(name=m, maximum_reporting_references=k) for m, k in MODELS], transformation='Original StationTransformer fitted once per station excluding all its original pseudo-gaps; target-wise retrospective reference observations', combination='r * exp(-distance/800) weights renormalized over the selected reporting gauges each month', numerical_guard='Original reference sigma floor .001; target visible standardized min/max envelope extended +/-3 SD; original inverse-transform log cap 50; zero-anomaly seasonal fallback without references', only_intervention='Maximum number of ranked, reporting references K; no retraining, retuning or outcome-based selection', support='Any K>=1 has reference support iff at least one qualified reference reports, hence all six support masks must agree', primary='Station NSE over identical pooled original test months; station-paired NSE and relative RMSE changes against K=8', uncertainty='2,000 spatial block bootstrap draws, 5-degree latitude x longitude blocks, seed ; station pairs remain together', interpretation='Descriptive sensitivity among prespecified counts; observed best count is not universal optimum; no R3 output modified or used to select K', no_reconstruction_as_reference=True, reproduction='K=8 and all monthly predictions and station scores must match frozen  run within 1e-12 tolerance')
    write(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/protocol.json', protocol)
    ids = np.load(_PROJECT_ROOT / 'workflows/benchmarks/internal_gaps/data/station_ids.npy', allow_pickle=True).astype(str)
    dates = pd.to_datetime(np.load(_PROJECT_ROOT / 'workflows/benchmarks/internal_gaps/data/dates.npy', allow_pickle=True))
    raw = np.load(_PROJECT_ROOT / 'workflows/benchmarks/internal_gaps/data/flow_qc20_dedup.npy')
    flow = pd.DataFrame(raw, index=dates, columns=ids)
    cfg = build_config(4)
    write(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/dataset_config.json', cfg)
    print('Building identical original R2 dataset, transformations and masks', flush=True)
    ds = GapImputationDataset(flow, load_static(_PROJECT_ROOT / 'data/global_station_meta_kg.csv'), cfg)
    cohort = pd.read_csv(_PROJECT_ROOT / 'data/benchmarks/selection_evidence/selection_vs_proximity_equal_stations.csv').station_id.astype(str)
    assert len(cohort) == len(set(cohort)) == 2990
    _, _, test = split_stations(ids, cfg['split'])
    assert set(cohort) <= test
    selected = set(cohort)
    gaps = [g for g in ds.gaps if g.station_id in selected and g.length >= 2]
    assert len(gaps) == 9410 and sum((g.length for g in gaps)) == 94242
    cohort.to_frame().to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/station_cohort.csv', index=False)
    write(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/sample_flow.json', dict(archive_stations=len(ids), archive_calendar_months=len(dates), all_original_pseudo_gaps=len(ds.gaps), frozen_cohort_stations=len(cohort), retained_length_min=2, retained_gaps=len(gaps), retained_gap_months=sum((g.length for g in gaps)), test_partition_stations=len(test), identical_target_months_across_counts=True))
    meta = pd.read_csv(_PROJECT_ROOT / 'data/global_station_meta_kg.csv').set_index('gsim.no')
    accum, gaprows = ({}, [])
    model_names = [m for m, _ in MODELS]
    reference_scales = np.array([ds.transformers[s].sigma_ for s in ids])
    with gzip.open(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/monthly_predictions.csv.gz', 'wt', newline='') as handle:
        writer = csv.writer(handle)
        writer.writerow(['station_id', 'gap_start', 'gap_end', 'date', 'obs', *model_names, 'support', 'n_reporting', 'n_qualified'])
        for seq, g in enumerate(gaps):
            j = ds.sid2idx[g.station_id]
            tt = np.arange(g.start, g.end + 1)
            y = ds.flow[tt, j]
            assert np.isfinite(y).all()
            cc, dd = ds.donor_selector._spatial_candidates(j)
            lo = max(0, g.start - 60)
            target, don = (ds.z[lo:g.start, j], ds.z[lo:g.start, cc])
            good = np.isfinite(target)[:, None] & np.isfinite(don)
            n = good.sum(0)
            a, b = (np.where(good, target[:, None], 0.0), np.where(good, don, 0.0))
            den = np.sqrt(np.maximum(0, (a * a).sum(0) - a.sum(0) ** 2 / np.maximum(n, 1)) * np.maximum(0, (b * b).sum(0) - b.sum(0) ** 2 / np.maximum(n, 1)))
            r = np.divide((a * b).sum(0) - a.sum(0) * b.sum(0) / np.maximum(n, 1), den, out=np.full(len(cc), np.nan), where=den > 1e-12)
            goodref = (n >= 24) & np.isfinite(r) & (r >= 0.2)
            refs = cc[goodref]
            weights = r[goodref] * np.exp(-dd[goodref] / 800.0)
            order = np.argsort(-weights, kind='stable')
            refs, weights = (refs[order], weights[order])
            zz = ds.z[np.ix_(tt, refs)] * (reference_scales[refs] / np.maximum(reference_scales[refs], 0.001))[None, :]
            ok = np.isfinite(zz)
            cumulative = np.cumsum(ok, axis=1)
            choices = {name: ok if k is None else ok & (cumulative <= k) for name, k in MODELS}
            tr = ds.transformers[g.station_id]
            vis = ds.valid[:, j] & ~ds.is_gap_month[:, j]
            envelope = ds.z[vis, j]
            elo, ehi = (envelope.min() - 3.0, envelope.max() + 3.0)
            predictions, supports = ({}, {})
            for name, choice in choices.items():
                ww = np.where(choice, weights[None, :], 0.0)
                den = ww.sum(1)
                zhat = np.divide((np.where(choice, zz, 0.0) * ww).sum(1), den, out=np.zeros(len(tt)), where=den > 0)
                support = den > 0
                zhat = np.where(support, np.clip(zhat, elo, ehi), 0.0)
                pp = tr.inverse_transform(zhat, ds.months[tt])
                assert np.isfinite(pp).all()
                predictions[name], supports[name] = (pp, support)
                ac = accum.setdefault((g.station_id, name), dict(n=0, sum_y=0.0, sum_y2=0.0, sse=0.0, supported=0))
                ac['n'] += len(y)
                ac['sum_y'] += float(y.sum())
                ac['sum_y2'] += float(y @ y)
                ac['sse'] += float(np.sum((pp - y) ** 2))
                ac['supported'] += int(support.sum())
            assert all((np.array_equal(supports['monthly8'], supports[name]) for name in model_names))
            gaprows.append(dict(station_id=g.station_id, start=str(dates[g.start].date()), end=str(dates[g.end].date()), n=len(tt), n_qualified=len(refs), support_monthly=int(supports['monthly8'].sum())))
            for k, t in enumerate(tt):
                writer.writerow([g.station_id, str(dates[g.start].date()), str(dates[g.end].date()), str(dates[t].date()), y[k], *[predictions[x][k] for x in model_names], bool(supports['monthly8'][k]), int(ok[k].sum()), len(refs)])
            if (seq + 1) % 1000 == 0:
                print(f'{seq + 1}/{len(gaps)} gaps completed; {time.time() - t0:.1f} s', flush=True)
    rows = []
    for (sid, model), a in accum.items():
        denom = a['sum_y2'] - a['sum_y'] ** 2 / a['n']
        rows.append(dict(station_id=sid, model=model, **a, NSE=1 - a['sse'] / denom if denom > 1e-12 else np.nan, RMSE=np.sqrt(a['sse'] / a['n']), continent=meta.loc[sid, 'continent'], latitude=meta.loc[sid, 'latitude'], longitude=meta.loc[sid, 'longitude']))
    scores = pd.DataFrame(rows)
    scores.to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/station_scores.csv', index=False)
    gapmanifest = pd.DataFrame(gaprows)
    gapmanifest.to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/gap_manifest.csv', index=False)
    assert scores.groupby('model').n.sum().eq(94242).all()
    assert scores.groupby('model').supported.sum().eq(85969).all()
    old = pd.read_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/station_scores.csv')
    reproduction = []
    for name in ['monthly8', 'all_qualified']:
        left = scores[scores.model == name].set_index('station_id').sort_index()
        right = old[old.model == name].set_index('station_id').sort_index()
        assert left.index.equals(right.index)
        for col in ['n', 'sum_y', 'sum_y2', 'sse', 'supported', 'NSE', 'RMSE']:
            aa, bb = (left[col].to_numpy(), right[col].to_numpy())
            assert np.allclose(aa, bb, rtol=1e-12, atol=1e-12, equal_nan=True), (name, col)
            reproduction.append(dict(model=name, field=col, max_abs_difference=float(np.nanmax(np.abs(aa - bb)))))
    oldpred = pd.read_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/monthly_predictions.csv.gz')
    newpred = pd.read_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/monthly_predictions.csv.gz')
    keys = ['station_id', 'gap_start', 'gap_end', 'date']
    assert oldpred[keys].equals(newpred[keys])
    for col in ['obs', 'monthly8', 'all_qualified']:
        assert np.allclose(oldpred[col], newpred[col], rtol=1e-12, atol=1e-12, equal_nan=True), col
        reproduction.append(dict(model='predictions', field=col, max_abs_difference=float(np.nanmax(np.abs(oldpred[col] - newpred[col])))))
    assert np.array_equal(oldpred.support_all, newpred.support)
    oldgaps = pd.read_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/gap_manifest.csv')
    assert oldgaps[list(gapmanifest.columns)].equals(gapmanifest)
    write(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/baseline_reproduction.json', dict(status='PASS', station_and_monthly_predictions=reproduction, identical_gap_manifest=True, identical_support_mask=True))
    wide = scores.pivot(index='station_id', columns='model', values=['NSE', 'RMSE'])
    pairs = pd.DataFrame(index=wide.index)
    for name in model_names:
        pairs[f'NSE_{name}'] = wide['NSE', name]
        pairs[f'RMSE_{name}'] = wide['RMSE', name]
        pairs[f'delta_NSE_{name}_minus_monthly8'] = wide['NSE', name] - wide['NSE', 'monthly8']
        pairs[f'relative_RMSE_reduction_{name}_vs_monthly8_pct'] = 100 * (1 - wide['RMSE', name] / wide['RMSE', 'monthly8'])
    for col in ['continent', 'latitude', 'longitude']:
        pairs[col] = meta.reindex(pairs.index)[col]
    pairs['block'] = np.floor(pairs.latitude / 5).astype(int).astype(str) + '_' + np.floor(pairs.longitude / 5).astype(int).astype(str)
    pairs.to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/paired_station_scores.csv')
    rng = np.random.default_rng(20261014)
    summaries = []
    absolute_rows = []
    for name, k in MODELS:
        for metric in [f'delta_NSE_{name}_minus_monthly8', f'relative_RMSE_reduction_{name}_vs_monthly8_pct']:
            row = bootstrap_row(pairs, metric, rng)
            row.update(model=name, max_references='all' if k is None else k, baseline='monthly8')
            summaries.append(row)
        ns = bootstrap_row(pairs, f'NSE_{name}', rng)
        ss = scores[scores.model == name]
        absolute_rows.append(dict(model=name, max_references='all' if k is None else k, n_stations=len(ss), n_finite_NSE=int(ss.NSE.notna().sum()), median_NSE=float(ss.NSE.median()), median_NSE_ci_low=ns['ci_low'], median_NSE_ci_high=ns['ci_high'], n_spatial_blocks=ns['n_blocks'], median_RMSE=float(ss.RMSE.median()), supported_months=int(ss.supported.sum()), months=int(ss.n.sum())))
    summary = pd.DataFrame(absolute_rows)
    summary.to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/model_summary.csv', index=False)
    pd.DataFrame(summaries).to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/paired_summary.csv', index=False)
    scores.groupby(['continent', 'model']).agg(n=('NSE', 'size'), median_NSE=('NSE', 'median'), median_RMSE=('RMSE', 'median'), supported_months=('supported', 'sum'), months=('n', 'sum')).to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/regional_summary.csv')
    differences = 'Old and new reference-count experiments must not be conflated.\nOld count audit: 3,004 stations; fixed reference selection per gap; equal-weight anomaly combination; counts 1,2,4,8,16; reported station-median NSE 0.784,0.818,0.824,0.810,0.787. A separate audit cohort, not a successive filter of the 2,990-station set.\nCurrent sensitivity: same 2,990 frozen complete-case stations as the operational selector/combiner comparison, using the 9,410 original gaps with L>=2 and 94,242 hidden months. All qualified candidates searched in the original spatial pool. Each month chooses up to K reporting references in the fixed r*exp(-distance/800) ranking; weights use that same score and renormalize over selected reporting gauges. Original DAT transformation and numerical guard preserved.\nThe count comparison changes only K. It uses no R3 result to optimize K and does not alter the existing R3 reconstruction. Counts with K>=1 have identical supported months, so count-dependent performance differences concern aggregation of available reference signals rather than coverage.\nThe earlier complete-case selector/combiner table also includes L=1 gaps (9,439 masks); the authoritative  rule comparison excludes those (9,410 masks).\n'
    (_PROJECT_ROOT / 'workflows/benchmarks/reference_count/old_and_new_protocols.txt').write_text(differences, encoding='utf-8')
    files = [p for p in HERE.iterdir() if p.is_file() and p.name not in {'audit.json', 'output_hashes.json'}]
    write(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/output_hashes.json', [dict(path=p.name, size_bytes=p.stat().st_size, sha256=sha(p)) for p in files])
    assert all((sha(x['path']) == x['sha256'] for x in sources)), 'Input source changed during run'
    write(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/audit.json', dict(status='PASS', created_utc=pd.Timestamp.now(tz='UTC').isoformat(), n_stations=len(wide), n_gaps=len(gaps), n_months=94242, supported_months_each_model=85969, same_support_all_counts=True, baseline_monthly8_and_all_reproduced=True, original_source_files_unchanged=True, protocol_sha256=sha(_PROJECT_ROOT / 'workflows/benchmarks/reference_count/protocol.json'), script_sha256=sha(__file__), bootstrap_draws=2000, bootstrap_seed=20261014, spatial_block_degrees=5, elapsed_seconds=time.time() - t0))
    print(summary.to_string(index=False), flush=True)
    print(pd.DataFrame(summaries).to_string(index=False), flush=True)
if __name__ == '__main__':
    main()
