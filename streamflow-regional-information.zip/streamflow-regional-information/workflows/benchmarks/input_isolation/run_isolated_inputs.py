"""Execute the original matched deep trainers through isolated dataset views.

Frozen architecture, seeds, optimizer, losses, epochs and early stopping. Source
trainers stay read-only. Only device routing, output routing, memoization and
progress/checkpoint logging are adapted. --execute is required to train.
"""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
import argparse, importlib.util, inspect, json, sys, time
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode = True
HERE = _PROJECT_ROOT / 'workflows/benchmarks/input_isolation'
ROOT = _PROJECT_ROOT
pass
pass
from workflows.benchmarks.input_isolation.audit_exposure import jwrite, sha
from workflows.benchmarks.input_isolation.training_hooks import adapt_training_source

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--scale', choices=['monthly', 'daily'], required=True)
    p.add_argument('--models', default='lstm,brits,saits')
    p.add_argument('--device', choices=['cpu', 'mps', 'cuda'], default='cpu')
    p.add_argument('--protocol', choices=['isolated', 'original'], default='isolated')
    p.add_argument('--execute', action='store_true')
    p.add_argument('--resume', action='store_true')
    p.add_argument('--cpu-threads', type=int, default=4)
    args = p.parse_args()
    names = args.models.split(',')
    assert all((n in ['lstm', 'brits', 'saits'] for n in names))
    dest = _PROJECT_ROOT / 'workflows/benchmarks/input_isolation/training_runs' / args.scale / args.protocol
    dest.mkdir(parents=True, exist_ok=True)
    plan = {'scale': args.scale, 'models': names, 'device': args.device, 'protocol': args.protocol, 'seed': 0, 'hidden': 64, 'learning_rate': 0.001, 'batch_size': 32, 'epochs_upper_limit': 50 if args.scale == 'monthly' else 80, 'early_stopping_patience': 10 if args.scale == 'monthly' else 12, 'checkpoint_selection': 'validation_loss' if args.scale == 'monthly' else 'validation_station_median_NSE', 'monthly_uncertainty_loss_enabled': args.scale == 'monthly', 'target_only_source_predictions_reused': True, 'training_started': False}
    jwrite(dest / 'run_plan.json', plan)
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return
    import torch
    assert args.device != 'mps' or torch.backends.mps.is_available(), 'MPS unavailable (run in approved GPU-enabled host context).'
    assert args.device != 'cuda' or torch.cuda.is_available()
    torch.set_num_threads(args.cpu_threads)
    from workflows.benchmarks.input_isolation.isolated_data import build
    ds, cfg, roles = build(args.scale, args.protocol)
    start = time.time()
    for name in names:
        folder = dest / name
        folder.mkdir(exist_ok=True)
        if (folder / 'completion.json').exists():
            print(f'Skip completed {name}; outputs preserved', flush=True)
            continue
        began = time.time()
        jwrite(folder / 'status.json', dict(plan, model=name, status='RUNNING', torch_version=torch.__version__, started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
        try:

            def resume(model, opt, rng, best_value, best_state, bad, history):
                checkpoint = folder / 'epoch_checkpoint.pth'
                if not args.resume or not checkpoint.exists():
                    return (0, best_value, best_state, bad, history)
                saved = torch.load(checkpoint, map_location='cpu', weights_only=False)
                assert saved['configuration'] == cfg and saved['model_name'] == name
                for key in ['scale', 'device', 'protocol', 'seed', 'hidden', 'learning_rate', 'batch_size', 'epochs_upper_limit', 'early_stopping_patience']:
                    assert saved['plan'][key] == plan[key], (key, saved['plan'][key], plan[key])
                model.load_state_dict(saved['model'])
                opt.load_state_dict(saved['optimizer'])
                rng.bit_generator.state = saved['batch_shuffle_rng']
                torch.set_rng_state(saved['torch_cpu_rng'])
                if args.device == 'mps':
                    torch.mps.set_rng_state(saved['torch_mps_rng'])
                print(f"Resumed {args.scale}/{name} after epoch {saved['epoch']}", flush=True)
                next_epoch = saved['epoch']
                if saved['bad_epochs'] >= plan['early_stopping_patience']:
                    next_epoch = plan['epochs_upper_limit']
                return (next_epoch, saved['best_value'], saved['best_state'], saved['bad_epochs'], saved['history'])

            def periodic(ep, model, opt, best_value, best_state, bad, rng, history):
                payload = {'epoch': ep, 'model': {k: v.detach().cpu() for k, v in model.state_dict().items()}, 'optimizer': opt.state_dict(), 'best_value': best_value, 'best_state': best_state, 'bad_epochs': bad, 'batch_shuffle_rng': rng.bit_generator.state, 'torch_cpu_rng': torch.get_rng_state(), 'torch_mps_rng': torch.mps.get_rng_state() if args.device == 'mps' else None, 'history': history, 'configuration': cfg, 'plan': plan, 'model_name': name}
                tmp = folder / 'epoch_checkpoint.tmp'
                torch.save(payload, tmp)
                tmp.replace(folder / 'epoch_checkpoint.pth')
                jwrite(folder / 'training_curve.json', history)
                print(f'{args.scale} {name} checkpoint epoch={ep} best={best_value:.6f} bad={bad} elapsed={time.time() - began:.1f}s', flush=True)
            if args.scale == 'monthly':
                source = _PROJECT_ROOT / 'workflows/benchmarks/train_deep_baselines.py'
                text = adapt_training_source(source.read_text(encoding='utf-8'), 'monthly', args.device)
                namespace = {'__name__': 'isolation_monthly_trainer', '__file__': str(source)}
                exec(compile(text, str(source), 'exec'), namespace)
                namespace['audit_periodic'] = periodic
                namespace['audit_resume'] = resume
                namespace['load_station_matrix'] = lambda *a, **k: ds.flow_df
                namespace['drop_gsim_twins'] = lambda flow: flow
                namespace['load_static'] = lambda *a, **k: ds.static_df

                def factory(flow, static, actual_cfg):
                    assert actual_cfg == cfg
                    return ds
                namespace['GapImputationDataset'] = factory
                save = namespace['save_run_outputs']
                append = namespace['append_result']
                namespace['save_run_outputs'] = lambda root, tag, records, df=None, summary=None: save(str(folder), tag, records, df, summary)
                namespace['append_result'] = lambda path, row: append(str(folder / 'results_summary.csv'), row)
                oldargv = sys.argv
                sys.argv = [str(source), '--model', name, '--series_dir', 'IN_MEMORY_ISOLATED_DATA', '--static', str(_PROJECT_ROOT / 'data/global_station_meta_kg.csv'), '--use_donor', '--uncertainty', '--epochs', '50', '--patience', '10', '--seed', '0', '--lr', '0.001', '--hidden', '64', '--run_id', f'isolation_{args.protocol}', '--out', str(folder / 'checkpoints')]
                try:
                    namespace['main']()
                finally:
                    sys.argv = oldargv
            else:
                import workflows.benchmarks.daily.run_benchmark as original
                source = _PROJECT_ROOT / 'workflows/benchmarks/daily/run_benchmark.py'
                code = adapt_training_source(inspect.getsource(original.train_eval_deep), 'daily', args.device)
                namespace = dict(vars(original))
                history = []

                def audit_epoch(ep, value):
                    history.append({'epoch': ep, 'validation_station_median_NSE': float(value)})
                    jwrite(folder / 'training_curve.json', history)
                    print(f'daily {name} epoch={ep} val_median_NSE={value:.6f} elapsed={time.time() - began:.1f}s', flush=True)

                def audit_checkpoint(model, best):
                    torch.save({'model': model.state_dict(), 'model_name': name, 'hidden': 64, 'use_donor': True, 'config': cfg, 'seed': 0, 'protocol': args.protocol, 'best_validation_median_nse': best}, folder / 'best_model.pth')

                def dump(tag, recs, run_id=''):
                    import pandas as pd
                    pd.DataFrame(recs, columns=['station_id', 'date', 'obs', 'pred']).to_csv(folder / 'predictions_long.csv', index=False)
                namespace.update(audit_epoch=audit_epoch, audit_checkpoint=audit_checkpoint, audit_periodic=periodic, audit_resume=resume, audit_history=history, _dump=dump)
                exec(compile(code, str(source), 'exec'), namespace)
                tr = [i for i, g in enumerate(ds.gaps) if roles[g.station_id] == 'train']
                va = [i for i, g in enumerate(ds.gaps) if roles[g.station_id] == 'validation']
                te = [i for i, g in enumerate(ds.gaps) if roles[g.station_id] == 'test']
                score, summary, n = namespace['train_eval_deep'](name, True, ds, tr, va, te, cfg, SimpleNamespace(smoke=False, epochs=80, patience=12), tag=name, dump=True, run_id=f'isolation_{args.protocol}')
                jwrite(folder / 'test_summary.json', {'station_median_NSE': score, 'n': n, 'summary': summary})
            complete = dict(plan, model=name, status='COMPLETED', training_started=True, elapsed_seconds=time.time() - began, torch_version=torch.__version__, source_trainer=str(source.relative_to(ROOT)), source_trainer_sha256=sha(source), adaptation='Read-only source execution; device/output routing and daily logging only; isolated dataset view; no epoch truncation.')
            jwrite(folder / 'completion.json', complete)
            jwrite(folder / 'status.json', complete)
        except BaseException as e:
            jwrite(folder / 'status.json', dict(plan, model=name, status='FAILED', training_started=True, error=repr(e), elapsed_seconds=time.time() - began))
            raise
    print(f'All requested models completed in {time.time() - start:.1f}s', flush=True)
if __name__ == '__main__':
    main()
