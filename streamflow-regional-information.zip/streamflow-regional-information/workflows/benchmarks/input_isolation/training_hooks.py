"""Attach device, resume and logging hooks without rewriting scientific logic.

Only the named training-control statements are transformed. The architecture,
loss, optimizer, seeds, validation criteria and stopping thresholds are retained.
Every required insertion is checked before the adapted trainer is executed.
"""
from __future__ import annotations

import ast
from collections import Counter


def _statements(source):
    return ast.parse(source).body


class _TrainingHooks(ast.NodeTransformer):
    def __init__(self, scale, device):
        if scale not in {"monthly", "daily"}:
            raise ValueError(scale)
        if device not in {"cpu", "cuda", "mps"}:
            raise ValueError(device)
        self.scale = scale
        self.device = device
        self.active = False
        self.in_epoch = False
        self.hits = Counter()

    @property
    def periodic(self):
        if self.scale == "monthly":
            return "audit_periodic(ep, model, opt, best_val, best_state, bad, rng, history)"
        return "audit_periodic(ep, model, opt, best, bs, bad, rng, audit_history)"

    def visit_FunctionDef(self, node):
        intended = "main" if self.scale == "monthly" else "train_eval_deep"
        if node.name == intended:
            self.active = True
            self.hits["function"] += 1
            node = self.generic_visit(node)
            self.active = False
            return node
        # Do not modify nested helpers or other training/evaluation functions.
        return node

    def visit_Assign(self, node):
        if not self.active:
            return node
        names = {target.id for target in node.targets if isinstance(target, ast.Name)}
        device_name = "device" if self.scale == "monthly" else "dev"
        if device_name in names:
            self.hits["device"] += 1
            node.value = ast.Constant(self.device)
        if self.scale == "monthly" and "history" in names and isinstance(node.value, ast.List):
            self.hits["resume"] += 1
            return [node, *_statements("resume_epoch, best_val, best_state, bad, history = audit_resume(model, opt, rng, best_val, best_state, bad, history)")]
        if self.scale == "daily" and "epmax" in names:
            self.hits["resume"] += 1
            return [node, *_statements("resume_epoch, best, bs, bad, restored_history = audit_resume(model, opt, rng, best, bs, bad, audit_history)\naudit_history[:] = restored_history")]
        if self.scale == "daily" and self.in_epoch and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == "ev":
            self.hits["validation_log"] += 1
            return [node, *_statements("audit_epoch(ep, v)")]
        return node

    def visit_For(self, node):
        is_epoch = self.active and isinstance(node.target, ast.Name) and node.target.id == "ep"
        if not is_epoch:
            return self.generic_visit(node)
        if not (isinstance(node.iter, ast.Call) and isinstance(node.iter.func, ast.Name) and node.iter.func.id == "range" and len(node.iter.args) == 2 and isinstance(node.iter.args[0], ast.Constant) and node.iter.args[0].value == 1):
            raise ValueError("Unexpected epoch-loop structure; no adaptation performed")
        self.hits["epoch_loop"] += 1
        node.iter.args[0] = ast.parse("resume_epoch + 1", mode="eval").body
        self.in_epoch = True
        node = self.generic_visit(node)
        self.in_epoch = False
        node.body.extend(_statements(self.periodic))
        self.hits["epoch_checkpoint"] += 1
        return node

    def visit_Break(self, node):
        if self.active and self.in_epoch:
            self.hits["early_stop_checkpoint"] += 1
            return [*_statements(self.periodic), node]
        return node

    def visit_If(self, node):
        node = self.generic_visit(node)
        if self.active and self.scale == "daily" and ast.unparse(node.test) == "bs is not None":
            self.hits["best_checkpoint"] += 1
            return [node, *_statements("audit_checkpoint(model, best)")]
        return node


def adapt_training_source(source: str, scale: str, device: str) -> str:
    """Return an instrumented trainer or fail if its control structure differs."""
    transformer = _TrainingHooks(scale, device)
    tree = transformer.visit(ast.parse(source))
    required = {"function", "device", "resume", "epoch_loop", "epoch_checkpoint", "early_stop_checkpoint"}
    if scale == "daily":
        required |= {"validation_log", "best_checkpoint"}
    unexpected = {key: transformer.hits[key] for key in required if transformer.hits[key] != 1}
    if unexpected:
        raise ValueError(f"Trainer instrumentation is ambiguous or incomplete: {unexpected}")
    ast.fix_missing_locations(tree)
    compile(tree, f"<adapted_{scale}_trainer>", "exec")
    return ast.unparse(tree) + "\n"
