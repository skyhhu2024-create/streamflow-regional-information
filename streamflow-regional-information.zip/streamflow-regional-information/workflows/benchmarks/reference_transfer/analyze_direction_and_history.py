"""Paired DAT8 audit on cohorts with complete selected-pool-8 support.

All contrasts hold station and hidden calendar block fixed. The primary
cohort is the 1990 subset common to all durations, histories, and directions
with complete R2-selected-pool-8 support. A duration-matched 1995 cohort with
the same support definition is included as sensitivity.
The top-four comparator changes both pool size and pooling rule; it is a
configuration sensitivity, not an isolated donor-count effect.
"""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import json
from pathlib import Path
import numpy as np
import pandas as pd
HERE = _PROJECT_ROOT / 'workflows/benchmarks/reference_transfer'
ROOT = _PROJECT_ROOT
COHORT = _PROJECT_ROOT / 'workflows/benchmarks/extensions/outputs/cohort_membership.csv'
KEY = ['station_id', 'year', 'history', 'horizon', 'direction']

def effect(label: str, values: np.ndarray, seed: int, n_boot: int=3000):
    x = np.asarray(values, float)
    x = x[np.isfinite(x)]
    rng = np.random.default_rng(seed)
    if len(x):
        draw = rng.integers(0, len(x), size=(n_boot, len(x)))
        medians = np.median(x[draw], axis=1)
        lo, hi = np.quantile(medians, [0.025, 0.975])
        med = np.median(x)
    else:
        lo = hi = med = np.nan
    return dict(contrast=label, n=len(x), median=float(med), ci_low=float(lo), ci_high=float(hi), share_positive=float(np.mean(x > 0)) if len(x) else np.nan, median_absolute=float(np.median(np.abs(x))) if len(x) else np.nan, share_absolute_gt_0_1=float(np.mean(np.abs(x) > 0.1)) if len(x) else np.nan)

def main():
    assert not (_PROJECT_ROOT / 'workflows/benchmarks/reference_transfer/paired_direction_history_r2full.csv').exists(), 'Completed paired audit must not be overwritten'
    dat = pd.read_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_transfer/case_metrics.csv.gz')
    cohort = pd.read_csv(COHORT, usecols=KEY + ['matched_full_support', 'strict_common_duration', 'n_valid_history'])
    assert len(dat) == len(cohort)
    dat = dat.merge(cohort, on=KEY, how='left', validate='one_to_one')
    assert dat.matched_full_support.notna().all()
    old_strict = dat[dat.strict_common_duration & (dat.year == 1990)].copy()
    full_strict_ids = old_strict.groupby('station_id').apply(lambda g: len(g) == 24 and bool((g.support8 == g.horizon).all()), include_groups=False)
    strict = old_strict[old_strict.station_id.isin(full_strict_ids[full_strict_ids].index)]
    old_matched95 = dat[dat.matched_full_support & (dat.year == 1995)].copy()
    full_match95 = old_matched95.groupby(['horizon', 'station_id']).apply(lambda g: len(g) == 6 and bool((g.support8 == g.name[0]).all()), include_groups=False)
    good95 = full_match95[full_match95].index
    matched95 = old_matched95.set_index(['horizon', 'station_id'])
    matched95 = matched95.loc[matched95.index.isin(good95)].reset_index()
    records = []
    seed = 3918
    cohort_counts = []
    for cohort_name, subset in (('r2full_strict1990', strict), ('r2full_matched1995', matched95)):
        for L, g in subset.groupby('horizon'):
            wide = g.pivot(index='station_id', columns=['history', 'direction'], values='nse8')
            cohort_counts.append(dict(cohort=cohort_name, horizon=L, n_stations=len(wide), n_finite_h120_pair=int(np.isfinite(wide[120, 'backward']).mul(np.isfinite(wide[120, 'forward'])).sum())))
            for H in (24, 60, 120):
                x = wide[H, 'backward'] - wide[H, 'forward']
                records.append(dict(cohort=cohort_name, horizon=L, history=H, **effect('backward_minus_forward_nse8', x.to_numpy(), seed)))
                seed += 1
            for direction in ('forward', 'backward'):
                for h0, h1 in ((24, 60), (60, 120), (24, 120)):
                    x = wide[h1, direction] - wide[h0, direction]
                    records.append(dict(cohort=cohort_name, horizon=L, history=f'{h1}-{h0}', **effect(f'history_gain_{direction}_nse8', x.to_numpy(), seed)))
                    seed += 1
            for h0, h1 in ((24, 60), (60, 120), (24, 120)):
                x = wide[h1, 'backward'] - wide[h0, 'backward'] - (wide[h1, 'forward'] - wide[h0, 'forward'])
                records.append(dict(cohort=cohort_name, horizon=L, history=f'{h1}-{h0}', **effect('backward_minus_forward_history_gain_nse8', x.to_numpy(), seed)))
                seed += 1
            p = g.set_index(['station_id', 'history', 'direction'])
            for H in (24, 60, 120):
                for direction in ('forward', 'backward'):
                    ss = p.loc[(slice(None), H, direction), :]
                    x = ss.nse8.to_numpy(float) - ss.nse4.to_numpy(float)
                    records.append(dict(cohort=cohort_name, horizon=L, history=H, **effect(f'selected8_minus_dynamic4_{direction}_nse', x, seed)))
                    seed += 1
    out = pd.DataFrame(records)
    out.to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_transfer/paired_direction_history_r2full.csv', index=False)
    pd.DataFrame(cohort_counts).to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_transfer/paired_cohort_counts_r2full.csv', index=False)
    summary = strict.groupby(['history', 'direction']).agg(median_valid_history=('n_valid_history', 'median'), median_selected8=('n_selected8', 'median'), median_n_qualified=('n_qualified', 'median'), full_support8=('support8', lambda s: float(np.mean(s.to_numpy() == strict.loc[s.index, 'horizon'].to_numpy()))), n=('station_id', 'size')).reset_index()
    summary.to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_transfer/strict_cohort_calibration_summary_r2full.csv', index=False)
    audit = dict(status='PASS', bootstrap='3000 whole-station resamples per contrast, seed sequence 3918+', primary_cohort='1990 original strict cohort restricted to selected-pool-8 full support across all 24 conditions', sensitivity_cohort='1995 duration-matched selected-pool-8 full-support stations', n_rows=len(out), n_primary_station_ids=strict.station_id.nunique(), top8_is_r2_selected_pool=True, top4_comparison='configuration sensitivity; donor count and selection rule both differ')
    (_PROJECT_ROOT / 'workflows/benchmarks/reference_transfer/paired_analysis_audit_r2full.json').write_text(json.dumps(audit, indent=2))
    print(json.dumps(audit, indent=2))
    print(out[(out.cohort == 'r2full_strict1990') & out.contrast.isin(['backward_minus_forward_nse8', 'backward_minus_forward_history_gain_nse8'])].to_string(index=False))
if __name__ == '__main__':
    main()
