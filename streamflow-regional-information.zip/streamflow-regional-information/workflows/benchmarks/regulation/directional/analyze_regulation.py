"""Independent, post hoc metadata and coherence-transfer diagnostics.

Read-only on inputs; all derived outputs stay beside this script. Reservoir
information never enters the reconstruction models or sample selection.
"""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
HERE = _PROJECT_ROOT / 'workflows/benchmarks/regulation/directional'
ROOT = _PROJECT_ROOT
EXP = _PROJECT_ROOT / 'workflows/benchmarks/extensions'
SEED = 20260922
BOOT = 2000
KEY = ['station_id', 'cutoff', 'horizon', 'direction']
PAIR_KEY = ['station_id', 'cutoff', 'horizon']
MODEL = 'AR1_reference_bridge__observed'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def flag(series):
    return series.astype(str).str.lower().map({'true': True, 'false': False, '1': True, '0': False})

def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=lambda x: x.item() if isinstance(x, np.generic) else str(x)), encoding='utf-8')

def prepare_metadata():
    stations = pd.read_csv(_PROJECT_ROOT / 'data/gsim_dor.csv').rename(columns={'gsim.no': 'station_id'})
    dams = pd.read_csv(_PROJECT_ROOT / 'data/gsim_dor_dams.csv').rename(columns={'gsim.no': 'station_id'})
    assert not stations.station_id.duplicated().any(), 'Duplicate station metadata keys'
    assert stations.station_id.notna().all() and dams.station_id.notna().all()
    for c in ['qc_area', 'qc_dam', 'qc_dor', 'reassigned']:
        stations[c] = flag(stations[c])
    duplicate_pair_rows = int(dams.duplicated(['station_id', 'gdw_id']).sum())
    exact_duplicate_rows = int(dams.duplicated().sum())
    conflicts = dams.groupby(['station_id', 'gdw_id'], dropna=False)[['year', 'cap_mcm']].nunique(dropna=False).max(axis=1)
    conflict_ids = set(conflicts[conflicts > 1].index.get_level_values('station_id'))
    dams = dams.drop_duplicates(['station_id', 'gdw_id']).copy()
    dams['valid_year'] = dams.year.notna() & dams.year.between(1, 2026) & (dams.year == dams.year.round())
    dams['positive_capacity'] = dams.cap_mcm.gt(0) & np.isfinite(dams.cap_mcm)
    dams['known_cap'] = dams.cap_mcm.where(dams.positive_capacity, 0)
    dams['dated_cap'] = dams.known_cap.where(dams.valid_year, 0)
    dams['positive_dated'] = dams.positive_capacity & dams.valid_year
    agg = dams.groupby('station_id').agg(pair_n_dams=('gdw_id', 'size'), positive_capacity_dams=('positive_capacity', 'sum'), positive_dated_dams=('positive_dated', 'sum'), pair_total_known_cap_mcm=('known_cap', 'sum'), pair_dated_cap_mcm=('dated_cap', 'sum'))
    stations = stations.merge(agg, on='station_id', how='left', validate='one_to_one')
    for c in agg.columns:
        stations[c] = stations[c].fillna(0)
    stations['metadata_conflict'] = stations.station_id.isin(conflict_ids)
    stations['clean_mapping'] = stations[['qc_area', 'qc_dam', 'qc_dor']].eq(False).all(axis=1) & stations.area_reported.gt(0) & np.isfinite(stations.area_reported) & ~stations.metadata_conflict
    stations['dated_capacity_fraction'] = stations.pair_dated_cap_mcm / stations.pair_total_known_cap_mcm.replace(0, np.nan)
    stations['timing_complete_90'] = stations.clean_mapping & stations.dated_capacity_fraction.ge(0.9)
    stations['timing_complete_all'] = stations.clean_mapping & stations.positive_capacity_dams.gt(0) & stations.positive_capacity_dams.eq(stations.positive_dated_dams)
    stations['static_stratum'] = np.select([~stations.clean_mapping, stations.pair_n_dams.eq(0), stations.positive_capacity_dams.eq(0), ~np.isfinite(stations.dor_pc), stations.dor_pc.le(50)], ['mapping_qc_or_conflict', 'no_mapped_reservoir', 'mapped_no_positive_capacity', 'missing_dor', 'positive_capacity_dor_le50'], default='positive_capacity_dor_gt50')
    count_mismatch = stations.n_dams.ne(stations.pair_n_dams)
    cap_error = (stations.cap_mcm - stations.pair_total_known_cap_mcm).abs()
    audit = {'source_hashes': {name: sha(ROOT / name) for name in ['gsim_dor.csv', 'gsim_dor_dams.csv', 'workflows/benchmarks/regulation/build_storage_ratio.py']}, 'n_station_records': len(stations), 'n_unique_station_dam_pairs': len(dams), 'n_duplicate_pair_rows': duplicate_pair_rows, 'n_exact_duplicate_rows': exact_duplicate_rows, 'n_conflicting_stations': len(conflict_ids), 'n_pair_count_mismatch': int(count_mismatch.sum()), 'n_capacity_sum_mismatch_over_1e-6': int(cap_error.gt(1e-06).sum()), 'n_clean_mapping': int(stations.clean_mapping.sum()), 'n_clean_reassigned': int((stations.clean_mapping & stations.reassigned.eq(True)).sum()), 'n_timing_complete_90': int(stations.timing_complete_90.sum()), 'n_timing_complete_all': int(stations.timing_complete_all.sum()), 'source_limitations': ['No mapped reservoirs does not establish unregulated flow.', 'Missing or zero capacity may reflect source missing values converted to zero by the old builder.', 'Static DOR denominator is full-record mean flow and is not time-isolated.', 'The original inventory excludes removed reservoirs and omits some HydroBASINS regions.', 'cross_year is cumulative static-denominator DOR exceeding 50%, not the first dam year.']}
    assert not count_mismatch.any(), 'Source station counts disagree with deduplicated pairs'
    assert not cap_error.gt(1e-06).any(), 'Source capacities disagree with deduplicated pairs'
    stations.to_csv(_PROJECT_ROOT / 'workflows/benchmarks/regulation/directional/station_regulation_metadata.csv', index=False)
    stations.groupby('static_stratum', dropna=False).agg(n_stations=('station_id', 'size'), n_timing_complete_90=('timing_complete_90', 'sum'), n_timing_complete_all=('timing_complete_all', 'sum')).reset_index().to_csv(_PROJECT_ROOT / 'workflows/benchmarks/regulation/directional/metadata_coverage.csv', index=False)
    write_json(_PROJECT_ROOT / 'workflows/benchmarks/regulation/directional/metadata_audit.json', audit)
    return (stations, dams, audit)

def finite_corr(x, y):
    x, y = (np.asarray(x, float), np.asarray(y, float))
    keep = np.isfinite(x) & np.isfinite(y)
    x, y = (x[keep], y[keep])
    if len(x) < 3 or np.std(x) <= 1e-10 or np.std(y) <= 1e-10:
        return (np.nan, len(x))
    return (float(np.corrcoef(x, y)[0, 1]), len(x))

def r2positive(r):
    return max(r, 0.0) ** 2 if np.isfinite(r) else np.nan

def nse(y, pred):
    y, pred = (np.asarray(y, float), np.asarray(pred, float))
    k = np.isfinite(y) & np.isfinite(pred)
    y, pred = (y[k], pred[k])
    den = float(np.sum((y - y.mean()) ** 2)) if len(y) else 0.0
    return 1 - float(np.sum((y - pred) ** 2)) / den if den > 1e-12 else np.nan

def spearman(x, y):
    return finite_corr(pd.Series(x).rank().to_numpy(), pd.Series(y).rank().to_numpy())[0]

def bootstrap_stat(values, statistic='median', y=None):
    x = np.asarray(values, float)
    keep = np.isfinite(x)
    if y is not None:
        y = np.asarray(y, float)
        keep &= np.isfinite(y)
        y = y[keep]
    x = x[keep]
    point = np.median(x) if statistic == 'median' and len(x) else spearman(x, y) if len(x) else np.nan
    if len(x) < 30:
        return (float(point), np.nan, np.nan, len(x))
    rng = np.random.default_rng(SEED)
    stats = []
    for _ in range(BOOT):
        ix = rng.integers(0, len(x), size=len(x))
        stats.append(float(np.median(x[ix])) if statistic == 'median' else spearman(x[ix], y[ix]))
    lo, hi = np.nanquantile(stats, [0.025, 0.975])
    return (float(point), float(lo), float(hi), len(x))

def used_reference_ids(values):
    result = set()
    for value in values:
        parsed = json.loads(value) if isinstance(value, str) else value
        assert isinstance(parsed, list)
        result.update((str(x) for x in parsed))
    return sorted(result)

def classify_event(sids, start_year, end_year, metadata, dam_years, strict=False):
    if not sids:
        return ('unknown', 0, 0, 0)
    event_ids, unknown, n_clean = (set(), 0, 0)
    for sid in sids:
        if sid not in metadata.index:
            unknown += 1
            continue
        row = metadata.loc[sid]
        if not bool(row.clean_mapping):
            unknown += 1
            continue
        n_clean += 1
        for dam_id, year in dam_years.get(sid, []):
            if start_year <= year <= end_year:
                event_ids.add(int(dam_id))
        complete = row.pair_n_dams == 0 or bool(row.timing_complete_all if strict else row.timing_complete_90)
        if not complete:
            unknown += 1
    state = 'dated_addition' if event_ids else 'unknown' if unknown else 'no_recorded_addition'
    return (state, len(event_ids), unknown, n_clean)

def event_union(states):
    values = set(states)
    if 'dated_addition' in values:
        return 'dated_addition'
    return 'unknown' if 'unknown' in values else 'no_recorded_addition'

def combined_event(target, reference):
    if target == 'dated_addition' and reference == 'dated_addition':
        return 'both_target_and_reference'
    if target == 'dated_addition':
        return 'target_addition_reference_unknown' if reference == 'unknown' else 'target_only'
    if reference == 'dated_addition':
        return 'reference_addition_target_unknown' if target == 'unknown' else 'reference_only'
    return 'unknown' if 'unknown' in (target, reference) else 'neither_recorded'

def analyze(stations, dams, metadata_audit):
    inp = _PROJECT_ROOT / 'workflows/benchmarks/extensions/outputs'
    paths = {name: inp / name for name in ['predictions_wide.csv.gz', 'windows_and_parameters.csv']}
    for path in paths.values():
        assert path.exists(), f'Missing experiment output: {path}'
    windows = pd.read_csv(paths['windows_and_parameters.csv'])
    pred = pd.read_csv(paths['predictions_wide.csv.gz'])
    required = KEY + ['date', 'obs', 'reference_composite', 'target_z_for_scoring_only', 'base_used_reference_ids', 'cohort_both_full_support', MODEL]
    assert set(required).issubset(pred.columns), sorted(set(required) - set(pred.columns))
    assert not windows.duplicated(KEY).any(), 'Nonunique directional windows'
    assert not pred.duplicated(KEY + ['date']).any(), 'Repeated prediction month within window'
    for c in ['qualification_start', 'qualification_end', 'train_coherence_r', 'train_coherence_r2', 'test_coherence_r', 'test_coherence_r2']:
        assert c in windows, c
    pred['cohort_both_full_support'] = flag(pred.cohort_both_full_support)
    main = pred[pred.cohort_both_full_support.eq(True)].copy()
    assert len(main) and set(main.direction) == {'forward', 'backward'}
    metadata = stations.set_index('station_id', verify_integrity=True)
    dated = dams[dams.positive_dated]
    dam_years = {sid: list(zip(g.gdw_id.astype(int), g.year.astype(int))) for sid, g in dated.groupby('station_id')}
    wlookup = windows.set_index(KEY, verify_integrity=True)
    records, all_used = ([], set())
    max_r_error = 0.0
    for key, g in main.groupby(KEY, sort=True):
        w = wlookup.loc[key]
        sid, cutoff, horizon, direction = key
        r, n = finite_corr(g.target_z_for_scoring_only, g.reference_composite)
        recorded_r = float(w.test_coherence_r)
        assert np.isfinite(r) == np.isfinite(recorded_r), f'Coherence availability mismatch {key}'
        if np.isfinite(r):
            max_r_error = max(max_r_error, abs(r - recorded_r))
            assert abs(r - recorded_r) < 1e-08, f'Coherence disagreement {key}'
        ref_ids = used_reference_ids(g.base_used_reference_ids)
        all_used.update(ref_ids)
        start_year = min(pd.Timestamp(w.qualification_start).year, pd.to_datetime(g.date).min().year)
        end_year = max(pd.Timestamp(w.qualification_end).year, pd.to_datetime(g.date).max().year)
        target = classify_event([sid], start_year, end_year, metadata, dam_years)
        reference = classify_event(ref_ids, start_year, end_year, metadata, dam_years)
        target_all = classify_event([sid], start_year, end_year, metadata, dam_years, strict=True)
        reference_all = classify_event(ref_ids, start_year, end_year, metadata, dam_years, strict=True)
        hist_r = float(w.train_coherence_r)
        rec = dict(zip(KEY, key))
        rec.update(train_r=hist_r, test_r=r, train_r2=r2positive(hist_r), test_r2=r2positive(r), delta_r=r - hist_r, delta_r2=r2positive(r) - r2positive(hist_r), test_coherence_n=n, NSE=nse(g.obs, g[MODEL]), n_months=len(g), n_used_reference_gauges=len(ref_ids), used_reference_ids=json.dumps(ref_ids), target_event=target[0], reference_event=reference[0], target_event_strict=target_all[0], reference_event_strict=reference_all[0], target_unique_dated_additions=target[1], reference_unique_dated_additions=reference[1], n_used_references_unknown_timing=reference[2], n_used_references_clean_mapping=reference[3], n_used_references_reassigned=sum((bool(metadata.at[x, 'reassigned']) for x in ref_ids if x in metadata.index)), exposure_start_year=start_year, exposure_end_year=end_year, target_static_stratum=metadata.at[sid, 'static_stratum'] if sid in metadata.index else 'unmatched_metadata', target_reassigned=bool(metadata.at[sid, 'reassigned']) if sid in metadata.index else np.nan)
        records.append(rec)
    diagnostic = pd.DataFrame(records)
    assert diagnostic.groupby(PAIR_KEY).direction.nunique().eq(2).all(), 'Unpaired main windows'
    pair_states = diagnostic.groupby(PAIR_KEY).agg(paired_target_event=('target_event', event_union), paired_reference_event=('reference_event', event_union), paired_target_event_strict=('target_event_strict', event_union), paired_reference_event_strict=('reference_event_strict', event_union), paired_n_used_references_reassigned=('n_used_references_reassigned', 'max')).reset_index()
    pair_states['paired_event_group'] = [combined_event(t, r) for t, r in zip(pair_states.paired_target_event, pair_states.paired_reference_event)]
    pair_states['paired_event_group_strict'] = [combined_event(t, r) for t, r in zip(pair_states.paired_target_event_strict, pair_states.paired_reference_event_strict)]
    pair_states['paired_any_event'] = np.select([pair_states.paired_target_event.eq('dated_addition') | pair_states.paired_reference_event.eq('dated_addition'), pair_states.paired_target_event.eq('no_recorded_addition') & pair_states.paired_reference_event.eq('no_recorded_addition')], ['any_recorded_addition', 'neither_recorded'], default='unknown')
    diagnostic = diagnostic.merge(pair_states, on=PAIR_KEY, validate='many_to_one')
    diagnostic['paired_any_event_no_reassignment'] = diagnostic.paired_any_event.where(diagnostic.target_reassigned.eq(False) & diagnostic.paired_n_used_references_reassigned.eq(0), 'excluded_reassignment_or_unknown_target')
    diagnostic.to_csv(_PROJECT_ROOT / 'workflows/benchmarks/regulation/directional/window_coherence_regulation_diagnostics.csv.gz', index=False)
    metrics = []
    for key, g in main.groupby(['station_id', 'horizon', 'direction'], sort=True):
        row = dict(zip(['station_id', 'horizon', 'direction'], key))
        row.update(NSE=nse(g.obs, g[MODEL]), n_prediction_rows=len(g), n_windows=g.cutoff.nunique())
        metrics.append(row)
    metric = pd.DataFrame(metrics)
    coh = diagnostic.groupby(['station_id', 'horizon', 'direction'])[['train_r', 'test_r', 'train_r2', 'test_r2', 'delta_r', 'delta_r2']].median().reset_index()
    metric = metric.merge(coh, on=['station_id', 'horizon', 'direction'], validate='one_to_one')
    metric.to_csv(_PROJECT_ROOT / 'workflows/benchmarks/regulation/directional/station_coherence_performance.csv', index=False)
    summaries = []
    for (horizon, direction), g in metric.groupby(['horizon', 'direction']):
        for variable in ['NSE', 'train_r', 'test_r', 'train_r2', 'test_r2', 'delta_r', 'delta_r2']:
            point, lo, hi, n = bootstrap_stat(g[variable])
            summaries.append(dict(horizon=horizon, direction=direction, analysis='station_median', variable=variable, estimate=point, low=lo, high=hi, n_gauges=n))
        for variable in ['train_r2', 'test_r2', 'delta_r2']:
            point, lo, hi, n = bootstrap_stat(g[variable], 'spearman', g.NSE)
            summaries.append(dict(horizon=horizon, direction=direction, analysis='spearman_with_NSE', variable=variable, estimate=point, low=lo, high=hi, n_gauges=n))
    paired = metric.pivot(index=['station_id', 'horizon'], columns='direction', values=['NSE', 'train_r2', 'test_r2', 'delta_r2'])
    direction_delta = pd.DataFrame(index=paired.index)
    for var in ['NSE', 'train_r2', 'test_r2', 'delta_r2']:
        direction_delta[var + '_forward_minus_backward'] = paired[var, 'forward'] - paired[var, 'backward']
    direction_delta = direction_delta.reset_index()
    direction_delta.to_csv(_PROJECT_ROOT / 'workflows/benchmarks/regulation/directional/paired_direction_differences.csv', index=False)
    for horizon, g in direction_delta.groupby('horizon'):
        for var in ['NSE', 'train_r2', 'test_r2', 'delta_r2']:
            col = var + '_forward_minus_backward'
            point, lo, hi, n = bootstrap_stat(g[col])
            summaries.append(dict(horizon=horizon, direction='paired_forward_minus_backward', analysis='station_median', variable=var, estimate=point, low=lo, high=hi, n_gauges=n))
        for var in ['train_r2', 'test_r2', 'delta_r2']:
            point, lo, hi, n = bootstrap_stat(g[var + '_forward_minus_backward'], 'spearman', g.NSE_forward_minus_backward)
            summaries.append(dict(horizon=horizon, direction='paired_forward_minus_backward', analysis='spearman_with_NSE_difference', variable=var, estimate=point, low=lo, high=hi, n_gauges=n))
    pd.DataFrame(summaries).to_csv(_PROJECT_ROOT / 'workflows/benchmarks/regulation/directional/coherence_performance_summary.csv', index=False)
    group_rows, group_differences = ([], [])
    for label in ['target_static_stratum', 'paired_event_group', 'paired_event_group_strict', 'paired_any_event', 'paired_any_event_no_reassignment']:
        for (horizon, group), g in diagnostic.groupby(['horizon', label], dropna=False):
            station = g.groupby(['station_id', 'direction'])[['NSE', 'delta_r2']].median().reset_index()
            for direction, part in station.groupby('direction'):
                for variable in ['NSE', 'delta_r2']:
                    point, lo, hi, n = bootstrap_stat(part[variable])
                    group_rows.append(dict(horizon=horizon, stratum=label, group=group, direction=direction, variable=variable, estimate=point, low=lo, high=hi, n_gauges=n, n_windows=g[g.direction.eq(direction)].shape[0], bootstrap_minimum_met=n >= 30))
            p = station.pivot(index='station_id', columns='direction', values=['NSE', 'delta_r2'])
            if {'forward', 'backward'}.issubset(p.columns.get_level_values(1)):
                for var in ['NSE', 'delta_r2']:
                    d = p[var, 'forward'] - p[var, 'backward']
                    point, lo, hi, n = bootstrap_stat(d)
                    group_differences.append(dict(horizon=horizon, stratum=label, group=group, variable=var, estimate=point, low=lo, high=hi, n_gauges=n, bootstrap_minimum_met=n >= 30))
    pd.DataFrame(group_rows).to_csv(_PROJECT_ROOT / 'workflows/benchmarks/regulation/directional/regulation_stratum_summary.csv', index=False)
    pd.DataFrame(group_differences).to_csv(_PROJECT_ROOT / 'workflows/benchmarks/regulation/directional/regulation_paired_direction_summary.csv', index=False)
    coverage = []
    for role, ids in [('target', set(main.station_id)), ('used_reference', all_used)]:
        matched = stations[stations.station_id.isin(ids)]
        for group, sub in matched.groupby('static_stratum'):
            coverage.append(dict(role=role, stratum=group, n_gauges=len(sub), n_timing_complete_90=int(sub.timing_complete_90.sum()), n_timing_complete_all=int(sub.timing_complete_all.sum())))
        coverage.append(dict(role=role, stratum='unmatched_metadata', n_gauges=len(ids - set(stations.station_id)), n_timing_complete_90=0, n_timing_complete_all=0))
    pd.DataFrame(coverage).to_csv(_PROJECT_ROOT / 'workflows/benchmarks/regulation/directional/experiment_metadata_coverage.csv', index=False)
    audit = dict(metadata_audit, experiment_input_hashes={name: sha(path) for name, path in paths.items()}, protocol_sha256=sha(_PROJECT_ROOT / 'workflows/benchmarks/regulation/directional/PROTOCOL.md'), script_sha256=sha(__file__), n_main_prediction_rows=len(main), n_main_window_direction_records=len(diagnostic), n_primary_36m_gauges=int(main.loc[main.horizon.eq(36), 'station_id'].nunique()), n_total_target_gauges=int(main.station_id.nunique()), n_used_reference_gauges=len(all_used), max_independent_test_coherence_error=max_r_error, bootstrap_resamples=BOOT, output_hashes={p.name: sha(p) for p in HERE.glob('*.csv*')})
    write_json(_PROJECT_ROOT / 'workflows/benchmarks/regulation/directional/analysis_audit.json', audit)
    print(json.dumps({k: audit[k] for k in ['n_primary_36m_gauges', 'n_total_target_gauges', 'max_independent_test_coherence_error']}, indent=2))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--metadata-only', action='store_true')
    args = ap.parse_args()
    stations, dams, audit = prepare_metadata()
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    if not args.metadata_only:
        analyze(stations, dams, audit)
if __name__ == '__main__':
    main()
