"""Stratified evaluation of classical baselines by gap length and climate zone."""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import os, sys, argparse, re
import numpy as np
import pandas as pd
pass
from workflows.shared.data.gsim_io import load_station_matrix, load_static
from workflows.shared.data.dedup_gsim import drop_gsim_twins
from workflows.shared.data.dataset import GapImputationDataset, split_stations
from workflows.shared.utils.metrics import evaluate_by_station
from workflows.shared.utils.results_log import save_run_outputs
from workflows.shared.utils.geo import continent_of_country
KG_BANDS = [(1, 3, 'A 热带'), (4, 7, 'B 干旱'), (8, 16, 'C 温带'), (17, 28, 'D 寒带'), (29, 30, 'E 极地')]

def climate_band(cid):
    try:
        c = int(cid)
    except (ValueError, TypeError):
        return 'NA'
    for lo, hi, name in KG_BANDS:
        if lo <= c <= hi:
            return name
    return 'NA'

def cfg_default():
    return {'features': {'use_log1p': True, 'deseasonalize': True, 'per_station_standardize': True}, 'pseudo_gap': {'seed': 42, 'gaps_per_station': 4, 'length_strata': [[1, 3], [4, 12], [13, 36]], 'min_context': 12, 'edge_margin': 6}, 'donors': {'max_donors': 8, 'max_distance_km': 800, 'min_overlap_months': 24, 'min_precorr': 0.2, 'precorr_window': 60}, 'split': {'test_station_frac': 0.15, 'val_station_frac': 0.15, 'seed': 7}, 'train': {'seq_pad': 6, 'batch_size': 32}}

def predict_classical(ds, test_gaps, name):
    from workflows.shared.baselines.classical import ALL_BASELINES
    key = {'seasonal_mean': 'seasonal_mean', 'idw': 'idw', 'similarity_reg': 'similarity_reg', 'ar1': 'ar1'}.get(name, name)
    fn = ALL_BASELINES[key]
    out = {}
    _err = 0
    _first = None
    for gi, gap in enumerate(test_gaps):
        try:
            out[gi] = np.asarray(fn(ds, gap), dtype=np.float64)
        except Exception as e:
            out[gi] = None
            _err += 1
            if _first is None:
                _first = repr(e)
    if _err:
        print("  [predict_classical] %d/%d gaps failed for '%s'; first error: %s" % (_err, len(test_gaps), key, _first))
    return out

def group_eval(test_gaps, preds, ds, key_fn):
    groups = {}
    for gi, gap in enumerate(test_gaps):
        pred = preds.get(gi)
        if pred is None:
            continue
        truth = ds.flow[gap.start:gap.end + 1, ds.station_ids.index(gap.station_id)]
        ok = np.isfinite(truth)
        if ok.sum() < 2:
            continue
        g = key_fn(gap)
        d = groups.setdefault(g, {})
        d.setdefault(gap.station_id, [[], []])
        d[gap.station_id][0].append(truth[ok])
        d[gap.station_id][1].append(pred[ok])
    rows = []
    for g, perstation in sorted(groups.items()):
        obs_by = {s: np.concatenate(v[0]) for s, v in perstation.items()}
        pred_by = {s: np.concatenate(v[1]) for s, v in perstation.items()}
        _, summ = evaluate_by_station(obs_by, pred_by, peak_quantile=0.9)
        rows.append({'group': g, 'NSE_med': summ.get('NSE_median', np.nan), 'KGE_med': summ.get('KGE_median', np.nan), 'alpha_med': summ.get('alpha_median', np.nan), 'peakNSE_med': summ.get('peak_NSE_median', np.nan), 'n_stations': summ.get('n_stations', 0), 'n_gaps': sum((len(v[0]) for v in perstation.values()))})
    return pd.DataFrame(rows)

def overall_eval(records):
    """Return auditable per-station metrics and their global summary."""
    if not records:
        return (pd.DataFrame(), {})
    frame = pd.DataFrame.from_records(records)
    obs_by = {sid: g['obs'].to_numpy(float) for sid, g in frame.groupby('station_id')}
    pred_by = {sid: g['pred'].to_numpy(float) for sid, g in frame.groupby('station_id')}
    return evaluate_by_station(obs_by, pred_by, peak_quantile=0.9)

def safe_run_id(value):
    return re.sub('[^A-Za-z0-9_.-]+', '_', value).strip('_')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    pass
    ap.add_argument('--series_dir', required=True)
    ap.add_argument('--static', default=None)
    ap.add_argument('--start', default='1980-01-01')
    ap.add_argument('--end', default='2015-12-31')
    ap.add_argument('--limit', type=int, default=None)
    ap.add_argument('--leak', action='store_true', help='full-record (leaky) normalization')
    ap.add_argument('--leak_mode', choices=['none', 'mean', 'var', 'both'], default=None, help='normalization mode; --leak is retained as an alias for --leak_mode both')
    ap.add_argument('--run_id', default=None, help='write to an isolated auditable tag instead of overwriting the standard result')
    ap.add_argument('--no_dedup', action='store_true', help='不剔除 GSIM 孪生站（默认剔除，见 gsim_near_duplicates_checked.csv）')
    args = ap.parse_args()
    if args.leak and args.leak_mode not in (None, 'both'):
        ap.error("--leak cannot be combined with --leak_mode other than 'both'")
    leak_mode = args.leak_mode or ('both' if args.leak else 'none')
    run_id = safe_run_id(args.run_id) if args.run_id else None
    cfg = cfg_default()
    cfg['features']['leak_mode'] = leak_mode
    print('>> normalization leak_mode=%s' % leak_mode)
    flow = load_station_matrix(args.series_dir, args.start, args.end, min_valid_months=60, min_days_available=20, limit=args.limit)
    if not args.no_dedup:
        flow = drop_gsim_twins(flow)
    static = load_static(args.static) if args.static and os.path.exists(args.static) else pd.DataFrame(index=flow.columns)
    _, _, test_s = split_stations(flow.columns, cfg['split'])
    ds = GapImputationDataset(flow, static, cfg)
    test_gaps = [g for g in ds.gaps if g.station_id in test_s]
    print('>> model=%s  test gaps=%d' % (args.model, len(test_gaps)))
    preds = predict_classical(ds, test_gaps, args.model)
    cid_col = 'climate_id' if 'climate_id' in static.columns else None

    def band_of(gap):
        if cid_col and gap.station_id in static.index:
            return climate_band(static.at[gap.station_id, cid_col])
        return 'NA'
    recs = []
    for gi, gap in enumerate(test_gaps):
        pr = preds.get(gi)
        if pr is None:
            continue
        j = ds.station_ids.index(gap.station_id)
        for t in range(gap.length):
            obs = ds.flow[gap.start + t, j]
            if not np.isfinite(obs):
                continue
            recs.append({'station_id': gap.station_id, 'date': ds.index[gap.start + t].strftime('%Y-%m'), 'obs': float(obs), 'pred': float(pr[t]), 'stratum': gap.stratum, 'climate': band_of(gap), 'gap_id': '%s_%d' % (gap.station_id, gap.start)})
    _root = str(_PROJECT_ROOT / 'data')
    if run_id:
        output_tag = 'leakage_%s_%s_%s' % (run_id, args.model, leak_mode)
    else:
        suffix = '' if leak_mode == 'none' else '_leak' if leak_mode == 'both' else '_leak_%s' % leak_mode
        output_tag = 'stratified_%s%s' % (args.model, suffix)
    per_station, overall = overall_eval(recs)
    summary = dict(overall, model=args.model, leak_mode=leak_mode, run_id=run_id or '', start=args.start, end=args.end, limit=args.limit or 'all', deduplicated=not args.no_dedup, config=cfg, n_prediction_rows=len(recs), n_test_gaps=len(test_gaps))
    save_run_outputs(_root, output_tag, recs, per_station, summary)
    print('>> overall NSE_med=%.6f n=%d rows=%d' % (overall.get('NSE_median', float('nan')), overall.get('n_stations', 0), len(recs)))
    ctry_col = 'country' if 'country' in static.columns else None
    cont_col = 'continent' if 'continent' in static.columns else None

    def country_of(gap):
        if ctry_col and gap.station_id in static.index:
            v = static.at[gap.station_id, ctry_col]
            vs = str(v).strip().upper()
            return vs if vs and vs not in ('NAN', 'NONE') else 'UNK'
        return 'UNK'

    def continent_of(gap):
        if cont_col and gap.station_id in static.index:
            v = static.at[gap.station_id, cont_col]
            vs = str(v).strip()
            if vs and vs.lower() not in ('nan', 'none', ''):
                return vs
        return continent_of_country(country_of(gap))
    by_len = group_eval(test_gaps, preds, ds, key_fn=lambda g: g.stratum)
    by_clim = group_eval(test_gaps, preds, ds, key_fn=band_of)
    by_cont = group_eval(test_gaps, preds, ds, key_fn=continent_of)
    by_ctry = group_eval(test_gaps, preds, ds, key_fn=country_of)
    pd.set_option('display.width', 140)
    fmt = {c: lambda x: f'{x:.3f}' for c in ['NSE_med', 'KGE_med', 'alpha_med', 'peakNSE_med']}
    print('\n== 按缺口长度分层 ==')
    print(by_len.to_string(index=False, formatters=fmt))
    print('\n== 按气候带分层 ==')
    print(by_clim.to_string(index=False, formatters=fmt))
    print('\n== 按大洲分层 ==')
    print(by_cont.to_string(index=False, formatters=fmt))
    print('\n== 按国家分层(站点数>=10) ==')
    _bc = by_ctry[by_ctry['n_stations'] >= 10] if len(by_ctry) else by_ctry
    print(_bc.to_string(index=False, formatters=fmt))
    by_len['dim'] = 'gap_length'
    by_clim['dim'] = 'climate'
    by_cont['dim'] = 'continent'
    by_ctry['dim'] = 'country'
    out = pd.concat([by_len, by_clim, by_cont, by_ctry], ignore_index=True)
    out.insert(0, 'model', args.model)
    if run_id:
        fn = 'results_leakage_%s_%s_%s_stratified.csv' % (run_id, args.model, leak_mode)
    else:
        suffix = '' if leak_mode == 'none' else '_leak' if leak_mode == 'both' else '_leak_%s' % leak_mode
        fn = 'results_stratified_%s.csv' % (args.model + suffix).replace('(', '_').replace(')', '')
    out.to_csv(fn, index=False, encoding='utf-8-sig')
    print('\n[OK] saved %s' % fn)
if __name__ == '__main__':
    main()
