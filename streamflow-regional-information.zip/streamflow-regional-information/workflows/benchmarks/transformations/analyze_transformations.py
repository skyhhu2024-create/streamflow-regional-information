"""Compare strict and full-record transformations for four classical methods. Monthly scoring helpers are shared by the twelve-system benchmark."""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import os
from math import erfc, sqrt
import numpy as np
import pandas as pd
ROOT = str(_PROJECT_ROOT / 'data')
RNG = np.random.default_rng(0)
NBOOT = 2000
LEAK_PAIRS = [('DAT', 'stratified_idw', 'stratified_idw_leak'), ('Similarity reg', 'stratified_similarity_reg', 'stratified_similarity_reg_leak'), ('RF (+donor)', 'stratified_rf_donor', 'stratified_rf_donor_leak'), ('GBM (+donor)', 'stratified_gbm_donor', 'stratified_gbm_donor_leak')]

def load(tag: str) -> pd.DataFrame:
    d = pd.read_csv(_PROJECT_ROOT / 'data/results/raw' / tag / 'predictions_long.csv')
    d.columns = [c.strip().lstrip('\ufeff') for c in d.columns]
    return d

def nse(o, p):
    m = np.isfinite(o) & np.isfinite(p)
    o, p = (o[m], p[m])
    if o.size < 2:
        return np.nan
    s = ((o - o.mean()) ** 2).sum()
    return np.nan if s < 1e-12 else 1.0 - ((o - p) ** 2).sum() / s

def ra(o, p):
    m = np.isfinite(o) & np.isfinite(p)
    o, p = (o[m], p[m])
    if o.size < 3 or o.std() < 1e-09 or p.std() < 1e-12:
        return (np.nan, np.nan)
    return (float(np.corrcoef(o, p)[0, 1]), float(p.std() / o.std()))

def per_station(d: pd.DataFrame):
    ns, rs, als = ({}, {}, {})
    for sid, g in d.groupby('station_id'):
        o = g['obs'].to_numpy(float)
        p = g['pred'].to_numpy(float)
        ns[sid] = nse(o, p)
        rs[sid], als[sid] = ra(o, p)
    return (pd.Series(ns), pd.Series(rs), pd.Series(als))

def cliffs_delta(x, y):
    n = len(x)
    gt = lt = 0
    for i in range(0, n, 2000):
        xb = x[i:i + 2000][:, None]
        gt += int((xb > y[None, :]).sum())
        lt += int((xb < y[None, :]).sum())
    return (gt - lt) / (n * n)

def wilcoxon_p(d):
    dz = d[d != 0]
    if len(dz) < 10:
        return np.nan
    r = pd.Series(np.abs(dz)).rank().to_numpy()
    n = len(dz)
    z = (r[dz > 0].sum() - n * (n + 1) / 4) / sqrt(n * (n + 1) * (2 * n + 1) / 24)
    return erfc(abs(z) / sqrt(2))

def block_ci(d: pd.Series, cell: pd.Series):
    g = d.groupby(cell)
    arrs = [g.get_group(k).to_numpy() for k in g.groups]
    bs = [np.median(np.concatenate([arrs[i] for i in RNG.integers(0, len(arrs), len(arrs))])) for _ in range(NBOOT)]
    return (float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5)), len(arrs))

def main() -> None:
    rows = []
    for name, strict_tag, full_tag in LEAK_PAIRS:
        strict, _, _ = per_station(load(strict_tag))
        full, _, _ = per_station(load(full_tag))
        paired = pd.concat({'strict': strict, 'full': full}, axis=1).dropna()
        rows.append({'method': name, 'strict': paired.strict.median(), 'leak': paired.full.median(), 'inflation': paired.full.median() - paired.strict.median(), 'n': len(paired)})
    output = _PROJECT_ROOT / 'workflows/benchmarks/transformations/results_monthly_leak.csv'
    pd.DataFrame(rows).to_csv(output, index=False, encoding='utf-8-sig', float_format='%.4f')
    print(pd.DataFrame(rows).to_string(index=False))
if __name__ == '__main__':
    main()
