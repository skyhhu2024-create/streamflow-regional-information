"""Paired reference-access rule comparison on the frozen R2 monthly cohort."""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
import sys, json, time, hashlib, gzip, csv
from pathlib import Path
sys.dont_write_bytecode = True
HERE = _PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison'
CODE = _PROJECT_ROOT
pass
pass
import numpy as np
import pandas as pd
from workflows.shared.data.dataset import GapImputationDataset, split_stations
from workflows.shared.data.gsim_io import load_static
from workflows.benchmarks.reference_selection.run_selection_grid import build_config

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def write(p, x):
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2, default=lambda a: a.item() if isinstance(a, np.generic) else str(a)), encoding='utf-8')

def main():
    t0 = time.time()
    out = _PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2'
    out.mkdir(exist_ok=True)
    assert not (_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/audit.json').exists(), 'No overwrite of completed results'
    protocol = dict(created_utc=pd.Timestamp.now(tz='UTC').isoformat(), stage='R2 rule comparison, before R3 predictions', cohort='Frozen 2,990 complete-case stations from the original R2 operational factorial comparison; original pseudo-gaps of length >=2 months', qualification='Nearest 200 within 800 km; >=24 common months and Pearson r>=0.2 in the 60 calendar months preceding each gap; no current hidden target values used', transformation='Original R2 StationTransformer fitted outside all own pseudo-gaps; reference values are actual observations; target-wise retrospective access', weights='r * exp(-distance/800), renormalized over references reporting in each month', models=['fixed8', 'monthly8', 'all_qualified'], numerical_guard='Same for all: reference sigma floor .001, target visible standardized envelope +/-3 SD, inverse-log cap 50; zero-reference anomaly fallback retained', search='Every qualified reference searched. monthly8 selects the first eight reporting references each month; all_qualified uses all reporting qualified references', primary_metric='Station NSE on pooled identical gap months, paired all minus monthly8; secondary relative RMSE, geographic breakdown and 5-degree spatial bootstrap', decision='Report observed paired changes, coverage, tails and uncertainty to authors before freezing. No R3 results used to select the rule; no equivalence claim without a justified margin', no_reconstruction_as_reference=True)
    write(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/protocol.json', protocol)
    dp = _PROJECT_ROOT / 'workflows/benchmarks/internal_gaps/data'
    ids = np.load(_PROJECT_ROOT / 'workflows/benchmarks/internal_gaps/data/station_ids.npy', allow_pickle=True).astype(str)
    dates = pd.to_datetime(np.load(_PROJECT_ROOT / 'workflows/benchmarks/internal_gaps/data/dates.npy', allow_pickle=True))
    raw = np.load(_PROJECT_ROOT / 'workflows/benchmarks/internal_gaps/data/flow_qc20_dedup.npy')
    flow = pd.DataFrame(raw, index=dates, columns=ids)
    cfg = build_config(4)
    print('Building original R2 transformations and gaps', flush=True)
    ds = GapImputationDataset(flow, load_static(_PROJECT_ROOT / 'data/global_station_meta_kg.csv'), cfg)
    cohort = pd.read_csv(_PROJECT_ROOT / 'data/benchmarks/selection_evidence/selection_vs_proximity_equal_stations.csv').station_id.astype(str)
    assert len(cohort) == 2990
    _, _, test = split_stations(ids, cfg['split'])
    assert set(cohort) <= test
    gaps = [g for g in ds.gaps if g.station_id in set(cohort) and g.length >= 2]
    meta = pd.read_csv(_PROJECT_ROOT / 'data/global_station_meta_kg.csv').set_index('gsim.no')
    model_names = protocol['models']
    accum = {}
    gaprows = []
    reference_scales = np.array([ds.transformers[s].sigma_ for s in ids])
    with gzip.open(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/monthly_predictions.csv.gz', 'wt', newline='') as handle:
        writer = csv.writer(handle)
        writer.writerow(['station_id', 'gap_start', 'gap_end', 'date', 'obs', 'fixed8', 'monthly8', 'all_qualified', 'support_fixed8', 'support_all', 'n_reporting', 'n_qualified'])
        for seq, g in enumerate(gaps):
            j = ds.sid2idx[g.station_id]
            tt = np.arange(g.start, g.end + 1)
            y = ds.flow[tt, j]
            assert np.isfinite(y).all()
            cc, dd = ds.donor_selector._spatial_candidates(j)
            lo = max(0, g.start - 60)
            target = ds.z[lo:g.start, j]
            don = ds.z[lo:g.start, cc]
            good = np.isfinite(target)[:, None] & np.isfinite(don)
            n = good.sum(0)
            a = np.where(good, target[:, None], 0.0)
            b = np.where(good, don, 0.0)
            den = np.sqrt(np.maximum(0, (a * a).sum(0) - a.sum(0) ** 2 / np.maximum(n, 1)) * np.maximum(0, (b * b).sum(0) - b.sum(0) ** 2 / np.maximum(n, 1)))
            r = np.divide((a * b).sum(0) - a.sum(0) * b.sum(0) / np.maximum(n, 1), den, out=np.full(len(cc), np.nan), where=den > 1e-12)
            goodref = (n >= 24) & np.isfinite(r) & (r >= 0.2)
            refs = cc[goodref]
            weights = r[goodref] * np.exp(-dd[goodref] / 800.0)
            order = np.argsort(-weights, kind='stable')
            refs = refs[order]
            weights = weights[order]
            zz = ds.z[np.ix_(tt, refs)] * (reference_scales[refs] / np.maximum(reference_scales[refs], 0.001))[None, :]
            ok = np.isfinite(zz)
            fixed_pool = np.flatnonzero(ok.any(0))[:8]
            choices = {'fixed8': ok & np.isin(np.arange(len(refs)), fixed_pool)[None, :], 'monthly8': ok & (np.cumsum(ok, axis=1) <= 8), 'all_qualified': ok}
            tr = ds.transformers[g.station_id]
            vis = ds.valid[:, j] & ~ds.is_gap_month[:, j]
            envelope = ds.z[vis, j]
            elo, ehi = (envelope.min() - 3.0, envelope.max() + 3.0)
            predictions = {}
            supports = {}
            for name, choice in choices.items():
                ww = np.where(choice, weights[None, :], 0.0)
                den = ww.sum(1)
                zhat = np.divide((np.where(choice, zz, 0.0) * ww).sum(1), den, out=np.zeros(len(tt)), where=den > 0)
                support = den > 0
                zhat = np.where(support, np.clip(zhat, elo, ehi), 0.0)
                pp = tr.inverse_transform(zhat, ds.months[tt])
                assert np.isfinite(pp).all()
                predictions[name] = pp
                supports[name] = support
                ac = accum.setdefault((g.station_id, name), dict(n=0, sum_y=0.0, sum_y2=0.0, sse=0.0, supported=0))
                ac['n'] += len(y)
                ac['sum_y'] += float(y.sum())
                ac['sum_y2'] += float(y @ y)
                ac['sse'] += float(np.sum((pp - y) ** 2))
                ac['supported'] += int(support.sum())
            assert np.array_equal(supports['monthly8'], supports['all_qualified'])
            gaprows.append(dict(station_id=g.station_id, start=str(dates[g.start].date()), end=str(dates[g.end].date()), n=len(tt), n_qualified=len(refs), support_fixed8=int(supports['fixed8'].sum()), support_monthly=int(supports['monthly8'].sum())))
            for k, t in enumerate(tt):
                writer.writerow([g.station_id, str(dates[g.start].date()), str(dates[g.end].date()), str(dates[t].date()), y[k], *[predictions[x][k] for x in model_names], bool(supports['fixed8'][k]), bool(supports['all_qualified'][k]), int(ok[k].sum()), len(refs)])
            if (seq + 1) % 1000 == 0:
                print(f'R2 {seq + 1}/{len(gaps)} gaps {time.time() - t0:.1f}s', flush=True)
    rows = []
    for (sid, model), a in accum.items():
        denom = a['sum_y2'] - a['sum_y'] ** 2 / a['n']
        rows.append(dict(station_id=sid, model=model, **a, NSE=1 - a['sse'] / denom if denom > 1e-12 else np.nan, RMSE=np.sqrt(a['sse'] / a['n']), continent=meta.loc[sid, 'continent'], latitude=meta.loc[sid, 'latitude'], longitude=meta.loc[sid, 'longitude']))
    scores = pd.DataFrame(rows)
    scores.to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/station_scores.csv', index=False)
    pd.DataFrame(gaprows).to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/gap_manifest.csv', index=False)
    wide = scores.pivot(index='station_id', columns='model', values=['NSE', 'RMSE'])
    pairs = pd.DataFrame(index=wide.index)
    pairs['NSE_monthly8'] = wide['NSE', 'monthly8']
    pairs['NSE_all'] = wide['NSE', 'all_qualified']
    pairs['delta_NSE_all_minus_monthly8'] = pairs.NSE_all - pairs.NSE_monthly8
    pairs['relative_RMSE_reduction_all_pct'] = 100 * (1 - wide['RMSE', 'all_qualified'] / wide['RMSE', 'monthly8'])
    pairs['delta_NSE_monthly8_minus_fixed8'] = wide['NSE', 'monthly8'] - wide['NSE', 'fixed8']
    for col in ['continent', 'latitude', 'longitude']:
        pairs[col] = meta.reindex(pairs.index)[col]
    pairs['block'] = np.floor(pairs.latitude / 5).astype(int).astype(str) + '_' + np.floor(pairs.longitude / 5).astype(int).astype(str)
    pairs.to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/paired_station_scores.csv')
    summaries = []
    rng = np.random.default_rng(20261013)
    for metric in ['delta_NSE_all_minus_monthly8', 'relative_RMSE_reduction_all_pct', 'delta_NSE_monthly8_minus_fixed8']:
        ff = pairs[np.isfinite(pairs[metric])]
        blocks = [g[metric].to_numpy() for _, g in ff.groupby('block')]
        x = ff[metric].to_numpy()
        draws = np.array([np.median(np.concatenate([blocks[k] for k in rng.integers(0, len(blocks), len(blocks))])) for _ in range(2000)])
        summaries.append(dict(metric=metric, n=len(x), median=float(np.median(x)), ci_low=float(np.quantile(draws, 0.025)), ci_high=float(np.quantile(draws, 0.975)), win_pct=float(100 * np.mean(x > 0)), tie_pct=float(100 * np.mean(x == 0)), q05=float(np.quantile(x, 0.05)), q95=float(np.quantile(x, 0.95))))
    summary = scores.groupby('model').agg(n_stations=('station_id', 'size'), median_NSE=('NSE', 'median'), median_RMSE=('RMSE', 'median'), supported_months=('supported', 'sum'), months=('n', 'sum')).reset_index()
    summary.to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/model_summary.csv', index=False)
    pd.DataFrame(summaries).to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/paired_summary.csv', index=False)
    pairs.groupby('continent').agg(n=('NSE_all', 'size'), median_NSE_all=('NSE_all', 'median'), median_NSE_monthly8=('NSE_monthly8', 'median'), paired_delta_NSE=('delta_NSE_all_minus_monthly8', 'median'), relative_RMSE_reduction_all_pct=('relative_RMSE_reduction_all_pct', 'median')).to_csv(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/regional_summary.csv')
    write(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/audit.json', dict(status='PASS', n_stations=len(wide), n_gaps=len(gaps), same_support_monthly8_and_all=True, source_flow_sha256=sha(_PROJECT_ROOT / 'workflows/benchmarks/internal_gaps/data/flow_qc20_dedup.npy'), protocol_sha256=sha(_PROJECT_ROOT / 'workflows/benchmarks/reference_selection/comparison/r2/protocol.json'), script_sha256=sha(__file__), elapsed_seconds=time.time() - t0, summaries=summaries))
    print(summary.to_string(index=False), flush=True)
    print(pd.DataFrame(summaries).to_string(index=False), flush=True)
if __name__ == '__main__':
    main()
