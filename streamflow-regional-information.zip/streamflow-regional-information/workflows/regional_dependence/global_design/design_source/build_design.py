from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, hashlib, json
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[k] = '1'
sys.dont_write_bytecode = True
ROOT = _PROJECT_ROOT / 'workflows/regional_dependence/global_design'
CODE = _PROJECT_ROOT
pass
import numpy as np, pandas as pd
from datetime import datetime, timezone

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def h(t):
    return int(hashlib.sha256(t.encode()).hexdigest()[:16], 16)

def main():
    out = _PROJECT_ROOT / 'workflows/regional_dependence/global_design/design'
    out.mkdir(exist_ok=True)
    if (_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/DESIGN_FROZEN.json').exists():
        raise RuntimeError('Design already frozen')
    p = _PROJECT_ROOT / 'workflows/regional_dependence/global_design/PROTOCOL.json'
    reg = json.loads(p.read_text(encoding='utf8'))
    f = _PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/GLOBAL_INPUTS_FROZEN.json'
    assert sha(f) == reg['input_freeze_sha256']
    meta = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/station_metadata.csv', encoding='utf-8-sig', low_memory=False)
    ids = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/station_ids.npy', allow_pickle=False).astype(str)
    assert np.array_equal(meta.station_id.astype(str), ids)

    def flag(x):
        return x.astype(str).str.lower().eq('true').to_numpy()
    twin = flag(meta.twin_listed)
    lat = meta.latitude.to_numpy(float)
    lon = meta.longitude.to_numpy(float)
    valid = np.isfinite(lat) & np.isfinite(lon) & (np.abs(lat) <= 90) & (np.abs(lon) <= 180)
    country = meta.country.fillna('').astype(str).to_numpy()
    groups = np.array([f'{int(np.floor(a / 5))}:{int(np.floor(b / 5))}' if ok else 'unknown_' + (str(c).strip() or sid.split('_')[0]) for a, b, ok, c, sid in zip(lat, lon, valid, country, ids)])
    outer = np.array([h('R3GLOBAL_outer|' + g) % 4 for g in groups], np.int8)
    for k in range(4):
        meta['inner_fold_' + str(k)] = [h('R3GLOBAL_inner|' + str(k) + '|' + g) % 3 for g in groups]
    meta['spatial_cell'] = groups
    meta['target_group_id'] = groups
    meta['outer_fold'] = outer
    meta['global_source_candidate'] = ~twin & (meta.QC20_n_finite.to_numpy(int) >= 12) & (meta.QC20_n_negative.to_numpy(int) == 0)
    meta['target_nonnegative_domain'] = meta.QC20_n_negative.to_numpy(int) == 0
    with np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/availability_H060_L120_forward.npz', allow_pickle=False) as z:
        joint = z['QC20_joint_complete']
        cuts = z['cutoff_index']
    assert joint.shape == (len(ids), 253)
    rows = []
    for j in np.flatnonzero(joint.any(1)):
        pos = np.flatnonzero(joint[j])
        starts = cuts[pos].astype(int)
        assert starts.min() >= 60 and starts.max() <= 312
        a = int(min(starts, key=lambda t: hashlib.sha256(('R3GLOBAL|' + ids[j] + '|' + str(int(t))).encode()).digest()))
        r = meta.iloc[j].to_dict()
        r.update(raw_index=int(j), anchor=a, history_start=a - 60, history_end=a, gap_start=a, gap_end=a + 120, H=60, L=120, task='forward', legal_anchor_count=int(len(starts)), case_id=hashlib.sha256(('R3GLOBAL_case|' + ids[j] + '|' + str(a)).encode()).hexdigest()[:28], mother_state='duplicate_alias' if twin[j] else 'nonnegative_DAT_outside_domain' if not bool(meta.target_nonnegative_domain.iloc[j]) else 'pending_DAT_and_axis_qualification')
        rows.append(r)
    mothers = pd.DataFrame(rows)
    assert len(mothers) == 8935
    targets = mothers[~flag(mothers.twin_listed)].copy()
    assert len(targets) == 8898
    mothers.to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/all_data_qualified_mothers.csv', index=False, encoding='utf-8-sig')
    targets.to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/independent_target_cases.csv', index=False, encoding='utf-8-sig')
    meta.to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/all_station_roles.csv', index=False, encoding='utf-8-sig')
    scenarios = []
    sources = meta.global_source_candidate.to_numpy(bool)
    for o in range(4):
        for i in [-1, 0, 1, 2]:
            name = f'outer_{o}' if i == -1 else f'inner_{o}_{i}'
            sm = sources & (outer != o)
            if i >= 0:
                sm &= meta['inner_fold_' + str(o)].to_numpy(int) != i
            sfile = out / (name + '_source_mask.npy')
            np.save(sfile, sm, allow_pickle=False)
            t = targets.copy() if i == -1 else targets[targets.outer_fold.ne(o)].copy()
            t['scenario_id'] = name
            t['scenario_kind'] = 'outer' if i == -1 else 'inner'
            t['scenario_outer_fold'] = o
            t['scenario_inner_fold'] = i
            if i == -1:
                t['role'] = np.where(t.outer_fold.eq(o), 'test', 'train')
            else:
                t['role'] = np.where(t['inner_fold_' + str(o)].eq(i), 'val', 'train')
            tf = out / (name + '_targets.csv')
            t.to_csv(tf, index=False, encoding='utf-8-sig')
            scenarios.append(dict(scenario_id=name, outer_fold=o, inner_fold=i, targets_file=str(tf.relative_to(ROOT)), source_mask_file=str(sfile.relative_to(ROOT)), source_count=int(sm.sum()), source_ids_sha256=hashlib.sha256(('\n'.join(ids[sm]) + '\n').encode()).hexdigest(), target_count=len(t), role_counts={k: int(v) for k, v in t.role.value_counts().items()}, target_nonnegative_count=int(t.target_nonnegative_domain.astype(bool).sum())))
    summary = {'raw_stations': len(ids), 'data_qualified_mothers': len(mothers), 'known_duplicate_mothers': int(flag(mothers.twin_listed).sum()), 'independent_targets': len(targets), 'negative_method_domain_targets': int((~targets.target_nonnegative_domain.astype(bool)).sum()), 'candidate_sources_before_fold_exclusion': int(sources.sum()), 'target_fold_counts': {str(k): int(v) for k, v in targets.outer_fold.value_counts().sort_index().items()}, 'target_continents': {str(k): int(v) for k, v in targets.continent.fillna('unknown').value_counts().items()}, 'target_missing_coordinates': int((~valid[targets.raw_index.to_numpy(int)]).sum()), 'anchor_calendar_months': {str(k): int(v) for k, v in (targets.anchor.astype(int) % 12 + 1).value_counts().sort_index().items()}}
    (_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/SCENARIOS.json').write_text(json.dumps({'scenarios': scenarios, 'summary': summary}, ensure_ascii=False, indent=2), encoding='utf8')
    files = {str(x.relative_to(ROOT)): sha(x) for x in out.iterdir() if x.is_file()}
    receipt = {'status': 'ALL_GLOBAL_QUALIFIED_STATIONS_ANCHORED_AND_SPATIAL_ROLES_FROZEN_BEFORE_PREDICTIONS', 'utc': datetime.now(timezone.utc).isoformat(), 'protocol_sha256': sha(p), 'input_freeze_sha256': sha(f), 'design_code_sha256': sha(__file__), 'summary': summary, 'files': files}
    (_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/DESIGN_FROZEN.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps(receipt['summary'], ensure_ascii=False))
if __name__ == '__main__':
    main()
