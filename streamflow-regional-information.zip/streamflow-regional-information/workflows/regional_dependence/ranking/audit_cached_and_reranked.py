"""Registered descriptive audit and frozen pure-correlation sensitivity scoring."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib, importlib.util, warnings
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[k] = '1'
import numpy as np
import pandas as pd
warnings.filterwarnings('ignore', category=RuntimeWarning)
HERE = _PROJECT_ROOT / 'workflows/regional_dependence/ranking'
STUDY_DATA = _PROJECT_ROOT / 'data/study_inputs'
EXP = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance'
PRED = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions'
spec = importlib.util.spec_from_file_location('score_core', _PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/trial_score_core.py')
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)
assert (_PROJECT_ROOT / 'workflows/regional_dependence/ranking/PROTOCOL.md').exists()
cases = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/cases.csv', keep_default_na=False)
assert len(cases) == 8898
pa = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/P_available.npy').astype(bool)
assert pa.sum() == 8083
plan = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/bootstrap_draws.npz')
cells = plan['spatial_cells'].astype(str)
draws = plan['draws']
lookup = {c: i for i, c in enumerate(cells)}
ix = np.array([lookup[c] for c in cases.spatial_cell.astype(str)])
assert draws.shape[0] == 2000

def ci(v):
    v = np.asarray(v)
    return np.nanquantile(v, [0.025, 0.975]).tolist() if np.isfinite(v).any() else [np.nan, np.nan]

def medboot(v, k):
    order = np.argsort(v)
    v = np.asarray(v)[order]
    k = np.asarray(k)[order]
    out = np.full(len(draws), np.nan)
    for b, w in enumerate(draws):
        ww = w[k]
        n = int(ww.sum())
        if n:
            cu = np.cumsum(ww)
            out[b] = 0.5 * (v[np.searchsorted(cu, (n - 1) // 2 + 1)] + v[np.searchsorted(cu, n // 2 + 1)])
    return out

def median(v, mask):
    m = np.asarray(mask, bool) & np.isfinite(v)
    v = np.asarray(v)[m]
    lo, hi = ci(medboot(v, ix[m]))
    return dict(n=int(m.sum()), median=float(np.median(v)) if len(v) else np.nan, ci025=lo, ci975=hi)

def binary_delta(v, mask):
    v = np.asarray(v, float)
    mask = np.asarray(mask, bool)
    den = np.bincount(ix[mask], minlength=len(cells))
    num = np.bincount(ix[mask], weights=v[mask], minlength=len(cells))
    bd = draws @ den
    lo, hi = ci(100 * np.divide(draws @ num, bd, out=np.full(len(draws), np.nan), where=bd > 0))
    return dict(net_change_pp=float(100 * v[mask].mean()), ci025=lo, ci975=hi)

def paircorr(a, b, minimum):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    ok = np.isfinite(a) & np.isfinite(b)
    n = ok.sum(1)
    am = np.divide(np.where(ok, a, 0).sum(1), n, out=np.zeros(len(a)), where=n > 0)
    bm = np.divide(np.where(ok, b, 0).sum(1), n, out=np.zeros(len(a)), where=n > 0)
    ac = np.where(ok, a - am[:, None], 0)
    bc = np.where(ok, b - bm[:, None], 0)
    den = np.sqrt((ac * ac).sum(1) * (bc * bc).sum(1))
    r = np.divide((ac * bc).sum(1), den, out=np.full(len(a), np.nan), where=(den > 0) & (n >= minimum))
    return (np.clip(r, -1, 1), n)
strict = _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage'
sm = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/summary_by_group.csv')
rows = []
for file, arm, label in [('summary.csv', 'GLOBAL_D800_DAT', 'DAT'), ('summary.csv', 'GLOBAL_D800_OLS', 'OLS, original transfer'), ('summary_survivor.csv', 'GLOBAL_D800_OLS_SURVIVOR', 'OLS, refit surviving references')]:
    df = pd.read_csv(strict / file)
    r = df[(df.arm == arm) & (df.subset == 'all_mothers')].iloc[0]
    rows.append(dict(source_domain='STRICT: target spatial fold excluded', configuration=label, n_registered=int(r['n']), success=int(r.success), success_pct=float(r.success_pct), source_file=str(strict / file)))
for method, label in [('ridge', 'Ridge'), ('rbf_ridge', 'RBF ridge')]:
    r = sm[(sm.D == 800) & (sm.method == method) & (sm.arm == 'Q') & (sm.subset == 'all_mothers') & (sm.stratum == 'all')].iloc[0]
    rows.append(dict(source_domain='FULL: safe 24714; target physical identity excluded', configuration=label, n_registered=int(r.n_subset), success=int(r.nse_success), success_pct=float(r.nse_success_pct), source_file=str(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/summary_by_group.csv')))
five = pd.DataFrame(rows)
assert five.n_registered.eq(8898).all()
five.to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/five_configurations_D800_common8898.csv', index=False)
Q = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', mmap_mode='r')
g = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/gap_months.npy')
raw = cases.raw_index.to_numpy(int)
y = np.asarray(Q[raw[:, None], g], float)
calendar = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/target_raw_calendar.npy')
base = np.take_along_axis(calendar, g % 12, axis=1)
logcal = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/target_log_calendar.npy')
sd = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/target_anomaly_sd.npy')
gz = (np.where((y >= 0) & np.isfinite(y), np.log1p(np.maximum(y, 0)), np.nan) - np.take_along_axis(logcal, g % 12, axis=1)) / sd[:, None]
hz = np.load(_PROJECT_ROOT / 'workflows/rainfall/global_inputs/prepared_inputs/target_Hz.npy')
oldpred = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/predictions.npy', mmap_mode='r')
oldfit = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/flags.npy', mmap_mode='r')
oldsupp = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/support.npy', mmap_mode='r')
oldcomp = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/composites.npy', mmap_mode='r')
oldcounts = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/counts.npy', mmap_mode='r')
scores = {}
sup = []
assoc = []
station = []
for di, D in enumerate([0, 100, 300, 800]):
    m = C.metrics(y, oldpred[:, di, 0, 0], base, oldfit[:, di, 0, 0, 0], oldsupp[:, di, 0, 0])
    scores[D] = m
    expected = sm[(sm.D == D) & (sm.method == 'ridge') & (sm.arm == 'Q') & (sm.subset == 'P_admitted') & (sm.stratum == 'all')].iloc[0]
    assert int(m['nse_success'][pa].sum()) == int(expected.nse_success)
    supp = oldsupp[:, di, 0, 0]
    counts = oldcounts[:, di, 60:]
    f = oldfit[:, di, 0, 0, 0]
    sup.append(dict(D=D, n_registered=8083, n_full120_reference_reports=int((pa & (counts > 0).all(1)).sum()), n_full120_actual_fitted_supported=int((pa & supp.all(1)).sum()), actual_supported_pct=100 * int((pa & supp.all(1)).sum()) / 8083, reference_report_months=int((counts[pa] > 0).sum()), actual_supported_months=int(supp[pa].sum()), n_no_actual_fit=int((pa & ~f).sum()), n_evaluable_truth_and_prediction=int((pa & m['eligible']).sum())))
    rh, nh = paircorr(oldcomp[:, di, :60], hz, 12)
    rg, ng = paircorr(oldcomp[:, di, 60:], gz, 24)
    valid = pa & m['valid_truth']
    pair = valid & np.isfinite(rh) & np.isfinite(rg)
    for label, values, mask in [('reference_H_log_anomaly_correlation', rh, pair), ('reference_G_log_anomaly_correlation', rg, pair), ('reference_G_minus_H_log_anomaly_correlation', rg - rh, pair), ('prediction_G_raw_r', m['r'], valid), ('prediction_G_H_deseasoned_raw_r', m['H_deseasonal_r'], valid), ('prediction_G_NSE', m['NSE'], valid), ('seasonal_baseline_G_r', m['seasonal_r'], valid), ('seasonal_baseline_G_NSE', m['seasonal_NSE'], valid)]:
        assoc.append(dict(D=D, quantity=label, **median(values, mask)))
    df = cases[['row', 'raw_index', 'continent', 'country', 'spatial_cell']].copy()
    df['P_available'] = pa
    df['D'] = D
    df['valid_truth'] = m['valid_truth']
    df['reference_H_log_r'] = rh
    df['reference_G_log_r'] = rg
    df['n_H_pairs'] = nh
    df['n_G_pairs'] = ng
    for name in ['r', 'H_deseasonal_r', 'NSE', 'seasonal_r', 'seasonal_NSE', 'nse_success', 'eligible', 'actual_model_estimable', 'support_months']:
        df[name] = m[name]
    station.append(df)
pd.DataFrame(sup).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/support_all_radii.csv', index=False)
pd.DataFrame(assoc).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/reference_history_gap_association.csv', index=False)
pd.concat(station, ignore_index=True).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/original_Q_reference_and_prediction_scores.csv.gz', index=False)
regions = ['Global', 'Africa', 'Asia', 'Europe', 'NorthAmerica', 'Oceania', 'SouthAmerica', 'Other']
ret = []
a = scores[0]['nse_success']
b = scores[800]['nse_success']
for reg in regions:
    mask = pa if reg == 'Global' else pa & cases.continent.eq(reg).to_numpy()
    aa = int((mask & a).sum())
    rr = int((mask & a & b).sum())
    new = int((mask & ~a & b).sum())
    ret.append(dict(region=reg, n_registered=int(mask.sum()), D0_success=aa, D800_success=int((mask & b).sum()), retained_success=rr, lost_success=aa - rr, new_success=new, retained_fraction_of_D0_pct=100 * rr / aa if aa else np.nan, net_retained_fraction_pct=100 * int((mask & b).sum()) / aa if aa else np.nan))
pd.DataFrame(ret).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/regional_D0_D800_success_retention.csv', index=False)
print('CACHED_AUDIT_COMPLETE', flush=True)
print(pd.DataFrame(sup).to_string(index=False), flush=True)
print(pd.DataFrame(assoc)[pd.DataFrame(assoc).quantity.str.contains('reference_')].to_string(index=False), flush=True)
NEW = _PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions'
if not (_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions/PREDICTIONS_FROZEN.json').exists():
    print('NEW_RANKING_NOT_YET_FROZEN; stop without reading new predictions', flush=True)
    sys.exit(0)
npred = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions/predictions.npy', mmap_mode='r')
nsupp = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions/support.npy', mmap_mode='r')
nfit = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions/actual_fit.npy', mmap_mode='r')
ncomp = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions/composites.npy', mmap_mode='r')
ncounts = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions/counts.npy', mmap_mode='r')
summary = []
cont = []
newassoc = []
newstations = []
for di, D in enumerate([0, 100, 300, 800]):
    old = scores[D]
    new = C.metrics(y, npred[:, di], base, nfit[:, di], nsupp[:, di])
    a = old['nse_success']
    b = new['nse_success']
    delta = b.astype(int) - a.astype(int)
    summary.append(dict(D=D, n_registered=8083, original_success=int((pa & a).sum()), reranked_success=int((pa & b).sum()), original_success_pct=100 * (pa & a).sum() / 8083, reranked_success_pct=100 * (pa & b).sum() / 8083, new_success=int((pa & ~a & b).sum()), lost_success=int((pa & a & ~b).sum()), **binary_delta(delta, pa), n_actual_fit=int(nfit[pa, di].sum()), n_full120_actual_support=int(nsupp[pa, di].all(1).sum()), actual_supported_months=int(nsupp[pa, di].sum()), n_full120_reports=int((ncounts[pa, di, 60:] > 0).all(1).sum())))
    valid = pa & old['valid_truth'] & new['valid_truth']
    for metric in ['r', 'NSE', 'H_deseasonal_r']:
        ok = valid & np.isfinite(old[metric]) & np.isfinite(new[metric])
        delta = new[metric] - old[metric]
        cont.append(dict(D=D, metric=metric, original_median=float(np.median(old[metric][ok])), reranked_median=float(np.median(new[metric][ok])), **median(delta, ok), improved_count=int((ok & (delta > 1e-12)).sum()), worsened_count=int((ok & (delta < -1e-12)).sum()), unchanged_count=int((ok & (np.abs(delta) <= 1e-12)).sum())))
    rh, nh = paircorr(ncomp[:, di, :60], hz, 12)
    rg, ng = paircorr(ncomp[:, di, 60:], gz, 24)
    ok = valid & np.isfinite(rh) & np.isfinite(rg)
    for label, v in [('reference_H_log_anomaly_correlation', rh), ('reference_G_log_anomaly_correlation', rg), ('reference_G_minus_H_log_anomaly_correlation', rg - rh)]:
        newassoc.append(dict(D=D, quantity=label, **median(v, ok)))
    orh, _ = paircorr(oldcomp[:, di, :60], hz, 12)
    org, _ = paircorr(oldcomp[:, di, 60:], gz, 24)
    for label, nv, ov in [('reranked_minus_original_H_log_correlation', rh, orh), ('reranked_minus_original_G_log_correlation', rg, org)]:
        newassoc.append(dict(D=D, quantity=label, **median(nv - ov, valid & np.isfinite(nv) & np.isfinite(ov))))
    df = cases[['row', 'raw_index', 'continent', 'country', 'spatial_cell']].copy()
    df['P_available'] = pa
    df['D'] = D
    df['reference_H_log_r'] = rh
    df['reference_G_log_r'] = rg
    for name, value in new.items():
        df[name] = value
    newstations.append(df)
pd.DataFrame(summary).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_success_paired.csv', index=False)
pd.DataFrame(cont).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_continuous_paired.csv', index=False)
pd.DataFrame(newassoc).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_reference_association.csv', index=False)
pd.concat(newstations, ignore_index=True).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_scores.csv.gz', index=False)
compact = pd.DataFrame(summary)
compact['success_original_new'] = compact.original_success.astype(str) + ' / ' + compact.reranked_success.astype(str)
compact['new_lost'] = compact.new_success.astype(str) + ' / ' + compact.lost_success.astype(str)
compact['net_pp_CI'] = compact.apply(lambda x: f'{x.net_change_pp:.3f} [{x.ci025:.3f}, {x.ci975:.3f}]', axis=1)
compact[['D', 'n_registered', 'success_original_new', 'new_lost', 'net_pp_CI', 'n_full120_actual_support']].to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_SI_compact.csv', index=False)
qa = dict(original_frozen_main_success_replayed=True, no_new_parameter_selection=True, primary_n=8083, registered_n=8898, original_bootstrap_replicates=len(draws), CI='global 5-degree blocks; percentile; paired medians for continuous and paired percent-point mean for binary', continuous='valid truth AND finite metrics; includes defined fallback; not eligible/success filter', source_pool=24714, ranking_only_change=True)
(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/AUDIT_QA.json').write_text(json.dumps(qa, indent=2), encoding='utf8')
print('PURE_CORRELATION_SCORING_COMPLETE', flush=True)
print(compact.to_string(index=False), flush=True)
print(pd.DataFrame(cont).to_string(index=False), flush=True)
