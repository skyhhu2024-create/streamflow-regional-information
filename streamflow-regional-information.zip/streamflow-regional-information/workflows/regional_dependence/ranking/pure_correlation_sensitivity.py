"""One authorized ranking sensitivity; no outcome-based selection or tuning."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, time, hashlib, argparse
from datetime import datetime, timezone
from concurrent.futures import ProcessPoolExecutor
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[k] = '1'
HERE = _PROJECT_ROOT / 'workflows/regional_dependence/ranking'
STUDY_DATA = _PROJECT_ROOT / 'data/study_inputs'
EXP = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance'
pass
import workflows.regional_dependence.source_distance.src.run_engine as R
import numpy as np
import pandas as pd
OUT = _PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions'

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def work(i):
    S = R.STATE
    E = R.E
    e = S['cases'].iloc[i]
    raw = int(e.raw_index)
    h = np.arange(int(e.history_start), int(e.history_end))
    g = np.arange(int(e.gap_start), int(e.gap_end))
    own = set(np.flatnonzero(S['group'] == S['group'][raw]).tolist())
    source = dict(raw=S['raw'], Q=E.GuardedSourceAccessor(S['Q'], S['raw'], own | S['excluded_raw'], h[0], g[-1] + 1))
    cl, sd, zh = R.source_history(h)
    tz = np.asarray(S['target_Hz'][i])
    n, r = E.C.relation(zh, tz)
    qualified = np.flatnonzero(np.isfinite(r) & (r > 0) & np.isfinite(sd) & ~np.isin(S['raw'], list(own)))
    order = qualified[np.lexsort((S['raw'][qualified], -r[qualified]))]
    dist = E.distances(e.latitude, e.longitude, S['latitude'], S['longitude'])
    months = np.r_[h, g]
    baseline = S['target_H_raw_calendar'][i][g % 12]
    result = dict(composites=np.full((4, 180), np.nan), counts=np.zeros((4, 180), np.int8), selected_ids=np.full((4, 180, 4), -1, np.int32), predictions=np.full((4, 120), np.nan), support=np.zeros((4, 120), bool), actual_fit=np.zeros(4, bool), training_rows=np.zeros(4, np.int16))
    for di, D in enumerate(E.DLEVELS):
        comp, count, ids = E.C.combine(source, order, r, cl, sd, months, dist <= D if D else None)
        assert not np.isin(ids, list(own | S['excluded_raw'])).any()
        qh = comp[:60, None]
        qg = comp[60:, None]
        train = np.isfinite(qh[:, 0]) & np.isfinite(tz)
        model, reason = E.M.fit_transfer(qh[train], tz[train], method='ridge', target_estimable=bool(S['input_meta'][i, 4]))
        actual = model is not None
        z = model.predict(qg) if actual else np.full(120, np.nan)
        pred, support = E.C.transfer(z, tz, S['target_H_log_calendar'][i], float(S['target_H_anomaly_sd'][i]), g, baseline, actual)
        for name, val in [('composites', comp), ('counts', count), ('selected_ids', ids), ('predictions', pred), ('support', support), ('actual_fit', actual), ('training_rows', train.sum())]:
            result[name][di] = val
    assert np.all(np.diff(result['counts'].astype(int), axis=0) <= 0)
    return (i, result)

def produce(workers=8):
    assert (_PROJECT_ROOT / 'workflows/regional_dependence/ranking/PROTOCOL.md').exists()
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions/PREDICTIONS_FROZEN.json').exists(), 'Never overwrite frozen predictions'
    inputs = [_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_sensitivity.py', _PROJECT_ROOT / 'workflows/regional_dependence/ranking/PROTOCOL.md', _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/src/engine.py', _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/src/run_engine.py', R.E.CORE_PATH, R.E.MODEL_PATH, R.EXCLUSIONS, R.PHYSICAL, R.OLD / 'global_data/QC20_Q.npy', R.OLD / 'predictions/source_cache/source_raw_indices.npy', R.TRIAL / 'cases.csv']
    frozen = {str(p): sha(p) for p in inputs}
    (_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions/REGISTRATION.json').write_text(json.dumps(dict(registered_utc=datetime.now(timezone.utc).isoformat(), inputs=frozen, no_target_G_truth_scoring_before_prediction_freeze=True), indent=2), encoding='utf8')
    cases = pd.read_csv(R.TRIAL / 'cases.csv')
    assert len(cases) == 8898
    order = cases.sort_values(['history_start', 'row']).row.to_numpy(int)
    arrays = {}
    start = time.time()
    with ProcessPoolExecutor(max_workers=workers, initializer=R.init) as pool:
        for k, (i, result) in enumerate(pool.map(work, map(int, order), chunksize=8), 1):
            if not arrays:
                arrays = {name: np.lib.format.open_memmap(OUT / f'{name}.npy', mode='w+', dtype=val.dtype, shape=(8898,) + val.shape) for name, val in result.items()}
            for name, val in result.items():
                arrays[name][i] = val
            if k % 500 == 0 or k == 8898:
                print(f'PREDICTIONS {k}/8898 elapsed={time.time() - start:.1f}s', flush=True)
    for a in arrays.values():
        a.flush()
    assert all((sha(p) == v for p, v in frozen.items()))
    receipt = dict(completed_utc=datetime.now(timezone.utc).isoformat(), n=8898, primary_n=8083, seconds=time.time() - start, workers=workers, source_n=24714, D=[0, 100, 300, 800], K=4, method='ridge', ranking='descending H anomaly correlation; ascending raw-index tie', target_G_used_as_model_input=False, files={name + '.npy': sha(OUT / f'{name}.npy') for name in arrays})
    (_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions/PREDICTIONS_FROZEN.json').write_text(json.dumps(receipt, indent=2), encoding='utf8')
    print('PREDICTIONS_FROZEN', flush=True)
if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--workers', type=int, default=8)
    a = p.parse_args()
    produce(a.workers)
