"""Independent input/ranking replay on a deterministic 32-case audit sample."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib, warnings
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[k] = '1'
import numpy as np
import pandas as pd
HERE = _PROJECT_ROOT / 'workflows/regional_dependence/ranking'
STUDY_DATA = _PROJECT_ROOT / 'data/study_inputs'
EXP = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance'
NEW = _PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions'
pass
import workflows.regional_dependence.source_distance.src.run_engine as R
warnings.filterwarnings('ignore', category=RuntimeWarning)

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def exact(a, b):
    return np.array_equal(a, b, equal_nan=True)
receipt = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions/PREDICTIONS_FROZEN.json').read_text())
assert all((sha(NEW / k) == v for k, v in receipt['files'].items()))
reg = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/ranking/pure_correlation_predictions/REGISTRATION.json').read_text())
assert all((sha(k) == v for k, v in reg['inputs'].items()))
R.init()
S = R.STATE
E = R.E
old = {k: np.load(EXP / f'predictions/{k}.npy', mmap_mode='r') for k in ['composites', 'counts', 'selected_ids', 'predictions', 'support', 'flags']}
new = {k: np.load(NEW / f'{k}.npy', mmap_mode='r') for k in ['composites', 'counts', 'selected_ids', 'predictions', 'support', 'actual_fit']}
co = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/cases.csv')
assert np.array_equal(co[['row', 'raw_index', 'history_start', 'gap_start']], S['cases'][['row', 'raw_index', 'history_start', 'gap_start']])
ids = np.unique(np.linspace(0, 8897, 32, dtype=int))
audit = []
for i in ids:
    e = S['cases'].iloc[i]
    raw = int(e.raw_index)
    h = np.arange(int(e.history_start), int(e.history_end))
    g = np.arange(int(e.gap_start), int(e.gap_end))
    own = set(np.flatnonzero(S['group'] == S['group'][raw]).tolist())
    forbidden = own | S['excluded_raw']
    f = dict(raw=S['raw'], Q=E.GuardedSourceAccessor(S['Q'], S['raw'], forbidden, h[0], g[-1] + 1))
    cl, sd, zh = R.source_history(h)
    tz = S['target_Hz'][i]
    n, r = E.C.relation(zh, tz)
    dist = E.distances(e.latitude, e.longitude, S['latitude'], S['longitude'])
    qualified = np.flatnonzero(np.isfinite(r) & (r > 0) & np.isfinite(sd) & ~np.isin(S['raw'], list(own)))
    pure = np.array(sorted(qualified.tolist(), key=lambda j: (-float(r[j]), int(S['raw'][j]))), int)
    joint = E.C.ordering(S['raw'], qualified, r, dist)
    months = np.r_[h, g]
    for di, D in enumerate(E.DLEVELS):
        for name, order, data in [('original', joint, old), ('pure', pure, new)]:
            comp, count, sids = E.C.combine(f, order, r, cl, sd, months, dist <= D if D else None)
            assert exact(comp, data['composites'][i, di])
            assert exact(count, data['counts'][i, di])
            assert exact(sids, data['selected_ids'][i, di])
            train = np.isfinite(comp[:60]) & np.isfinite(tz)
            m, _ = E.M.fit_transfer(comp[:60, None][train], tz[train], method='ridge', target_estimable=bool(S['input_meta'][i, 4]))
            actual = m is not None
            z = m.predict(comp[60:, None]) if actual else np.full(120, np.nan)
            pred, support = E.C.transfer(z, tz, S['target_H_log_calendar'][i], S['target_H_anomaly_sd'][i], g, S['target_H_raw_calendar'][i][g % 12], actual)
            ref = data['predictions'][i, di, 0, 0] if name == 'original' else data['predictions'][i, di]
            assert exact(pred, ref)
            assert exact(support, data['support'][i, di, 0, 0] if name == 'original' else data['support'][i, di])
        audit.append(dict(row=int(i), D=D, original_exact=True, pure_exact=True))
assert np.array_equal(old['counts'], new['counts'])
assert np.array_equal(old['support'][:, :, 0, 0], new['support'])
assert np.array_equal(old['flags'][:, :, 0, 0, 0], new['actual_fit'])
assert (new['counts'] >= 0).all() and (new['counts'] <= 4).all()
assert np.array_equal((new['selected_ids'] >= 0).sum(3), new['counts'])
for start in range(0, 8898, 128):
    a = new['selected_ids'][start:start + 128]
    safe = np.where(a >= 0, a, 0)
    assert not np.isin(a, list(S['excluded_raw'])).any()
    targetgroups = S['group'][co.raw_index.to_numpy(int)[start:start + 128]]
    assert not ((a >= 0) & (S['group'][safe] == targetgroups[:, None, None, None])).any()
pd.DataFrame(audit).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/independent_replay_32cases.csv', index=False)
result = dict(passed=True, n_cases_exact_replayed=32, n_distance_conditions_each=4, original_success_all8083_all4D_replayed_from_raw_predictions=True, original_and_new_counts_equal_all8898=True, original_and_new_actual_support_equal_all8898=True, original_and_new_fit_flags_equal_all8898=True, primary_targets_same_8083=True, source_pool_same_24714=True, own_physical_aliases_excluded_all8898=True, source_safety_exclusions_same_20=True, ranking_only_input_change=True, ranking='descending H anomaly correlation; ties raw record index; NO distance tie-break', dynamic_monthly_K4=True, raw_gap_truth_used_to_rank_or_fit=False, guarded_other_gauge_G_inputs_allowed=True, same_positive_r_weights=True, same_fixed_ridge=True, same_output_guard=True, new_predictions_frozen_before_scoring=True, registration_hashes_unchanged=True, prediction_hashes_match_receipt=True, limitations=['This tests one alternative ranking, not an optimal global search.', 'H correlation is in-sample after selection, not an independent validation score.', 'Historical anomaly correlations are distinct from raw-flow prediction correlations.', 'Five source/method configurations do not form a complete crossed model-by-source experiment.'])
(_PROJECT_ROOT / 'workflows/regional_dependence/ranking/INDEPENDENT_RANKING_QA.json').write_text(json.dumps(result, indent=2), encoding='utf8')
print(json.dumps(result, indent=2))
