"""Production driver; disabled until the parent freezes the audited protocol.

No scoring command is provided. Registration, prediction and assembly operate
on H target transforms plus other physical sites' observations only.
"""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os
import sys
import json
import hashlib
import argparse
import time
import warnings
from datetime import datetime, timezone
from concurrent.futures import ProcessPoolExecutor
from collections import OrderedDict
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[k] = '1'
sys.dont_write_bytecode = True
ROOT = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance'
CODE = _PROJECT_ROOT
pass
import numpy as np
import pandas as pd
import workflows.regional_dependence.source_distance.src.engine as E
PREV = _PROJECT_ROOT / 'workflows/rainfall/global_inputs'
OLD = _PROJECT_ROOT / 'workflows/regional_dependence/global_design'
TRIAL = _PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions'
BRIDGE = _PROJECT_ROOT / 'workflows/monitoring/external_locations/full_domain_rain_bridge/predictions'
PHYSICAL = _PROJECT_ROOT / 'workflows/monitoring/location_selection/census/physical_identity_map.csv'
DISPLAY_META = _PROJECT_ROOT / 'workflows/monitoring/location_selection/census/metadata_enrichment/global_station_metadata.csv'
EXCLUSIONS = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/design_review/recommended_source_exclusions.csv'
PFILE = _PROJECT_ROOT / 'workflows/rainfall/global_inputs/prepared_inputs/PRECIPITATION_H_ONLY_INPUTS.npz'
OUT = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions'
N, H, G = (8898, 60, 120)
STATE = {}
TARGET_KEYS = ('target_Hz', 'target_H_log_calendar', 'target_H_anomaly_sd', 'target_H_raw_calendar', 'input_meta')

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf8')

def paths():
    return [_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/src/run_engine.py', _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/src/engine.py', _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/PROTOCOL.json', _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/src/SYNTHETIC_QA.json', E.CORE_PATH, E.MODEL_PATH, EXCLUSIONS, PHYSICAL, DISPLAY_META, _PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/predictions/source_cache/source_raw_indices.npy', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/all_station_roles.csv', _PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/cases.csv', _PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/selected_ids.npy', _PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/composites.npy', _PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/training_mask.npy', PFILE, *[PREV / f'prepared_inputs/{k}.npy' for k in TARGET_KEYS], *[BRIDGE / f'{k}.npy' for k in ('predictions', 'support', 'flags')]]

def register():
    auth = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/EXECUTION_AUTHORIZED.json').read_text(encoding='utf8'))
    assert auth.get('production_authorized') is True
    assert auth['protocol_sha256'] == sha(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/PROTOCOL.json')
    assert not (_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/CODE_INPUTS_FROZEN.json').exists(), 'Never overwrite registration'
    proto = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/PROTOCOL.json').read_text(encoding='utf8'))
    assert proto['status'] == 'FROZEN_BEFORE_NEW_GRADIENT_PREDICTION'
    qa = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/src/SYNTHETIC_QA.json').read_text(encoding='utf8'))
    assert qa['passed'] is True
    assert qa['engine_sha256'] == sha(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/src/engine.py')
    save(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/CODE_INPUTS_FROZEN.json', dict(created_utc=datetime.now(timezone.utc).isoformat(), files={str(p.resolve()): sha(p) for p in paths()}, target_G_truth_read=False, old_target_scores_read=False, retrospective_project_extension=True))
    print('REGISTERED_FULL_SOURCE_GRADIENT', flush=True)

def check_registration():
    record = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/CODE_INPUTS_FROZEN.json').read_text(encoding='utf8'))
    for p, expected in record['files'].items():
        assert sha(p) == expected, p

def init():
    warnings.filterwarnings('ignore', category=RuntimeWarning)
    STATE['cases'] = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/cases.csv', keep_default_na=False)
    assert len(STATE['cases']) == N
    assert np.array_equal(STATE['cases'].row.to_numpy(int), np.arange(N))
    STATE['Q'] = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', mmap_mode='r')
    STATE['meta'] = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/all_station_roles.csv', keep_default_na=False)
    oldraw = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/predictions/source_cache/source_raw_indices.npy')
    ex = pd.read_csv(EXCLUSIONS, keep_default_na=False)
    assert len(oldraw) == 24734 and len(ex) == 20 and (ex.raw_index.nunique() == 20)
    assert np.array_equal(STATE['meta'].iloc[ex.raw_index].station_id.to_numpy(str), ex.station_id.to_numpy(str))
    raw = oldraw[~np.isin(oldraw, ex.raw_index)]
    assert len(raw) == 24714
    STATE['raw'] = raw
    STATE['excluded_raw'] = set(ex.raw_index.to_numpy(int))
    sm = STATE['meta'].iloc[raw]
    STATE['latitude'], STATE['longitude'] = (sm.latitude.to_numpy(float), sm.longitude.to_numpy(float))
    assert np.isfinite(STATE['latitude']).all() and np.isfinite(STATE['longitude']).all()
    physical = pd.read_csv(PHYSICAL, keep_default_na=False).sort_values('raw_index')
    assert np.array_equal(physical.raw_index.to_numpy(int), np.arange(len(STATE['meta'])))
    assert np.array_equal(physical.station_id.to_numpy(str), STATE['meta'].station_id.to_numpy(str))
    STATE['group'] = physical.physical_group_raw_index.to_numpy(int)
    for key in TARGET_KEYS:
        STATE[key] = np.load(PREV / f'prepared_inputs/{key}.npy', mmap_mode='r')
    with np.load(PFILE, allow_pickle=False) as p:
        STATE['p'] = {name: p[name].copy() for name in ('p_available', 'p_h', 'p_g', 'p_g_climatology')}
    assert int(STATE['p']['p_available'].sum()) == 8083
    for key in ('selected_ids', 'composites', 'training_mask'):
        STATE['old_' + key] = np.load(TRIAL / f'{key}.npy', mmap_mode='r')
    for key in ('predictions', 'support', 'flags'):
        STATE['old_' + key] = np.load(BRIDGE / f'{key}.npy', mmap_mode='r')
    STATE['history_cache'] = OrderedDict()

def source_history(h):
    key = (int(h[0]), int(h[-1]) + 1)
    cache = STATE['history_cache']
    if key not in cache:
        values = np.asfortranarray(STATE['Q'][STATE['raw'][:, None], h[None, :]], dtype=float)
        cache[key] = E.C.prep(values, h)
        if len(cache) > 4:
            cache.popitem(last=False)
    else:
        cache.move_to_end(key)
    return cache[key]

def exact(x, y):
    return bool(np.array_equal(x, y, equal_nan=True))

def compute_case(i):
    e = STATE['cases'].iloc[i]
    raw = int(e.raw_index)
    h = np.arange(int(e.history_start), int(e.history_end))
    g = np.arange(int(e.gap_start), int(e.gap_end))
    assert len(h) == H and len(g) == G and (h[-1] + 1 == g[0])
    own = set(np.flatnonzero(STATE['group'] == STATE['group'][raw]).tolist())
    forbidden = own | STATE['excluded_raw']
    source = dict(raw=STATE['raw'], Q=E.GuardedSourceAccessor(STATE['Q'], STATE['raw'], forbidden, h[0], g[-1] + 1))
    cl, sd, zh = source_history(h)
    distance = E.distances(e.latitude, e.longitude, STATE['latitude'], STATE['longitude'])
    target_z = np.asarray(STATE['target_Hz'][i])
    built = E.build_composites(source, cl, sd, zh, target_z, own, distance, h, g)
    fitted = []
    p = STATE['p']
    for di in range(4):
        fitted.append(E.fit_arms(built['composites'][di], target_z, STATE['target_H_log_calendar'][i], float(STATE['target_H_anomaly_sd'][i]), STATE['target_H_raw_calendar'][i], bool(STATE['input_meta'][i, 4]), p['p_h'][i], p['p_g'][i], p['p_g_climatology'][i], bool(p['p_available'][i]), g))
    for name in ('predictions', 'model_z', 'support', 'flags', 'training_mask'):
        built[name] = np.stack([f[name] for f in fitted])
    built['P_available'] = np.array(bool(p['p_available'][i]))
    built['target_risk'] = np.array(raw in STATE['excluded_raw'])
    built['target_estimable'] = np.array(bool(STATE['input_meta'][i, 4]))
    built['target_log_calendar'] = np.asarray(STATE['target_H_log_calendar'][i])
    built['target_anomaly_sd'] = np.asarray(STATE['target_H_anomaly_sd'][i])
    built['target_raw_calendar'] = np.asarray(STATE['target_H_raw_calendar'][i])
    built['gap_months'] = g.astype(np.int16)
    near = built['nearest_qualified_reporter_distance_G']
    valid_near = np.isfinite(near)
    built['nearest_reported_month_count'] = np.array(valid_near.sum(), dtype=np.int16)
    built['nearest_far800_fraction_all_G'] = np.array(np.sum(valid_near & (near > 800)) / G)
    built['nearest_no_report_fraction'] = np.array(np.sum(~valid_near) / G)
    built['nearest_full_G_median_distance'] = np.array(np.median(near) if valid_near.all() else np.nan)
    sameids = exact(built['selected_ids'][0], STATE['old_selected_ids'][i, 1])
    samecomp = exact(built['composites'][0], STATE['old_composites'][i, 1])
    samepred = exact(built['predictions'][0], STATE['old_predictions'][i])
    sametrain = exact(built['training_mask'][0], STATE['old_training_mask'][i, 1])
    samesupport = exact(built['support'][0], STATE['old_support'][i])
    sameflags = exact(built['flags'][0], STATE['old_flags'][i])
    if sameids:
        assert samecomp and sametrain and samepred and samesupport and sameflags, 'Unchanged input must exactly replay old FULL'
    built['D0_replay'] = np.array([sameids, samecomp, sametrain, samepred, samesupport, sameflags])
    built['reasons'] = np.array([json.dumps(dict(distance=E.DLEVELS[di], fits=f['reasons'])) for di, f in enumerate(fitted)], dtype=str)
    return built

def work(i):
    result = compute_case(i)
    result['_registration_sha256'] = np.array(sha(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/CODE_INPUTS_FROZEN.json'))
    dest = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/case_cache' / f'{i:05d}.npz'
    temp = dest.with_suffix('.tmp.npz')
    np.savez_compressed(temp, **result)
    temp.replace(dest)
    return (i, bool(result['D0_replay'][0]))

def produce(workers):
    check_registration()
    assert not (_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/PREDICTIONS_FROZEN.json').exists(), 'Frozen results are immutable'
    cache = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/case_cache'
    cache.mkdir(parents=True, exist_ok=True)
    cases = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/cases.csv')
    order = cases.sort_values(['history_start', 'row']).row.to_numpy(int)
    receipt_hash = sha(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/CODE_INPUTS_FROZEN.json')
    for p in cache.glob('*.npz'):
        with np.load(p, allow_pickle=False) as z:
            assert str(z['_registration_sha256']) == receipt_hash, 'Stale resumable case: ' + str(p)
    todo = [int(i) for i in order if not (cache / f'{i:05d}.npz').exists()]
    start = time.time()
    with ProcessPoolExecutor(max_workers=workers, initializer=init) as pool:
        for n, (_, unchanged) in enumerate(pool.map(work, todo, chunksize=8), 1):
            if n % 100 == 0 or n == len(todo):
                print(f'PREDICTED {n}/{len(todo)} elapsed={time.time() - start:.1f}s', flush=True)
    save(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/RUN_COMPLETION.json', dict(completed_utc=datetime.now(timezone.utc).isoformat(), cases_run=len(todo), total_cases=N, seconds=time.time() - start, workers=workers, code_inputs_sha256=sha(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/CODE_INPUTS_FROZEN.json'), target_G_truth_read=False))

def assemble():
    check_registration()
    assert not (_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/PREDICTIONS_FROZEN.json').exists()
    matrices = {}
    records = []
    receipt_hash = sha(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/CODE_INPUTS_FROZEN.json')
    for i in range(N):
        with np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/case_cache' / f'{i:05d}.npz', allow_pickle=False) as z:
            assert str(z['_registration_sha256']) == receipt_hash
            if i == 0:
                for name in z.files:
                    if name in ('reasons', '_registration_sha256'):
                        continue
                    matrices[name] = np.lib.format.open_memmap(OUT / f'{name}.npy', mode='w+', dtype=z[name].dtype, shape=(N, *z[name].shape))
            for name, mm in matrices.items():
                mm[i] = z[name]
            for reason in z['reasons']:
                records.append(json.dumps(dict(row=i, **json.loads(str(reason))), ensure_ascii=False))
    for mm in matrices.values():
        mm.flush()
    del matrices
    (_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/fit_records.jsonl').write_text('\n'.join(records) + '\n', encoding='utf8')
    cases = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/cases.csv', keep_default_na=False)
    display = pd.read_csv(DISPLAY_META, keep_default_na=False).set_index('raw_index')
    matched = display.loc[cases.raw_index.to_numpy(int)]
    assert np.array_equal(matched.station_id.to_numpy(str), cases.station_id.to_numpy(str))
    for name in ('continent', 'country'):
        if name in cases:
            cases[name + '_previous_label'] = cases[name].copy()
        cases[name] = matched[name + '_display'].to_numpy(str)
        cases[name + '_label_changed'] = cases[name].ne(cases[name + '_previous_label']) if name + '_previous_label' in cases else False
    ex = pd.read_csv(EXCLUSIONS, keep_default_na=False).set_index('raw_index')
    cases['target_source_safety_warning'] = cases.raw_index.isin(ex.index)
    cases['P_available'] = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/P_available.npy')
    cases.to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/cases.csv', index=False, encoding='utf-8-sig')
    interface = dict(N=N, H=H, G=G, axes=['case', 'distance', 'method', 'arm', 'G_month'], distances=list(E.DLEVELS), methods=list(E.METHODS), arms=list(E.ARMS), flag_columns=list(E.FLAG_NAMES), prediction_units='raw discharge m3/s', D0_replay_columns=['selected_ids', 'composites', 'training_mask', 'predictions', 'support', 'flags'], nearest_distance='D0 minimum among all H-qualified synchronous sources; NaN=no qualified report', baseline='target_raw_calendar indexed by gap_months modulo12', primary_denominator='P_available8083; all8898 secondary including815 exactQ fallback', eligible_prediction='Original actual_fit plus positive number of supported G months (>0); finite truth/prediction metrics handled by scorer. Full120/120 support may be separately reported as sensitivity, not silently made primary.', target_risk='Five case IDs flagged in cases.csv; all retained in main mother denominator', source_domain='24714 safety-cleaned FULL candidates before target-identity exclusion', temporal_scope='one target gap at a time, not simultaneous removal of all target gaps')
    save(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/SCORING_INTERFACE.json', interface)
    replay = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/D0_replay.npy')
    save(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/D0_REPLAY_SUMMARY.json', dict(N=N, columns=interface['D0_replay_columns'], exact_counts=replay.sum(0).astype(int).tolist(), changed_selected_input_rows=np.flatnonzero(~replay[:, 0]).tolist(), unchanged_inputs_exact_replay=bool(replay[replay[:, 0]].all()), interpretation='Safe source exclusions and reranking may change D0; no scores inspected.'))
    files = sorted([p for p in OUT.iterdir() if p.is_file() and p.name != 'PREDICTIONS_FROZEN.json'])
    save(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/PREDICTIONS_FROZEN.json', dict(status='ALL8898_ALL_DISTANCE_PREDICTIONS_FROZEN_BEFORE_NEW_SCORING', frozen_utc=datetime.now(timezone.utc).isoformat(), N=N, target_G_truth_read=False, old_target_scores_read=False, code_inputs_sha256=sha(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/CODE_INPUTS_FROZEN.json'), files={p.name: sha(p) for p in files}))
    print('ASSEMBLED_AND_FROZEN; independent QA required before scoring', flush=True)
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['register', 'produce', 'assemble'])
    parser.add_argument('--workers', type=int, default=4)
    args = parser.parse_args()
    if args.command == 'register':
        register()
    elif args.command == 'produce':
        produce(args.workers)
    else:
        assemble()
