"""Fixed E1/E3 scoring. No source/model selection, gated after prediction QA."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib, argparse
from datetime import datetime, timezone
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[k] = '1'
sys.dont_write_bytecode = True
HERE = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance'
CODE = _PROJECT_ROOT
CORE = _PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/trial_score_core.py'
pass
pass
import numpy as np
import pandas as pd
from workflows.monitoring.external_locations.input_audit.trial_score_core import metrics, paired, transition, synthetic_checks
OLD = _PROJECT_ROOT / 'workflows/regional_dependence/global_design'
PRED = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions'
OUT = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis'
DS = (0, 100, 300, 800)
METHODS = ('ridge', 'rbf_ridge')
ARMS = ('Q', 'QP', 'QP_Gclim')
PAIRS = (('QP', 'Q', 'added_precipitation'), ('QP', 'QP_Gclim', 'actual_vs_climatological_P'), ('QP_Gclim', 'Q', 'climatology_control_vs_Q'))
CONTINUOUS = ('r', 'H_deseasonal_r', 'NSE')
BINARY = ('r07_pass', 'nse_success')
IDS = ['row', 'station_id', 'raw_index', 'latitude', 'longitude', 'continent', 'country', 'spatial_cell', 'outer_fold', 'history_start', 'history_end', 'gap_start', 'gap_end']

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def save(path, value):

    def clean(v):
        if isinstance(v, dict):
            return {str(k): clean(x) for k, x in v.items()}
        if isinstance(v, (list, tuple, np.ndarray)):
            return [clean(x) for x in v]
        if isinstance(v, np.generic):
            return clean(v.item())
        if isinstance(v, float) and (not np.isfinite(v)):
            return None
        return v
    Path(path).write_text(json.dumps(clean(value), ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf8')

def load(path):
    return json.loads(Path(path).read_text(encoding='utf8'))

def finite(v, median=False):
    v = np.asarray(v, float)
    v = v[np.isfinite(v)]
    return float(np.median(v) if median else np.mean(v)) if len(v) else np.nan

def distance_labels(distance):
    """Outcome-free target distance groups; 120 valid monthly distances required."""
    d = np.asarray(distance, float)
    valid = np.isfinite(d)
    assert d.ndim == 2 and d.shape[1] == 120 and np.all(d[valid] >= 0)
    n = valid.sum(1)
    med = np.full(len(d), np.nan)
    for i in range(len(d)):
        if n[i]:
            med[i] = np.median(d[i, valid[i]])
    sens = np.full(len(d), 'no_reporting_months', object)
    sens[(n > 0) & (med <= 100)] = '0_to_100km'
    sens[(n > 0) & (med > 100) & (med <= 300)] = '100_to_300km'
    sens[(n > 0) & (med > 300) & (med <= 800)] = '300_to_800km'
    sens[(n > 0) & (med > 800)] = 'over_800km'
    main = sens.copy()
    main[n < 120] = 'partial_or_no_reporting'
    return pd.DataFrame(dict(nearest_report_valid_months=n, median_nearest_qualified_reporter_km=med, far_only_months=((d > 800) & valid).sum(1), far_only_share_of_120=((d > 800) & valid).sum(1) / 120, no_report_months=120 - n, no_report_share_of_120=(120 - n) / 120, E3_main_group=main, E3_available_months_group=sens))

def freeze():
    assert not (_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/SCORING_PLAN_FROZEN.json').exists()
    tests = synthetic_checks()
    d = np.stack([np.full(120, x) for x in (100, 300, 800, 801, np.nan)])
    d = np.vstack([d, np.r_[np.full(119, 20.0), np.nan]])
    z = distance_labels(d)
    assert z.E3_main_group.tolist() == ['0_to_100km', '100_to_300km', '300_to_800km', 'over_800km', 'partial_or_no_reporting', 'partial_or_no_reporting']
    assert z.E3_available_months_group.iloc[-1] == '0_to_100km'
    plan = dict(date_utc=datetime.now(timezone.utc).isoformat(), N=8898, H=60, G=120, D=DS, methods=METHODS, arms=ARMS, primary='Actual-model r>0.7 on fixed original 8083 P-admitted targets; all8898 and815 P-unavailable separately. No NSE gate in r outcome.', secondary='NSE>=0.5 and >target-history seasonal NSE and actual fit/support. All constant, unfit and failed cases retained in group denominators.', pairs=PAIRS, continuous=CONTINUOUS, support='Scores use actual fit and at least one contributed G month, all120 predicted months scored; full120 support count also reported. Continuous pairs require both arms eligible and finite.', groups='All8898; P-admitted8083; P-unknown815; all8898 and admitted by continent; source/target-risk exclusion sensitivity. E3D0 fixed source-availability distance bins.', E3='For targets with all120 G months having any legal qualified reporter, median of monthly nearest source distance: <=100, (100,300], (300,800], >800 km. Partial/no reporting separate. Sensitivity groups all available months; no outcome selection. Distances use ALL qualified reporters, not K4.', interactions='For each D100/300/800 and both methods, paired (QP-Q)D minus (QP-Q)D0; both r07 and NSE passes plus r and deseasonal r. Same fixed mother for binary; all4 arms valid for continuous.', bootstrap='2000 paired spatial-cell multinomial bootstrap draws; seed, equal target weights within resample. Same global-cell draws for all comparisons. CIs estimate mean differences, never median intervals.', status='Existing project outcomes have previously been viewed; fixed retrospective diagnostic extension, not new blind confirmation. Freeze before this new scoring, no favorable threshold or processor selection.')
    save(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/SCORING_PLAN.json', plan)
    save(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/SCORING_PLAN_FROZEN.json', dict(files={str(p): sha(p) for p in [_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/src/score_gradient.py', CORE, _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/SCORING_PLAN.json']}, synthetic_checks=tests, E3_synthetic_checks='PASS', new_E1_target_G_scored=False))
    print('SCORING_PLAN_FROZEN_WITH_SYNTHETIC_QA', flush=True)

def verify_manifest(path, base=None):
    m = load(path)
    for name, expected in m['files'].items():
        p = Path(name) if Path(name).is_absolute() else Path(base or Path(path).parent) / name
        if isinstance(expected, dict):
            expected = expected['sha256']
        assert sha(p) == expected, str(p)
    return m

def score(authorized):
    if not authorized:
        raise RuntimeError('Scoring requires explicit parent authorization after independent prediction QA.')
    qa = load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/design_review/PRE_SCORING_QA_PASS.json')
    assert qa.get('passed') is True
    assert qa['scoring_code_sha256'] == sha(__file__)
    assert qa['scoring_plan_freeze_sha256'] == sha(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/SCORING_PLAN_FROZEN.json')
    assert qa['predictions_freeze_sha256'] == sha(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/PREDICTIONS_FROZEN.json')
    verify_manifest(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/SCORING_PLAN_FROZEN.json')
    verify_manifest(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/PREDICTIONS_FROZEN.json', PRED)
    assert not (_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/ANALYSIS_COMPLETE.json').exists()
    OUT.mkdir(exist_ok=True)
    save(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/SCORING_AUTHORIZATION.json', dict(time_utc=datetime.now(timezone.utc).isoformat(), QA_sha256=sha(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/design_review/PRE_SCORING_QA_PASS.json')))
    cases = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/cases.csv', keep_default_na=False)
    assert len(cases) == 8898 and np.array_equal(cases.row.to_numpy(), np.arange(8898))
    p = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/predictions.npy', mmap_mode='r')
    s = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/support.npy', mmap_mode='r')
    f = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/flags.npy', mmap_mode='r')
    assert p.shape == s.shape == (8898, 4, 2, 3, 120) and f.shape == (8898, 4, 2, 3, 7)
    hasp = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/P_available.npy').astype(bool)
    risk = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/target_risk.npy').astype(bool)
    training_n = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/training_mask.npy').sum(2)
    assert training_n.shape == (8898, 4)
    assert hasp.shape == risk.shape == (8898,) and hasp.sum() == 8083
    raw = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', mmap_mode='r')
    y = np.stack([raw[int(e.raw_index), int(e.gap_start):int(e.gap_end)] for e in cases.itertuples()])
    months = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/gap_months.npy')
    calendar = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/target_raw_calendar.npy')
    b = calendar[np.arange(8898)[:, None], months % 12]
    assert months.shape == y.shape == (8898, 120)
    dist = distance_labels(np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/predictions/nearest_qualified_reporter_distance_G.npy'))
    dist = pd.concat([cases[IDS].reset_index(drop=True), dist], axis=1)
    dist['P_available'] = hasp
    dist['target_risk'] = risk
    dist.to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/E3_target_distance_groups.csv', index=False)
    common = cases[IDS].copy()
    common['P_available'] = hasp
    common['target_risk'] = risk
    frames = []
    models = {}
    for di, D in enumerate(DS):
        for mi, method in enumerate(METHODS):
            for ai, arm in enumerate(ARMS):
                v = metrics(y, p[:, di, mi, ai], b, f[:, di, mi, ai, 0], s[:, di, mi, ai])
                z = pd.concat([common.reset_index(drop=True), pd.DataFrame(v)], axis=1)
                z['D'] = D
                z['method'] = method
                z['arm'] = arm
                z['full120_supported'] = v['support_months'] == 120
                frames.append(z)
                models[D, method, arm] = z
    pd.concat(frames, ignore_index=True).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/scores_long.csv.gz', index=False)
    groups = [('all_mothers', 'all', np.ones(8898, bool)), ('P_admitted', 'all', hasp), ('P_unavailable', 'all', ~hasp), ('risk_excluded', 'all', ~risk), ('P_admitted_risk_excluded', 'all', hasp & ~risk)]
    cv = cases.continent.astype(str).to_numpy()
    for c in np.unique(cv):
        groups.extend([('continent_all', c, cv == c), ('continent_P_admitted', c, (cv == c) & hasp)])
    e3groups = []
    for col, subset in [('E3_main_group', 'E3_all120'), ('E3_available_months_group', 'E3_available_months')]:
        for value in np.unique(dist[col].to_numpy(str)):
            mask = dist[col].eq(value).to_numpy()
            e3groups.extend([(subset + '_all', value, mask), (subset + '_P_admitted', value, mask & hasp)])
    names, cells = np.unique(cases.spatial_cell.astype(str), return_inverse=True)
    rng = np.random.default_rng(20261026)
    draws = rng.multinomial(len(names), np.full(len(names), 1 / len(names)), size=2000)
    np.savez_compressed(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/bootstrap_draws.npz', spatial_cells=names.astype(str), draws=draws)
    summaries = []
    pairs = []
    counts = []
    station = []
    for (D, method, arm), z in models.items():
        for subset, stratum, mask in groups + (e3groups if D == 0 else []):
            n = int(mask.sum())
            ok = mask & z.eligible.to_numpy(bool)
            di = DS.index(D)
            rec = dict(D=D, method=method, arm=arm, subset=subset, stratum=stratum, n_subset=n, n_eligible=int(ok.sum()), n_actual_model_estimable=int((mask & z.actual_model_estimable.to_numpy(bool)).sum()), H_training_rows_median=finite(training_n[mask, di], True), H_training_rows_min=int(training_n[mask, di].min()) if n else np.nan, n_full120_supported=int((mask & z.full120_supported.to_numpy(bool)).sum()), support_months=int(z.loc[mask, 'support_months'].sum()))
            for metric in BINARY:
                v = int((mask & z[metric].to_numpy(bool)).sum())
                rec[metric] = v
                rec[metric + '_pct'] = 100 * v / n if n else np.nan
            for metric in CONTINUOUS:
                rec[metric + '_mean'] = finite(z.loc[ok, metric])
                rec[metric + '_median'] = finite(z.loc[ok, metric], True)
            for metric in BINARY:
                q = paired(z[metric].to_numpy(float), ok, mask, cells, draws, binary=True)
                rec[metric + '_pct_ci025'] = q['mean_gain_ci025']
                rec[metric + '_pct_ci975'] = q['mean_gain_ci975']
            summaries.append(rec)
    for D in DS:
        for method in METHODS:
            for aa, bb, label in PAIRS:
                a, c = (models[D, method, aa], models[D, method, bb])
                eligible = a.eligible.to_numpy(bool) & c.eligible.to_numpy(bool)
                sr = common.copy()
                sr['D'] = D
                sr['method'] = method
                sr['contrast'] = label
                sr['paired_eligible'] = eligible
                sr['new_r07'] = a.r07_pass.to_numpy(bool) & ~c.r07_pass.to_numpy(bool)
                sr['lost_r07'] = ~a.r07_pass.to_numpy(bool) & c.r07_pass.to_numpy(bool)
                for metric in CONTINUOUS:
                    sr[metric + '_gain'] = a[metric].to_numpy() - c[metric].to_numpy()
                station.append(sr)
                for subset, stratum, mask in groups + (e3groups if D == 0 else []):
                    head = dict(D=D, method=method, arm=aa, reference_arm=bb, contrast=label, subset=subset, stratum=stratum)
                    for metric in BINARY:
                        counts.append({**head, 'metric': metric, **transition(a[metric].to_numpy(bool), c[metric].to_numpy(bool), mask)})
                    for metric in CONTINUOUS + BINARY:
                        v = a[metric].to_numpy(float) - c[metric].to_numpy(float)
                        pairs.append({**head, 'metric': metric, **paired(v, eligible, mask, cells, draws, binary=metric in BINARY)})
    interactions = []
    for D in DS[1:]:
        for method in METHODS:
            a, c = (models[D, method, 'QP'], models[D, method, 'Q'])
            a0, c0 = (models[0, method, 'QP'], models[0, method, 'Q'])
            eligible = np.logical_and.reduce([v.eligible.to_numpy(bool) for v in (a, c, a0, c0)])
            for subset, stratum, mask in groups:
                for metric in ('r', 'H_deseasonal_r') + BINARY:
                    v = a[metric].to_numpy(float) - c[metric].to_numpy(float) - (a0[metric].to_numpy(float) - c0[metric].to_numpy(float))
                    interactions.append(dict(D=D, method=method, subset=subset, stratum=stratum, metric=metric, contrast='(QP-Q)D_minus_(QP-Q)D0', **paired(v, eligible, mask, cells, draws, binary=metric in BINARY)))
    pd.DataFrame(summaries).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/summary_by_group.csv', index=False)
    pd.DataFrame(pairs).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/paired_bootstrap.csv', index=False)
    pd.DataFrame(counts).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/new_lost_counts.csv', index=False)
    pd.DataFrame(interactions).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/gradient_interactions.csv', index=False)
    pd.concat(station, ignore_index=True).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/paired_station_changes.csv.gz', index=False)
    pd.DataFrame([dict(subset=a, stratum=b, n=int(c.sum())) for a, b, c in groups + e3groups]).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/stratum_denominators.csv', index=False)
    save(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/ANALYSIS_COMPLETE.json', dict(status='ALL_FIXED_E1_E3_RESULTS_COMPLETE', N=8898, primary_P_admitted=8083, bootstrap_replicates=2000, spatial_cells=len(names), all_methods_distances_and_arms_retained=True, project_new_blind_test=False, outputs={p.name: dict(sha256=sha(p), bytes=p.stat().st_size) for p in OUT.iterdir() if p.is_file()}))
    print('SCORING_COMPLETE_ALL_PREDEFINED_E1_E3', flush=True)
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('step', choices=['freeze', 'score'])
    ap.add_argument('--authorized-after-QA', action='store_true')
    args = ap.parse_args()
    freeze() if args.step == 'freeze' else score(args.authorized_after_QA)
