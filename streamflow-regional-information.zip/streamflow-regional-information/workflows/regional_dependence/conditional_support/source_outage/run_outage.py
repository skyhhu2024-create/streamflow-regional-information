from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib, time, warnings, argparse
from concurrent.futures import ProcessPoolExecutor
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[k] = '1'
sys.dont_write_bytecode = True
HERE = _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage'
CODE = _PROJECT_ROOT
OLD = _PROJECT_ROOT / 'workflows/regional_dependence/global_design'
pass
import numpy as np
import pandas as pd
from scipy.stats import rankdata
G = {}
DLEVELS = [0, 100, 300, 800]

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def js(p, o):

    def clean(x):
        if isinstance(x, dict):
            return {str(k): clean(v) for k, v in x.items()}
        if isinstance(x, (list, tuple, np.ndarray)):
            return [clean(v) for v in x]
        if isinstance(x, np.generic):
            return clean(x.item())
        if isinstance(x, float) and (not np.isfinite(x)):
            return None
        return x
    Path(p).write_text(json.dumps(clean(o), ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf8')

def init():
    warnings.filterwarnings('ignore', category=RuntimeWarning)
    G['Q'] = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', mmap_mode='r')
    G['source_raw'] = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/predictions/source_cache/source_raw_indices.npy')
    G['meta'] = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/all_station_roles.csv')
    G['folds'] = {}

def fold(o):
    if o in G['folds']:
        return G['folds'][o]
    mask = np.load(OLD / f'design/outer_{o}_source_mask.npy')
    raw = G['source_raw'][mask[G['source_raw']]]
    assert (G['meta'].iloc[raw].outer_fold.to_numpy() != o).all()
    f = dict(raw=raw, Q=np.asarray(G['Q'][raw]), lat=G['meta'].iloc[raw].latitude.to_numpy(float), lon=G['meta'].iloc[raw].longitude.to_numpy(float))
    G['folds'][o] = f
    return f

def prep(raw, months):
    raw = np.asarray(raw, float)
    valid = np.isfinite(raw) & (raw >= 0)
    x = np.full_like(raw, np.nan)
    x[valid] = np.log1p(raw[valid])
    cl = np.stack([np.nanmean(x[:, months % 12 == m], axis=1) for m in range(12)], axis=1)
    a = x - cl[:, months % 12]
    sd = np.nanstd(a, axis=1)
    sd[sd <= 1e-12] = np.nan
    z = a / sd[:, None]
    return (cl, sd, z)

def relation(x, y):
    ok = np.isfinite(x) & np.isfinite(y)[None, :]
    n = ok.sum(1)
    xx = np.where(ok, x, 0)
    yy = np.where(ok, y[None, :], 0)
    nn = np.maximum(n, 1)
    sx = xx.sum(1)
    sy = yy.sum(1)
    vx = (xx * xx).sum(1) - sx * sx / nn
    vy = (yy * yy).sum(1) - sy * sy / nn
    cv = (xx * yy).sum(1) - sx * sy / nn
    good = (n >= 12) & (vx > 1e-24) & (vy > 1e-24)
    r = np.full(len(n), np.nan)
    r[good] = np.clip(cv[good] / np.sqrt(vx[good] * vy[good]), -1, 1)
    return (n, r)

def ordering(raw, q, r, dist):
    rr = rankdata(-r[q], method='average')
    dd = rankdata(dist[q], method='average')
    return q[np.lexsort((raw[q], rr, rr + dd))]

def combine(f, q, r, cl, sd, months, excluded=None):
    count = np.zeros(len(months), np.int8)
    num = np.zeros(len(months))
    den = np.zeros(len(months))
    ids = np.full((len(months), 4), -1, np.int32)
    for j in q:
        if excluded is not None and excluded[j]:
            continue
        raw = f['Q'][j, months]
        cc = cl[j, months % 12]
        take = np.isfinite(raw) & (raw >= 0) & np.isfinite(cc) & (count < 4)
        if take.any():
            ii = np.flatnonzero(take)
            z = (np.log1p(raw[take]) - cc[take]) / sd[j]
            w = r[j]
            ids[ii, count[ii]] = f['raw'][j]
            count[ii] += 1
            den[ii] += w
            num[ii] += w * z
        if (count == 4).all():
            break
    return (np.divide(num, den, out=np.full(len(months), np.nan), where=den > 0), count, ids)

def transfer(comp, tz, cl, sd, gap, base, estimable):
    if not estimable:
        return (base.copy(), np.zeros(len(gap), bool))
    supported = np.isfinite(comp) & np.isfinite(cl[gap % 12])
    vals = tz[np.isfinite(tz)]
    z = np.where(supported, np.clip(comp, vals.min() - 3, vals.max() + 3), 0.0)
    pp = np.maximum(np.expm1(np.minimum(z * sd + cl[gap % 12], 50)), 0)
    pp[~supported] = base[~supported]
    return (pp, supported)

def work(e):
    j = int(e['raw_index'])
    f = fold(int(e['outer_fold']))
    assert j not in f['raw']
    h = np.arange(int(e['history_start']), int(e['history_end']))
    gap = np.arange(int(e['gap_start']), int(e['gap_end']))
    assert len(h) == 60 and len(gap) == 120
    th = np.asarray(G['Q'][j, h])
    domain = bool(np.isfinite(th).all() and (th >= 0).all())
    tc, ts, tz = prep(th[None, :], h)
    tz = tz[0]
    tc = tc[0]
    ts = float(ts[0])
    estim = bool(domain and np.isfinite(ts) and np.isfinite(tc).all())
    if not estim:
        tz = np.full(60, np.nan)
    basecl = np.array([np.mean(th[h % 12 == m]) if np.isfinite(th[h % 12 == m]).all() else np.nanmean(th[h % 12 == m]) for m in range(12)])
    base = basecl[gap % 12]
    cl, sd, zh = prep(f['Q'][:, h], h)
    n, r = relation(zh, tz)
    a, b = (np.deg2rad(float(e['latitude'])), np.deg2rad(float(e['longitude'])))
    c, d = (np.deg2rad(f['lat']), np.deg2rad(f['lon']))
    hav = np.sin((c - a) / 2) ** 2 + np.cos(a) * np.cos(c) * np.sin((d - b) / 2) ** 2
    dist = 6371 * 2 * np.arcsin(np.sqrt(np.clip(hav, 0, 1)))
    pred = np.full((2, 4, 2, 120), np.nan)
    sup = np.zeros((2, 4, 2, 120), bool)
    cnt = np.zeros((2, 4, 180), np.int8)
    comps = np.full((2, 4, 180), np.nan)
    ids = np.full((2, 4, 120, 4), -1, np.int32)
    meta = np.zeros((2, 8))
    coef = np.full((2, 2), np.nan)
    for pool in range(2):
        q = np.flatnonzero(np.isfinite(r) & (r > 0) & np.isfinite(sd) & (dist <= 800 if pool == 0 else np.ones(len(r), bool)))
        q = ordering(f['raw'], q, r, dist)
        hc, hcnt, hids = combine(f, q, r, cl, sd, h)
        ok = np.isfinite(hc) & np.isfinite(tz)
        fit = False
        b0 = b1 = np.nan
        if estim and ok.sum() >= 12:
            x = hc[ok]
            y = tz[ok]
            xx = x - x.mean()
            vv = float(xx @ xx)
            if vv > 1e-24:
                b1 = float(xx @ (y - y.mean()) / vv)
                b0 = float(y.mean() - b1 * x.mean())
                fit = bool(np.isfinite([b0, b1]).all())
        coef[pool] = [b0, b1]
        meta[pool] = [len(q), ok.sum(), estim, fit, domain, bool(e['target_nonnegative_domain']), np.sum(~np.isfinite(cl[q])), np.sum(~np.isfinite(sd))]
        for k, D in enumerate(DLEVELS):
            gc, gcnt, gids = combine(f, q, r, cl, sd, gap, dist <= D if D else None)
            comps[pool, k] = np.r_[hc, gc]
            cnt[pool, k] = np.r_[hcnt, gcnt]
            ids[pool, k] = gids
            pred[pool, k, 0], sup[pool, k, 0] = transfer(gc, tz, tc, ts, gap, base, estim)
            pred[pool, k, 1], sup[pool, k, 1] = transfer(gc * b1 + b0, tz, tc, ts, gap, base, fit)
    assert (np.diff(cnt[:, :, 60:], axis=1) <= 0).all()
    assert not sup[0, 3].any() and (not cnt[0, 3, 60:].any())
    assert not np.any(ids == j)
    return (int(e['row']), pred, sup, cnt, comps, ids, meta, coef, base)

def register():
    proto = dict(date='2026-10-24', purpose='Matched source reporting outage stress test', mothers=8898, H=60, L=120, pools=['local800_all_candidates', 'global_all_candidates'], D_km=DLEVELS, methods=['DAT', 'OLS_same_composite'], selection='H-only anomaly Pearson r>0 and >=12 paired observations; monthly K4 by average ranks(-r)+ranks(distance), then rank(-r),rawID; positive r weighted', preprocessing='Float64 log1p, calendarmeans and anomaly SD exclusively from corresponding original target H60 interval for sources and target. Source negative values missing. SD<=1e-12 undefined. Source G values used only for synchronous anomaly, never statistics. Inherited all-record target domain flag audited only; targetH negative => unsupported.', outage='All source reports at distance<=D hidden throughout G; H unchanged. Fixed qualifying identities and ranks for all D. D0 means no removal even if colocated.', metrics='NSE/r/alpha/delta/S relative to target raw seasonalmean. Success NSE>=0.5 and >baseline NSE and actual reference contribution. Constant truth and unsupported stay mother denominator. Common evaluable precision comparison.', affected='At each D>0, fixed subset where LOCAL baseline supported months>LOCAL outage supported months. Global comparisons report same subset.', inference='2000 paired bootstrap over existing spatial_cell groups, equal station weight. All values retained; no clipping scores. Prediction standard guard targetH z-range+-3, log cap50.', scope='No oracle, source truth selection, figures, manuscript editing or cloud. Prediction freeze precedes scoring. New H-only prep means numeric baselines are not directly comparable to old A.', workers=4)
    js(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/PROTOCOL.json', proto)
    raw = np.tile(np.arange(1, 13.0), 5)[None, :]
    cl, sd, z = prep(raw, np.arange(60))
    assert np.isnan(sd[0])
    raw2 = raw.copy()
    raw2[:, np.arange(60) % 12 == 2] = np.nan
    cl, sd, z = prep(raw2, np.arange(60))
    assert np.isnan(cl[0, 2])
    x = np.arange(60.0, dtype=float)
    n, r = relation(x[None, :], x)
    assert n[0] == 60 and np.isclose(r[0], 1)
    paths = [_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/run_outage.py', _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/PROTOCOL.json', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/independent_target_cases.csv', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/all_station_roles.csv', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/predictions/source_cache/source_raw_indices.npy'] + [OLD / f'design/outer_{o}_source_mask.npy' for o in range(4)]
    js(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/CODE_INPUTS_FROZEN.json', dict(files={str(p): sha(p) for p in paths}, synthetic_checks='PASS', target_G_scored=False))
    print('REGISTERED', flush=True)

def produce():
    reg = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/CODE_INPUTS_FROZEN.json').read_text())
    assert all((sha(p) == v for p, v in reg['files'].items()))
    cases = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/independent_target_cases.csv').sort_values('raw_index').reset_index(drop=True)
    cases['row'] = np.arange(len(cases))
    assert len(cases) == 8898
    cases.to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/cases.csv', index=False)
    shapes = {'predictions': ((8898, 2, 4, 2, 120), 'float64'), 'support': ((8898, 2, 4, 2, 120), 'bool'), 'counts': ((8898, 2, 4, 180), 'int8'), 'composites': ((8898, 2, 4, 180), 'float64'), 'source_ids_G': ((8898, 2, 4, 120, 4), 'int32'), 'input_meta': ((8898, 2, 8), 'float64'), 'ols_coefficients': ((8898, 2, 2), 'float64'), 'baseline': ((8898, 120), 'float64')}
    arrays = {k: np.lib.format.open_memmap(HERE / (k + '.npy'), mode='w+', shape=s, dtype=d) for k, (s, d) in shapes.items()}
    st = time.time()
    with ProcessPoolExecutor(max_workers=4, initializer=init) as pool:
        for i, res in enumerate(pool.map(work, cases.to_dict('records'), chunksize=4), 1):
            row, *vs = res
            for k, v in zip(shapes, vs):
                arrays[k][row] = v
            if i % 250 == 0:
                print(f'Outage predictions {i}/8898; sec={time.time() - st:.1f}', flush=True)
    for a in arrays.values():
        a.flush()
    js(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/ALL_PREDICTIONS_FROZEN.json', dict(status='ALL_PREDICTIONS_BEFORE_ANY_G_SCORING', seconds=time.time() - st, files={p.name: sha(p) for p in [_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/cases.csv'] + [HERE / (k + '.npy') for k in shapes]}, code_freeze=sha(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/CODE_INPUTS_FROZEN.json')))
    print('PREDICTIONS_FROZEN', flush=True)

def scores():
    fr = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/ALL_PREDICTIONS_FROZEN.json').read_text())
    assert all((sha(HERE / p) == v for p, v in fr['files'].items()))
    cases = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/cases.csv')
    P = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/predictions.npy', mmap_mode='r')
    sup = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/support.npy', mmap_mode='r')
    M = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/input_meta.npy')
    base = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/baseline.npy')
    Q = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', mmap_mode='r')
    frames = []
    y = np.stack([Q[int(e.raw_index), int(e.gap_start):int(e.gap_end)] for e in cases.itertuples()])
    constant = np.all(y == y[:, 0, None], 1)
    ym = y.mean(1)
    yc = y - ym[:, None]
    sst = np.sum(yc * yc, 1)
    sst[constant] = 0
    sd = np.sqrt(sst / 120)
    bsse = np.sum((base - y) ** 2, 1)
    bn = 1 - np.divide(bsse, sst, out=np.full(8898, np.nan), where=sst > 0)
    validtruth = np.isfinite(y).all(1) & (y >= 0).all(1) & (sst > 0)
    for p in range(2):
        for k, D in enumerate(DLEVELS):
            for m in range(2):
                pp = np.asarray(P[:, p, k, m])
                pm = pp.mean(1)
                pc = pp - pm[:, None]
                pss = np.sum(pc * pc, 1)
                pss[np.all(pp == pp[:, 0, None], 1)] = 0
                sse = np.sum((pp - y) ** 2, 1)
                ns = 1 - np.divide(sse, sst, out=np.full(8898, np.nan), where=sst > 0)
                ss = 1 - np.divide(sse, bsse, out=np.full(8898, np.nan), where=bsse > 0)
                r = np.clip(np.divide(np.sum(pc * yc, 1), np.sqrt(pss * sst), out=np.full(8898, np.nan), where=(pss > 0) & (sst > 0)), -1, 1)
                al = np.divide(np.sqrt(pss / 120), sd, out=np.full(8898, np.nan), where=sd > 0)
                de = np.divide(pm - ym, sd, out=np.full(8898, np.nan), where=sd > 0)
                sm = sup[:, p, k, m].sum(1)
                eligible = (sm > 0) & M[:, p, 2 + m].astype(bool) & validtruth & np.isfinite(pp).all(1)
                success = eligible & (ns >= 0.5) & (ns > bn)
                df = cases[['station_id', 'raw_index', 'spatial_cell', 'outer_fold', 'continent']].copy()
                df['arm'] = f"{('LOCAL', 'GLOBAL')[p]}_D{D:03d}_{('DAT', 'OLS')[m]}"
                df['pool'] = ('LOCAL', 'GLOBAL')[p]
                df['D'] = D
                df['method'] = ('DAT', 'OLS')[m]
                for key, v in dict(NSE=ns, baseline_NSE=bn, S=ss, r=r, alpha=al, delta=de, absolute_alpha_error=np.abs(al - 1), absolute_delta_error=np.abs(de), support_months=sm, eligible=eligible, success=success, valid_truth=validtruth, method_estimable=M[:, p, 2 + m].astype(bool), qualified_sources=M[:, p, 0], input_domain=M[:, p, 4].astype(bool)).items():
                    df[key] = v
                frames.append(df)
    out = pd.concat(frames, ignore_index=True)
    out.to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/scores_long.csv.gz', index=False)
    js(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/SCORES_FROZEN.json', dict(rows=len(out), files={'scores_long.csv.gz': sha(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/scores_long.csv.gz')}, old_target_domain_diff=int(np.sum(M[:, 0, 4] != M[:, 0, 5])), valid_truth=int(validtruth.sum())))
    print('SCORES_FROZEN', flush=True)

def summarize():
    df = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/scores_long.csv.gz')
    groups = {a: g.sort_values('raw_index').reset_index(drop=True) for a, g in df.groupby('arm')}
    ref = next(iter(groups.values()))
    _, cell = np.unique(ref.spatial_cell.astype(str), return_inverse=True)
    K = cell.max() + 1
    rng = np.random.default_rng(20261024)
    draw = rng.multinomial(K, np.ones(K) / K, size=2000).astype(float)
    srows = []
    prows = []
    for arm, g in groups.items():
        D = int(g.D.iloc[0])
        affected = groups[f'LOCAL_D000_DAT'].support_months > groups[f'LOCAL_D{D:03d}_DAT'].support_months
        for name, mask in [('all_mothers', np.ones(len(g), bool)), ('local_support_loss', affected.to_numpy())]:
            v = g.loc[mask]
            e = v[v.eligible]
            srows.append(dict(arm=arm, subset=name, n=len(v), evaluable=len(e), success=int(v.success.sum()), success_pct=100 * v.success.mean(), support_months=int(v.support_months.sum()), full_support=int(v.support_months.eq(120).sum()), median_NSE=e.NSE.median(), mean_NSE=e.NSE.mean(), median_S=e.S.median(), median_r=e.r.median(), median_abs_alpha=e.absolute_alpha_error.median(), median_abs_delta=e.absolute_delta_error.median()))
    pairs = []
    for D in DLEVELS:
        for m in ('DAT', 'OLS'):
            pairs.append((f'GLOBAL_D{D:03d}_{m}', f'LOCAL_D{D:03d}_{m}', 'global_vs_local', D))
        for p in ('LOCAL', 'GLOBAL'):
            pairs.append((f'{p}_D{D:03d}_OLS', f'{p}_D{D:03d}_DAT', 'same_input_OLS', D))
    for D in DLEVELS[1:]:
        for p in ('LOCAL', 'GLOBAL'):
            for m in ('DAT', 'OLS'):
                pairs.append((f'{p}_D{D:03d}_{m}', f'{p}_D000_{m}', 'outage_vs_intact', D))
    for aa, bb, kind, D in pairs:
        a, b = (groups[aa], groups[bb])
        affected = (groups['LOCAL_D000_DAT'].support_months > groups[f'LOCAL_D{D:03d}_DAT'].support_months).to_numpy()
        for name, mask in [('all_mothers', np.ones(len(a), bool)), ('local_support_loss', affected)]:
            for metric, sign in [('success', 1), ('support_months', 1), ('NSE', 1), ('S', 1), ('r', 1), ('absolute_alpha_error', -1), ('absolute_delta_error', -1)]:
                v = sign * (a[metric].to_numpy(float) - b[metric].to_numpy(float))
                ok = mask & np.isfinite(v)
                if metric not in ('success', 'support_months'):
                    ok &= a.eligible.to_numpy() & b.eligible.to_numpy()
                vv = v[ok]
                cc = cell[ok]
                num = np.bincount(cc, weights=vv, minlength=K)
                den = np.bincount(cc, minlength=K)
                bd = draw @ den
                boot = np.divide(draw @ num, bd, out=np.full(2000, np.nan), where=bd > 0)
                fac = 100 if metric == 'success' else 1
                prows.append(dict(arm=aa, reference=bb, contrast=kind, subset=name, D=D, metric=metric, n=int(ok.sum()), mean_gain=fac * np.mean(vv) if len(vv) else np.nan, median_gain=fac * np.median(vv) if len(vv) else np.nan, ci025=fac * np.nanquantile(boot, 0.025) if len(vv) else np.nan, ci975=fac * np.nanquantile(boot, 0.975) if len(vv) else np.nan, positive_pct=100 * np.mean(vv > 0) if len(vv) else np.nan, negative_pct=100 * np.mean(vv < 0) if len(vv) else np.nan, new_success=int((mask & a.success.to_numpy() & ~b.success.to_numpy()).sum()), lost_success=int((mask & ~a.success.to_numpy() & b.success.to_numpy()).sum())))
    pd.DataFrame(srows).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/summary.csv', index=False)
    pd.DataFrame(prows).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/paired_bootstrap.csv', index=False)
    js(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/COMPLETE.json', dict(status='COMPLETE_ALL8898_SOURCE_OUTAGE', bootstrap_cells=int(K), bootstrap_replicates=2000, outputs={p.name: sha(p) for p in [_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/summary.csv', _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/paired_bootstrap.csv', _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/scores_long.csv.gz']}))
    print(pd.DataFrame(srows).query('subset=="all_mothers"').to_string(index=False), flush=True)
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('step', choices=['register', 'produce', 'scores', 'summarize'])
    a = ap.parse_args()
    globals()[a.step]()
