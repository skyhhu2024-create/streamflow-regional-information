from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, time, hashlib, argparse, warnings
from concurrent.futures import ProcessPoolExecutor
for k in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[k] = '1'
HERE = _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/history_season'
CODE = _PROJECT_ROOT
OLD = _PROJECT_ROOT / 'workflows/regional_dependence/global_design'
pass
import numpy as np
import pandas as pd
from scipy.stats import rankdata
G = {}
METHODS = ['DAT', 'AnomalyOLS', 'SeasonalOLS']

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def js(p, x):

    def clean(z):
        if isinstance(z, dict):
            return {str(k): clean(v) for k, v in z.items()}
        if isinstance(z, (list, tuple, np.ndarray)):
            return [clean(v) for v in z]
        if isinstance(z, np.generic):
            return clean(z.item())
        if isinstance(z, float) and (not np.isfinite(z)):
            return None
        return z
    Path(p).write_text(json.dumps(clean(x), ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')

def conditions(kind):
    if kind == 'history':
        return [dict(label=f'H{h:03}', H=h, k=0, rotation=-1, type='history') for h in [6, 12, 18, 24, 36, 60]]
    return [dict(label=f'{typ}_K{k}_R{r:02}', H=36, k=k, rotation=r, type=typ) for k in [1, 3, 6] for r in range(12) for typ in ['season_deleted', 'count_matched']]

def init():
    warnings.filterwarnings('ignore', category=RuntimeWarning)
    G['Q'] = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', mmap_mode='r')
    G['meta'] = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/all_station_roles.csv')
    sr = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/predictions/source_cache/source_raw_indices.npy')
    G['folds'] = {o: sr[np.load(OLD / f'design/outer_{o}_source_mask.npy')[sr]] for o in range(4)}

def transform(q, months):
    q = np.asarray(q, float)
    valid = np.isfinite(q) & (q >= 0)
    x = np.where(valid, np.log1p(np.maximum(q, 0)), np.nan)
    cl = np.stack([np.nanmean(x[:, months % 12 == m], axis=1) for m in range(12)], axis=1)
    dev = x - cl[:, months % 12]
    sd = np.nanstd(dev, axis=1)
    repeated = np.stack([np.sum(valid[:, months % 12 == m], axis=1) for m in range(12)], axis=1).max(1) > 1
    sd[(sd <= 1e-12) | ~repeated] = np.nan
    return (x, cl, sd, dev / sd[:, None])

def masked_h(h, condition):
    hh = h[-condition['H']:]
    keep = np.ones(len(hh), bool)
    if condition['type'] == 'season_deleted':
        keep = ~np.isin(hh % 12, (condition['rotation'] + np.arange(condition['k'])) % 12)
    if condition['type'] == 'count_matched':
        nremove = 3 * condition['k']
        r = condition['rotation']
        for j in range(nremove):
            cal = (r + j) % 12
            positions = np.flatnonzero(hh % 12 == cal)
            age = (r + j // 12) % 3
            keep[positions[age]] = False
        assert np.all(np.bincount(hh[keep] % 12, minlength=12) >= 1)
    return hh[keep]

def target_info(raw, h, gap):
    domain = bool(np.all(np.isfinite(raw)) and np.all(raw >= 0))
    x, cl, sd, z = transform(raw[None, :], h)
    basecl = np.array([np.mean(raw[h % 12 == m]) if np.any(h % 12 == m) else np.mean(raw) for m in range(12)])
    return (x[0], cl[0], float(sd[0]), z[0], basecl[gap % 12], domain)

def relation(zs, yt):
    ok = np.isfinite(zs) & np.isfinite(yt)[None, :]
    n = ok.sum(1)
    nn = np.maximum(n, 1)
    xx = np.where(ok, zs, 0.0)
    yy = np.where(ok, yt, 0.0)
    sx = xx.sum(1)
    sy = yy.sum(1)
    vx = np.sum(xx * xx, 1) - sx * sx / nn
    vy = np.sum(yy * yy, 1) - sy * sy / nn
    cv = np.sum(xx * yy, 1) - sx * sy / nn
    r = np.divide(cv, np.sqrt(np.maximum(vx * vy, 0)), out=np.full(len(n), np.nan), where=(n >= 12) & (vx > 1e-24) & (vy > 1e-24))
    return (n, np.clip(r, -1, 1))

def getcomp(raw, logq, cl, sd, r, dist, months, sourcecols):
    qualify = np.flatnonzero(np.isfinite(r) & (r > 0) & np.isfinite(sd))
    cnt = np.zeros(len(months), np.int16)
    den = np.zeros(len(months))
    nums = np.zeros((3, len(months)))
    if len(qualify):
        rr = rankdata(-r[qualify])
        dd = rankdata(dist[qualify])
        qq = qualify[np.lexsort((raw[qualify], rr, rr + dd))]
        for j in qq:
            cc = cl[j, months % 12]
            ddv = logq[j, sourcecols] - cc
            zz = ddv / sd[j]
            take = np.isfinite(zz) & (cnt < 4)
            if take.any():
                w = r[j]
                cnt[take] += 1
                den[take] += w
                nums[:, take] += w * np.stack([zz[take], cc[take], ddv[take]])
            if (cnt >= 4).all():
                break
    return (np.divide(nums, den, out=np.full_like(nums, np.nan), where=den > 0), cnt, len(qualify))

def predict(comp, count, tx, tcl, tsd, tz, h, gap, base, domain):
    nh = len(h)
    gp = np.arange(nh, nh + len(gap))
    out = np.tile(base, (3, 1))
    sup = np.zeros((3, len(gap)), bool)
    co = np.full((3, 3), np.nan)
    fit = np.zeros(3, bool)
    caps = np.zeros(3, int)
    good = np.isfinite(comp[0, :nh]) & np.isfinite(tz)
    if domain and np.isfinite(tsd) and np.isfinite(tz).any():
        a, b = (float(np.nanmin(tz) - 3), float(np.nanmax(tz) + 3))
        for m in range(2):
            z = comp[0, gp].copy()
            if m == 1:
                if good.sum() < 12:
                    continue
                xx = comp[0, :nh][good]
                yy = tz[good]
                xc = xx - xx.mean()
                v = xc @ xc
                if v <= 1e-24:
                    continue
                slope = xc @ (yy - yy.mean()) / v
                inter = yy.mean() - slope * xx.mean()
                co[m, :2] = [inter, slope]
                z = inter + slope * z
            use = np.isfinite(z) & np.isfinite(tcl[gap % 12])
            lp = np.clip(z, a, b) * tsd + tcl[gap % 12]
            caps[m] = np.sum(use & (lp > 50))
            out[m, use] = np.maximum(np.expm1(np.minimum(lp[use], 50)), 0)
            sup[m] = use
            fit[m] = True
        xx = np.column_stack([np.ones(nh), comp[1, :nh], comp[2, :nh]])
        ok = np.isfinite(xx).all(1) & np.isfinite(tx)
        if ok.sum() >= 12 and np.linalg.matrix_rank(xx[ok]) == 3:
            beta = np.linalg.lstsq(xx[ok], tx[ok], rcond=None)[0]
            xp = np.column_stack([np.ones(len(gap)), comp[1, gp], comp[2, gp]])
            use = np.isfinite(xp).all(1)
            lp = xp @ beta
            caps[2] = np.sum(use & (lp > 50))
            out[2, use] = np.maximum(np.expm1(np.minimum(lp[use], 50)), 0)
            sup[2] = use
            co[2] = beta
            fit[2] = True
    return (out, sup, fit, co, caps)

def work(item):
    e, kind = item
    raw = G['folds'][int(e['outer_fold'])]
    j = int(e['raw_index'])
    assert j not in raw
    assert (G['meta'].iloc[raw].outer_fold.to_numpy() != int(e['outer_fold'])).all()
    h = np.arange(int(e['history_start']), int(e['history_end']))
    gap = np.arange(int(e['gap_start']), int(e['gap_end']))
    allm = np.r_[h, gap]
    srcq = np.asarray(G['Q'][np.ix_(raw, allm)], float)
    srch = srcq[:, :60]
    slog, scl, ssd, sz = transform(srch, h)
    srcall = np.where(np.isfinite(srcq) & (srcq >= 0), np.log1p(np.maximum(srcq, 0)), np.nan)
    lat = np.deg2rad(G['meta'].iloc[raw].latitude.to_numpy(float))
    lon = np.deg2rad(G['meta'].iloc[raw].longitude.to_numpy(float))
    la, lo = np.deg2rad([float(e['latitude']), float(e['longitude'])])
    hh = np.sin((lat - la) / 2) ** 2 + np.cos(la) * np.cos(lat) * np.sin((lon - lo) / 2) ** 2
    dist = 12742 * np.arcsin(np.sqrt(np.clip(hh, 0, 1)))
    cons = conditions(kind)
    pred = np.empty((len(cons), 3, 120))
    support = np.zeros_like(pred, bool)
    refcount = np.zeros((len(cons), 120), np.int16)
    base = np.empty((len(cons), 120))
    meta = np.empty((len(cons), 10))
    coeff = np.full((len(cons), 3, 3), np.nan)
    guard = np.zeros((len(cons), 3), int)
    for a, c in enumerate(cons):
        hv = masked_h(h, c)
        pos = hv - h[0]
        target = np.asarray(G['Q'][j, hv], float)
        tx, tcl, tsd, tz, bs, domain = target_info(target, hv, gap)
        n, r = relation(sz[:, pos], tz)
        cc, ct, nq = getcomp(raw, srcall, scl, ssd, r, dist, np.r_[hv, gap], np.r_[pos, np.arange(60, 180)])
        pred[a], support[a], fits, coeff[a], guard[a] = predict(cc, ct, tx, tcl, tsd, tz, hv, gap, bs, domain)
        base[a] = bs
        refcount[a] = ct[-120:]
        meta[a] = [len(hv), np.isfinite(tcl).sum(), np.isfinite(tsd), domain, nq, *fits, np.sum(ct[-120:] > 0), np.sum(np.isfinite(tcl[gap % 12]))]
    return (int(e['row']), pred, support, refcount, base, meta, coeff, guard)

def register():
    HERE.mkdir(parents=True, exist_ok=True)
    for anchor in range(60, 313):
        h = np.arange(anchor - 60, anchor)
        for c in conditions('season'):
            hv = masked_h(h, c)
            assert len(hv) == 36 - 3 * c['k']
            assert len(np.unique(hv)) == len(hv) and set(hv).issubset(set(h))
    for nh in [6, 12]:
        _, _, sd, _ = transform(np.arange(nh, dtype=float)[None, :], np.arange(nh))
        assert np.isnan(sd[0])
    protocol = dict(scope='matched forward target-history and season-coverage stress; exploratory reused 8898 mothers', no_oracle=True, source_transform='all legal source records from original 60-month H only, float64 log1p calendar mean and population anomaly SD; source negative values excluded; SD<=1e-12 invalid', target_transform='visible target H only, repeated calendar evidence and SD>1e-12 required; nonnegative domain from visible H only', selector='global outer-fold-excluded sources; joint H>=12, positive anomaly Pearson r; average rank(-r)+rank(distance), tie rank(-r) then raw ID; monthly first 4 reporting sources, positive r weights', methods=METHODS, season_rule='H36: delete all 3 observations of k consecutive calendar months, rotate all12 starts; count-matched removes3k observations cyclically across calendar months, age=(rotation+cycle)%3; every calendar retains>=1. Same observation count. This control is deterministic and varies temporal placement as necessary.', guard='DAT/anomalyOLS composite z clipped visible target z min-3,max+3; all methods log cap50 and nonnegative inverse; no result-dependent repair; SeasonalOLS no target z clipping', support='reference-count support distinct from method-convertible support; target missing calendar prevents DAT/anomalyOLS that month only; SeasonalOLS can predict missing calendar if fit rank3 >=12 observations', hist_conditions=conditions('history'), season_conditions=conditions('season'), scoring='freeze each full experiment predictions before accessing target gap for scores; all120 main, season omitted and retained calendar subsets separately; station-equal weight and rotations aggregated before bootstrap; success NSE>=.5 and >own visible-H seasonal baseline and positive actual method support', boundary='H6/H12 have no repeated-calendar anomaly evidence; no forced reference relation. They are method-condition audits, not claims information absent.', bootstrap='2000 spatial-cell resamples; paired all-mother success, joint-evaluable other metrics; retain extremes')
    js(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/history_season/PROTOCOL.json', protocol)
    paths = [_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/history_season/run_history_season.py', _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/history_season/PROTOCOL.json', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/independent_target_cases.csv', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/all_station_roles.csv', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/predictions/source_cache/source_raw_indices.npy'] + [OLD / f'design/outer_{o}_source_mask.npy' for o in range(4)]
    js(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/history_season/CODE_FROZEN.json', dict(files={str(p): sha(p) for p in paths}, time=time.time(), target_gap_scored=False))
    print('REGISTERED', flush=True)

def produce(kind, workers=4):
    fr = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/history_season/CODE_FROZEN.json').read_text())
    assert all((sha(p) == v for p, v in fr['files'].items()))
    out = HERE / kind
    out.mkdir(exist_ok=True)
    cases = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/independent_target_cases.csv').sort_values('raw_index').reset_index(drop=True)
    assert len(cases) == 8898
    cases['row'] = np.arange(len(cases))
    cases.to_csv(out / 'cases.csv', index=False)
    pd.DataFrame(conditions(kind)).to_csv(out / 'conditions.csv', index=False)
    n = len(conditions(kind))
    shapes = {'predictions': ((8898, n, 3, 120), float), 'support': ((8898, n, 3, 120), bool), 'reference_count': ((8898, n, 120), np.int16), 'baseline': ((8898, n, 120), float), 'metadata': ((8898, n, 10), float), 'coefficients': ((8898, n, 3, 3), float), 'guards': ((8898, n, 3), np.int32)}
    files = {k: np.lib.format.open_memmap(out / (k + '.npy'), mode='r+' if (out / (k + '.npy')).exists() else 'w+', dtype=d, shape=s) for k, (s, d) in shapes.items()}
    done = np.load(out / 'done.npy') if (out / 'done.npy').exists() else np.zeros(8898, bool)
    todo = cases.loc[~done].to_dict('records')
    t = time.time()
    completed = int(done.sum())
    with ProcessPoolExecutor(max_workers=workers, initializer=init) as pool:
        for i, res in enumerate(pool.map(work, [(e, kind) for e in todo], chunksize=2), 1):
            row, *vals = res
            for k, v in zip(shapes, vals):
                files[k][row] = v
            done[row] = True
            if i % 100 == 0:
                for v in files.values():
                    v.flush()
                np.save(out / 'done.npy', done)
                print(kind, completed + i, '/8898 seconds', round(time.time() - t, 1), flush=True)
    for v in files.values():
        v.flush()
    np.save(out / 'done.npy', done)
    assert done.all()
    js(out / 'PREDICTIONS_FROZEN.json', dict(files={p.name: sha(p) for p in [out / (k + '.npy') for k in shapes] + [out / 'cases.csv', out / 'conditions.csv']}, time=time.time(), seconds=time.time() - t, code_freeze=sha(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/history_season/CODE_FROZEN.json'), target_gap_scored=False))
    print('ALL_PREDICTIONS_FROZEN', kind, flush=True)

def metrics(y, p, b, s):
    ym = y.mean(1)
    yc = y - ym[:, None]
    ss = np.sum(yc * yc, 1)
    ss[np.all(y == y[:, 0, None], axis=1)] = 0
    pm = p.mean(1)
    pc = p - pm[:, None]
    ps = np.sum(pc * pc, 1)
    ps[np.all(p == p[:, 0, None], axis=1)] = 0
    err = np.sum((p - y) ** 2, 1)
    bs = np.sum((b - y) ** 2, 1)
    nse = 1 - np.divide(err, ss, out=np.full(len(y), np.nan), where=ss > 0)
    bn = 1 - np.divide(bs, ss, out=np.full(len(y), np.nan), where=ss > 0)
    r = np.divide(np.sum(pc * yc, 1), np.sqrt(ps * ss), out=np.full(len(y), np.nan), where=(ps > 0) & (ss > 0))
    alpha = np.sqrt(np.divide(ps, ss, out=np.full(len(y), np.nan), where=ss > 0))
    delta = np.divide(pm - ym, np.sqrt(ss / y.shape[1]), out=np.full(len(y), np.nan), where=ss > 0)
    eligible = (s.sum(1) > 0) & np.isfinite(nse)
    return dict(NSE=nse, baseline_NSE=bn, S=1 - np.divide(err, bs, out=np.full(len(y), np.nan), where=bs > 0), r=np.clip(r, -1, 1), absolute_alpha_error=np.abs(alpha - 1), absolute_delta_error=np.abs(delta), eligible=eligible, success=eligible & (nse >= 0.5) & (nse > bn), support_months=s.sum(1))

def score(kind):
    out = HERE / kind
    fr = json.loads((out / 'PREDICTIONS_FROZEN.json').read_text())
    assert all((sha(out / p) == v for p, v in fr['files'].items()))
    if (out / 'scores.csv.gz').exists():
        raise RuntimeError('Existing score output: refuse duplicate append. Preserve it and explicitly choose a new scoring directory if a repair is required.')
    cases = pd.read_csv(out / 'cases.csv')
    cons = conditions(kind)
    p = np.load(out / 'predictions.npy', mmap_mode='r')
    s = np.load(out / 'support.npy', mmap_mode='r')
    b = np.load(out / 'baseline.npy', mmap_mode='r')
    met = np.load(out / 'metadata.npy')
    rc = np.load(out / 'reference_count.npy')
    guards = np.load(out / 'guards.npy')
    Q = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', mmap_mode='r')
    y = np.stack([Q[int(e.raw_index), int(e.gap_start):int(e.gap_end)] for e in cases.itertuples()])
    cal = np.stack([np.arange(int(e.gap_start), int(e.gap_end)) % 12 for e in cases.itertuples()])
    frames = []
    summary = []
    for a, c in enumerate(cons):
        slices = ['all'] if kind == 'history' else ['all', 'omitted_calendars', 'retained_calendars']
        for part in slices:
            use = np.ones_like(y, bool) if part == 'all' else np.isin(cal, (c['rotation'] + np.arange(c['k'])) % 12)
            if part == 'retained_calendars':
                use = ~use
            yy = y[use].reshape(8898, -1)
            bb = b[:, a][use].reshape(8898, -1)
            for m, method in enumerate(METHODS):
                vals = metrics(yy, np.asarray(p[:, a, m])[use].reshape(8898, -1), np.asarray(bb), np.asarray(s[:, a, m])[use].reshape(8898, -1))
                f = cases[['raw_index', 'station_id', 'spatial_cell', 'outer_fold', 'continent']].copy()
                for k, v in c.items():
                    f[k] = v
                f['method'] = method
                f['part'] = part
                for k, v in vals.items():
                    f[k] = v
                f['reference_supported_months'] = (rc[:, a][use].reshape(8898, -1) > 0).sum(1)
                f['qualified_sources'] = met[:, a, 4]
                f['missing_target_calendars'] = 12 - met[:, a, 1]
                f['log_cap_months'] = guards[:, a, m]
                frames.append(f)
                valid = f.eligible
                summary.append(dict(**c, method=method, part=part, all_mothers=8898, evaluable=int(valid.sum()), success=int(f.success.sum()), success_pct=100 * f.success.mean(), pure_NSE05_count=int((valid & (f.NSE >= 0.5)).sum()), median_baseline_NSE=f.baseline_NSE.median(), reference_supported_months=int(f.reference_supported_months.sum()), method_supported_months=int(f.support_months.sum()), median_NSE=f.loc[valid, 'NSE'].median(), mean_NSE=f.loc[valid, 'NSE'].mean(), median_S=f.loc[valid, 'S'].median(), mean_r=f.loc[valid, 'r'].mean(), median_abs_alpha=f.loc[valid, 'absolute_alpha_error'].median(), median_abs_delta=f.loc[valid, 'absolute_delta_error'].median(), log_cap_months=int(f.log_cap_months.sum())))
        if len(frames) >= 36:
            mode = 'a' if (out / 'scores.csv.gz').exists() else 'w'
            pd.concat(frames).to_csv(out / 'scores.csv.gz', index=False, mode=mode, header=mode == 'w', compression='gzip')
            frames = []
    if frames:
        mode = 'a' if (out / 'scores.csv.gz').exists() else 'w'
        pd.concat(frames).to_csv(out / 'scores.csv.gz', index=False, mode=mode, header=mode == 'w', compression='gzip')
    pd.DataFrame(summary).to_csv(out / 'summary.csv', index=False)
    js(out / 'SCORES_COMPLETE.json', dict(time=time.time(), predictions_freeze=sha(out / 'PREDICTIONS_FROZEN.json')))
    print(pd.DataFrame(summary).to_string(index=False), flush=True)

def bootstrap(kind):
    out = HERE / kind
    df = pd.read_csv(out / 'scores.csv.gz')
    cols = ['NSE', 'S', 'r', 'absolute_alpha_error', 'absolute_delta_error', 'success']
    for c in cols[:-1]:
        df.loc[~df.eligible, c] = np.nan
    keys = ['H', 'k', 'type', 'method', 'part', 'raw_index', 'spatial_cell']
    a = df.groupby(keys, dropna=False)[cols].mean().reset_index()
    a.to_csv(out / 'station_aggregated_scores.csv.gz', index=False)
    groups = {k: v.set_index(['raw_index', 'rotation'])[cols] for k, v in df.groupby(['H', 'k', 'type', 'method', 'part'])}
    cases = pd.read_csv(out / 'cases.csv').set_index('raw_index')
    _, cells = np.unique(cases.spatial_cell.astype(str), return_inverse=True)
    K = cells.max() + 1
    rng = np.random.default_rng(20261024)
    draw = rng.multinomial(K, np.ones(K) / K, size=2000).astype(float)
    rows = []
    pairs = []
    for key in groups:
        H, k, typ, method, part = key
        if method != 'DAT':
            pairs.append((key, (H, k, typ, 'DAT', part), 'same_input_method'))
        if kind == 'history' and H not in [6, 12, 60]:
            pairs.append((key, (60, 0, 'history', method, part), 'shorter_history'))
        if typ == 'season_deleted':
            pairs.append((key, (H, k, 'count_matched', method, part), 'season_coverage_loss'))
    for ka, kb, label in pairs:
        aa = groups[ka]
        bb = groups[kb]
        for col in cols:
            sign = -1 if col.startswith('absolute') else 1
            delta = sign * (aa[col].astype(float) - bb[col].astype(float)).groupby('raw_index').mean().reindex(cases.index).to_numpy()
            ok = np.isfinite(delta)
            num = np.bincount(cells[ok], weights=delta[ok], minlength=K)
            den = np.bincount(cells[ok], minlength=K)
            denb = draw @ den
            boot = np.divide(draw @ num, denb, out=np.full(2000, np.nan), where=denb > 0)
            factor = 100 if col == 'success' else 1
            rows.append(dict(arm=str(ka), reference=str(kb), comparison=label, metric=col, n=int(ok.sum()), mean_gain=factor * np.nanmean(delta), median_gain=factor * np.nanmedian(delta), ci025=factor * np.nanquantile(boot, 0.025), ci975=factor * np.nanquantile(boot, 0.975), positive_fraction=np.mean(delta[ok] > 0), negative_fraction=np.mean(delta[ok] < 0)))
    pd.DataFrame(rows).to_csv(out / 'paired_bootstrap.csv', index=False)
    print('BOOTSTRAP_COMPLETE', kind, flush=True)
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('step', choices=['register', 'produce', 'score', 'bootstrap', 'timing'])
    ap.add_argument('--kind', default='history', choices=['history', 'season'])
    ap.add_argument('--workers', type=int, default=4)
    args = ap.parse_args()
    if args.step == 'register':
        register()
    elif args.step == 'produce':
        produce(args.kind, args.workers)
    elif args.step == 'score':
        score(args.kind)
    elif args.step == 'bootstrap':
        bootstrap(args.kind)
    else:
        init()
        case = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/independent_target_cases.csv').iloc[0].to_dict()
        case['row'] = 0
        t = time.time()
        res = work((case, args.kind))
        print('TIMING', args.kind, time.time() - t, res[1].shape, flush=True)
