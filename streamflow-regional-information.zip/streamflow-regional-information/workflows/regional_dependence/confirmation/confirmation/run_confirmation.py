from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, time, argparse, hashlib
from concurrent.futures import ProcessPoolExecutor
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
sys.dont_write_bytecode = True
HERE = _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation'
CODE = _PROJECT_ROOT
BASE = _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/history_season'
pass
import workflows.regional_dependence.conditional_support.history_season.run_history_season as S
np, pd = (S.np, S.pd)
METHODS = ['DAT', 'AnomalyOLS', 'SeasonalOLS', 'SeasonalRidge']
RIDGE = 0.1

def conditions():
    return [dict(label='H036_complete', H=36, k=0, rotation=-1, type='complete')] + [dict(label=f'{typ}_K{k}_R{r:02}', H=36, k=k, rotation=r, type=typ) for k in [3, 6] for r in range(12) for typ in ['season_deleted', 'count_matched']]

def getcomp(raw, logq, cl, sd, r, dist, months, cols):
    qualify = np.flatnonzero(np.isfinite(r) & (r > 0) & np.isfinite(sd))
    cnt = np.zeros(len(months), np.int16)
    den = np.zeros(len(months))
    num = np.zeros((3, len(months)))
    ids = np.full((len(months), 4), -1, np.int32)
    if len(qualify):
        rr = S.rankdata(-r[qualify])
        dd = S.rankdata(dist[qualify])
        order = qualify[np.lexsort((raw[qualify], rr, rr + dd))]
        for j in order:
            cc = cl[j, months % 12]
            dev = logq[j, cols] - cc
            z = dev / sd[j]
            take = np.isfinite(z) & (cnt < 4)
            if take.any():
                ii = np.flatnonzero(take)
                ids[ii, cnt[ii]] = raw[j]
                w = r[j]
                cnt[take] += 1
                den[take] += w
                num[:, take] += w * np.stack([z[take], cc[take], dev[take]])
            if (cnt >= 4).all():
                break
    return (np.divide(num, den, out=np.full_like(num, np.nan), where=den > 0), cnt, len(qualify), ids)

def predict(comp, count, tx, tcl, tsd, tz, h, gap, base, domain):
    old = S.predict(comp, count, tx, tcl, tsd, tz, h, gap, base, domain)
    pp, sup, fit, co, caps = old
    out = np.vstack([pp, base[None, :]])
    support = np.vstack([sup, np.zeros((1, len(gap)), bool)])
    fits = np.r_[fit, False]
    coeff = np.vstack([co, np.full((1, 3), np.nan)])
    guards = np.r_[caps, 0]
    nh = len(h)
    gp = np.arange(nh, nh + len(gap))
    X = comp[1:3, :nh].T
    ok = np.isfinite(X).all(1) & np.isfinite(tx)
    diag = np.full(7, np.nan)
    if fit[2] and ok.sum() >= 12:
        xx = X[ok]
        y = tx[ok]
        mu = xx.mean(0)
        sd = xx.std(0)
        diag[:5] = [ok.sum(), *mu, *sd]
        if np.all(sd > 1e-12):
            z = (xx - mu) / sd
            yc = y - y.mean()
            mat = z.T @ z / len(y) + RIDGE * np.eye(2)
            beta = np.linalg.solve(mat, z.T @ yc / len(y))
            rawbeta = beta / sd
            inter = y.mean() - mu @ rawbeta
            coeff[3] = np.r_[inter, rawbeta]
            xp = comp[1:3, gp].T
            use = np.isfinite(xp).all(1)
            lp = inter + xp @ rawbeta
            guards[3] = np.sum(use & (lp > 50))
            out[3, use] = np.maximum(np.expm1(np.minimum(lp[use], 50)), 0)
            support[3] = use
            fits[3] = True
            diag[5:] = [np.linalg.cond(mat), np.linalg.norm(beta)]
    return (out, support, fits, coeff, guards, diag)

def work(e):
    G = S.G
    raw = G['folds'][int(e['outer_fold'])]
    j = int(e['raw_index'])
    assert j not in raw
    assert (G['meta'].iloc[raw].outer_fold.to_numpy() != int(e['outer_fold'])).all()
    h = np.arange(int(e['source_history_start']), int(e['gap_start']))
    gap = np.arange(int(e['gap_start']), int(e['gap_end']))
    assert len(h) == 60 and len(gap) == 120
    allm = np.r_[h, gap]
    srcq = np.asarray(G['Q'][np.ix_(raw, allm)], float)
    _, scl, ssd, sz = S.transform(srcq[:, :60], h)
    srcall = np.where(np.isfinite(srcq) & (srcq >= 0), np.log1p(np.maximum(srcq, 0)), np.nan)
    lat = np.deg2rad(G['meta'].iloc[raw].latitude.to_numpy(float))
    lon = np.deg2rad(G['meta'].iloc[raw].longitude.to_numpy(float))
    la, lo = np.deg2rad([float(e['latitude']), float(e['longitude'])])
    hav = np.sin((lat - la) / 2) ** 2 + np.cos(la) * np.cos(lat) * np.sin((lon - lo) / 2) ** 2
    dist = 12742 * np.arcsin(np.sqrt(np.clip(hav, 0, 1)))
    cons = conditions()
    prepared = []
    Y = np.zeros((len(cons), 60))
    M = np.zeros_like(Y)
    for a, c in enumerate(cons):
        hv = S.masked_h(h, c)
        pos = hv - h[0]
        target = np.asarray(G['Q'][j, hv], float)
        tx, tcl, tsd, tz, bs, domain = S.target_info(target, hv, gap)
        prepared.append((hv, pos, tx, tcl, tsd, tz, bs, domain))
        valid = np.isfinite(tz)
        Y[a, pos[valid]] = tz[valid]
        M[a, pos[valid]] = 1.0
    V = np.isfinite(sz).astype(float)
    Z = np.where(np.isfinite(sz), sz, 0.0)
    n = V @ M.T
    nn = np.maximum(n, 1)
    sx = Z @ M.T
    sy = V @ Y.T
    vx = Z * Z @ M.T - sx * sx / nn
    vy = V @ (Y * Y).T - sy * sy / nn
    cv = Z @ Y.T - sx * sy / nn
    r = np.divide(cv, np.sqrt(np.maximum(vx * vy, 0)), out=np.full_like(n, np.nan), where=(n >= 12) & (vx > 1e-24) & (vy > 1e-24))
    r = np.clip(r, -1, 1)
    nc = len(cons)
    pred = np.empty((nc, 4, 120))
    support = np.zeros_like(pred, bool)
    refcount = np.zeros((nc, 120), np.int16)
    baseline = np.empty((nc, 120))
    metadata = np.empty((nc, 11))
    coef = np.full((nc, 4, 3), np.nan)
    guards = np.zeros((nc, 4), np.int32)
    comps = np.full((nc, 3, 156), np.nan)
    sourceids = np.full((nc, 156, 4), -1, np.int32)
    visible = np.zeros((nc, 36), bool)
    ridge_diag = np.full((nc, 7), np.nan)
    for a, (hv, pos, tx, tcl, tsd, tz, bs, domain) in enumerate(prepared):
        rr = r[:, a]
        finite = np.flatnonzero(np.isfinite(rr))
        order = finite[np.argsort(rr[finite])]
        tied = np.flatnonzero(np.diff(rr[order]) < 1e-10)
        boundary = np.zeros(len(raw), bool)
        boundary[order[tied]] = True
        boundary[order[tied + 1]] = True
        boundary |= (n[:, a] >= 12) & ((vx[:, a] < 1e-10) | (vy[:, a] < 1e-10) | (np.abs(rr) < 1e-10) | (np.abs(rr) > 1 - 1e-10))
        recalc = np.flatnonzero(boundary)
        if len(recalc):
            _, rr[recalc] = S.relation(np.asfortranarray(sz[np.ix_(recalc, pos)]), tz)
        cc, ct, nq, ids = getcomp(raw, srcall, scl, ssd, rr, dist, np.r_[hv, gap], np.r_[pos, np.arange(60, 180)])
        pred[a], support[a], fits, coef[a], guards[a], ridge_diag[a] = predict(cc, ct, tx, tcl, tsd, tz, hv, gap, bs, domain)
        baseline[a] = bs
        refcount[a] = ct[-120:]
        metadata[a] = [len(hv), np.isfinite(tcl).sum(), np.isfinite(tsd), domain, nq, *fits, np.sum(ct[-120:] > 0), np.sum(np.isfinite(tcl[gap % 12]))]
        slots = np.r_[hv - (gap[0] - 36), np.arange(36, 156)]
        comps[a, :, slots] = cc.T
        sourceids[a, slots] = ids
        visible[a, hv - (gap[0] - 36)] = True
    return (int(e['row']), pred, support, refcount, baseline, metadata, coef, guards, comps, sourceids, visible, ridge_diag)

def register():
    ledger = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/mask_only_candidate_ledger.csv')
    rows = ledger[~ledger.duplicate & ledger.new_anchor.ge(0)].sort_values('raw_index').copy()
    assert len(rows) == 5811
    roles = pd.read_csv(S.OLD / 'design/all_station_roles.csv')
    cases = roles.iloc[rows.raw_index].reset_index(drop=True).copy()
    cases['raw_index'] = rows.raw_index.to_numpy()
    cases['row'] = np.arange(len(cases))
    cases['gap_start'] = rows.new_anchor.to_numpy()
    cases['gap_end'] = cases.gap_start + 120
    cases['history_start'] = cases.gap_start - 36
    cases['history_end'] = cases.gap_start
    cases['source_history_start'] = cases.gap_start - 60
    cases['old_target'] = rows.old_target.to_numpy()
    cases['old_gap_start'] = rows.old_gap_start.to_numpy()
    cases['old_gap_end'] = rows.old_gap_end.to_numpy()
    cases['cohort'] = np.where(cases.old_target, 'same_station_new_period', 'new_H36_qualified')
    cases['H'] = 36
    cases['L'] = 120
    cases['task'] = 'forward'
    cases['old_G_overlap_H_months'] = np.maximum(0, np.minimum(cases.history_end, cases.old_gap_end) - np.maximum(cases.history_start, cases.old_gap_start))
    cases.to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/cases.csv', index=False)
    pd.DataFrame(conditions()).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/conditions.csv', index=False)
    proto = dict(date='2026-10-24', purpose='Confirm seasonal information transfer and stability on all globally qualified nonoverlapping forward periods', mothers=5811, cohorts=cases.cohort.value_counts().to_dict(), target_H=36, source_H=60, G=120, conditions=conditions(), methods=METHODS, case_rule='QC20 finite mask only; latest H36+G120 complete anchor with source H60 calendar space available; exclude known twins; old targets require G disjoint from old same-target G. New H may overlap old G, explicitly recorded. No assertion that data were never encountered in long project.', source_rule='Inherited legal source IDs and outer-fold exclusion; source log1p calendar mean/anomaly SD from source H60 only; joint target-visible H >=12 and positive anomaly correlation; monthly max4 via rank-correlation plus rank-distance, positive r weights', ridge='Only added arm: visible-H predictor centering and population-SD scaling; unpenalized intercept; objective mean squared target log1p residual + 0.1*(beta_season^2+beta_anomaly^2). Fixed lambda=.1, no CV, not optimal, no guaranteed extrapolation safety. Same >=12 and rank3 admissibility as SeasonalOLS, additionally predictor SD>1e-12.', guards='Inherited DAT/AnomalyOLS target z min-3/max+3 guard; SeasonalOLS and SeasonalRidge both only common log50 and inverse nonnegative guard. All cap counts preserved. No outcome-based trimming.', score='All120 primary; omitted and retained calendar periods secondary; corrected truth finite/nonnegative/nonconstant scoring; all5811 denominator for success; eligibility and valid rotation denominators for continuous metrics; all negative tails retained.', main_gate='For BOTH K3 and K6 deleted-calendar scenarios, SeasonalRidge vs AnomalyOLS success gain >=5 percentage points and paired spatial95% CI lower>0. Additionally inspect mean and median component errors/NSE, extreme-tail rates (<-100/<-1e6) and cap counts; success alone cannot establish universal stable method.', inference='Within matched rotation differences -> station average -> equal-station paired bootstrap of spatial cells 2000 resamples, seed; completeH36 and countmatched controls mandatory; same_station_new_period and new_H36_qualified reported separately', no_oracle=True, no_external_inputs=True, no_figures_manuscript_cloud=True)
    S.js(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/PROTOCOL.json', proto)
    paths = [_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/run_confirmation.py', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/preflight.py', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/PREFLIGHT.json', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/mask_only_candidate_ledger.csv', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/cases.csv', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/conditions.csv', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/PROTOCOL.json', _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/history_season/run_history_season.py', S.OLD / 'global_data/QC20_Q.npy', S.OLD / 'global_data/QC20_finite_mask.npy', S.OLD / 'design/all_station_roles.csv', S.OLD / 'design/independent_target_cases.csv', S.OLD / 'predictions/source_cache/source_raw_indices.npy'] + [S.OLD / f'design/outer_{i}_source_mask.npy' for i in range(4)]
    S.js(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/CODE_DESIGN_FROZEN.json', dict(files={str(p): S.sha(p) for p in paths}, time=time.time(), target_G_scored=False))
    print('REGISTERED', len(cases), flush=True)
SHAPES = {'predictions': (lambda n: (n, 49, 4, 120), np.float64), 'support': (lambda n: (n, 49, 4, 120), bool), 'reference_count': (lambda n: (n, 49, 120), np.int16), 'baseline': (lambda n: (n, 49, 120), np.float64), 'metadata': (lambda n: (n, 49, 11), np.float64), 'coefficients': (lambda n: (n, 49, 4, 3), np.float64), 'guards': (lambda n: (n, 49, 4), np.int32), 'composites': (lambda n: (n, 49, 3, 156), np.float64), 'source_ids': (lambda n: (n, 49, 156, 4), np.int32), 'visible_history': (lambda n: (n, 49, 36), bool), 'ridge_diagnostics': (lambda n: (n, 49, 7), np.float64)}

def smoke():
    S.init()
    cases = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/cases.csv')
    out = _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/preproduction'
    out.mkdir(exist_ok=True)
    t = time.time()
    for e in cases.iloc[:20].to_dict('records'):
        res = work(e)
        np.savez_compressed(out / f'row{res[0]:05d}.npz', **dict(zip(SHAPES, res[1:])))
        print('INPUT_ONLY_CHECK', res[0] + 1, 'seconds', round(time.time() - t, 1), flush=True)
    S.js(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/preproduction/COMPLETE.json', dict(n=20, seconds=time.time() - t, target_G_scored=False, cases='first20 raw-index order, no outcome sampling'))

def produce(workers):
    fr = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/CODE_DESIGN_FROZEN.json').read_text())
    assert all((S.sha(p) == v for p, v in fr['files'].items()))
    assert (_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/audit/PREPRODUCTION_APPROVED.json').exists(), 'independent input/code audit required'
    cases = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/cases.csv')
    N = len(cases)
    out = _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production'
    out.mkdir(exist_ok=True)
    arrays = {k: np.lib.format.open_memmap(out / (k + '.npy'), mode='r+' if (out / (k + '.npy')).exists() else 'w+', dtype=d, shape=f(N)) for k, (f, d) in SHAPES.items()}
    done = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/done.npy') if (_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/done.npy').exists() else np.zeros(N, bool)
    todo = cases.loc[~done].to_dict('records')
    st = time.time()
    completed = int(done.sum())
    with ProcessPoolExecutor(max_workers=workers, initializer=S.init) as pool:
        for i, res in enumerate(pool.map(work, todo, chunksize=2), 1):
            row, *vals = res
            for k, v in zip(SHAPES, vals):
                arrays[k][row] = v
            done[row] = True
            if i % 100 == 0:
                for v in arrays.values():
                    v.flush()
                np.save(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/done.npy', done)
                print('PRODUCTION', completed + i, '/', N, 'seconds', round(time.time() - st, 1), flush=True)
    for v in arrays.values():
        v.flush()
    np.save(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/done.npy', done)
    assert done.all()
    S.js(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/PREDICTIONS_FROZEN.json', dict(files={p.name: S.sha(p) for p in [out / (k + '.npy') for k in SHAPES] + [_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/done.npy']}, seconds=time.time() - st, code_design_freeze=S.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/CODE_DESIGN_FROZEN.json'), target_G_scored=False))
    print('ALL_PREDICTIONS_FROZEN', flush=True)
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('step', choices=['register', 'smoke', 'produce'])
    ap.add_argument('--workers', type=int, default=12)
    a = ap.parse_args()
    if a.step == 'register':
        register()
    elif a.step == 'smoke':
        smoke()
    else:
        produce(a.workers)
