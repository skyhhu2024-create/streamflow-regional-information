from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import sys, time, json, argparse, ast
HERE = _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation'
pass
import workflows.regional_dependence.confirmation.confirmation.run_confirmation as C
S, np, pd = (C.S, C.np, C.pd)
OUT = _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production'
METRICS = ['NSE', 'S', 'r', 'absolute_alpha_error', 'absolute_delta_error', 'success']

def metrics(y, p, b, s):
    d = S.metrics(y, p, b, s)
    sy = y.std(1)
    sp = p.std(1)
    sy[np.all(y == y[:, 0, None], 1)] = 0
    sp[np.all(p == p[:, 0, None], 1)] = 0
    d['alpha'] = np.divide(sp, sy, out=np.full(len(y), np.nan), where=sy > 0)
    d['delta'] = np.divide(p.mean(1) - y.mean(1), sy, out=np.full(len(y), np.nan), where=sy > 0)
    valid = np.isfinite(y).all(1) & (y >= 0).all(1) & ~np.all(y == y[:, 0, None], 1)
    d['eligible'] &= valid & np.isfinite(p).all(1)
    d['success'] &= d['eligible']
    d['valid_truth'] = valid
    return d

def freeze():
    S.js(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/SCORING_CODE_FROZEN.json', dict(files={str(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/score_confirmation.py'): S.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/score_confirmation.py'), str(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/CONFIRMATION_DECISION_RULES.md'): S.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/CONFIRMATION_DECISION_RULES.md')}, time=time.time(), target_G_scored=False))
    print('SCORING_AND_DECISION_RULES_FROZEN', flush=True)

def score():
    reg = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/SCORING_CODE_FROZEN.json').read_text())
    assert all((S.sha(p) == v for p, v in reg['files'].items()))
    predfr = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/PREDICTIONS_FROZEN.json').read_text())
    assert all((S.sha(OUT / p) == v for p, v in predfr['files'].items()))
    assert not (_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/scores.csv.gz').exists(), 'no append or overwrite of prior scores'
    cases = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/cases.csv')
    N = len(cases)
    cons = C.conditions()
    P = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/predictions.npy', mmap_mode='r')
    sup = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/support.npy', mmap_mode='r')
    B = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/baseline.npy', mmap_mode='r')
    rc = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/reference_count.npy', mmap_mode='r')
    met = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/metadata.npy', mmap_mode='r')
    guards = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/guards.npy', mmap_mode='r')
    Q = np.load(S.OLD / 'global_data/QC20_Q.npy', mmap_mode='r')
    y = np.stack([Q[int(e.raw_index), int(e.gap_start):int(e.gap_end)] for e in cases.itertuples()])
    cal = np.stack([np.arange(int(e.gap_start), int(e.gap_end)) % 12 for e in cases.itertuples()])
    summ = []
    st = time.time()
    for a, c in enumerate(cons):
        parts = ['all'] if c['k'] == 0 else ['all', 'omitted_calendars', 'retained_calendars']
        frames = []
        for part in parts:
            use = np.ones_like(y, bool) if part == 'all' else np.isin(cal, (c['rotation'] + np.arange(c['k'])) % 12)
            if part == 'retained_calendars':
                use = ~use
            yy = y[use].reshape(N, -1)
            bb = np.asarray(B[:, a])[use].reshape(N, -1)
            for m, method in enumerate(C.METHODS):
                vals = metrics(yy, np.asarray(P[:, a, m])[use].reshape(N, -1), bb, np.asarray(sup[:, a, m])[use].reshape(N, -1))
                f = cases[['raw_index', 'station_id', 'spatial_cell', 'outer_fold', 'continent', 'cohort']].copy()
                for k, v in c.items():
                    f[k] = v
                f['method'] = method
                f['part'] = part
                for k, v in vals.items():
                    f[k] = v
                f['reference_supported_months'] = (np.asarray(rc[:, a])[use].reshape(N, -1) > 0).sum(1)
                f['qualified_sources'] = met[:, a, 4]
                f['missing_target_calendars'] = 12 - met[:, a, 1]
                f['log_cap_full120_months'] = guards[:, a, m]
                frames.append(f)
                for cohort in ['all_mothers', 'same_station_new_period', 'new_H36_qualified']:
                    group = f if cohort == 'all_mothers' else f[f.cohort.eq(cohort)]
                    e = group[group.eligible]
                    summ.append(dict(**c, method=method, part=part, cohort=cohort, mothers=len(group), evaluable=len(e), success=int(group.success.sum()), success_pct=100 * group.success.mean(), pure_NSE05_count=int((group.eligible & group.NSE.ge(0.5)).sum()), reference_supported_months=int(group.reference_supported_months.sum()), method_supported_months=int(group.support_months.sum()), median_NSE=e.NSE.median(), mean_NSE=e.NSE.mean(), median_S=e.S.median(), mean_S=e.S.mean(), median_r=e.r.median(), mean_r=e.r.mean(), median_alpha=e.alpha.median(), mean_alpha=e.alpha.mean(), median_delta=e.delta.median(), mean_delta=e.delta.mean(), median_abs_alpha=e.absolute_alpha_error.median(), mean_abs_alpha=e.absolute_alpha_error.mean(), median_abs_delta=e.absolute_delta_error.median(), mean_abs_delta=e.absolute_delta_error.mean(), median_baseline_NSE=group.baseline_NSE.median(), NSE_below_minus100=int(e.NSE.lt(-100).sum()), NSE_below_minus1e6=int(e.NSE.lt(-1000000.0).sum()), log_cap_cases=int(group.log_cap_full120_months.gt(0).sum()), log_cap_full120_months=int(group.log_cap_full120_months.sum())))
        mode = 'w' if a == 0 else 'a'
        pd.concat(frames, ignore_index=True).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/scores.csv.gz', index=False, mode=mode, header=a == 0, compression='gzip')
        if a % 6 == 0:
            print('SCORE', a + 1, '/', len(cons), 'seconds', round(time.time() - st, 1), flush=True)
    pd.DataFrame(summ).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/summary_by_rotation.csv', index=False)
    S.js(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/TRUTH_DOMAIN_AUDIT.json', dict(mothers=N, negative_cases=int((y < 0).any(1).sum()), constant_cases=int(np.all(y == y[:, 0, None], 1).sum()), nonfinite_cases=int((~np.isfinite(y)).any(1).sum())))
    S.js(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/SCORES_COMPLETE.json', dict(time=time.time(), seconds=time.time() - st, files={p.name: S.sha(p) for p in [_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/scores.csv.gz', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/summary_by_rotation.csv', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/TRUTH_DOMAIN_AUDIT.json']}, prediction_freeze=S.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/PREDICTIONS_FROZEN.json'), score_code_freeze=S.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/SCORING_CODE_FROZEN.json')))
    print('SCORES_COMPLETE', flush=True)

def bootstrap():
    st = time.time()
    df = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/scores.csv.gz')
    cases = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/cases.csv').set_index('raw_index')
    N = len(cases)
    for col in ['NSE', 'S', 'r', 'alpha', 'delta', 'absolute_alpha_error', 'absolute_delta_error']:
        df.loc[~df.eligible, col] = np.nan
    keys = ['k', 'type', 'method', 'part', 'raw_index', 'spatial_cell', 'cohort']
    metriccols = METRICS + ['alpha', 'delta', 'baseline_NSE', 'support_months', 'reference_supported_months']
    station = df.groupby(keys, dropna=False)[metriccols].mean().reset_index()
    station.to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/station_aggregated_scores.csv.gz', index=False)
    groups = {key: g.set_index(['raw_index', 'rotation'])[METRICS] for key, g in df.groupby(['k', 'type', 'method', 'part'])}
    pairs = []
    for key in groups:
        k, typ, method, part = key
        if method == 'SeasonalRidge':
            for ref in ['DAT', 'AnomalyOLS', 'SeasonalOLS']:
                pairs.append((key, (k, typ, ref, part), 'same_input_ridge'))
        if typ == 'season_deleted':
            pairs.append((key, (k, 'count_matched', method, part), 'season_coverage_loss'))
    _, cells = np.unique(cases.spatial_cell.astype(str), return_inverse=True)
    K = cells.max() + 1
    rng = np.random.default_rng(20261024)
    draw = rng.multinomial(K, np.ones(K) / K, size=2000).astype(float)
    rows = []
    for aa, bb, label in pairs:
        for col in METRICS:
            sign = -1 if col.startswith('absolute') else 1
            paired = sign * (groups[aa][col].astype(float) - groups[bb][col].astype(float))
            nrot = paired.notna().groupby('raw_index').sum().reindex(cases.index, fill_value=0)
            delta = paired.groupby('raw_index').mean().reindex(cases.index).to_numpy()
            for cohort in ['all_mothers', 'same_station_new_period', 'new_H36_qualified']:
                within = np.ones(N, bool) if cohort == 'all_mothers' else cases.cohort.eq(cohort).to_numpy()
                ok = within & np.isfinite(delta)
                num = np.bincount(cells[ok], weights=delta[ok], minlength=K)
                den = np.bincount(cells[ok], minlength=K)
                db = draw @ den
                boot = np.divide(draw @ num, db, out=np.full(2000, np.nan), where=db > 0)
                factor = 100 if col == 'success' else 1
                rr = nrot.to_numpy()[ok]
                rows.append(dict(arm=str(aa), reference=str(bb), comparison=label, metric=col, cohort=cohort, n=int(ok.sum()), mean_gain=factor * np.nanmean(delta[ok]), median_gain=factor * np.nanmedian(delta[ok]), ci025=factor * np.nanquantile(boot, 0.025), ci975=factor * np.nanquantile(boot, 0.975), positive_fraction=float(np.mean(delta[ok] > 0)), negative_fraction=float(np.mean(delta[ok] < 0)), paired_rotation_min=int(rr.min()) if len(rr) else 0, paired_rotation_median=float(np.median(rr)) if len(rr) else np.nan, paired_rotation_max=int(rr.max()) if len(rr) else 0, stations_all_rotations=int((rr == (1 if aa[0] == 0 else 12)).sum())))
    pd.DataFrame(rows).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/paired_bootstrap.csv', index=False)
    summary = []
    for key, g in station.groupby(['k', 'type', 'method', 'part']):
        for cohort in ['all_mothers', 'same_station_new_period', 'new_H36_qualified']:
            v = g if cohort == 'all_mothers' else g[g.cohort.eq(cohort)]
            d = dict(zip(['k', 'type', 'method', 'part'], key))
            d.update(cohort=cohort, mothers=len(v), success_pct=100 * v.success.mean())
            for col in metriccols:
                if col == 'success':
                    continue
                d['median_station_mean_' + col] = v[col].median()
                d['mean_station_mean_' + col] = v[col].mean()
            summary.append(d)
    pd.DataFrame(summary).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/station_summary.csv', index=False)
    tail = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/summary_by_rotation.csv')
    tail = tail[tail.part.eq('all')]
    tail = tail.groupby(['k', 'type', 'method', 'cohort'], as_index=False)[['mothers', 'evaluable', 'NSE_below_minus100', 'NSE_below_minus1e6', 'log_cap_cases', 'log_cap_full120_months']].sum()
    tail = tail.rename(columns={'mothers': 'station_rotation_cases'})
    tail['below_minus100_pct'] = 100 * tail.NSE_below_minus100 / tail.station_rotation_cases
    tail['below_minus1e6_pct'] = 100 * tail.NSE_below_minus1e6 / tail.station_rotation_cases
    tail.to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/tail_audit.csv', index=False)
    pairs = pd.DataFrame(rows)
    gate = []
    for k in [3, 6]:
        r = pairs[pairs.arm.eq(str((k, 'season_deleted', 'SeasonalRidge', 'all'))) & pairs.reference.eq(str((k, 'season_deleted', 'AnomalyOLS', 'all'))) & pairs.metric.eq('success') & pairs.cohort.eq('all_mothers')].iloc[0]
        gate.append(dict(k=k, success_gain_pp=float(r.mean_gain), ci025=float(r.ci025), ci975=float(r.ci975), passes_predefined_effect_gate=bool(r.mean_gain >= 5 and r.ci025 > 0)))
    S.js(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/DECISION_GATE.json', dict(comparisons=gate, both_pass=all((x['passes_predefined_effect_gate'] for x in gate)), stability='Separate tail and continuous-error assessment required; passing success criterion alone is not universal algorithm endorsement', no_adaptive_models=True))
    S.js(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/INFERENCE_COMPLETE.json', dict(seconds=time.time() - st, station_equal_rotation_first=True, bootstrap=2000, files={p.name: S.sha(p) for p in [_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/paired_bootstrap.csv', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/station_summary.csv', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/station_aggregated_scores.csv.gz', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/tail_audit.csv', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/confirmation/production/DECISION_GATE.json']}))
    print('INFERENCE_COMPLETE', time.time() - st, flush=True)
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('step', choices=['freeze', 'score', 'bootstrap'])
    a = ap.parse_args()
    if a.step == 'freeze':
        freeze()
    elif a.step == 'score':
        score()
    else:
        bootstrap()
