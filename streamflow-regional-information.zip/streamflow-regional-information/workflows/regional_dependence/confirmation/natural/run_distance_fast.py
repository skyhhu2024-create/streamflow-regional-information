from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, importlib.util, json, time, argparse
from concurrent.futures import ProcessPoolExecutor
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[k] = '1'
HERE = _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural'
spec = importlib.util.spec_from_file_location('natural_distance_v1', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/run_distance_audit.py')
B = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = B
spec.loader.exec_module(B)
np, pd = (B.np, B.pd)
G = B.G

def work_fast(e):
    row = int(e['output_row'])
    j = int(e['raw_index'])
    end = int(e['history_end_exclusive'])
    gap = np.arange(end, 432)
    L = len(gap)
    h, scl, ssd, sz = B.source_h(end)
    tq = np.asarray(G['raw'][j, h], float)
    tx = np.where(np.isfinite(tq) & (tq >= 0), np.log1p(np.maximum(tq, 0)), np.nan)
    tcl, tsd, tz = B.transform_log(tx[None, :], h)
    tz = tz[0]
    state = np.ones(L, np.uint8)
    fields = np.full((4, L), np.nan, np.float32)
    counts = np.zeros((3, L), np.int32)
    nearest_ids = np.full((2, L), -1, np.int32)
    sid = np.full((L, 4), -1, np.int32)
    sr = np.full((L, 4), np.nan, np.float32)
    meta = {'output_row': row, 'station_id': e['station_id'], 'raw_index': j, 'history_end_exclusive': end, 'history_span_months': len(h), 'history_valid_nonnegative': int(np.isfinite(tx).sum()), 'history_missing_calendar': int((~np.isfinite(tcl[0])).sum()), 'history_repeated_calendars': int(sum((np.isfinite(tx[h % 12 == m]).sum() >= 2 for m in range(12)))), 'target_anomaly_estimable': bool(np.isfinite(tsd[0])), 'joint_ge12': 0, 'qualified_sources': 0, 'relation_reason': 'target_history_not_estimable', 'target_twin_listed': bool(G['meta'].twin_listed.iloc[j])}
    if not np.isfinite(tsd[0]):
        return (row, end, state, fields, counts, nearest_ids, sid, sr, meta)
    ok = np.isfinite(sz) & np.isfinite(tz)[None, :]
    n = ok.sum(1)
    nn = np.maximum(n, 1)
    xx = np.where(ok, sz, 0)
    yy = np.where(ok, tz, 0)
    sx = xx.sum(1)
    sy = yy.sum(1)
    vx = (xx * xx).sum(1) - sx * sx / nn
    vy = (yy * yy).sum(1) - sy * sy / nn
    cv = (xx * yy).sum(1) - sx * sy / nn
    r = np.divide(cv, np.sqrt(np.maximum(vx * vy, 0)), out=np.full(len(n), np.nan), where=(n >= 12) & (vx > 1e-24) & (vy > 1e-24))
    r = np.clip(r, -1, 1)
    r[G['workflows/shared'] == j] = np.nan
    meta['joint_ge12'] = int(((n >= 12) & (G['workflows/shared'] != j)).sum())
    qual = np.flatnonzero(np.isfinite(r) & (r > 0) & np.isfinite(ssd))
    meta['qualified_sources'] = len(qual)
    meta['relation_reason'] = 'qualified_relation' if len(qual) else 'no_positive_qualified_relation'
    if not len(qual):
        return (row, end, state, fields, counts, nearest_ids, sid, sr, meta)
    src = G['workflows/shared'][qual]
    rr = r[qual]
    la = G['lat'][j]
    lo = G['lon'][j]
    hh = np.sin((G['lat'][src] - la) / 2) ** 2 + np.cos(la) * np.cos(G['lat'][src]) * np.sin((G['lon'][src] - lo) / 2) ** 2
    dd = 12742 * np.arcsin(np.sqrt(np.clip(hh, 0, 1)))
    rawreport = np.isfinite(G['source_log'][np.ix_(qual, gap)])
    usereport = rawreport & np.isfinite(scl[qual][:, gap % 12])
    counts[0] = rawreport.sum(0)
    counts[1] = usereport.sum(0)
    state[:] = 2
    state[counts[0] > 0] = 3
    state[counts[1] > 0] = 4
    nearorder = np.lexsort((np.arange(len(qual)), dd))
    for k, rep in enumerate([rawreport, usereport]):
        matrix = np.ascontiguousarray(rep[nearorder].T)
        first = matrix.argmax(axis=1)
        have = counts[k] > 0
        chosen = nearorder[first[have]]
        fields[k, have] = dd[chosen]
        nearest_ids[k, have] = src[chosen]
    ranks = B.rankdata(-rr)
    dranks = B.rankdata(dd)
    order = np.lexsort((src, ranks, ranks + dranks))
    matrix = np.ascontiguousarray(usereport[order].T)
    selected = np.full((L, 4), -1, int)
    for k in range(4):
        active = np.flatnonzero(counts[1] > k)
        if not len(active):
            break
        first = matrix[active].argmax(axis=1)
        selected[active, k] = order[first]
        matrix[active, first] = False
    counts[2] = np.minimum(counts[1], 4)
    valid = selected >= 0
    safe = np.maximum(selected, 0)
    weight = np.where(valid, rr[safe], 0.0)
    den = weight.sum(axis=1)
    have = den > 0
    fields[2, have] = (weight * dd[safe]).sum(1)[have] / den[have]
    fields[3, have] = (weight * rr[safe]).sum(1)[have] / den[have]
    sid[valid] = src[safe[valid]]
    sr[valid] = rr[safe[valid]]
    return (row, end, state, fields, counts, nearest_ids, sid, sr, meta)

def equivalence():
    B.init()
    c = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_cases.csv', keep_default_na=False).sort_values('raw_index').reset_index(drop=True)
    sel = np.unique(np.linspace(0, len(c) - 1, 100, dtype=int))
    rows = []
    t = time.time()
    max_abs = 0.0
    for k, e in enumerate(c.iloc[sel].to_dict('records'), 1):
        a = B.work(e)
        b = work_fast(e)
        for j in [0, 1, 8]:
            assert a[j] == b[j], (e['station_id'], j)
        for j in [2, 4, 5, 6]:
            assert np.array_equal(a[j], b[j]), (e['station_id'], j)
        for j in [3, 7]:
            assert np.allclose(a[j], b[j], atol=1e-05, rtol=2e-07, equal_nan=True), (e['station_id'], j)
            finite = np.isfinite(a[j]) & np.isfinite(b[j])
            delta = np.max(np.abs(a[j][finite] - b[j][finite])) if finite.any() else 0.0
            max_abs = max(max_abs, float(delta))
        rows.append({'raw_index': e['raw_index'], 'station_id': e['station_id'], 'output_row': e['output_row'], 'exact_identity_count_state_meta': True})
        if k % 20 == 0:
            print('equivalence', k, '/100', round(time.time() - t, 1), 's', flush=True)
    pd.DataFrame(rows).to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/DISTANCE_V2_EQUIVALENCE_CASES.csv', index=False)
    B.js(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/DISTANCE_V2_EQUIVALENCE.json', {'status': 'PASS', 'cases': 100, 'selection': '100 deterministic evenly spaced original raw-order targets, fixed before comparisons; includes same no-relation branches', 'identity_count_state_meta_exact': True, 'float_rtol': 2e-07, 'float_atol': 1e-05, 'max_float_absolute_difference': max_abs, 'seconds': time.time() - t, 'v1_code_sha256': B.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/run_distance_audit.py'), 'v2_code_sha256': B.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/run_distance_fast.py'), 'target_gap_truth_or_accuracy_used': False})
    print('EQUIVALENCE_PASS', max_abs, flush=True)

def produce(workers):
    eq = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/DISTANCE_V2_EQUIVALENCE.json').read_text())
    assert eq['status'] == 'PASS' and B.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/run_distance_fast.py') == eq['v2_code_sha256']
    pr = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/DISTANCE_PROTOCOL.json').read_text(encoding='utf8'))
    assert all((B.sha(B.CODE / p) == v['sha256'] for p, v in pr['sources_hash'].items()))
    out = _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance'
    out.mkdir(exist_ok=True)
    assert not (_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance/DISTANCE_FROZEN.json').exists()
    B.js(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance/CODE_FROZEN.json', {'scientific_protocol_sha256': B.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/DISTANCE_PROTOCOL.json'), 'v1_code_sha256': eq['v1_code_sha256'], 'v2_code_sha256': eq['v2_code_sha256'], 'equivalence_sha256': B.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/DISTANCE_V2_EQUIVALENCE.json'), 'amendment': 'No scientific rule changes; first4 boolean argmax replaces full cumulative-sum/weight matrices, nearest positive reports found by distance order. Original partial output retained.'})
    cases = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_cases.csv', keep_default_na=False).sort_values(['history_end_exclusive', 'raw_index'])
    t = time.time()
    met = []
    shapes = {'state': ((19418, 432), np.uint8), 'distance_and_r': ((19418, 4, 432), np.float32), 'counts': ((19418, 3, 432), np.int32), 'nearest_ids': ((19418, 2, 432), np.int32), 'selected_ids': ((19418, 432, 4), np.int32), 'selected_r': ((19418, 432, 4), np.float32)}
    arrays = {k: np.lib.format.open_memmap(out / (k + '.npy'), mode='w+', dtype=dt, shape=sh) for k, (sh, dt) in shapes.items()}
    for k, a in arrays.items():
        a[:] = np.nan if a.dtype.kind == 'f' else -1 if k.endswith('ids') else 0
    with ProcessPoolExecutor(max_workers=workers, initializer=B.init) as pool:
        for n, res in enumerate(pool.map(work_fast, cases.to_dict('records'), chunksize=8), 1):
            row, end, st, fields, counts, near, sids, srs, meta = res
            arrays['state'][row, end:] = st
            arrays['distance_and_r'][row, :, end:] = fields
            arrays['counts'][row, :, end:] = counts
            arrays['nearest_ids'][row, :, end:] = near
            arrays['selected_ids'][row, end:] = sids
            arrays['selected_r'][row, end:] = srs
            met.append(meta)
            if n % 1000 == 0:
                print('natural distance v2', n, '/19418', round(time.time() - t, 1), 's', flush=True)
    for a in arrays.values():
        a.flush()
    pd.DataFrame(met).sort_values('output_row').to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_station_relation_metadata.csv', index=False)
    total = int((arrays['state'] > 0).sum())
    assert total == 2612522
    B.js(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance/DISTANCE_FROZEN.json', {'status': 'COMPLETE_INPUT_ONLY', 'forward_targets': 19418, 'forward_missing_months': total, 'elapsed_seconds': time.time() - t, 'files': {p.name: B.sha(p) for p in out.glob('*.npy')}, 'cases_sha256': B.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_cases.csv'), 'metadata_sha256': B.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_station_relation_metadata.csv'), 'protocol_sha256': B.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/DISTANCE_PROTOCOL.json'), 'code_freeze_sha256': B.sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance/CODE_FROZEN.json'), 'field_axes': ['nearest_qualified_raw_report_km', 'nearest_qualified_transformable_report_km', 'RD4_r_weighted_km', 'RD4_r_weighted_r'], 'count_axes': ['qualified_raw_reports', 'qualified_transformable_reports', 'selected_RD4_count']})
    print('DISTANCE_FROZEN', total, flush=True)
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('step', choices=['equivalence', 'produce'])
    ap.add_argument('--workers', type=int, default=12)
    a = ap.parse_args()
    if a.step == 'equivalence':
        equivalence()
    else:
        produce(a.workers)
