from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import sys, json, hashlib
HERE = _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural'
CODE = _PROJECT_ROOT
pass
import numpy as np
import pandas as pd
OLD = _PROJECT_ROOT / 'workflows/regional_dependence/global_design'

def main():
    out = _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance'
    fr = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance/DISTANCE_FROZEN.json').read_text())
    c = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_cases.csv').sort_values('output_row')
    meta = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_station_relation_metadata.csv').sort_values('output_row')
    sta = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance/state.npy', mmap_mode='r')
    ct = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance/counts.npy', mmap_mode='r')
    ff = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance/distance_and_r.npy', mmap_mode='r')
    ids = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance/selected_ids.npy', mmap_mode='r')
    rr = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance/selected_r.npy', mmap_mode='r')
    near = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance/nearest_ids.npy', mmap_mode='r')
    m = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/all_station_roles.csv')
    raw = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/raw_Q.npy', mmap_mode='r')
    tw = m.twin_listed.to_numpy(bool)
    gap = np.arange(432)[None, :] >= c.history_end_exclusive.to_numpy()[:, None]
    assert np.array_equal(sta > 0, gap) and int(gap.sum()) == 2612522
    assert np.all(ct[:, 0] >= ct[:, 1]) and np.all(ct[:, 1] >= ct[:, 2]) and np.array_equal(ct[:, 2], np.minimum(ct[:, 1], 4))
    assert np.array_equal(sta == 4, ct[:, 2] > 0)
    assert np.array_equal(sta == 3, gap & (ct[:, 0] > 0) & (ct[:, 1] == 0))
    assert np.all((sta == 1).any(1) == meta.qualified_sources.eq(0).to_numpy())
    assert np.array_equal(sta == 2, gap & (ct[:, 0] == 0) & meta.qualified_sources.gt(0).to_numpy()[:, None])
    assert np.array_equal((ids >= 0).sum(2), ct[:, 2])
    assert np.array_equal(np.isfinite(rr), ids >= 0)
    valid = ids >= 0
    ti, mm, slot = np.nonzero(valid)
    sources = ids[ti, mm, slot]
    assert np.all(sources != c.raw_index.to_numpy()[ti]) and (not tw[sources].any())
    assert np.all(rr[ti, mm, slot] > 0) and np.all(rr[ti, mm, slot] <= 1)
    q = raw[sources, mm]
    assert np.isfinite(q).all() and (q >= 0).all()
    for a in range(4):
        for b in range(a + 1, 4):
            assert not ((ids[:, :, a] == ids[:, :, b]) & (ids[:, :, a] >= 0)).any()
    lat = np.deg2rad(m.latitude.to_numpy(float))
    lon = np.deg2rad(m.longitude.to_numpy(float))
    target = c.raw_index.to_numpy()[ti]
    hh = np.sin((lat[sources] - lat[target]) / 2) ** 2 + np.cos(lat[sources]) * np.cos(lat[target]) * np.sin((lon[sources] - lon[target]) / 2) ** 2
    dist = 12742 * np.arcsin(np.sqrt(np.clip(hh, 0, 1)))
    weighted = np.zeros(sta.shape, float)
    den = np.zeros(sta.shape, float)
    weighted_r = np.zeros(sta.shape, float)
    np.add.at(weighted, (ti, mm), dist * rr[ti, mm, slot])
    np.add.at(den, (ti, mm), rr[ti, mm, slot])
    np.add.at(weighted_r, (ti, mm), rr[ti, mm, slot].astype(float) ** 2)
    have = den > 0
    assert np.allclose(weighted[have] / den[have], ff[:, 2][have], rtol=3e-07, atol=0.0001)
    assert np.allclose(weighted_r[have] / den[have], ff[:, 3][have], rtol=3e-07, atol=1e-07)
    nearchecked = 0
    for k in [0, 1]:
        ti, mm = np.nonzero(near[:, k] >= 0)
        si = near[ti, k, mm]
        target = c.raw_index.to_numpy()[ti]
        assert not tw[si].any() and np.all(si != target)
        q = raw[si, mm]
        assert np.isfinite(q).all() and (q >= 0).all()
        hh = np.sin((lat[si] - lat[target]) / 2) ** 2 + np.cos(lat[si]) * np.cos(lat[target]) * np.sin((lon[si] - lon[target]) / 2) ** 2
        dis = 12742 * np.arcsin(np.sqrt(np.clip(hh, 0, 1)))
        assert np.allclose(dis, ff[ti, k, mm], rtol=2e-07, atol=0.0001)
        assert np.array_equal(near[:, k] >= 0, ct[:, k] > 0)
        nearchecked += len(si)
    result = {'status': 'PASS', 'targets': len(c), 'forward_months': int(gap.sum()), 'selected_source_slots': len(sources), 'nearest_source_slots': nearchecked, 'source_identity_self_twin_report_checks': 'all exact', 'distance_recompute': 'all selected weighted and nearest distances checked from independent coordinate formula; float32 tolerance 3e-7', 'states_counts_masks': 'all exact', 'no_target_gap_outcomes': 'no predictions or accuracy evaluated'}
    (_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/DISTANCE_ARRAY_AUDIT.json').write_text(json.dumps(result, indent=2), encoding='utf8')
    print(json.dumps(result))
if __name__ == '__main__':
    main()
