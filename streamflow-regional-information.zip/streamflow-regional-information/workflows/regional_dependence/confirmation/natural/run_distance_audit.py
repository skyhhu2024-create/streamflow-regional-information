from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib, time, warnings, argparse
from datetime import datetime, timezone
from concurrent.futures import ProcessPoolExecutor
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[k] = '1'
HERE = _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural'
CODE = _PROJECT_ROOT
pass
import numpy as np
import pandas as pd
from scipy.stats import rankdata
OLD = _PROJECT_ROOT / 'workflows/regional_dependence/global_design'
G = {}

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def js(p, obj):
    Path(p).write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')

def register():
    p = _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/DISTANCE_PROTOCOL.json'
    assert not p.exists()
    paths = [_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/run_distance_audit.py', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/NATURAL_PROTOCOL.json', _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/forward_station_history_calendar.csv.gz', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/raw_Q.npy', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/station_ids.npy', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/all_station_roles.csv']
    js(p, {'frozen_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Input-only natural forward-gap distance support audit. Original paper 19418 target stations and 2612522 missing months, no target gap outcomes or predictions.', 'archive': 'Original unfiltered GSIM monthly MEAN; use raw_Q float64, whose float32 values and masks match original Z.mm exactly. Original observed mask defines targets/gaps; signed finite months remain observations in descriptive calendar counts, but are excluded from log transfer inputs.', 'sources': 'All 30959 original GSIM rows except twin_listed and target itself. No QC20, heldout role or full-record negativity gate. Coordinates independently checked finite; current H determines relationship eligibility. Target twin flags retained in denominator and output.', 'history': 'H is last up to60 CALENDAR months ending at original last observation. Source and target transforms each use only this H, current finite nonnegative values, log1p calendar means, population anomaly SD >1e-12 and repeated calendar evidence. Missing target values are ignored, never filled for qualification.', 'qualification': 'At least12 joint finite standardized H anomalies, nondegenerate pair variances and positive Pearson r. Never choose by G outcome. Source G reports are solely availability inputs.', 'selection': 'RD ranking: rank(-r)+rank(distance), ties rank(-r) then original row; each G month first up to4 reporting sources with H-estimable seasonal background. Positive r weights normalized within month.', 'distance_endpoints': 'Nearest qualifying nonnegative raw report and nearest H-transformable report separately. Selected RD4 r-weighted distance, mean weighted r, count, source IDs and r saved. min distance >100/300/800 means no qualifying report within radius, not physical gauge absence.', 'states': {'0': 'not a natural forward missing month', '1': 'no qualified historical relation under this H/rule', '2': 'qualified relations but no synchronous nonnegative raw report', '3': 'synchronous raw report exists but no H-transformable report', '4': 'at least one qualified H-transformable report'}, 'aggregation': 'All19418 targets and2612522 months retained. By continent, missing-month decade, all-visible missing-calendar band, and historical relation reason. Support is not quality or recovery.', 'sources_hash': {str(p.relative_to(CODE)): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in paths}})

def init():
    warnings.filterwarnings('ignore', category=RuntimeWarning)
    G['raw'] = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/raw_Q.npy', mmap_mode='r')
    G['meta'] = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/all_station_roles.csv', keep_default_na=False)
    ids = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/station_ids.npy').astype(str)
    assert ids.tolist() == G['meta'].station_id.tolist()
    twin = G['meta'].twin_listed.astype(str).str.lower().eq('true').to_numpy()
    G['workflows/shared'] = np.flatnonzero(~twin)
    lat = G['meta'].latitude.to_numpy(float)
    lon = G['meta'].longitude.to_numpy(float)
    assert np.isfinite(lat).all() and np.isfinite(lon).all()
    G['lat'] = np.deg2rad(lat)
    G['lon'] = np.deg2rad(lon)
    sq = np.asarray(G['raw'][G['workflows/shared']], float)
    G['source_log'] = np.where(np.isfinite(sq) & (sq >= 0), np.log1p(np.maximum(sq, 0)), np.nan)
    G['cache_end'] = -1

def transform_log(x, h):
    cl = np.stack([np.nanmean(x[:, h % 12 == m], axis=1) for m in range(12)], axis=1)
    dev = x - cl[:, h % 12]
    sd = np.nanstd(dev, axis=1)
    repeated = np.stack([np.isfinite(x[:, h % 12 == m]).sum(1) for m in range(12)], axis=1).max(1) > 1
    sd[(sd <= 1e-12) | ~repeated] = np.nan
    return (cl, sd, dev / sd[:, None])

def source_h(end):
    if G['cache_end'] != end:
        h = np.arange(max(0, end - 60), end)
        x = G['source_log'][:, h]
        cl, sd, z = transform_log(x, h)
        G['cache'] = (h, cl, sd, z)
        G['cache_end'] = end
    return G['cache']

def work(e):
    row = int(e['output_row'])
    j = int(e['raw_index'])
    end = int(e['history_end_exclusive'])
    gap = np.arange(end, 432)
    L = len(gap)
    h, scl, ssd, sz = source_h(end)
    tq = np.asarray(G['raw'][j, h], float)
    tx = np.where(np.isfinite(tq) & (tq >= 0), np.log1p(np.maximum(tq, 0)), np.nan)
    tcl, tsd, tz = transform_log(tx[None, :], h)
    tz = tz[0]
    state = np.ones(L, np.uint8)
    fields = np.full((4, L), np.nan, np.float32)
    counts = np.zeros((3, L), np.int32)
    nearest_ids = np.full((2, L), -1, np.int32)
    sid = np.full((L, 4), -1, np.int32)
    sr = np.full((L, 4), np.nan, np.float32)
    meta = {'output_row': row, 'station_id': e['station_id'], 'raw_index': j, 'history_end_exclusive': end, 'history_span_months': len(h), 'history_valid_nonnegative': int(np.isfinite(tx).sum()), 'history_missing_calendar': int((~np.isfinite(tcl[0])).sum()), 'history_repeated_calendars': int(sum((np.isfinite(tx[h % 12 == m]).sum() >= 2 for m in range(12)))), 'target_anomaly_estimable': bool(np.isfinite(tsd[0])), 'joint_ge12': 0, 'qualified_sources': 0, 'relation_reason': 'target_history_not_estimable', 'target_twin_listed': bool(G['meta'].twin_listed.iloc[j])}
    if not np.isfinite(tsd[0]):
        return (row, end, state, fields, counts, nearest_ids, sid, sr, meta)
    ok = np.isfinite(sz) & np.isfinite(tz)[None, :]
    n = ok.sum(1)
    nn = np.maximum(n, 1)
    xx = np.where(ok, sz, 0)
    yy = np.where(ok, tz, 0)
    sx = xx.sum(1)
    sy = yy.sum(1)
    vx = (xx * xx).sum(1) - sx * sx / nn
    vy = (yy * yy).sum(1) - sy * sy / nn
    cv = (xx * yy).sum(1) - sx * sy / nn
    r = np.divide(cv, np.sqrt(np.maximum(vx * vy, 0)), out=np.full(len(n), np.nan), where=(n >= 12) & (vx > 1e-24) & (vy > 1e-24))
    r = np.clip(r, -1, 1)
    r[G['workflows/shared'] == j] = np.nan
    meta['joint_ge12'] = int(((n >= 12) & (G['workflows/shared'] != j)).sum())
    qual = np.flatnonzero(np.isfinite(r) & (r > 0) & np.isfinite(ssd))
    meta['qualified_sources'] = len(qual)
    meta['relation_reason'] = 'qualified_relation' if len(qual) else 'no_positive_qualified_relation'
    if not len(qual):
        return (row, end, state, fields, counts, nearest_ids, sid, sr, meta)
    src = G['workflows/shared'][qual]
    rr = r[qual]
    la = G['lat'][j]
    lo = G['lon'][j]
    hh = np.sin((G['lat'][src] - la) / 2) ** 2 + np.cos(la) * np.cos(G['lat'][src]) * np.sin((G['lon'][src] - lo) / 2) ** 2
    dd = 12742 * np.arcsin(np.sqrt(np.clip(hh, 0, 1)))
    rawreport = np.isfinite(G['source_log'][np.ix_(qual, gap)])
    usereport = rawreport & np.isfinite(scl[qual][:, gap % 12])
    counts[0] = rawreport.sum(0)
    counts[1] = usereport.sum(0)
    state[:] = 2
    state[counts[0] > 0] = 3
    state[counts[1] > 0] = 4
    for k, rep in enumerate([rawreport, usereport]):
        tmp = np.where(rep, dd[:, None], np.inf)
        idx = tmp.argmin(0)
        mins = tmp[idx, np.arange(L)]
        have = np.isfinite(mins)
        fields[k, have] = mins[have]
        nearest_ids[k, have] = src[idx[have]]
    ranks = rankdata(-rr)
    dranks = rankdata(dd)
    order = np.lexsort((src, ranks, ranks + dranks))
    report = usereport[order]
    cs = np.cumsum(report, axis=0, dtype=np.int32)
    take = report & (cs <= 4)
    wi = np.where(take, rr[order, None], 0)
    den = wi.sum(0)
    have = den > 0
    fields[2, have] = (wi * dd[order, None]).sum(0)[have] / den[have]
    fields[3, have] = (wi * rr[order, None]).sum(0)[have] / den[have]
    counts[2] = take.sum(0)
    a, b = np.nonzero(take)
    slots = cs[a, b] - 1
    sid[b, slots] = src[order[a]]
    sr[b, slots] = rr[order[a]]
    return (row, end, state, fields, counts, nearest_ids, sid, sr, meta)

def produce(workers):
    pr = json.loads((_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/DISTANCE_PROTOCOL.json').read_text(encoding='utf8'))
    assert all((sha(CODE / p) == v['sha256'] for p, v in pr['sources_hash'].items()))
    cases = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/forward_station_history_calendar.csv.gz', keep_default_na=False)
    cases = cases[cases.window.eq('H60')].sort_values('raw_index').reset_index(drop=True)
    assert len(cases) == 19418
    cases['output_row'] = np.arange(len(cases))
    cases.to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_cases.csv', index=False)
    out = _PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_arrays'
    out.mkdir(exist_ok=True)
    shapes = {'state': ((19418, 432), np.uint8), 'distance_and_r': ((19418, 4, 432), np.float32), 'counts': ((19418, 3, 432), np.int32), 'nearest_ids': ((19418, 2, 432), np.int32), 'selected_ids': ((19418, 432, 4), np.int32), 'selected_r': ((19418, 432, 4), np.float32)}
    assert not (_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_arrays/DISTANCE_FROZEN.json').exists(), 'Do not overwrite frozen output'
    arrays = {k: np.lib.format.open_memmap(out / (k + '.npy'), mode='w+', dtype=dt, shape=sh) for k, (sh, dt) in shapes.items()}
    for k, a in arrays.items():
        a[:] = np.nan if a.dtype.kind == 'f' else -1 if k.endswith('ids') else 0
    cases = cases.sort_values(['history_end_exclusive', 'raw_index'])
    t = time.time()
    met = []
    with ProcessPoolExecutor(max_workers=workers, initializer=init) as pool:
        for n, res in enumerate(pool.map(work, cases.to_dict('records'), chunksize=8), 1):
            row, end, st, fields, counts, near, sids, srs, meta = res
            arrays['state'][row, end:] = st
            arrays['distance_and_r'][row, :, end:] = fields
            arrays['counts'][row, :, end:] = counts
            arrays['nearest_ids'][row, :, end:] = near
            arrays['selected_ids'][row, end:] = sids
            arrays['selected_r'][row, end:] = srs
            met.append(meta)
            if n % 500 == 0:
                print('natural distance', n, '/19418', round(time.time() - t, 1), 's', flush=True)
    for a in arrays.values():
        a.flush()
    pd.DataFrame(met).sort_values('output_row').to_csv(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_station_relation_metadata.csv', index=False)
    total = int((arrays['state'] > 0).sum())
    assert total == 2612522
    js(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_arrays/DISTANCE_FROZEN.json', {'status': 'COMPLETE_INPUT_ONLY', 'forward_targets': 19418, 'forward_missing_months': total, 'elapsed_seconds': time.time() - t, 'files': {p.name: sha(p) for p in out.glob('*.npy')}, 'cases_sha256': sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_cases.csv'), 'metadata_sha256': sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/distance_station_relation_metadata.csv'), 'protocol_sha256': sha(_PROJECT_ROOT / 'workflows/regional_dependence/confirmation/natural/DISTANCE_PROTOCOL.json'), 'field_axes': ['nearest_qualified_raw_report_km', 'nearest_qualified_transformable_report_km', 'RD4_r_weighted_km', 'RD4_r_weighted_r'], 'count_axes': ['qualified_raw_reports', 'qualified_transformable_reports', 'selected_RD4_count']})
    print('DISTANCE_FROZEN', total, flush=True)
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('step', choices=['register', 'produce'])
    ap.add_argument('--workers', type=int, default=4)
    args = ap.parse_args()
    if args.step == 'register':
        register()
    else:
        produce(args.workers)
