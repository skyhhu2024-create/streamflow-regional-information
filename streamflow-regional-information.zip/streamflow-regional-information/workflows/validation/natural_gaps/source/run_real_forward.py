"""Frozen full-source reconstruction of genuine forward gaps; never reads GRDC truth."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib, importlib.util, argparse, warnings, time
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[k] = '1'
sys.dont_write_bytecode = True
ROOT = _PROJECT_ROOT / 'workflows/validation/natural_gaps'
CODE = _PROJECT_ROOT
pass
PREV = _PROJECT_ROOT / 'workflows/rainfall/global_inputs'
pass
import numpy as np
import pandas as pd
import workflows.rainfall.global_inputs.design_review.transfer_model as M
spec = importlib.util.spec_from_file_location('frozen_source_math', _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/run_outage.py')
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)
METHODS = ['ridge', 'rbf_ridge']
ARMS = ['Q', 'QP', 'QP_Gclim']
G = {}
OUT = _PROJECT_ROOT / 'workflows/validation/natural_gaps/predictions'

def sha(p):
    return C.sha(p)

def js(p, x):
    Path(p).parent.mkdir(exist_ok=True, parents=True)
    C.js(p, x)

def input_paths():
    return [_PROJECT_ROOT / 'workflows/validation/natural_gaps/source/run_real_forward.py', _PROJECT_ROOT / 'workflows/validation/natural_gaps/PROTOCOL.json', _PROJECT_ROOT / 'workflows/validation/natural_gaps/census/registered_cases.csv', _PROJECT_ROOT / 'workflows/validation/natural_gaps/census/REGISTERED_CENSUS_COMPLETE.json', _PROJECT_ROOT / 'workflows/validation/natural_gaps/census/registered_evaluation_truth.npz', _PROJECT_ROOT / 'workflows/validation/natural_gaps/census/complete_physical_identity_source_exclusions.csv', _PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/precipitation.npz', _PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/admission.csv', _PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/PRECIPITATION_READY.json', _PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/source_manifest.csv', _PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/lineage.csv', _PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/native_geometry_qa.csv', _PROJECT_ROOT / 'workflows/rainfall/global_inputs/design_review/transfer_model.py', Path(C.__file__), C.OLD / 'global_data/QC20_Q.npy', C.OLD / 'design/all_station_roles.csv', C.OLD / 'predictions/source_cache/source_raw_indices.npy']

def register():
    assert not (_PROJECT_ROOT / 'workflows/validation/natural_gaps/predictions/PREDICTIONS_FROZEN.json').exists()
    d = pd.read_csv(_PROJECT_ROOT / 'workflows/validation/natural_gaps/census/registered_cases.csv')
    assert len(d) == 141 and d.station_id.is_unique
    p = dict(date='2026-10-26', N=len(d), H=60, G='min(120,432-anchor)', methods=METHODS, arms=ARMS, scope='Actual GSIM forward gaps only; retrospective external validation, not a new untouched blind cohort.', cohort='All primary596 identity/overlap-compatible entries with H60 inside study window and >=24 original-entry GRDC truth months in first min(120,remaining study months) following the last original GSIM observation. Selection by availability only, before predictions. Keep all141 even if target H unestimable or fewer24 physical-gap truth months.', exact120='Keep fixed H60/G120 calendar subset separately; no physical-identity-missing complete120 GRDC truth case exists. Entry-level FR has120 truth but12 months also observed under another GSIM identity.', source_domain='Frozen24734 full GSIM QC20 source candidates, no spatial fold exclusions. Remove target whole same-GRDC-ID/checked-twin connected component; also conservatively exclude all four known pending British cross-archive aliases globally.', potential_aliases_excluded=['GB_0000239', 'GB_0000240', 'GB_0000241', 'GB_0000242'], qualification='Frozen old-source H-only log1p calendarmean and anomaly SD; >=12 common finite target-source H anomaly pairs and positive r. Rank average(-r)+average(distance), then r-rank, rawID; monthly K4 positive-r-weighted anomaly composite. No GRDC values enter any inputs.', target_rule='Frozen target H60 all finite/nonnegative, full calendars and positive finite anomaly SD. Otherwise model unestimable, raw-H seasonal fallback; retain denominator. H is never repaired from GRDC.', model='Original fixed standardized ridge lambda.1 and single fixed RBF lambda.1, same H training mask finite(tz)&finite(Q composite). No tuning. Original H z-range+-3, log50 guard and seasonal fallback.', precipitation='Full-catchment same-product ERA5-Land tp mm/month only following registered input admission. lag0..3 log1p, all needed antecedent/H/G months. QP unavailable/failed returns Q. QP_Gclim same fitted QP object replacing only underlying G dates by H logP calendar means before lagging.', evaluation='Main raw monthly r>.7, actual fit and support within scored months; fixed physical-identity-missing GRDC mask primary, original-entry-missing mask separate. Require>=24 truth months; all methods same mask, nonfinite prediction cannot silently drop months. Constant truth, undefined r, no support and unestimable retained in141 denominator with separate status. Seasonal baseline numerical r pass separate. Full-H estimable/complete-G/degrees/regions/P availability explicitly stratified.', secondary='NSE, alpha/delta, H-calendar-deseasonal rawQ correlation; >=.6/.8 sensitivity. No seasonal-baseline victory condition added to primary threshold. 2000 spatial5degree cluster bootstrap, fixed seed, paired targets; tiny strata descriptive.', scoring_gate='All predictions frozen then independent QA PASS before evaluator loads GRDC values. Truth container is byte-hashed for version binding only; production never loads its values.', scope_guards='No interpolation/backward extension, no oracle, no new processor/tuning, no rainfall source swapping, no manuscript/SI/figures/cloud.')
    js(_PROJECT_ROOT / 'workflows/validation/natural_gaps/PROTOCOL.json', p)
    js(_PROJECT_ROOT / 'workflows/validation/natural_gaps/CODE_INPUTS_FROZEN.json', dict(files={str(p): sha(p) for p in input_paths()}, target_G_truth_read=False))
    print('REGISTERED_141_REAL_FORWARD_BEFORE_PREDICTION', flush=True)

def init():
    warnings.filterwarnings('ignore', category=RuntimeWarning)
    C.init()
    G['cases'] = pd.read_csv(_PROJECT_ROOT / 'workflows/validation/natural_gaps/census/registered_cases.csv')
    G['rain'] = np.load(_PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/precipitation.npz', allow_pickle=False)
    assert np.array_equal(G['rain']['station_ids'].astype(str), G['cases'].station_id.to_numpy(str))
    assert G['rain']['periods'].astype(str).tolist() == pd.period_range('1979-10', '2015-12', freq='M').astype(str).tolist()
    raw = C.G['source_raw']
    meta = C.G['meta']
    risk = meta.station_id.isin(['GB_0000239', 'GB_0000240', 'GB_0000241', 'GB_0000242']).to_numpy()
    raw = raw[~risk[raw]]
    G['source'] = dict(raw=raw, Q=np.asarray(C.G['Q'][raw]), lat=meta.iloc[raw].latitude.to_numpy(float), lon=meta.iloc[raw].longitude.to_numpy(float))

def one(i):
    e = G['cases'].iloc[i]
    f = G['source']
    h = np.arange(int(e.history_start), int(e.history_end))
    g = np.arange(int(e.gap_start), int(e.gap_end))
    L = len(g)
    assert len(h) == 60 and 24 <= L <= 120
    th = np.asarray(C.G['Q'][int(e.raw_index), h])
    domain = np.isfinite(th).all() and (th >= 0).all()
    cc, ss, zz = C.prep(th[None, :], h)
    tc, sd, tz = (cc[0], float(ss[0]), zz[0])
    estim = bool(domain and np.isfinite(tc).all() and np.isfinite(sd))
    if not estim:
        tz = np.full(60, np.nan)
    rawcal = np.array([np.nanmean(th[h % 12 == m]) for m in range(12)])
    base = rawcal[g % 12]
    cl, st, zh = C.prep(f['Q'][:, h], h)
    n, r = C.relation(zh, tz)
    a, b = np.deg2rad([float(e.latitude), float(e.longitude)])
    c, d = (np.deg2rad(f['lat']), np.deg2rad(f['lon']))
    dist = 6371 * 2 * np.arcsin(np.sqrt(np.clip(np.sin((c - a) / 2) ** 2 + np.cos(a) * np.cos(c) * np.sin((d - b) / 2) ** 2, 0, 1)))
    excluded = json.loads(e.all_same_station_exclusion_raw_indices)
    assert int(e.raw_index) in excluded
    q = np.flatnonzero(np.isfinite(r) & (r > 0) & np.isfinite(st) & ~np.isin(f['raw'], excluded))
    order = C.ordering(f['raw'], q, r, dist)
    comp, cnt, ids = C.combine(f, order, r, cl, st, np.r_[h, g])
    assert not np.isin(ids, excluded).any()
    train = np.isfinite(tz) & np.isfinite(comp[:60])
    rain = G['rain']
    rawp = rain['precip_mm_month'][i, int(e.history_start):int(e.gap_end) + 3]
    pp = M.prepare_precipitation_lags(rawp, history_start_month=int(e.history_start), h_length=60, g_length=L)
    hasp = bool(rain['admission_mask'][i]) and pp.available
    qh, qg = (comp[:60, None], comp[60:, None])
    pred = np.full((2, 3, 120), np.nan)
    sup = np.zeros((2, 3, 120), bool)
    flags = np.zeros((2, 3, 7), bool)
    fits = []
    for mi, m in enumerate(METHODS):
        qm, qr = M.fit_transfer(qh[train], tz[train], method=m, target_estimable=estim)
        pm, pr = (None, 'P_not_admitted_or_incomplete')
        if hasp:
            pm, pr = M.fit_transfer(np.column_stack([qh, pp.h])[train], tz[train], method=m, target_estimable=estim)
        models = [qm, pm if pm is not None else qm, pm if pm is not None else qm]
        features = [qg, np.column_stack([qg, pp.g]) if pm is not None else qg, np.column_stack([qg, pp.g_climatology]) if pm is not None else qg]
        assert models[1] is models[2]
        for ai, model in enumerate(models):
            actual = model is not None
            requested = qm is not None if ai == 0 else pm is not None
            usep = ai > 0 and pm is not None
            z = model.predict(features[ai]) if actual else np.full(L, np.nan)
            pred[mi, ai, :L], sup[mi, ai, :L] = C.transfer(z, tz, tc, sd, g, base, actual)
            flags[mi, ai] = [actual, requested, True if ai == 0 else hasp, not requested, usep, usep and ai == 1, usep and ai == 2]
        fits.append(dict(method=m, Q_fit=qr, QP_fit=pr, common_H_rows=int(train.sum())))
    if not hasp:
        np.testing.assert_allclose(pred[:, 0], pred[:, 1], rtol=0, atol=0, equal_nan=True)
    return dict(predictions=pred, support=sup, flags=flags, composites=comp, counts=cnt, source_ids=ids, training_mask=train, target_Hz=tz, target_H_log_calendar=tc, target_H_anomaly_sd=np.array(sd), target_H_raw_calendar=rawcal, p_h=pp.h, p_g=pp.g, p_g_climatology=pp.g_climatology, p_available=np.array(hasp), baseline=base, source_qualified_count=np.array(len(q)), target_estimable=np.array(estim), history_months=h, gap_months=g, fit_records=np.array(json.dumps(fits)), source_pool_count=np.array(len(f['raw'])))

def produce():
    freeze = json.loads((_PROJECT_ROOT / 'workflows/validation/natural_gaps/CODE_INPUTS_FROZEN.json').read_text(encoding='utf8'))
    assert all((sha(p) == v for p, v in freeze['files'].items()))
    assert not (_PROJECT_ROOT / 'workflows/validation/natural_gaps/predictions/PREDICTIONS_FROZEN.json').exists()
    OUT.mkdir(exist_ok=True)
    (_PROJECT_ROOT / 'workflows/validation/natural_gaps/predictions/cases').mkdir(exist_ok=True)
    init()
    start = time.time()
    for i in range(len(G['cases'])):
        p = _PROJECT_ROOT / 'workflows/validation/natural_gaps/predictions/cases' / f'{i:04d}.npz'
        np.savez_compressed(p, **one(i))
        if (i + 1) % 20 == 0 or i + 1 == len(G['cases']):
            print(f"Predicted {i + 1}/{len(G['cases'])} sec={time.time() - start:.1f}", flush=True)
    js(_PROJECT_ROOT / 'workflows/validation/natural_gaps/predictions/PREDICTIONS_FROZEN.json', dict(status='ALL141_REAL_FORWARD_PREDICTED_BEFORE_GRDC_SCORING', target_G_read=False, methods=METHODS, arms=ARMS, files={str(p.relative_to(OUT)): sha(p) for p in sorted((_PROJECT_ROOT / 'workflows/validation/natural_gaps/predictions/cases').glob('*.npz'))}, cases_sha256=sha(_PROJECT_ROOT / 'workflows/validation/natural_gaps/census/registered_cases.csv'), code_freeze_sha256=sha(_PROJECT_ROOT / 'workflows/validation/natural_gaps/CODE_INPUTS_FROZEN.json')))
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('step', choices=['register', 'produce'])
    args = ap.parse_args()
    globals()[args.step]()
