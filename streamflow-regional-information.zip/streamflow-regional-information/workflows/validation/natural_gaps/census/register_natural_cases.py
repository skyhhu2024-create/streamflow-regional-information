"""Register availability-defined genuine forward gaps before any prediction."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import sys, json, hashlib
R = _PROJECT_ROOT / 'workflows/validation/natural_gaps/census'
C = _PROJECT_ROOT
pass
import numpy as np
import pandas as pd
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
d = pd.read_csv(_PROJECT_ROOT / 'workflows/validation/natural_gaps/census/truncated_calendar_candidates_NOT_REGISTERED.csv').sort_values('station_id').reset_index(drop=True)
assert len(d) == 141 and d.station_id.is_unique
p = pd.read_csv(_PROJECT_ROOT / 'workflows/validation/natural_gaps/census/physical_identity_gap_audit.csv').set_index('station_id')
t = np.load(_PROJECT_ROOT / 'workflows/validation/natural_gaps/census/confirmed_GRDC_truth_values_NOT_INPUT.npz', allow_pickle=False)
a = np.load(_PROJECT_ROOT / 'workflows/validation/natural_gaps/census/physical_identity_observation_masks.npz', allow_pickle=False)
assert np.array_equal(t['station_ids'], a['station_ids'])
index = {s: i for i, s in enumerate(t['station_ids'].astype(str))}
truth = np.full((len(d), 120), np.nan)
months = np.full((len(d), 120), -1, int)
alias = np.zeros((len(d), 120), bool)
physical = np.zeros_like(alias)
for i, e in enumerate(d.itertuples()):
    j = index[e.station_id]
    g = np.arange(e.gap_start, e.gap_end)
    n = len(g)
    assert e.history_start >= 0 and e.history_end == e.gap_start and (e.history_end - e.history_start == 60)
    assert e.gap_end == min(e.gap_start + 120, 432) and np.isfinite(t['Q_m3s'][j, g]).sum() >= 24
    truth[i, :n] = t['Q_m3s'][j, g]
    months[i, :n] = g
    alias[i, :n] = a['same_identity_GSIM_observed_mask'][j, g]
    physical[i, :n] = np.isfinite(truth[i, :n]) & ~alias[i, :n]
d.insert(0, 'row', np.arange(len(d)))
d['H'] = 60
d['L'] = d.gap_end - d.gap_start
for col in ['all_same_station_exclusion_raw_indices', 'all_same_station_exclusion_ids', 'same_identity_raw_observed_G_months', 'GRDC_truth_already_in_other_GSIM_identity_months', 'GRDC_physical_all_GSIM_identities_missing_truth_months', 'physical_missing_truth_calendar_months']:
    d[col] = d.station_id.map(p[col])
d['primary_identity_strong'] = True
d['entry_truth_ge24'] = np.isfinite(truth).sum(1) >= 24
d['physical_truth_ge24'] = physical.sum(1) >= 24
d['exact_H60_G120_entry_complete_truth'] = d.target_estimable_fixed_rule & d.L.eq(120) & (np.isfinite(truth).sum(1) == 120)
d['exact_H60_G120_physical_complete_truth'] = d.target_estimable_fixed_rule & d.L.eq(120) & (physical.sum(1) == 120)
d['same_physical_station_GSIM_records_recovered_only'] = np.any(np.isfinite(truth) & alias, axis=1)
d.to_csv(_PROJECT_ROOT / 'workflows/validation/natural_gaps/census/registered_cases.csv', index=False, encoding='utf-8-sig')
np.savez_compressed(_PROJECT_ROOT / 'workflows/validation/natural_gaps/census/registered_evaluation_truth.npz', station_ids=d.station_id.to_numpy(str), GRDC_ids=d.GRDC_id.to_numpy(int), raw_indices=d.raw_index.to_numpy(int), values=truth, mask=np.isfinite(truth), month_indices=months, true_physical_gap_mask=physical, alias_observed_mask=alias, same_identity_retrievable_truth_mask=np.isfinite(truth) & alias, padding_mask=months < 0)
assert not np.any(physical & alias)
assert not np.isfinite(truth[months < 0]).any()
assert np.array_equal(physical, np.isfinite(truth) & ~alias)
assert int(physical.sum()) == 6929 and int(np.isfinite(truth).sum()) == 6965
registration = {'status': 'REGISTERED_AVAILABILITY_ONLY_BEFORE_NEW_PREDICTIONS', 'scope': 'genuine forward entry gaps, original stop anchor, H60, G truncated only by 2015-12, >=24 GRDC valid entry-gap observations', 'cohort': 141, 'complete_H60_estimable': int(d.target_estimable_fixed_rule.sum()), 'strict_full120_calendar_cases': int(d.L.eq(120).sum()), 'exact_H60_G120_entry_complete_truth_cases': int(d.exact_H60_G120_entry_complete_truth.sum()), 'exact_H60_G120_physical_complete_truth_cases': int(d.exact_H60_G120_physical_complete_truth.sum()), 'entry_truth_months': 6965, 'physical_missing_truth_months': 6929, 'same_identity_GSIM_retrievable_truth_months': 36, 'physical_gap_atleast24_cases': int(d.physical_truth_ge24.sum()), 'physical_gap_less24_cases_retained': d.loc[~d.physical_truth_ge24, 'station_id'].tolist(), 'no_predictions_or_skill_read': True, 'no_GRDC_as_H_or_reference_input': True, 'original_5case_interfaces_preserved': True, 'candidate_selection_has_not_used_r_NSE_or_model_outcome': True, 'truth_only_loaded_after_predictions_freeze': True, 'files': {name: {'sha256': sha(R / name), 'bytes': (R / name).stat().st_size} for name in ['registered_cases.csv', 'registered_evaluation_truth.npz', 'complete_physical_identity_source_exclusions.csv', 'physical_identity_gap_audit.csv', 'physical_identity_observation_masks.npz', 'truncated_calendar_candidates_NOT_REGISTERED.csv']}}
(_PROJECT_ROOT / 'workflows/validation/natural_gaps/census/REGISTERED_CENSUS_COMPLETE.json').write_text(json.dumps(registration, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps(registration, ensure_ascii=False, indent=2))
