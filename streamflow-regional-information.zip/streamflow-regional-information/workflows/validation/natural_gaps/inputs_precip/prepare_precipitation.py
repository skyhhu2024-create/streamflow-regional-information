"""Bind rainfall to registered true-forward cases without target-flow access."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))

def _release_path(kind, relative):
    import os as _release_os
    from pathlib import Path as _ReleasePath
    code_root = _PROJECT_ROOT
    root = code_root if kind == 'code' else _ReleasePath(_release_os.environ.get('STREAMFLOW_DATA_ROOT', str(code_root.parent / 'inputs')))
    return str(root / relative)
from pathlib import Path
import sys, json, hashlib, importlib.util, warnings
from types import SimpleNamespace
sys.dont_write_bytecode = True
OUT = _PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip'
ROOT = _PROJECT_ROOT / 'workflows/validation/natural_gaps'
EXP = _PROJECT_ROOT / 'data/study_inputs'
P = _PROJECT_ROOT / 'data'
CODE = _PROJECT_ROOT
OLD = _PROJECT_ROOT / 'workflows/rainfall/global_inputs'
pass
import numpy as np, pandas as pd, shapefile, shapely
from shapely.geometry import shape, Point
from shapely.ops import nearest_points
from pyproj import CRS, Geod
from scipy import sparse
from workflows.rainfall.global_inputs.precipitation_inventory.prepare_precipitation_candidates import build_one
from workflows.rainfall.global_inputs.precipitation_inventory.extract_available_early_precipitation import extract
W = _PROJECT_ROOT / 'data/meteorology'
T = _PROJECT_ROOT / 'data/meteorology/station_inputs'
F = _PROJECT_ROOT / 'data/meteorology/catchment_forcing'
GS = _PROJECT_ROOT.parent / '3-GSIM_indices/GSIM_metadata/GSIM_metadata'
GD = Geod(ellps='WGS84')

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def area(g):
    if g.geom_type == 'Polygon':
        from shapely.geometry.polygon import orient
        return abs(GD.geometry_area_perimeter(orient(g, sign=1))[0]) / 1000000.0
    return sum((area(v) for v in g.geoms if v.geom_type in ['Polygon', 'MultiPolygon']))

def flag(v):
    return False if pd.isna(v) else str(v).lower() == 'true'

def write(df, name):
    df.to_csv(OUT / name, index=False, encoding='utf-8-sig')

def main():
    cp = _PROJECT_ROOT / 'workflows/validation/natural_gaps/census/registered_cases.csv'
    use = ['station_id', 'row', 'raw_index', 'country', 'continent', 'latitude', 'longitude', 'H', 'L', 'history_start', 'history_end', 'gap_start', 'gap_end']
    names = pd.read_csv(cp, nrows=0).columns
    c = pd.read_csv(cp, usecols=[k for k in use if k in names], float_precision='round_trip')
    if 'row' not in c:
        c['row'] = np.arange(len(c))
    assert len(c) == 141 and c.station_id.is_unique
    periods = pd.period_range('1979-10', '2015-12', freq='M').astype(str).to_numpy(dtype=str)
    x = np.full((len(c), 435), np.nan, np.float32)
    admit = np.zeros(len(c), bool)
    warn = np.zeros(len(c), bool)
    origins = [''] * len(c)
    reasons = [''] * len(c)
    notes = [''] * len(c)
    lineage = []
    manifest = []

    def bind(p, role):
        p = Path(p)
        r = dict(path=str(p), role=role, sha256=sha(p), bytes=p.stat().st_size, mtime_ns=p.stat().st_mtime_ns)
        manifest.append(r)
        return r['sha256']
    bind(cp, 'registered case metadata only; no flow values read')
    oldpath = _PROJECT_ROOT / 'workflows/rainfall/global_inputs/final_inputs/global8898_tp_197910_201512_ADMITTED.npz'
    oldledgerpath = _PROJECT_ROOT / 'workflows/rainfall/global_inputs/final_inputs/global8898_precipitation_admission_ledger.csv'
    bind(oldpath, 'previously independently admitted full-basin rainfall')
    bind(oldledgerpath, 'preserved rainfall/geometry admission')
    old = np.load(oldpath, allow_pickle=False)
    oldpos = {s: i for i, s in enumerate(old['station_ids'].astype(str))}
    ol = pd.read_csv(oldledgerpath, low_memory=False).set_index('station_id')
    assert np.array_equal(old['periods'].astype(str), periods)
    masterpath = _PROJECT_ROOT / 'data/meteorology/station_inputs/weather_1994_2025.npz'
    regpath = _PROJECT_ROOT / 'data/meteorology/station_inputs/station_registry.csv'
    bind(masterpath, 'pre-existing screened full-catchment weather; rainfall only')
    bind(regpath, 'geometry and forcing lineage columns only')
    mz = np.load(masterpath, allow_pickle=False)
    mids = mz['station_ids'].astype(str)
    mp = {s: i for i, s in enumerate(mids)}
    mvals = mz['values'][:, :, list(mz['variable_names'].astype(str)).index('tp')]
    mperiod = mz['periods'].astype(str)
    assert mperiod[:264].tolist() == periods[171:].tolist()
    regcols = ['station_id', 'forcing_input_origin', 'forcing_geometry_status', 'geometry_source', 'original_catchment_path', 'original_gsim_latitude', 'original_gsim_longitude', 'baseline_reach_scope_review_signal', 'unresolved_agency_area_signal_after_registered_input_correction']
    reg = pd.read_csv(regpath, usecols=regcols, low_memory=False).set_index('station_id')
    forcingpath = _PROJECT_ROOT / 'data/meteorology/catchment_forcing/global_catchment_forcing_1994_2025.npz'
    wp = _PROJECT_ROOT / 'data/meteorology/catchment_forcing/global_catchment_grid_weights.npz'
    gp = _PROJECT_ROOT / 'data/meteorology/catchment_forcing/catchment_geometry_audit.csv'
    wm = _PROJECT_ROOT / 'data/meteorology/catchment_forcing/weight_manifest.json'
    bind(forcingpath, 'original screened forcing crosscheck against master')
    wh = bind(wp, 'screened full basin grid weights')
    bind(gp, 'original screened full catchment geometry audit')
    bind(wm, 'grid weight provenance')
    fz = np.load(forcingpath, allow_pickle=False)
    fids = fz['station_ids'].astype(str)
    fp = {s: i for i, s in enumerate(fids)}
    fvals = fz['values'][:, :, list(fz['variable_names'].astype(str)).index('tp')]
    weights = sparse.load_npz(wp).tocsr()
    geometry = pd.read_csv(gp).set_index('station_id')
    assert weights.shape == (len(fids), 1801 * 3600)
    pending = []
    bound = []
    for i, r in c.iterrows():
        sid = r.station_id
        start = int(r.history_start)
        end = int(r.gap_end) + 3
        assert start >= 0 and end <= 435
        if sid in oldpos:
            j = oldpos[sid]
            x[i] = old['precip_mm_month'][j]
            admit[i] = bool(old['admission_mask'][j])
            warn[i] = bool(old['geometry_warning_mask'][j])
            origins[i] = 'previous8898_admitted' if admit[i] else 'previous8898_pending'
            reasons[i] = str(ol.loc[sid, 'admission_reason'])
            notes[i] = 'Exact full435 replay; previous flags retained.'
            lineage.append(dict(row=i, station_id=sid, origin=origins[i], source_path=str(oldpath), source_row=j, source_first='1979-10', source_last='2015-12'))
            if admit[i]:
                continue
            pending.append(i)
            continue
        if sid in mp:
            q = reg.loc[sid]
            g = geometry.loc[sid]
            assert q.forcing_input_origin == 'original_screened_full_catchment'
            assert q.forcing_geometry_status == 'screened_full_catchment'
            assert sid in fp and np.array_equal(fvals[fp[sid]], mvals[mp[sid]], equal_nan=True)
            assert g.forcing_geometry_status == 'screened_full_catchment'
            assert str(g.reason) == 'source_quality_area_and_outlet_checks_pass'
            sub = weights[fp[sid]]
            ws = float(sub.astype(np.float64).sum())
            assert abs(ws - 1) < 3e-06
            coord_m = abs(GD.inv(r.longitude, r.latitude, q.original_gsim_longitude, q.original_gsim_latitude)[2])
            assert coord_m <= 10, (sid, coord_m)
            x[i, 171:] = mvals[mp[sid], :264]
            assert start >= 171 and np.isfinite(x[i, start:end]).all() and (x[i, start:end] >= 0).all()
            admit[i] = True
            warn[i] = flag(q.baseline_reach_scope_review_signal) | flag(q.unresolved_agency_area_signal_after_registered_input_correction)
            origins[i] = 'existing_verified_master_screened_full_catchment'
            reasons[i] = 'ADMITTED_existing_verified_geometry_weight_and_forcing_lineage_required_window_complete'
            notes[i] = 'Only1994-01..2015-12 populated; earlier unneeded months unknown; not an all435-complete record.'
            bound.append(dict(row=i, station_id=sid, master_row=mp[sid], forcing_row=fp[sid], forcing_path=str(forcingpath), master_path=str(masterpath), weight_path=str(wp), weight_sha256=wh, weight_row=fp[sid], weight_sum=ws, geometry_audit_path=str(gp), original_polygon_path=q.original_catchment_path, forcing_geometry_status=q.forcing_geometry_status, geometry_reason=g.reason, original_coordinate_distance_m=coord_m, required_start=periods[start], required_end=periods[end - 1], master_all384_tp_exact_match=True, agency_area_warning=flag(q.unresolved_agency_area_signal_after_registered_input_correction), reach_scope_warning=flag(q.baseline_reach_scope_review_signal), geometry_warning=bool(warn[i])))
            lineage.append(dict(row=i, station_id=sid, origin=origins[i], source_path=str(masterpath), source_row=mp[sid], source_first='1994-01', source_last='2015-12'))
        else:
            pending.append(i)
    assert len(bound) == 29 and sum((o == 'previous8898_admitted' for o in origins)) == 107
    write(pd.DataFrame(bound), 'bound_master29.csv')
    chars = GS / 'GSIM_catalog/GSIM_catchment_characteristics.csv'
    bind(chars, 'official static coordinates quality and area.meta (km2)')
    cat = pd.read_csv(chars, usecols=['gsim.no', 'long.org', 'lat.org', 'dist.km', 'area.meta', 'area.est', 'quality']).set_index('gsim.no')
    native_rows = []
    wrows = []
    wcols = []
    wvals = []
    native_i = []
    for i in pending:
        r = c.iloc[i]
        sid = r.station_id
        d = cat.loc[sid]
        poly = GS / 'GSIM_catchments' / f'{sid.lower()}.shp'
        rec = dict(row=i, station_id=sid, original_quality=d.quality, area_meta_km2=d['area.meta'], catalogue_outlet_offset_km=d['dist.km'], native_polygon_path=str(poly), native_layer=poly.stem, native_feature_indices='0', latitude=r.latitude, longitude=r.longitude, official_latitude=d['lat.org'], official_longitude=d['long.org'], crs='EPSG:4326', preliminary_geometry_pass=False)
        fails = []
        if origins[i] == 'previous8898_pending':
            rec['prior_rejection_reason'] = reasons[i]
            rec['geometry_status'] = 'PRESERVED_PREVIOUS_REJECTION'
            native_rows.append(rec)
            continue
        try:
            for ext in ['.shp', '.shx', '.dbf', '.prj']:
                bind(poly.with_suffix(ext), 'native static catchment geometry ' + sid)
            crs = CRS.from_wkt(poly.with_suffix('.prj').read_text())
            rec['crs_WGS84'] = crs.equals(CRS.from_epsg(4326), ignore_axis_order=True)
            rd = shapefile.Reader(str(poly))
            sr = list(rd.iterShapeRecords())
            rec['native_feature_indices'] = ';'.join(map(str, range(len(sr))))
            rec['native_identity_match'] = all((str(v.record.as_dict().get('FILENAME', '')).upper() == sid for v in sr))
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                geom = shapely.union_all([shape(v.shape.__geo_interface__) for v in sr])
            a = area(geom)
            rec['original_geometry_valid'] = geom.is_valid
            fixed = geom if geom.is_valid else shapely.make_valid(geom)
            if fixed.geom_type == 'GeometryCollection':
                fixed = shapely.union_all([v for v in fixed.geoms if v.geom_type in ['Polygon', 'MultiPolygon']])
            fa = area(fixed)
            rec['fixed_geometry_valid'] = fixed.is_valid
            rec['geodesic_area_km2'] = a
            rec['repair_relative_area_change'] = abs(fa - a) / a
            pt = Point(r.longitude, r.latitude)
            dist = 0.0 if fixed.covers(pt) else abs(GD.inv(pt.x, pt.y, nearest_points(pt, fixed)[1].x, nearest_points(pt, fixed)[1].y)[2]) / 1000
            rec['target_to_polygon_km'] = dist
            rec['origin_coordinate_distance_m'] = abs(GD.inv(r.longitude, r.latitude, d['long.org'], d['lat.org'])[2])
            rec['area_relative_to_official_meta'] = abs(a - d['area.meta']) / d['area.meta'] if d['area.meta'] > 0 else np.nan
            if d.quality not in ['High', 'Medium']:
                fails.append('native_quality')
            if not rec['crs_WGS84'] or not rec['native_identity_match']:
                fails.append('identity_CRS')
            if rec['origin_coordinate_distance_m'] > 10:
                fails.append('origin_coordinate')
            if not d['dist.km'] <= 10 or not dist <= 10:
                fails.append('outlet_polygon_distance')
            if not rec['area_relative_to_official_meta'] <= 0.3:
                fails.append('official_area_meta')
            if not fixed.is_valid or not rec['repair_relative_area_change'] <= 1e-08:
                fails.append('valid_area_preserving_geometry')
            if not fails:
                j = len(native_i)
                _, wr, cols, values = build_one((j, SimpleNamespace(station_id=sid, original_GSIM_quality=d.quality, late_period_priority199=False, native_GSIM_polygon_path=str(poly))))
                rec['weight_status'] = wr['status']
                rec['geometric_grid_coverage'] = wr.get('geometric_grid_coverage', np.nan)
                rec['grid_cells'] = len(cols)
                if not len(cols) or not abs(rec['geometric_grid_coverage'] - 1) <= 1e-05:
                    fails.append('complete_grid_intersection')
                else:
                    native_i.append(i)
                    wrows.append(np.full(len(cols), j))
                    wcols.append(cols)
                    wvals.append(values)
                    rec['weight_row'] = j
            rec['preliminary_geometry_pass'] = not fails
            rec['geometry_status'] = 'PENDING_INDEPENDENT_QA' if not fails else 'PENDING:' + ';'.join(fails)
        except Exception as e:
            rec['geometry_status'] = 'PENDING:' + type(e).__name__ + ':' + str(e)[:180]
        native_rows.append(rec)
    nq = pd.DataFrame(native_rows)
    write(nq, 'native_geometry_qa.csv')
    assert len(native_i) <= 4
    if native_i:
        mat = sparse.coo_matrix((np.concatenate(wvals), (np.concatenate(wrows), np.concatenate(wcols))), shape=(len(native_i), 1801 * 3600)).tocsr()
        sparse.save_npz(_PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/native_grid_weights.npz', mat)
        nwh = bind(_PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/native_grid_weights.npz', 'new native geometry exact intersection weights')
        mat = mat.astype(np.float64)
        annual = _PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/native_annual'
        annual.mkdir(exist_ok=True)
        pp = {m: j for j, m in enumerate(periods)}
        raw = pd.read_csv(_PROJECT_ROOT / 'workflows/rainfall/global_inputs/final_inputs/precipitation_raw_source_manifest.csv')
        coverage = np.full((len(native_i), 435), np.nan, np.float32)
        needed = set()
        for i in native_i:
            r = c.iloc[i]
            needed.update((int(v[:4]) for v in periods[int(r.history_start):int(r.gap_end) + 3]))
        for year in sorted(needed):
            rr = raw[raw.year.eq(year)].iloc[0]
            rp = Path(rr.path)
            target = annual / f'tp_{year}.npz'
            if target.exists():
                zz = np.load(target, allow_pickle=False)
                assert str(zz['weight_sha256']) == nwh
                months = zz['periods'].astype(str)
                vals = zz['precip_mm_month']
                cov = zz['valid_area_fraction']
            else:
                rh = sha(rp)
                assert rh == rr.sha256
                months, vals, cov = extract(rp, mat)
                np.savez_compressed(target, station_ids=c.iloc[native_i].station_id.to_numpy(str), periods=months.astype(str), precip_mm_month=vals, valid_area_fraction=cov, weight_sha256=np.array(nwh), raw_sha256=np.array(rh))
                print('native rainfall extracted', year, flush=True)
            manifest.append(dict(path=str(rp), role=f'ERA5-Land original monthly means {year}', sha256=rr.sha256, bytes=rp.stat().st_size, mtime_ns=rp.stat().st_mtime_ns))
            for j, m in enumerate(months):
                if m in pp:
                    x[native_i, pp[m]] = vals[:, j]
                    coverage[:, pp[m]] = cov[:, j]
        np.savez_compressed(_PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/native_monthly_coverage.npz', station_ids=c.iloc[native_i].station_id.to_numpy(str), periods=periods, valid_area_fraction=coverage)
        for j, i in enumerate(native_i):
            r = c.iloc[i]
            a = int(r.history_start)
            b = int(r.gap_end) + 3
            complete = bool(np.isfinite(x[i, a:b]).all() and (x[i, a:b] >= 0).all() and np.all(coverage[j, a:b] >= 0.95))
            origins[i] = 'native_GSIM_HighMedium_candidate'
            reasons[i] = 'PENDING_INDEPENDENT_NATIVE_QA' if complete else 'PENDING_required_valid_ERA5_area_below95pct_or_missing'
            notes[i] = 'Native static geometry passes frozen rules; admission awaits independent QA.'
            nq.loc[nq.row.eq(i), 'required_window_precipitation_complete'] = complete
            nq.loc[nq.row.eq(i), 'required_window_min_valid_area'] = float(np.nanmin(coverage[j, a:b]))
            nq.loc[nq.row.eq(i), 'required_first_precip_month'] = periods[a]
            nq.loc[nq.row.eq(i), 'required_last_precip_month'] = periods[b - 1]
            lineage.append(dict(row=i, station_id=r.station_id, origin=origins[i], source_path=str(_PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/native_grid_weights.npz'), source_row=j, source_first=periods[np.flatnonzero(np.isfinite(x[i]))[0]], source_last=periods[np.flatnonzero(np.isfinite(x[i]))[-1]]))
        write(nq, 'native_geometry_qa.csv')
    d = c.copy()
    d['input_origin'] = origins
    d['admission_mask'] = admit
    d['admission_reason'] = reasons
    d['geometry_warning'] = warn
    d['notes'] = notes
    d['required_precip_first_month'] = [periods[int(v)] for v in c.history_start]
    d['required_precip_last_month'] = [periods[int(v) + 2] for v in c.gap_end]
    d['required_window_complete'] = [bool(np.isfinite(x[i, int(r.history_start):int(r.gap_end) + 3]).all() and (x[i, int(r.history_start):int(r.gap_end) + 3] >= 0).all()) for i, r in c.iterrows()]
    d['all435_complete'] = np.isfinite(x).all(axis=1) & (x >= 0).all(axis=1)
    assert d.loc[d.admission_mask, 'required_window_complete'].all()
    write(d, 'admission_PENDING_NATIVE_QA.csv')
    write(pd.DataFrame(lineage), 'lineage.csv')
    write(pd.DataFrame(manifest).drop_duplicates('path'), 'source_manifest.csv')
    np.savez_compressed(_PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/precipitation_PENDING_NATIVE_QA.npz', station_ids=c.station_id.to_numpy(str), periods=periods, precip_mm_month=x, admission_mask=admit, geometry_warning_mask=warn, required_window_complete=d.required_window_complete.to_numpy(bool), all435_complete=d.all435_complete.to_numpy(bool), calendar_index_1980=np.arange(-3, 432, dtype=np.int32), units=np.array('mm/month'), product=np.array('ERA5-Land/monthly_averaged_reanalysis'))
    summary = dict(status='PREPARED_PENDING_INDEPENDENT_NATIVE_QA', n=141, old_admitted=107, master29_bound=len(bound), current_admitted=int(admit.sum()), native_geometry_candidates=len(native_i), unadmitted=int((~admit).sum()), target_flow_values_read=False, GRDC_truth_read=False, predictions_or_scores_read=False, case_sha256=sha(cp), input_array_sha256=sha(_PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/precipitation_PENDING_NATIVE_QA.npz'), source_files_modified=False)
    (_PROJECT_ROOT / 'workflows/validation/natural_gaps/inputs_precip/PREPARATION_COMPLETE.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
if __name__ == '__main__':
    main()
