"""Read-only evidence extraction from frozen predictions' existing scores.
No refitting, hyperparameter search, source selection or prediction changes.
"""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import json, hashlib, sys
import numpy as np
import pandas as pd
HERE = _PROJECT_ROOT / 'workflows/validation/common_metrics'
STUDY_DATA = _PROJECT_ROOT / 'data/study_inputs'
SRC = _PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis'
GRDC = _PROJECT_ROOT / 'workflows/validation/natural_gaps/analysis'

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs = [SRC / x for x in ['summary_by_group.csv', 'paired_bootstrap.csv', 'new_lost_counts.csv', 'gradient_interactions.csv', 'scores_long.csv.gz', 'bootstrap_draws.npz']]
inputs += [GRDC / x for x in ['scores_long.csv.gz', 'bootstrap_spatial_cell_draws.npz']]
manifest = {str(p): sha(p) for p in inputs}
s = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/summary_by_group.csv', keep_default_na=False)
p = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/paired_bootstrap.csv', keep_default_na=False)
t = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/new_lost_counts.csv', keep_default_na=False)
it = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/gradient_interactions.csv', keep_default_na=False)
z = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/scores_long.csv.gz', keep_default_na=False, na_values=[''])
main = s[(s.subset == 'P_admitted') & (s.method == 'ridge')].copy()
main.to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_primary_NSE_and_r_gradient.csv', index=False)
p[(p.subset == 'P_admitted') & (p.method == 'ridge')].to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_primary_all_paired_effects.csv', index=False)
t[(t.subset == 'P_admitted') & (t.method == 'ridge')].to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_primary_new_lost.csv', index=False)
it[(it.subset == 'P_admitted') & (it.method == 'ridge')].to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_primary_gradient_interactions.csv', index=False)
s[s.subset == 'all_mothers'].to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_all8898_sensitivity.csv', index=False)
s[(s.subset == 'P_admitted') & (s.method == 'rbf_ridge')].to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_fixed_RBF_sensitivity.csv', index=False)
p[(p.subset == 'P_admitted') & (p.method == 'rbf_ridge')].to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_fixed_RBF_paired_effects.csv', index=False)
bs = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/source_distance/analysis/bootstrap_draws.npz')
names = bs['spatial_cells'].astype(str)
draws = bs['draws']
lookup = {x: i for i, x in enumerate(names)}
base = z[(z.method == 'ridge') & (z.arm == 'Q') & (z.D == 0)].sort_values('row').reset_index(drop=True)
assert len(base) == 8898 and int(base.P_available.sum()) == 8083
cells = np.array([lookup[x] for x in base.spatial_cell.astype(str)])
admit = base.P_available.to_numpy(bool)
cv = base.continent.astype(str).to_numpy()

def boot_means(values, mask):
    v = np.asarray(values, float)
    mask = np.asarray(mask, bool) & np.isfinite(v)
    numerator = np.bincount(cells[mask], weights=v[mask], minlength=len(names))
    denominator = np.bincount(cells[mask], minlength=len(names))
    den = draws @ denominator
    return np.divide(draws @ numerator, den, out=np.full(len(draws), np.nan), where=den > 0)

def model(D, arm='Q', method='ridge'):
    zz = z[(z.method == method) & (z.arm == arm) & (z.D == D)].sort_values('row').reset_index(drop=True)
    assert np.array_equal(zz.row.to_numpy(), base.row.to_numpy())
    return zz
continent_rows = []
direct = []
recalc_errors = []
components = []
transitions = []
for D in [0, 100, 300, 800]:
    q = model(D)
    qp = model(D, 'QP')
    for metric in ['nse_success', 'r07_pass']:
        gains = qp[metric].to_numpy(float) - q[metric].to_numpy(float)
        for c in sorted(np.unique(cv)):
            mask = admit & (cv == c)
            v = 100 * gains[mask]
            b = 100 * boot_means(gains, mask)
            ci = np.nanquantile(b, [0.025, 0.975])
            row = dict(D=D, continent=c, metric=metric, n=int(mask.sum()), n_spatial_cells=int(np.unique(cells[mask]).size), Q_pass=int(q.loc[mask, metric].sum()), QP_pass=int(qp.loc[mask, metric].sum()), new=int(((gains == 1) & mask).sum()), lost=int(((gains == -1) & mask).sum()), net_pp=float(v.mean()), ci025=float(ci[0]), ci975=float(ci[1]))
            continent_rows.append(row)
            ref = p[(p.D == D) & (p.method == 'ridge') & (p.contrast == 'added_precipitation') & (p.subset == 'continent_P_admitted') & (p.stratum == c) & (p.metric == metric)].iloc[0]
            recalc_errors.append(max(abs(row['net_pp'] - float(ref.mean_gain)), abs(row['ci025'] - float(ref.mean_gain_ci025)), abs(row['ci975'] - float(ref.mean_gain_ci975))))
        for c1, c2 in [('Europe', 'Asia'), ('Europe', 'Africa'), ('Asia', 'Africa')]:
            a = admit & (cv == c1)
            b = admit & (cv == c2)
            ba = boot_means(gains, a)
            bb = boot_means(gains, b)
            bd = 100 * (ba - bb)
            ci = np.nanquantile(bd, [0.025, 0.975])
            direct.append(dict(D=D, metric=metric, continent_A=c1, continent_B=c2, n_A=int(a.sum()), n_B=int(b.sum()), gain_A_pp=float(100 * gains[a].mean()), gain_B_pp=float(100 * gains[b].mean()), difference_pp=float(100 * (gains[a].mean() - gains[b].mean())), difference_ci025=float(ci[0]), difference_ci975=float(ci[1]), valid_paired_bootstrap_draws=int(np.isfinite(bd).sum()), interpretation='Difference of within-continent net increments, same 2000 global spatial resamples; conditional experimental cohorts, not natural gaps'))
    use = admit & q.eligible.to_numpy(bool)
    c = dict(D=D, n=8083, n_evaluable=int(use.sum()), support_months=int(q.loc[admit, 'support_months'].sum()), n_full120_supported=int(q.loc[admit, 'full120_supported'].sum()))
    for metric in ['r', 'H_deseasonal_r', 'NSE', 'alpha', 'delta', 'absolute_alpha_error', 'absolute_delta_error']:
        x = q.loc[use, metric].to_numpy(float)
        c[metric + '_median'] = float(np.nanmedian(x))
        c[metric + '_mean'] = float(np.nanmean(x))
    c.update(unevaluable=int((admit & ~q.eligible.to_numpy(bool)).sum()), below_r_requirement=int((use & (q.r.to_numpy() < np.sqrt(0.5))).sum()), r_sufficient_NSE_below_threshold=int((use & (q.r.to_numpy() >= np.sqrt(0.5)) & (q.NSE.to_numpy() < 0.5)).sum()), NSE_above_threshold_not_better_than_seasonal=int((use & (q.NSE.to_numpy() >= 0.5) & ~q.nse_success.to_numpy(bool)).sum()), success=int((admit & q.nse_success.to_numpy(bool)).sum()))
    assert sum((c[k] for k in ['unevaluable', 'below_r_requirement', 'r_sufficient_NSE_below_threshold', 'NSE_above_threshold_not_better_than_seasonal', 'success'])) == 8083
    components.append(c)
    baseline = base.nse_success.to_numpy(bool)
    new = q.nse_success.to_numpy(bool)
    transitions.append(dict(D=D, n=8083, retained=int((admit & baseline & new).sum()), lost=int((admit & baseline & ~new).sum()), gained=int((admit & ~baseline & new).sum()), neither=int((admit & ~baseline & ~new).sum()), baseline_success=int((admit & baseline).sum()), current_success=int((admit & new).sum())))
    finite = use & np.isfinite(q.r) & np.isfinite(q.alpha) & np.isfinite(q.delta) & np.isfinite(q.NSE)
    np.testing.assert_allclose(q.loc[finite, 'NSE'], 2 * q.loc[finite, 'r'] * q.loc[finite, 'alpha'] - q.loc[finite, 'alpha'] ** 2 - q.loc[finite, 'delta'] ** 2, atol=1e-08, rtol=1e-08)
pd.DataFrame(continent_rows).to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/continent_increments_NSE_and_r.csv', index=False)
pd.DataFrame(direct).to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/direct_between_continent_increment_contrasts.csv', index=False)
pd.DataFrame(components).to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_Q_component_diagnostics.csv', index=False)
pd.DataFrame(transitions).to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_Q_success_transitions.csv', index=False)
model(800)[admit].to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_Q_D800_all8083_station_scores.csv.gz', index=False)
model(0)[admit].to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_Q_D0_all8083_station_scores.csv.gz', index=False)
q8 = model(800)
qp8 = model(800, 'QP')
map8 = q8.copy()
map8 = map8.rename(columns={c: 'Q_' + c for c in ['nse_success', 'r07_pass', 'NSE', 'r', 'eligible']})
for metric in ['nse_success', 'r07_pass', 'NSE', 'r', 'eligible']:
    map8['QP_' + metric] = qp8[metric]
map8['NSE_success_change'] = qp8.nse_success.astype(int) - q8.nse_success.astype(int)
map8['map_status'] = np.select([~admit, map8.NSE_success_change.eq(1), map8.NSE_success_change.eq(-1), q8.nse_success], ['P_not_admitted', 'newly_successful', 'lost_success', 'both_successful'], default='both_below_criterion')
map8.to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_D800_Q_QP_map_all8898.csv.gz', index=False)
map8[admit].to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_D800_Q_QP_map_P8083.csv.gz', index=False)
g = pd.read_csv(_PROJECT_ROOT / 'workflows/validation/natural_gaps/analysis/scores_long.csv.gz', keep_default_na=False, na_values=[''])
g = g[g['mask'] == 'physical_gap'].copy()
gb = g[(g.method == 'seasonal') & (g.arm == 'baseline')].sort_values('row').reset_index(drop=True)
gq = g[(g.method == 'ridge') & (g.arm == 'Q')].sort_values('row').reset_index(drop=True)
gp = g[(g.method == 'ridge') & (g.arm == 'QP')].sort_values('row').reset_index(drop=True)
assert len(gb) == len(gq) == len(gp) == 141
gh = gq.target_estimable_fixed_rule.to_numpy(bool)
assert gh.sum() == 102
gr = []
for name, gm in [('flow', gq), ('flow_precipitation', gp), ('seasonal', gb)]:
    for group, mask in [('all141', np.ones(141, bool)), ('H60_estimable102', gh)]:
        numeric = gm.numeric_eligible.to_numpy(bool) & (gm.NSE.to_numpy(float) >= 0.5)
        strict = gm.eligible.to_numpy(bool) & (gm.NSE.to_numpy(float) >= 0.5) & (gm.NSE.to_numpy(float) > gb.NSE.to_numpy(float))
        row = dict(method=name, group=group, n=int(mask.sum()), evaluable=int((mask & gm.numeric_eligible.to_numpy(bool)).sum()), numeric_NSE_ge05_count=int((mask & numeric).sum()), numeric_NSE_ge05_pct=float(100 * np.mean(numeric[mask])), compound_success_count=None if name == 'seasonal' else int((mask & strict).sum()), compound_success_pct=None if name == 'seasonal' else float(100 * np.mean(strict[mask])), NSE_median=float(np.nanmedian(gm.loc[mask & gm.numeric_eligible.to_numpy(bool), 'NSE'])), r_median=float(np.nanmedian(gm.loc[mask & gm.numeric_eligible.to_numpy(bool), 'r'])))
        gr.append(row)
pd.DataFrame(gr).to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/GRDC_same_NSE_gate.csv', index=False)
manifest_after = {str(p): sha(p) for p in inputs}
assert manifest == manifest_after
assert max(recalc_errors) < 1e-10, max(recalc_errors)
qa = {'all_frozen_input_sha256': manifest, 'frozen_inputs_unchanged': True, 'models': False, 'new_computation': 'Only aggregation and direct between-continent bootstrap contrasts of already frozen station scores, plus an NSE gate applied to frozen real-gap scores', 'continent_reaggregation_max_absolute_difference_from_existing_summaries': max(recalc_errors), 'NSE_component_identity_checked': True, 'all_8083_component_classes_sum_to_mother': True, 'bootstrap_replicates': 2000, 'global_spatial_cells': len(names), 'GRDC_primary_mask': 'physical_gap', 'GRDC_history_eligible_mother': 102}
(_PROJECT_ROOT / 'workflows/validation/common_metrics/FULL_REVIEW_METRIC_QA.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf8')
print('COMPLETE; continent max reaggregation difference', max(recalc_errors))
print(pd.DataFrame(continent_rows).query('D==800').to_string(index=False))
print(pd.DataFrame(direct).query('D==800').to_string(index=False))
print(pd.DataFrame(components).to_string(index=False))
print(pd.DataFrame(gr).to_string(index=False))
