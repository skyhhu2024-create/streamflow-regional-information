"""Independent arithmetic audit of frozen scores and actual support; no fitting."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import hashlib, json
import numpy as np
import pandas as pd
E = _PROJECT_ROOT / 'workflows/validation/common_metrics'
X = _PROJECT_ROOT / 'data/study_inputs'
Q = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', mmap_mode='r')

def tab(p):
    return pd.read_csv(p, keep_default_na=False, na_values=[''])

def score(y, p, fit, support):
    y = np.asarray(y, float)
    p = np.asarray(p, float)
    fit = np.asarray(fit, bool)
    support = np.asarray(support, bool)
    den = ((y - y.mean(-1, keepdims=True)) ** 2).sum(-1)
    good = np.isfinite(y).all(-1) & (y >= 0).all(-1) & (den > 0) & np.isfinite(p).all(-1) & (p >= 0).all(-1)
    nse = 1 - np.divide(((y - p) ** 2).sum(-1), den, out=np.full(den.shape, np.nan), where=den > 0)
    return (nse, good & fit & support.any(-1))
report = {}
root = _PROJECT_ROOT / 'workflows/monitoring/single_location'
P = _PROJECT_ROOT / 'workflows/monitoring/single_location/final_predictions'
b = tab(_PROJECT_ROOT / 'workflows/monitoring/single_location/analysis/final_results/baseline_target_metrics.csv').sort_values('row')
a = tab(_PROJECT_ROOT / 'workflows/monitoring/single_location/analysis/final_results/all_selected_target_metrics.csv.gz')
y = np.asarray(Q[np.ix_(b.raw_index.to_numpy(int), np.arange(396, 420))], float)
sn = tab(_PROJECT_ROOT / 'workflows/validation/common_metrics/single_location_history_seasonal_NSE.csv').sort_values('row').seasonal_NSE.to_numpy(float)
pred = np.load(_PROJECT_ROOT / 'workflows/monitoring/single_location/final_predictions/baseline.npy')
fit = np.load(_PROJECT_ROOT / 'workflows/monitoring/single_location/final_predictions/baseline_fit.npy')
support = np.load(_PROJECT_ROOT / 'workflows/monitoring/single_location/final_predictions/baseline_support.npy')
nse, elig = score(y, pred, fit, support)
np.testing.assert_allclose(nse, b.NSE, rtol=1e-11, atol=1e-11)
np.testing.assert_array_equal(elig, b.eligible)
bp = elig & (nse >= 0.5) & (nse > sn)
targetfit = np.load(_PROJECT_ROOT / 'workflows/monitoring/single_location/final_predictions/target_estimable.npy')
pos = np.load(_PROJECT_ROOT / 'workflows/monitoring/single_location/final_predictions/candidate_positions.npy')[0]
frozen = {mode: (np.load(P / f'{mode}_predictions.npy'), np.load(P / f'{mode}_support.npy')) for mode in ['gated', 'forced']}
summ = tab(_PROJECT_ROOT / 'workflows/validation/common_metrics/single_location_all_NSE.csv')
check = []
for (rule, mode), d in a.groupby(['selection_rule', 'use_mode']):
    d = d.sort_values('row')
    j = int(np.flatnonzero(pos == d.candidate_position.iloc[0])[0])
    pp, ss = frozen[mode]
    nn, ee = score(y, pp[:, j], targetfit, ss[:, j])
    np.testing.assert_allclose(nn, d.NSE, rtol=1e-11, atol=1e-11)
    np.testing.assert_array_equal(ee, d.eligible)
    success = ee & (nn >= 0.5) & (nn > sn)
    r = summ[(summ.selection_rule == rule) & (summ.use_mode == mode)].iloc[0]
    assert int(success.sum()) == r.added_count and int(bp.sum()) == r.base_count
    assert int((success & ~bp).sum()) == r.new_count and int((~success & bp).sum()) == r.lost_count
    assert not (success & ~ee).any()
    check.append({'rule': rule, 'mode': mode, 'n': len(d), 'success': int(success.sum()), 'no_actual_support': int((~ss[:, j].any(1)).sum()), 'fallback_success': int((success & ~ss[:, j].any(1)).sum())})
report['single'] = {'full_precision_NSE_and_actual_eligibility_reproduced': True, 'all_frozen_selections': check}
root = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60'
J = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation_complete/filtered_inputs/layouts'
B = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background'
c = tab(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/cases.csv')
y = np.asarray(Q[np.ix_(c.raw_index.to_numpy(int), np.arange(240, 264))], float)
bs = np.load(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation_complete/filtered_inputs/layouts/baseline_metrics.npz')
strict = bs['identity_strict']
met = np.load(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation_complete/filtered_inputs/layouts/metrics.npy')
used = np.load(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation_complete/filtered_inputs/layouts/new_channel_used.npy')
fit = np.load(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/fit.npy')
sp = np.load(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/support.npy')
season = np.load(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/seasonal.npy')
sn, _ = score(y, season, np.ones(len(c), bool), np.ones_like(season, bool))
base_actual = fit & sp.any(1)
base_pass = strict & base_actual & (bs['metrics'][:, 1] >= 0.5) & (bs['metrics'][:, 1] > sn)
pred32 = np.stack([np.load(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation_complete/filtered_inputs/layouts/blocks' / f'target_{i:05d}.npz')['predictions'] for i in range(len(c))])
yn = np.broadcast_to(y[:, None, :], pred32.shape)
ss = np.broadcast_to((base_actual[:, None] | used)[:, :, None], pred32.shape)
nn, ee = score(yn, pred32, np.broadcast_to(strict[:, None], used.shape), ss)
p32 = ee & (nn >= 0.5) & (nn > sn[:, None])
p64 = strict[:, None] & (base_actual[:, None] | used) & (met[:, :, 1] >= 0.5) & (met[:, :, 1] > sn[:, None])
np.testing.assert_array_equal(p32, p64)
no_support = ~(base_actual[:, None] | used)
assert not (p64 & no_support).any()
summary = tab(_PROJECT_ROOT / 'workflows/validation/common_metrics/shared_layout_all_NSE.csv')
meta = tab(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation_complete/filtered_inputs/layouts/summary_by_candidate_or_layout_and_continent.csv')[['arm', 'arm_index']].drop_duplicates()
for arm, idx in meta.itertuples(index=False):
    rr = summary[summary.selection_rule == arm].iloc[0]
    assert p64[:, idx].sum() == rr.added_count and base_pass.sum() == rr.base_count
    assert (p64[:, idx] & ~base_pass).sum() == rr.new_count
    assert (~p64[:, idx] & base_pass).sum() == rr.lost_count
finite = np.isfinite(nn) & np.isfinite(met[:, :, 1])
report['joint'] = {'all_24_arms_checked': True, 'n_strict': int(strict.sum()), 'float32_saved_prediction_success_matches_float64_frozen_score_success': True, 'score_max_absolute_float32_difference': float(np.max(np.abs(nn[finite] - met[:, :, 1][finite]))), 'no_actual_support_arm_target_pairs': int(no_support[strict].sum()), 'fallback_success': int((p64 & no_support).sum()), 'baseline_success': int(base_pass.sum()), 'all_counts_and_transitions_reproduced': True}
report['models_refit'] = False
report['candidates_reselected'] = False
report['passed'] = True
(_PROJECT_ROOT / 'workflows/validation/common_metrics/INDEPENDENT_LOCATION_SCORE_QA.json').write_text(json.dumps(report, indent=2), encoding='utf8')
print(json.dumps(report, indent=2))
