"""Apply the common manuscript NSE gate to already frozen location predictions.
Selectors are NOT reoptimized for NSE. Only scoring/aggregation is harmonized.
"""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
HERE = _PROJECT_ROOT / 'workflows/validation/common_metrics'
V = _PROJECT_ROOT / 'data/study_inputs'
files = {}

def use(p):
    p = Path(p)
    files[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
    return p

def table(p):
    return pd.read_csv(use(p), keep_default_na=False, na_values=[''])

def array(p):
    return np.load(use(p), mmap_mode='r')

def bs_plan(cells, seed):
    names, idx = np.unique(np.asarray(cells, str), return_inverse=True)
    k = len(names)
    draws = np.random.default_rng(seed).multinomial(k, np.full(k, 1 / k), size=2000)
    return (names, idx, draws)

def bs_values(values, mask, idx, draws):
    values = np.asarray(values, float)
    ok = np.asarray(mask, bool) & np.isfinite(values)
    num = np.bincount(idx[ok], weights=values[ok], minlength=draws.shape[1])
    den = np.bincount(idx[ok], minlength=draws.shape[1])
    bd = draws @ den
    return np.divide(draws @ num, bd, out=np.full(len(draws), np.nan), where=bd > 0)

def effect(a, b, mask, idx, draws):
    a = np.asarray(a, bool)
    b = np.asarray(b, bool)
    m = np.asarray(mask, bool)
    gain = a.astype(float) - b.astype(float)
    bb = 100 * bs_values(gain, m, idx, draws)
    ci = np.nanquantile(bb, [0.025, 0.975])
    return dict(n=int(m.sum()), base_count=int((b & m).sum()), added_count=int((a & m).sum()), base_pct=float(100 * b[m].mean()), added_pct=float(100 * a[m].mean()), new_count=int((m & a & ~b).sum()), lost_count=int((m & ~a & b).sum()), net_pp=float(100 * gain[m].mean()), ci025=float(ci[0]), ci975=float(ci[1]))
groot = _PROJECT_ROOT / 'workflows/validation/natural_gaps/analysis'
g = table(_PROJECT_ROOT / 'workflows/validation/natural_gaps/analysis/scores_long.csv.gz')
g = g[g['mask'] == 'physical_gap']
q = g[(g.method == 'ridge') & (g.arm == 'Q')].sort_values('row').reset_index(drop=True)
qp = g[(g.method == 'ridge') & (g.arm == 'QP')].sort_values('row').reset_index(drop=True)
baseline = g[(g.method == 'seasonal') & (g.arm == 'baseline')].sort_values('row').reset_index(drop=True)
m = q.target_estimable_fixed_rule.to_numpy(bool)
assert m.sum() == 102
gd = q.loc[:, ['row', 'station_id', 'country', 'continent', 'spatial_cell', 'truth_months', 'target_estimable_fixed_rule', 'numeric_eligible', 'eligible', 'NSE', 'r']].copy()
gd = gd.rename(columns={'NSE': 'Q_NSE', 'r': 'Q_r', 'eligible': 'Q_eligible'})
gd['seasonal_NSE'] = baseline.NSE
gd['QP_NSE'] = qp.NSE
gd['paired_NSE_gain'] = q.NSE - baseline.NSE
gd['compound_Q_pass'] = q.eligible & (q.NSE >= 0.5) & (q.NSE > baseline.NSE)
gd['seasonal_numeric_NSE_ge05'] = baseline.numeric_eligible & (baseline.NSE >= 0.5)
gd[m].to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/GRDC_102_paired_NSE_for_figure.csv', index=False)
gb = np.load(use(_PROJECT_ROOT / 'workflows/validation/natural_gaps/analysis/bootstrap_spatial_cell_draws.npz'))
weights = gb['station_weights']
assert weights.shape == (2000, 141)
ok = m & q.eligible.to_numpy(bool) & baseline.numeric_eligible.to_numpy(bool) & np.isfinite(gd.paired_NSE_gain)
values = gd.paired_NSE_gain.to_numpy(float)
meanboot = weights[:, ok] @ values[ok] / weights[:, ok].sum(1)

def wmedian(v, w):
    order = np.argsort(v)
    v = v[order]
    w = np.asarray(w)[order]
    n = w.sum()
    c = np.cumsum(w)
    if not n:
        return np.nan
    lo = (n - 1) // 2 + 1
    hi = n // 2 + 1
    return 0.5 * (v[np.searchsorted(c, lo)] + v[np.searchsorted(c, hi)])
medboot = np.array([wmedian(values[ok], w[ok]) for w in weights])
grdc = dict(n_mother=102, n_pairs=int(ok.sum()), Q_NSE_median=float(np.median(q.loc[ok, 'NSE'])), seasonal_NSE_median=float(np.median(baseline.loc[ok, 'NSE'])), paired_mean_NSE_gain=float(np.mean(values[ok])), paired_mean_NSE_gain_ci025=float(np.quantile(meanboot, 0.025)), paired_mean_NSE_gain_ci975=float(np.quantile(meanboot, 0.975)), paired_median_NSE_gain=float(np.median(values[ok])), paired_median_NSE_gain_ci025=float(np.quantile(medboot, 0.025)), paired_median_NSE_gain_ci975=float(np.quantile(medboot, 0.975)), Q_compound_pass_count=int(gd.loc[m, 'compound_Q_pass'].sum()), seasonal_numeric_NSE_ge05_count=int(gd.loc[m, 'seasonal_numeric_NSE_ge05'].sum()), bootstrap_replicates=2000, bootstrap_source='Original spatial-cell station replication weights', NSE_gain_positive_count=int((values[ok] > 0).sum()), NSE_gain_negative_count=int((values[ok] < 0).sum()))
(_PROJECT_ROOT / 'workflows/validation/common_metrics/GRDC_NSE_paired_summary.json').write_text(json.dumps(grdc, indent=2), encoding='utf8')
sa_root = _PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_analysis'
sa = table(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_analysis/scores_long.csv.gz')
sa = sa[sa.method == 'ridge']
sa_b = sa[sa.arm == 'FULL_BASE'].sort_values('row').reset_index(drop=True)
sa_bs = np.load(use(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_analysis/bootstrap_spatial_cell_draws.npz'), allow_pickle=True)
names = sa_bs['spatial_cells'].astype(str)
draws = sa_bs['draws']
lookup = {x: i for i, x in enumerate(names)}
idx = np.array([lookup[x] for x in sa_b.spatial_cell.astype(str)])
mask = sa_b.country.eq('ZA').to_numpy()
assert mask.sum() == 80
sa_rows = []
for y, arm in [(0, 'FULL_BASE'), (2, 'FULL_H24'), (3, 'FULL_H36'), (5, 'FULL_H60')]:
    a = sa[sa.arm == arm].sort_values('row').reset_index(drop=True)
    ee = effect(a.nse_success, sa_b.nse_success, mask, idx, draws)
    sa_rows.append(dict(design='observed_external_SouthAfrica', years=y, arm=arm, **ee))
pd.DataFrame(sa_rows).to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/SouthAfrica_common_history_NSE.csv', index=False)
nr = _PROJECT_ROOT / 'workflows/monitoring/location_selection/analysis/long120'
na = table(_PROJECT_ROOT / 'workflows/monitoring/location_selection/analysis/long120/scores_long.csv.gz')
nb = table(_PROJECT_ROOT / 'workflows/monitoring/location_selection/analysis/long120/seasonal_baseline.csv').sort_values('row').reset_index(drop=True)
na = na[(na.method == 'ridge') & (na.inputs == 'QP')]
b = na[na.network == 'REDUCED'].sort_values('row').reset_index(drop=True)
a = na[na.network == 'NEAREST_60'].sort_values('row').reset_index(drop=True)
assert len(b) == len(a) == len(nb) == 8898
basepass = b.evaluable.to_numpy(bool) & (b.NSE >= 0.5) & (b.NSE > nb.NSE)
addpass = a.evaluable.to_numpy(bool) & (a.NSE >= 0.5) & (a.NSE > nb.NSE)
names, idx, draws = bs_plan(b.spatial_cell, 1691174963)
nearest = dict(design='targetwise_nearest', selection_rule='nearest_60', years=5, **effect(addpass, basepass, np.ones(8898, bool), idx, draws), bootstrap_seed=1691174963)
pd.DataFrame([nearest]).to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/nearest_location_NSE.csv', index=False)
jroot = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60'
j = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation_complete/filtered_inputs/layouts'
bg = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background'
jm = array(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation_complete/filtered_inputs/layouts/metrics.npy')
jb = np.load(use(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation_complete/filtered_inputs/layouts/baseline_metrics.npz'))
used = array(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation_complete/filtered_inputs/layouts/new_channel_used.npy')
jcases = table(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/cases.csv')
season = array(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/seasonal.npy')
fit = array(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/fit.npy')
support = array(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/support.npy')
strict = jb['identity_strict']
assert strict.sum() == 5905
qdata = np.load(use(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy'), mmap_mode='r')
truth = np.asarray(qdata[np.ix_(jcases.raw_index.to_numpy(int), np.arange(240, 264))], float)
den = ((truth - truth.mean(1)[:, None]) ** 2).sum(1)
den[np.all(truth == truth[:, :1], axis=1)] = 0
season_nse = 1 - np.divide(((truth - season) ** 2).sum(1), den, out=np.full(len(truth), np.nan), where=den > 0)
base_support = np.asarray(fit, bool) & np.asarray(support, bool).any(1)
bp = strict & base_support & (jb['metrics'][:, 1] >= 0.5) & (jb['metrics'][:, 1] > season_nse)
oldpred = array(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation_complete/filtered_inputs/layouts/success.npy')
np.testing.assert_array_equal(oldpred, strict[:, None] & (base_support[:, None] | used) & (jm[:, :, 0] > 0.7))
meta = table(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation_complete/filtered_inputs/layouts/summary_by_candidate_or_layout_and_continent.csv')[['arm', 'arm_index']].drop_duplicates().sort_values('arm_index')
subcells = jcases.loc[strict, 'spatial_cell'].astype(str).to_numpy()
cn = np.unique(subcells)
seed = int(hashlib.sha256(('|global1995|Global|pass_pp|' + ','.join(cn)).encode()).hexdigest()[:8], 16)
names, idxsub, draws = bs_plan(subcells, seed)
jointrows = []
jointflags = {}
for arm, ai in meta.itertuples(index=False):
    ap = strict & (base_support | used[:, ai]) & (jm[:, ai, 1] >= 0.5) & (jm[:, ai, 1] > season_nse)
    jointflags[arm] = ap[strict]
    jointrows.append(dict(design='shared_layout', selection_rule=arm, years=5, **effect(ap[strict], bp[strict], np.ones(5905, bool), idxsub, draws), bootstrap_seed=seed))
pd.DataFrame(jointrows).to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/shared_layout_all_NSE.csv', index=False)
jointcontrasts = []
for arm, ap in jointflags.items():
    if arm.startswith('RANDOM') and arm.endswith('_K50'):
        jointcontrasts.append(dict(design='shared_layout', main='CONDITIONAL_K50', comparator=arm, **effect(jointflags['CONDITIONAL_K50'], ap, np.ones(5905, bool), idxsub, draws)))
pd.DataFrame(jointcontrasts).to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/shared50_vs_random_direct_paired_NSE.csv', index=False)
dr = _PROJECT_ROOT / 'workflows/monitoring/single_location'
d = table(_PROJECT_ROOT / 'workflows/monitoring/single_location/analysis/final_results/all_selected_target_metrics.csv.gz')
b = table(_PROJECT_ROOT / 'workflows/monitoring/single_location/analysis/final_results/baseline_target_metrics.csv').sort_values('row').reset_index(drop=True)
tt = np.asarray(qdata[np.ix_(b.raw_index.to_numpy(int), np.arange(396, 420))], float)
hh = np.asarray(qdata[np.ix_(b.raw_index.to_numpy(int), np.arange(336, 396))], float)
assert np.isfinite(hh).all() and (hh >= 0).all()
rawcal = np.stack([hh[:, np.arange(60) % 12 == m].mean(1) for m in range(12)], axis=1)
season = rawcal[:, np.arange(24) % 12]
den = ((tt - tt.mean(1)[:, None]) ** 2).sum(1)
den[np.all(tt == tt[:, :1], axis=1)] = 0
bn = 1 - np.divide(((tt - season) ** 2).sum(1), den, out=np.full(len(tt), np.nan), where=den > 0)
pd.DataFrame({'row': b.row, 'station_id': b.station_id, 'seasonal_NSE': bn}).to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/single_location_history_seasonal_NSE.csv', index=False)
bp = b.eligible.to_numpy(bool) & (b.NSE >= 0.5) & (b.NSE > bn)
names, idx, draws = bs_plan(b.spatial_cell, 2026102607)
single = []
singleflags = {}
for (sel, mode), a in d.groupby(['selection_rule', 'use_mode'], sort=False):
    a = a.sort_values('row').reset_index(drop=True)
    assert np.array_equal(a.row, b.row)
    ap = a.eligible.to_numpy(bool) & (a.NSE >= 0.5) & (a.NSE > bn)
    singleflags[sel, mode] = ap
    single.append(dict(design='single_shared_location', selection_rule=sel, use_mode=mode, candidate_station_id=a.candidate_station_id.iloc[0], years=5, **effect(ap, bp, np.ones(5229, bool), idx, draws), bootstrap_seed=2026102607))
pd.DataFrame(single).to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/single_location_all_NSE.csv', index=False)
singlecontrasts = []
for (arm, mode), ap in singleflags.items():
    if arm.startswith('random_') and mode == 'gated':
        singlecontrasts.append(dict(design='single_shared_location', main='direct_gated', comparator=arm, **effect(singleflags['direct_gated', 'gated'], ap, np.ones(5229, bool), idx, draws)))
pd.DataFrame(singlecontrasts).to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/single_vs_random_direct_paired_NSE.csv', index=False)
joint_main = next((x for x in jointrows if x['selection_rule'] == 'CONDITIONAL_K50'))
joint_random = [x['net_pp'] for x in jointrows if x['selection_rule'].startswith('RANDOM') and x['selection_rule'].endswith('_K50')]
single_main = next((x for x in single if x['selection_rule'] == 'direct_gated' and x['use_mode'] == 'gated'))
single_random = [x['net_pp'] for x in single if x['selection_rule'].startswith('random_') and x['use_mode'] == 'gated']
mainloc = []
for row, rr in [(nearest, []), (joint_main, joint_random), (single_main, single_random)]:
    x = row.copy()
    x['random_min_pp'] = min(rr) if rr else np.nan
    x['random_max_pp'] = max(rr) if rr else np.nan
    mainloc.append(x)
pd.DataFrame(mainloc).to_csv(_PROJECT_ROOT / 'workflows/validation/common_metrics/location_primary_designs_NSE_for_figure.csv', index=False)
qa = {'source_files_sha256': files, 'no_model_refitting': True, 'no_candidate_reselection': True, 'criterion_status': 'Retrospective harmonization requested by review. Original shared selectors optimized the original r criterion, not the now-applied NSE gate.', 'nearest_baseline': 'Withheld-network QP, not intact FULL', 'single_seasonal_baseline': 'Arithmetic calendar means of the same observed H2008-2012, evaluated on G2013-2014. Baseline calculation only; frozen prediction/model files unchanged.', 'joint_float64_r_flags_reproduced': True, 'all_frozen_inputs_unchanged': all((hashlib.sha256(Path(k).read_bytes()).hexdigest() == h for k, h in files.items()))}
assert qa['all_frozen_inputs_unchanged']
(_PROJECT_ROOT / 'workflows/validation/common_metrics/LOCATION_NSE_HARMONIZATION_QA.json').write_text(json.dumps(qa, indent=2), encoding='utf8')
print('GRDC', grdc)
print(pd.DataFrame(sa_rows).to_string(index=False))
print(pd.DataFrame(mainloc).to_string(index=False))
