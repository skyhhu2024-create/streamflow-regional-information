"""Pre-siting covariance proxy; no file IO and no candidate-flow input.

The default representation is log1p(flow), minus pre-period calendar means,
divided by the station's pre-period anomaly SD.  It is NOT the raw-r outcome.
All covariance models have the form L @ L.T + diag(psi), with unit diagonals.

Public array APIs
-----------------
fit_pre_covariance(qpre_background, rank=24, max_iter=40) -> dictionary
    Observed-data factor-analysis EM; returns loadings, factors, psi, mean, sd,
    calendar_means, eligible, counts, month_counts and fitting diagnostics.
    Ineligible rows remain present as L=0, psi=1; always respect eligible.
fit_map(xyz, kg, log_area, loadings, psi, *, eligible=None, station_ids=None)
    Attribute-only Nystrom kernel ridge regression. xyz is unit-sphere N x 3;
    log_area is the natural logarithm of positive official drainage area.
predict_map(model, xyz, kg, log_area, *, station_ids=None, allow_seen=False)
    Returns predicted loadings, psi and eligible. Supplying station IDs on
    both sides enables an explicit train/prediction identity-overlap check.
conditional_gain_given_refs(...)
    Main wrapper for a weighted K4 composite, excluding target identity.
gain_given_condition(...)
    General small-condition-covariance Schur-complement implementation.

Gains are conditional variance reductions, NOT probabilities of raw r > .7.
Calendar dates, spatial folds, actual ridge fitting and G evaluation belong
to the caller. A spatial validation fold must be removed from BOTH factor
fitting and map fitting. Never fit this module to formal candidate flow.
Run this file with Python -B for synthetic-only checks (no files are written).
"""
from __future__ import annotations
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
import hashlib
import json
import math
from typing import Any
import numpy as np
EARTH_RADIUS_KM = 6371.0088
SPATIAL_SCALES_KM = (250.0, 1000.0, 4000.0)
MIN_PSI = 0.05

def spherical_xyz(latitude: np.ndarray, longitude: np.ndarray) -> np.ndarray:
    """Convert degrees to unit-sphere coordinates; invalid locations stay NaN."""
    lat, lon = np.broadcast_arrays(np.asarray(latitude, float), np.asarray(longitude, float))
    valid = np.isfinite(lat) & np.isfinite(lon) & (np.abs(lat) <= 90)
    p, q = (np.deg2rad(lat), np.deg2rad(lon))
    xyz = np.stack((np.cos(p) * np.cos(q), np.cos(p) * np.sin(q), np.sin(p)), -1)
    return np.where(valid[..., None], xyz, np.nan)

def _unit_covariance(loadings: np.ndarray, psi: np.ndarray, minpsi: float=MIN_PSI, *, mapped: bool=False):
    """Normalize without amplifying small mapped loadings.

    For mapped rows, unexplained loading energy becomes independent noise.
    In particular L=0 implies psi=1, regardless of predicted training psi.
    """
    L = np.asarray(loadings, float).copy()
    p = np.asarray(psi, float).copy()
    energy = np.einsum('ij,ij->i', L, L)
    if mapped:
        floor = np.clip(p, minpsi, 1.0)
        keep = np.minimum(energy, 1.0 - floor)
        scale = np.sqrt(np.divide(keep, energy, out=np.zeros_like(keep), where=energy > 0))
        L *= scale[:, None]
        p = 1.0 - keep
    else:
        total = energy + np.maximum(p, minpsi)
        L /= np.sqrt(total)[:, None]
        p = np.maximum(p, minpsi) / total
        too_small = p < minpsi
        if np.any(too_small):
            old_energy = np.einsum('ij,ij->i', L[too_small], L[too_small])
            L[too_small] *= np.sqrt((1.0 - minpsi) / old_energy)[:, None]
            p[too_small] = minpsi
    return (L, p)

def _estep(L, psi, observed, z_observed):
    """Exact Gaussian factor E-step using observed entries only.

    z_observed contains zero placeholders for absent contributions to sums;
    their masks also remove precision, logdet and sample-count contributions.
    It is never treated as a zero-imputed covariance matrix.
    """
    n, k = L.shape
    t = observed.shape[1]
    row_outer = (L[:, :, None] * L[:, None, :] / psi[:, None, None]).reshape(n, k * k)
    precision = (observed.T @ row_outer).reshape(t, k, k)
    precision += np.eye(k)[None, :, :]
    covariance = np.linalg.inv(precision)
    rhs = L.T @ (z_observed / psi[:, None])
    mu = np.einsum('tij,jt->it', covariance, rhs, optimize=True)
    sign, logdet = np.linalg.slogdet(precision)
    if np.any(sign <= 0):
        raise FloatingPointError('Factor posterior precision is not positive definite')
    quadratic = np.sum(z_observed * z_observed / psi[:, None], axis=0)
    quadratic -= np.sum(rhs * mu, axis=0)
    ll = -0.5 * np.sum(observed.sum(axis=0) * math.log(2 * math.pi) + observed.T @ np.log(psi) + logdet + quadratic)
    return (mu, covariance, float(ll))

def fit_pre_covariance(qpre_background: np.ndarray, rank: int=24, max_iter: int=40, *, minpsi: float=MIN_PSI, min_observed: int=24, deseasonalize: bool=True, start_month: int=1, tol: float=1e-05, chunk_size: int=2048) -> dict[str, Any]:
    """Fit observed-data factor analysis to background pre-period flow only.

    NaN/inf/negative values are absent. Default eligibility requires at least
    24 observations, >=2 observations in every calendar month, and a positive
    pre-anomaly SD. Calendar means alone do not imply covariance eligibility.
    EM maximizes the masked Gaussian likelihood with a fixed psi lower bound;
    the final covariance is row-normalized to variance one. factors are the
    posterior means under that final normalized covariance, not raw PCs.
    """
    q = np.asarray(qpre_background, dtype=float)
    if q.ndim != 2 or q.shape[1] < 2:
        raise ValueError('qpre_background must have shape (stations, pre_months>=2)')
    if rank < 1 or max_iter < 1 or (not 0 < minpsi < 1):
        raise ValueError('rank/max_iter must be positive and 0 < minpsi < 1')
    if not 1 <= start_month <= 12 or chunk_size < 1 or min_observed < 2:
        raise ValueError('Invalid start_month, chunk_size or min_observed')
    n, t = q.shape
    obs = np.isfinite(q) & (q >= 0)
    counts = obs.sum(axis=1)
    logq = np.full(q.shape, np.nan)
    logq[obs] = np.log1p(q[obs])
    sums = np.nansum(logq, axis=1)
    mean = np.divide(sums, counts, out=np.full(n, np.nan), where=counts > 0)
    month = (np.arange(t) + start_month - 1) % 12
    calendar_means = np.full((n, 12), np.nan)
    month_counts = np.zeros((n, 12), dtype=np.int32)
    for m in range(12):
        selected = month == m
        cm = obs[:, selected].sum(axis=1)
        month_counts[:, m] = cm
        calendar_means[:, m] = np.divide(np.nansum(logq[:, selected], axis=1), cm, out=np.full(n, np.nan), where=cm > 0)
    centered = logq - (calendar_means[:, month] if deseasonalize else mean[:, None])
    variance = np.divide(np.nansum(centered * centered, axis=1), counts, out=np.full(n, np.nan), where=counts > 0)
    sd = np.sqrt(variance)
    eligible = (counts >= min_observed) & np.isfinite(sd) & (sd > 1e-12)
    if deseasonalize:
        eligible &= np.all(month_counts >= 2, axis=1)
    indices = np.flatnonzero(eligible)
    Lall, pall = (np.zeros((n, rank)), np.ones(n))
    factors = np.zeros((rank, t))
    result = dict(loadings=Lall, factors=factors, psi=pall, mean=mean, sd=sd, calendar_means=calendar_means, eligible=eligible, counts=counts, month_counts=month_counts, rank=int(rank), effective_rank=0, deseasonalize=bool(deseasonalize), start_month=int(start_month), representation='pre_calendar_anomaly_log1p_standardized' if deseasonalize else 'pre_log1p_standardized', minpsi=float(minpsi), iterations=0, converged=False, log_likelihood_history=np.empty(0), final_normalized_log_likelihood=float('nan'))
    if not len(indices):
        return result
    k = min(rank, len(indices), t - 1)
    mask = obs[indices]
    z = np.where(mask, centered[indices] / sd[indices, None], 0.0)
    row_n = mask.sum(axis=1).astype(float)
    rng = np.random.default_rng(20261026)
    basis = rng.normal(size=(t, k))
    basis -= basis.mean(axis=0)
    basis = np.linalg.qr(basis, mode='reduced')[0].T * np.sqrt(t)
    L = z @ basis.T / row_n[:, None]
    energy = np.einsum('ij,ij->i', L, L)
    L *= np.sqrt(np.minimum(0.25 / np.maximum(energy, 1e-15), 1.0))[:, None]
    psi = np.maximum(minpsi, 1.0 - np.einsum('ij,ij->i', L, L))
    mu, cov, ll = _estep(L, psi, mask, z)
    history = [ll]
    converged = False
    for iteration in range(1, max_iter + 1):
        eff = cov + mu.T[:, :, None] * mu.T[:, None, :]
        newL, newpsi = (np.empty_like(L), np.empty_like(psi))
        for lo in range(0, len(indices), chunk_size):
            hi = min(lo + chunk_size, len(indices))
            a = (mask[lo:hi] @ eff.reshape(t, k * k)).reshape(hi - lo, k, k)
            b = z[lo:hi] @ mu.T
            a += 1e-10 * np.eye(k)[None, :, :]
            fitted = np.linalg.solve(a, b[..., None])[..., 0]
            newL[lo:hi] = fitted
            residual_ss = np.sum(z[lo:hi] ** 2, axis=1) - 2 * np.sum(fitted * b, axis=1) + np.einsum('bi,bij,bj->b', fitted, a, fitted, optimize=True)
            newpsi[lo:hi] = np.maximum(minpsi, residual_ss / row_n[lo:hi])
        L, psi = (newL, newpsi)
        mu, cov, newll = _estep(L, psi, mask, z)
        history.append(newll)
        change = newll - ll
        ll = newll
        if abs(change) <= tol * max(1.0, abs(history[-2])):
            converged = True
            break
    L, psi = _unit_covariance(L, psi, minpsi)
    mu, _, normalized_ll = _estep(L, psi, mask, z)
    Lall[indices, :k], pall[indices], factors[:k] = (L, psi, mu)
    result.update(effective_rank=k, iterations=iteration, converged=converged, log_likelihood_history=np.asarray(history), final_normalized_log_likelihood=normalized_ll)
    return result

def _attributes(xyz, kg, log_area, area_median=None):
    xyz = np.asarray(xyz, dtype=float)
    kg = np.asarray(kg).astype(str)
    area = np.asarray(log_area, dtype=float)
    if xyz.ndim != 2 or xyz.shape[1] != 3 or kg.shape != (len(xyz),) or (area.shape != kg.shape):
        raise ValueError('Expected xyz (N,3), kg (N,), log_area (N,)')
    norm = np.linalg.norm(xyz, axis=1)
    valid = np.all(np.isfinite(xyz), axis=1) & (norm > 1e-12)
    unit = np.divide(xyz, norm[:, None], out=np.zeros_like(xyz), where=valid[:, None])
    missing = ~np.isfinite(area)
    if area_median is None:
        finite_area = area[~missing & valid]
        area_median = float(np.median(finite_area)) if len(finite_area) else 0.0
    area = np.where(missing, area_median, area)
    return dict(xyz=unit, kg=kg, area=area, area_missing=missing.astype(float), valid=valid, area_median=float(area_median))

def _take_attributes(a, idx):
    return {key: value[idx] if isinstance(value, np.ndarray) else value for key, value in a.items()}

def _attribute_kernel(a, b):
    d2 = np.maximum(0.0, 2.0 - 2.0 * (a['xyz'] @ b['xyz'].T)) * EARTH_RADIUS_KM ** 2
    spatial = sum((np.exp(-0.5 * d2 / s ** 2) for s in SPATIAL_SCALES_KM)) / 3.0
    kg_kernel = 0.2 + 0.8 * (a['kg'][:, None] == b['kg'][None, :])
    da = a['area'][:, None] - b['area'][None, :]
    dm = a['area_missing'][:, None] - b['area_missing'][None, :]
    return spatial * kg_kernel * np.exp(-0.5 * (da * da + dm * dm))

def fit_map(xyz: np.ndarray, kg: np.ndarray, log_area: np.ndarray, loadings: np.ndarray, psi: np.ndarray, *, eligible=None, station_ids=None, n_landmarks: int=256, ridge: float=0.01, minpsi: float=MIN_PSI, chunk_size: int=2048) -> dict[str, Any]:
    """Fit attribute-only Nystrom KRR, mean-square loss + ridge*||beta||^2.

    Landmarks are the smallest SHA256 static-attribute hashes among all valid
    training rows: deterministic across row order, with no geographic radius.
    The caller must pass only eligible BACKGROUND training rows (or its mask).
    Predictors never include flow, factor scores, date-H/G data or record length.
    """
    L, p = (np.asarray(loadings, float), np.asarray(psi, float))
    if L.ndim != 2 or p.shape != (len(L),):
        raise ValueError('loadings/psi must have shapes (N,R), (N,)')
    n = len(L)
    raw_area = np.asarray(log_area, float)
    mask = np.ones(n, bool) if eligible is None else np.asarray(eligible, bool).copy()
    if mask.shape != (n,) or len(np.asarray(xyz)) != n:
        raise ValueError('Training attribute/loadings/eligible dimensions differ')
    mask &= np.all(np.isfinite(L), axis=1) & np.isfinite(p) & (p > 0)
    prelim = _attributes(xyz, kg, raw_area)
    mask &= prelim['valid']
    rows = np.flatnonzero(mask)
    if not len(rows) or n_landmarks < 1 or ridge <= 0:
        raise ValueError('Need eligible training rows, positive landmarks and ridge')
    med = float(np.median(raw_area[mask & np.isfinite(raw_area)])) if np.any(mask & np.isfinite(raw_area)) else 0.0
    attrs = _take_attributes(_attributes(xyz, kg, raw_area, med), rows)
    train_ids = None if station_ids is None else np.asarray(station_ids).astype(str)
    if train_ids is not None and train_ids.shape != (n,):
        raise ValueError('station_ids must have shape (N,)')
    keys = []
    for j, row in enumerate(rows):
        static = (tuple((float(v).hex() for v in attrs['xyz'][j])), str(attrs['kg'][j]), float(attrs['area'][j]).hex(), bool(attrs['area_missing'][j]))
        keys.append((hashlib.sha256(repr(static).encode('utf-8')).hexdigest(), str(train_ids[row]) if train_ids is not None else repr(static), j))
    chosen = np.array([item[2] for item in sorted(keys)[:min(n_landmarks, len(rows))]], int)
    landmarks = _take_attributes(attrs, chosen)
    w = _attribute_kernel(landmarks, landmarks)
    values, vectors = np.linalg.eigh((w + w.T) / 2)
    keep = values > max(float(values[-1]) * 1e-10, 1e-12)
    inverse_sqrt = vectors[:, keep] / np.sqrt(values[keep])[None, :]
    dim = inverse_sqrt.shape[1]
    y = np.column_stack((L[rows], np.log(np.clip(p[rows], minpsi, 1.0))))
    ymean = y.mean(axis=0)
    sum_phi, gram, cross = (np.zeros(dim), np.zeros((dim, dim)), np.zeros((dim, y.shape[1])))
    for lo in range(0, len(rows), chunk_size):
        hi = min(lo + chunk_size, len(rows))
        phi = _attribute_kernel(_take_attributes(attrs, slice(lo, hi)), landmarks) @ inverse_sqrt
        sum_phi += phi.sum(axis=0)
        gram += phi.T @ phi
        cross += phi.T @ (y[lo:hi] - ymean)
    phimean = sum_phi / len(rows)
    gram -= len(rows) * np.outer(phimean, phimean)
    beta = np.linalg.solve((gram + gram.T) / 2 + ridge * len(rows) * np.eye(dim), cross)
    return dict(landmarks=landmarks, inverse_sqrt=inverse_sqrt, beta=beta, feature_mean=phimean, response_mean=ymean, area_median=med, minpsi=float(minpsi), ridge=float(ridge), rank=L.shape[1], training_rows=rows, landmark_training_rows=rows[chosen], training_ids=None if train_ids is None else frozenset(train_ids[rows]), n_training=len(rows), n_landmarks=len(chosen), nystrom_rank=dim, kernel='mean_chord_RBF_250_1000_4000km_times_KG_times_logarea_missing_RBF', proxy_only=True)

def predict_map(model: dict[str, Any], xyz: np.ndarray, kg: np.ndarray, log_area: np.ndarray, *, station_ids=None, allow_seen: bool=False, chunk_size: int=2048) -> dict[str, np.ndarray]:
    """Predict unknown-site covariance from static attributes, never its flow.

    IDs are optional because the API accepts arrays. With IDs on both sides,
    overlap raises unless explicitly requesting a training diagnostic.
    """
    attrs = _attributes(xyz, kg, log_area, model['area_median'])
    n = len(attrs['xyz'])
    if station_ids is not None:
        ids = np.asarray(station_ids).astype(str)
        if ids.shape != (n,):
            raise ValueError('station_ids must have shape (N,)')
        if model['training_ids'] is not None and (not allow_seen):
            overlap = model['training_ids'].intersection(ids)
            if overlap:
                raise ValueError('Prediction identities occur in map training; spatial/candidate leakage')
    L, p = (np.zeros((n, model['rank'])), np.ones(n))
    rows = np.flatnonzero(attrs['valid'])
    predicted_logpsi = np.full(n, np.nan)
    for lo in range(0, len(rows), chunk_size):
        idx = rows[lo:lo + chunk_size]
        phi = _attribute_kernel(_take_attributes(attrs, idx), model['landmarks']) @ model['inverse_sqrt']
        pred = (phi - model['feature_mean']) @ model['beta'] + model['response_mean']
        pp = np.exp(np.clip(pred[:, -1], np.log(model['minpsi']), 0.0))
        L[idx], p[idx] = _unit_covariance(pred[:, :-1], pp, model['minpsi'], mapped=True)
        predicted_logpsi[idx] = pred[:, -1]
    return dict(loadings=L, psi=p, eligible=attrs['valid'].copy(), predicted_logpsi_before_unexplained_loading=predicted_logpsi, area_missing=attrs['area_missing'].astype(bool))

def _as_rows(L, psi, name):
    L, psi = (np.asarray(L, float), np.asarray(psi, float))
    if L.ndim == 1:
        L = L[None, :]
    psi = np.broadcast_to(psi, (len(L),)).copy()
    if L.ndim != 2 or np.any(~np.isfinite(L)) or np.any(~np.isfinite(psi)) or np.any(psi < 0):
        raise ValueError(f'{name} must contain finite loadings and nonnegative noise')
    return (L, psi)

def _batched_condition(a, nt, tail_ndim, name):
    a = np.asarray(a, float)
    if a.ndim == tail_ndim:
        a = np.broadcast_to(a, (nt,) + a.shape)
    if a.ndim != tail_ndim + 1 or a.shape[0] != nt or np.any(~np.isfinite(a)):
        raise ValueError(f'Invalid {name} shape/values')
    return a

def _psd_inverse(cov, name):
    cov = (cov + np.swapaxes(cov, -1, -2)) / 2
    eig, vec = np.linalg.eigh(cov)
    scale = np.maximum(np.max(np.abs(eig), axis=-1), 1.0)
    if np.any(eig < -1e-09 * scale[..., None]):
        raise ValueError(f'{name} must be positive semidefinite')
    cutoff = 1e-12 * scale[..., None]
    inv = np.divide(1.0, eig, out=np.zeros_like(eig), where=eig > cutoff)
    return vec * inv[..., None, :] @ np.swapaxes(vec, -1, -2)

def gain_given_condition(target_loadings, target_psi, condition_loadings, noise_cov, candidate_loadings, candidate_psi, *, target_condition_noise=None, candidate_condition_noise=None, target_candidate_noise=None, return_details: bool=False, chunk_size: int=64, output_dtype=np.float32):
    """Conditional variance reduction from adding each candidate separately.

    target_loadings: (T,R); candidate_loadings: (C,R).
    condition_loadings: (T,J,R) or common (J,R).
    noise_cov: (T,J,J) or common (J,J), the FULL PSD condition-noise covariance.
    Optional noise cross-covariances are target_condition_noise (T,J),
    candidate_condition_noise (T,J,C) or (J,C), target_candidate_noise (T,C).
    These are useful when a variable shares independent noise with a condition.
    Otherwise only the common latent factors correlate distinct variables.

    Returns (T,C) gain; with return_details also covariance, candidate conditional
    variance and target conditional variance. No clipping converts proxy to r.
    Chunk the candidates externally if retaining multiple global matrices.
    """
    lt, pt = _as_rows(target_loadings, target_psi, 'target')
    lc, pc = _as_rows(candidate_loadings, candidate_psi, 'candidate')
    nt, nc = (len(lt), len(lc))
    if lt.shape[1] != lc.shape[1] or chunk_size < 1:
        raise ValueError('Rank mismatch or invalid chunk_size')
    conditions = _batched_condition(condition_loadings, nt, 2, 'condition_loadings')
    noise = _batched_condition(noise_cov, nt, 2, 'noise_cov')
    nj = conditions.shape[1]
    if conditions.shape[2] != lt.shape[1] or noise.shape[1:] != (nj, nj):
        raise ValueError('Condition rank/noise dimensions differ')
    tn = np.zeros((nt, nj)) if target_condition_noise is None else np.asarray(target_condition_noise, float)
    if tn.shape != (nt, nj) or np.any(~np.isfinite(tn)):
        raise ValueError('target_condition_noise must be finite with shape (T,J)')
    cn = None if candidate_condition_noise is None else _batched_condition(candidate_condition_noise, nt, 2, 'candidate_condition_noise')
    if cn is not None and cn.shape[1:] != (nj, nc):
        raise ValueError('candidate_condition_noise must have shape (T,J,C) or (J,C)')
    tc = None if target_candidate_noise is None else np.asarray(target_candidate_noise, float)
    if tc is not None and (tc.shape != (nt, nc) or np.any(~np.isfinite(tc))):
        raise ValueError('target_candidate_noise must be finite with shape (T,C)')
    gain = np.empty((nt, nc), dtype=output_dtype)
    vc_all = np.empty_like(gain) if return_details else None
    cov_all = np.empty_like(gain) if return_details else None
    vt_all = np.empty(nt, dtype=output_dtype)
    base_vc = np.einsum('ij,ij->i', lc, lc) + pc
    for lo in range(0, nt, chunk_size):
        hi = min(lo + chunk_size, nt)
        cl = conditions[lo:hi]
        base_vt = np.einsum('ij,ij->i', lt[lo:hi], lt[lo:hi]) + pt[lo:hi]
        cross = lt[lo:hi] @ lc.T
        if tc is not None:
            cross += tc[lo:hi]
        if nj:
            _psd_inverse(noise[lo:hi], 'noise_cov')
            cc = cl @ np.swapaxes(cl, -1, -2) + noise[lo:hi]
            inverse = _psd_inverse(cc, 'condition covariance')
            yt = np.einsum('bjr,br->bj', cl, lt[lo:hi], optimize=True) + tn[lo:hi]
            yc = cl @ lc.T
            if cn is not None:
                yc += cn[lo:hi]
            beta = np.einsum('bij,bj->bi', inverse, yt, optimize=True)
            vt = base_vt - np.sum(yt * beta, axis=1)
            vc = base_vc[None, :] - np.sum(yc * (inverse @ yc), axis=1)
            cross -= np.einsum('bj,bjc->bc', beta, yc, optimize=True)
        else:
            vt, vc = (base_vt, np.broadcast_to(base_vc, cross.shape))
        if np.any(vt < -1e-08) or np.any(vc < -1e-08):
            raise ValueError('Inconsistent covariance gives negative conditional variance')
        vt, vc = (np.maximum(vt, 0), np.maximum(vc, 0))
        dg = np.divide(cross * cross, vc, out=np.zeros_like(cross), where=vc > 1e-12)
        if np.any(dg > vt[:, None] + 1e-07):
            raise ValueError('Joint covariance inconsistent: gain exceeds target variance')
        dg = np.minimum(dg, vt[:, None])
        gain[lo:hi], vt_all[lo:hi] = (dg, vt)
        if return_details:
            vc_all[lo:hi], cov_all[lo:hi] = (vc, cross)
    if not return_details:
        return gain
    return dict(gain=gain, conditional_covariance=cov_all, candidate_conditional_variance=vc_all, target_conditional_variance=vt_all)

def conditional_gain_given_refs(target_loadings, target_psi, background_loadings, background_psi, candidate_loadings, candidate_psi, *, ref_indices=None, ref_weights=None, target_background_indices=None, mode: str='composite', extra_condition_loadings=None, extra_condition_noise_cov=None, composite_extra_noise_cov=None, return_details: bool=False, chunk_size: int=64, output_dtype=np.float32):
    """Condition on the K4 weighted composite, with mandatory self exclusion.

    ref_indices is (T,K) or common (K,), padded by -1. Weights have the same
    shape; omitted weights are equal. Alternatively pass dense weights (T,Nb)
    without ref_indices. Weights must be nonnegative, and duplicates coalesce.
    target_background_indices is mandatory: use -1 only for genuinely external
    targets. Matching references are removed BEFORE weight normalization.
    Physical aliases must already have been collapsed by the caller.

    mode='individual' conditions jointly on each reference, NOT the composite.
    Extras can hold e.g. P0..3: their loadings and FULL residual noise covariance
    must already be in the same latent coordinate system. The optional cross
    noise block has shape (T,Jq,Jp) or (Jq,Jp). No P model is silently invented.
    """
    lt, pt = _as_rows(target_loadings, target_psi, 'target')
    lb, pb = _as_rows(background_loadings, background_psi, 'background')
    nt, nb, r = (len(lt), len(lb), lb.shape[1])
    if lt.shape[1] != r or mode not in ('composite', 'individual'):
        raise ValueError('Rank mismatch or invalid reference mode')
    if target_background_indices is None:
        raise ValueError('target_background_indices is required to exclude self')
    own = np.asarray(target_background_indices, int)
    if own.shape != (nt,) or np.any((own < -1) | (own >= nb)):
        raise ValueError('Invalid target_background_indices')
    if ref_indices is None:
        weights = np.asarray(ref_weights, float)
        if weights.shape != (nt, nb):
            raise ValueError('Without ref_indices, ref_weights must have shape (T,Nb)')
        indices = None
    else:
        indices = np.asarray(ref_indices, int)
        if indices.ndim == 1:
            indices = np.broadcast_to(indices, (nt, len(indices)))
        if indices.ndim != 2 or indices.shape[0] != nt or np.any((indices < -1) | (indices >= nb)):
            raise ValueError('Invalid ref_indices')
        weights = np.ones(indices.shape) if ref_weights is None else np.asarray(ref_weights, float)
        weights = np.broadcast_to(weights, indices.shape)
    if np.any(~np.isfinite(weights)) or np.any(weights < 0):
        raise ValueError('Reference weights must be finite and nonnegative')
    rows = []
    for i in range(nt):
        ids = np.arange(nb) if indices is None else indices[i]
        w = weights[i]
        good = (ids >= 0) & (ids != own[i]) & (w > 0)
        ids, w = (ids[good], w[good])
        if len(ids):
            unique, inverse = np.unique(ids, return_inverse=True)
            combined = np.bincount(inverse, weights=w, minlength=len(unique))
            rows.append((unique, combined / combined.sum()))
        else:
            rows.append((np.empty(0, int), np.empty(0)))
    jq = 1 if mode == 'composite' else max((len(x[0]) for x in rows), default=0)
    qL, qnoise = (np.zeros((nt, jq, r)), np.zeros((nt, jq, jq)))
    for i, (ids, w) in enumerate(rows):
        if mode == 'composite':
            qL[i, 0] = w @ lb[ids]
            qnoise[i, 0, 0] = np.sum(w * w * pb[ids])
        elif len(ids):
            k = len(ids)
            qL[i, :k] = w[:, None] * lb[ids]
            qnoise[i, np.arange(k), np.arange(k)] = w * w * pb[ids]
    if extra_condition_loadings is not None:
        eL = _batched_condition(extra_condition_loadings, nt, 2, 'extra_condition_loadings')
        jp = eL.shape[1]
        if eL.shape[2] != r or extra_condition_noise_cov is None:
            raise ValueError('Extras require matching rank and explicit noise covariance')
        en = _batched_condition(extra_condition_noise_cov, nt, 2, 'extra_condition_noise_cov')
        if en.shape[1:] != (jp, jp):
            raise ValueError('Extra condition noise shape differs')
        Lcond = np.concatenate((qL, eL), axis=1)
        ncond = np.zeros((nt, jq + jp, jq + jp))
        ncond[:, :jq, :jq], ncond[:, jq:, jq:] = (qnoise, en)
        if composite_extra_noise_cov is not None:
            cross = _batched_condition(composite_extra_noise_cov, nt, 2, 'composite_extra_noise_cov')
            if cross.shape[1:] != (jq, jp):
                raise ValueError('Extra cross-noise shape differs')
            ncond[:, :jq, jq:], ncond[:, jq:, :jq] = (cross, np.swapaxes(cross, -1, -2))
    else:
        if extra_condition_noise_cov is not None or composite_extra_noise_cov is not None:
            raise ValueError('Noise extras need extra_condition_loadings')
        Lcond, ncond = (qL, qnoise)
    return gain_given_condition(lt, pt, Lcond, ncond, candidate_loadings, candidate_psi, return_details=return_details, chunk_size=chunk_size, output_dtype=output_dtype)

def synthetic_checks() -> dict[str, Any]:
    """Deterministic numerical/identity tests; does not read or write any files."""
    rng = np.random.default_rng(419)
    n, t, r = (52, 180, 4)
    f = rng.normal(size=(r, t))
    l = rng.normal(scale=0.12, size=(n, r))
    seasonal = 0.25 * np.sin(2 * np.pi * np.arange(t) / 12)
    logq = 3.0 + seasonal[None, :] + l @ f + rng.normal(scale=0.08, size=(n, t))
    q = np.expm1(logq)
    q[rng.random(q.shape) < 0.1] = np.nan
    q[0] = np.nan
    q[1] = 1.0
    q[2, 23:] = np.nan
    q[3, np.arange(t) % 12 == 2] = np.nan
    fit = fit_pre_covariance(q, rank=6, max_iter=20)
    assert not fit['eligible'][:4].any()
    assert np.allclose(np.sum(fit['loadings'] ** 2, axis=1) + fit['psi'], 1)
    assert np.min(fit['psi']) >= MIN_PSI - 1e-12
    assert np.all(np.diff(fit['log_likelihood_history']) > -1e-06)
    q2 = np.where(np.isnan(q), -999, q)
    fit2 = fit_pre_covariance(q2, rank=6, max_iter=20)
    assert np.allclose(fit['loadings'], fit2['loadings'])
    assert np.allclose(fit['calendar_means'], fit2['calendar_means'], equal_nan=True)
    xyz = spherical_xyz(rng.uniform(-70, 70, n), rng.uniform(-180, 180, n))
    kg = np.array(['A', 'B', 'C', 'D'] * (n // 4))
    area = rng.normal(7, 1, n)
    area[::7] = np.nan
    attrs = _attributes(xyz, kg, area)
    assert np.linalg.eigvalsh(_attribute_kernel(attrs, attrs)).min() > -1e-09
    model = fit_map(xyz, kg, area, fit['loadings'], fit['psi'], eligible=fit['eligible'], station_ids=np.arange(n), n_landmarks=16)
    pred = predict_map(model, xyz[:9], kg[:9], area[:9], station_ids=np.arange(100, 109))
    assert np.allclose(np.sum(pred['loadings'] ** 2, axis=1) + pred['psi'], 1)
    assert np.min(pred['psi']) >= MIN_PSI - 1e-12
    zeroL, zeroP = _unit_covariance(np.zeros((2, 6)), np.full(2, 0.05), mapped=True)
    assert np.array_equal(zeroP, np.ones(2)) and (not zeroL.any())
    try:
        predict_map(model, xyz[4:5], kg[4:5], area[4:5], station_ids=np.array([4]))
    except ValueError:
        pass
    else:
        raise AssertionError('Training identity leakage was not rejected')
    L, p = _unit_covariance(rng.normal(size=(15, 6)), np.ones(15))
    tl, tp, cl, cp = (L[:3], p[:3], L[9:], p[9:])
    refids = np.array([[0, 3, 4, 4], [1, 5, 6, 7], [2, 4, 5, -1]])
    weights = np.array([[0.2, 0.3, 0.1, 0.4], [0.2, 0.1, 0.3, 0.4], [0.2, 0.4, 0.4, 0]])
    extra = L[8:9]
    result = conditional_gain_given_refs(tl, tp, L[:9], p[:9], cl, cp, ref_indices=refids, ref_weights=weights, target_background_indices=np.arange(3), extra_condition_loadings=extra, extra_condition_noise_cov=np.array([[p[8]]]), return_details=True, output_dtype=np.float64)
    fullcov = L @ L.T + np.diag(p)
    expected = np.empty((3, 6))
    for i in range(3):
        w = np.zeros(15)
        for j, weight in zip(refids[i], weights[i]):
            if j >= 0 and j != i:
                w[j] += weight
        w /= w.sum()
        transform = np.zeros((2, 15))
        transform[0], transform[1, 8] = (w, 1)
        zz = transform @ fullcov @ transform.T
        ic = fullcov[i, 9:] - fullcov[i] @ transform.T @ np.linalg.solve(zz, transform @ fullcov[:, 9:])
        cc = np.diag(fullcov)[9:] - np.sum(transform @ fullcov[:, 9:] * np.linalg.solve(zz, transform @ fullcov[:, 9:]), axis=0)
        expected[i] = ic * ic / cc
    assert np.allclose(result['gain'], expected, atol=1e-11)
    empty = gain_given_condition(tl, tp, np.empty((0, 6)), np.empty((0, 0)), cl, cp, output_dtype=np.float64)
    assert np.allclose(empty, (tl @ cl.T) ** 2 / (np.sum(cl * cl, axis=1) + cp))
    individual = conditional_gain_given_refs(tl, tp, L[:9], p[:9], cl, cp, ref_indices=refids, ref_weights=weights, target_background_indices=np.arange(3), mode='individual', output_dtype=np.float64)
    for i in range(3):
        rr = np.unique(refids[i][(refids[i] >= 0) & (refids[i] != i)])
        zz = fullcov[np.ix_(rr, rr)]
        yc = fullcov[np.ix_(rr, np.arange(9, 15))]
        yc_solve = np.linalg.solve(zz, yc)
        ic = fullcov[i, 9:] - fullcov[i, rr] @ yc_solve
        cc = np.diag(fullcov)[9:] - np.sum(yc * yc_solve, axis=0)
        assert np.allclose(individual[i], ic * ic / cc, atol=1e-11)
    return dict(status='PASS', checks=['masked_EM', 'calendar_eligibility', 'unit_variance', 'noise_floor', 'negative_missing_equivalence', 'kernel_PSD', 'candidate_identity_guard', 'mapped_unexplained_noise', 'K4_self_and_duplicate_exclusion', 'full_Schur_crosscheck', 'extra_condition_covariance', 'empty_condition', 'individual_reference_conditioning'], eligible=int(fit['eligible'].sum()), em_iterations=fit['iterations'], max_dense_gain_error=float(np.max(abs(expected - result['gain']))))
if __name__ == '__main__':
    print(json.dumps(synthetic_checks(), indent=2))
