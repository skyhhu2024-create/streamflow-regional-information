"""Fixed global layout evaluation. Selection never calls any function here.

prepare_background does not materialize candidate runoff. All production is
bound to a pre-score selection freeze. Target G truth is read only by score_*.
"""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib, argparse, time, warnings, importlib.util
for _k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_k] = '1'
sys.dont_write_bytecode = True
ROOT = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60'
CODE = _PROJECT_ROOT
pass
import numpy as np
import pandas as pd
from concurrent.futures import ProcessPoolExecutor
OLD = _PROJECT_ROOT / 'workflows/monitoring/location_selection'
D = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design'
OUT = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation'
GDATA = _PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data'
spec = importlib.util.spec_from_file_location('outage_helpers', _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/run_outage.py')
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)
pass
import workflows.rainfall.global_inputs.design_review.transfer_model as M
H = np.arange(180, 240)
G = np.arange(240, 264)
HG = np.r_[H, G]
LAM = 0.1
EPS = 1e-12
RISK = {'GB_0000239', 'GB_0000240', 'GB_0000241', 'GB_0000242'}
W = {}

def sha(p):
    return C.sha(p)

def js(p, x):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    C.js(p, x)

def verify(path):
    path = Path(path)
    x = json.loads(path.read_text(encoding='utf8'))
    for key in ('files', 'outputs'):
        for k, v in x.get(key, {}).items():
            p = Path(k)
            p = p if p.is_absolute() else path.parent / p
            assert sha(p) == v, (path, p)
    assert x.get('passed', True), path
    return x

def freeze(folder, name, files, **meta):
    js(folder / name, dict(files={str(Path(p).resolve()): sha(p) for p in files}, **meta))

def atomic_npz(path, **arrays):
    path = Path(path)
    tmp = path.with_name(path.stem + '.pending.npz')
    np.savez_compressed(tmp, **arrays)
    os.replace(tmp, path)

def selection_gate(path):
    path = Path(path).resolve()
    verify(path)
    assert 'FROZEN' in path.name.upper(), 'Explicit frozen global selection file required'
    return (str(path), sha(path))

def require_layout_in_selection(selection, layouts_path):
    x = verify(selection)
    actual = sha(layouts_path)
    bound = {h for key in ('files', 'outputs') for h in x.get(key, {}).values()}
    assert actual in bound, 'Joint layout CSV must already be bound by global selection freeze before candidate access'

def production_gate(selection):
    verify(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/DESIGN_FROZEN.json')
    sp, sh = selection_gate(selection)
    verify(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/INPUTS_FROZEN.json')
    protocol = json.loads((_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/EVALUATION_PROTOCOL.json').read_text(encoding='utf8'))
    assert protocol['code_sha256'] == sha(__file__), 'Run fixture before production to bind current protocol/code'
    return dict(selection_freeze=sp, selection_sha256=sh, design_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/DESIGN_FROZEN.json'), code_sha256=sha(__file__), evaluation_protocol_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/EVALUATION_PROTOCOL.json'), rain_input_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/INPUTS_FROZEN.json'), flow_file_sha256=sha(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy'), outage_helper_sha256=sha(C.__file__), transfer_helper_sha256=sha(M.__file__))

def distance(lat, lon, lats, lons):
    a, b = np.deg2rad([lat, lon])
    c, d = (np.deg2rad(lats), np.deg2rad(lons))
    return 12742 * np.arcsin(np.sqrt(np.clip(np.sin((c - a) / 2) ** 2 + np.cos(a) * np.cos(c) * np.sin((d - b) / 2) ** 2, 0, 1)))

def ridge_base(x, y):
    """Exactly fixed standardized ridge; unpenalized response mean."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    mean = x.mean(0)
    scale = x.std(0)
    scale = np.where(scale > EPS, scale, 1.0)
    z = (x - mean) / scale
    ym = float(y.mean())
    yc = y - ym
    n, p = x.shape
    A = z.T @ z + n * LAM * np.eye(p)
    Ai = np.linalg.inv(A)
    beta = Ai @ (z.T @ yc)
    return dict(mean=mean, scale=scale, z=z, ym=ym, yc=yc, Ai=Ai, beta=beta, n=n)

def schur_additions(base, ct, observed, eligible, xg, cg):
    """Each column is one independently added channel, not cumulative order.

    ct already has H missing anomalies replaced by zero. Every column is
    centred/scaled on the identical original baseline training rows.
    """
    cm = ct.mean(0)
    cs = ct.std(0)
    ok = eligible & (observed.sum(0) >= 24) & (cs > EPS)
    scale = np.where(cs > EPS, cs, 1.0)
    cz = (ct - cm) / scale
    q = base['z'].T @ cz
    aq = base['Ai'] @ q
    denom = np.sum(cz * cz, axis=0) + base['n'] * LAM - np.sum(q * aq, axis=0)
    beta = (cz.T @ base['yc'] - q.T @ base['beta']) / denom
    ok &= np.isfinite(beta) & np.isfinite(denom) & (denom > 0)
    beta = np.where(ok, beta, 0.0)
    bx = base['beta'][:, None] - aq * beta[None, :]
    zg = (xg - base['mean']) / base['scale']
    pred = base['ym'] + zg @ bx + (cg - cm) / scale * beta
    return (pred, dict(candidate_mean=cm, candidate_scale=scale, candidate_coefficient=beta, base_coefficients=bx, eligible=ok, common_observed_n=observed.sum(0).astype(np.int16), schur_denominator=denom))

def candidate_only_parameters(ct, y, observed, quality):
    """Independent one-channel ridge fits; H rows are target-finite, not Q-finite."""
    n = len(y)
    mean = ct.mean(0)
    sd = ct.std(0)
    scale = np.where(sd > EPS, sd, 1.0)
    z = (ct - mean) / scale
    ym = float(np.mean(y))
    yc = y - ym
    eligible = quality & (observed.sum(0) >= 24) & (sd > EPS)
    coef = z.T @ yc / (np.sum(z * z, axis=0) + n * LAM)
    eligible &= np.isfinite(coef)
    coef = np.where(eligible, coef, 0.0)
    return dict(rescue_mean=mean, rescue_scale=scale, rescue_coefficient=coef, rescue_target_mean=np.array(ym), rescue_eligible=eligible, rescue_common_observed_n=observed.sum(0).astype(np.int16))

def baseline_available_months(i):
    b = W['base']
    p = int(b['feature_count'][i])
    return bool(b['fit'][i]) & np.isfinite(b['xg'][i, :, :p]).all(1)

def write_evaluation_protocol():
    assert not (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/BACKGROUND_FROZEN.json').exists(), 'No protocol rewrite after production freeze'
    js(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/EVALUATION_PROTOCOL.json', dict(code_sha256=sha(__file__), date='2026-10-26', protocol_note='Prescore candidate-only rescue added before any candidate actual-data production', calendar=dict(pre='1980-1994', H='1995-1999', G='2000-2001'), mother=17161, prediction_cases=5914, strict_main_domain=5905, strict_domain='Keep5914 outputs; sixH/G-negative cases and three pending physical identities excluded only from strict main accuracy. Constants and unestimable results remain5905 denominator.', baseline='New16446 pre-admitted physical background; target and all aliases omitted. H log1p calendar anomalies;>=12 commonH and positive r. MonthlyK4 by equal r/distance ranks; positive-r weighted composite. Fixed standardized ridge lambda0.1, sameH numerical guards. Existing admitted target P lag0..3 only when complete87month input; otherwiseQ. Unfit or missingbaselineXg returns unchanged raw targetH seasonal mean.', candidate_admission='No positive correlation criterion. H finite nonnegative, >=2 in everycalendar month, >=24 total, nonzero H calendar-anomaly SD; >=24 candidate observations paired with chosen training rows and positive filled-feature SD. Zero runoff retained.', normal_augmentation='Baselinefit and all originalXg channels finite: extra independent candidate channels, no competition withK4. BaselineH training rows fixed. CandidateH missing anomaly filled0; feature mean/SD recalculated on those fixed rows. Same ridge lambda0.1.', rescue='Baselinecannotfit or originalXg incomplete thatmonth: candidate-onlyridge, sameH60 and target-finite H rows, sameeligibility and fixedlambda0.1. Single candidatechannel or jointly selected H-qualifiedchannels; no score-driven model choice.', missing_G='SinglecandidateG absent -> exactoriginalbaseline. Jointcandidatechannels missingG -> correspondingH training featuremean (standardized0); no qualifiedcandidate reports thatmonth -> exactoriginalbaseline. Normal and rescue domains disjoint and decided withouttargetG.', target_transform='TargetH-only log1p calendar mean/anomaly SD; z clipped to Hrange+-3 then log cap50 and Q>=0. TargetH-transformunestimable cannot be rescued with this unchanged transform.', outputs='float32 predictions plus allfloat64 fittedparameters and monthly branch0baseline/1augmented/2rescue. Scoring reevaluates frozenparameters in float64 withoutrefit; nointervention metrics exactlybaseline.', outcome='r>0.7 and actual baseline-support OR added-channel-support;5905 fixedstrictdomain. Baselinepass requiresbaselinefit/support. New/lost measured separately; global/continent available/rescuedomain summaries. Constanttruth retained as nonpass.', inference='Joint layouts:2000 paired5degree spatial-cell bootstrap, equalstationmean, resample representedcells within eachfixedregional metric subset; noCI if<5cells. No population extrapolation to17161 targetmother.', gates='Global ranking+jointlayouts frozenbeforecandidateH/G; layoutsCSVhash must be inselectionfreeze. Allpredictions andfloat64params frozenbeforetargetG scoring; independentQA must bindpredictionfreeze. Allsources+helpers+protocol hashes unchanged.'))
    (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/新增信息评估_预先登记规则.md').write_text('# 新增信息评估：共同时间与救援分支\n\n本轮在1995年之前确定全球布局，使用1995—1999年共同观测校准，并检验2000—2001年。4930个候选位置的实际流量须在布局冻结后才开放。\n\n三个分支在评分前确定：\n\n1. 原基线能够拟合且当月输入完整：使用基线＋新增站独立通道，保持原训练月份。\n2. 原基线不能拟合或当月输入缺失，而新增站有观测：使用候选站单独ridge救援。候选单独模型用同一H60内目标变换可用的月份；不要求原Q复合也可用。\n3. 新增站也无当月可用观测：完整保留原基线预测。\n\n所有ridge的惩罚参数固定为0.1。候选H每历月至少2个月非负有效观测、总数至少24、变换标准差非零；在相应训练行至少有24个月共同观测，不要求历史相关性为正。零径流是有效观测。H中候选缺失距平先填0，再在训练行标准化；联合布局中缺失的G通道使用该通道训练均值，若全部缺失则回原基线。\n\n正常增广模型与救援模型分别存储float64参数，逐月记录使用路径。评分从冻结参数重算float64，不重新拟合；没有实际新增输入的结果与原基线逐位相同。\n\n所有5914个未来窗口完整的固定代表均生成预测。严格主评价域为5905站，其余6站负值、3站身份待核单列；常量序列和拟合失败仍留在5905分母。主达标率为r>0.7并实际获得基线或新增站支持。完整基线域和需要救援域分开报告，不能把不可验证的17161母集成员直接算成重构失败。\n\n没有改变原基线、候选清单、全球布局或算法参数，没有依据未来成绩选择分支。\n', encoding='utf8')

def fixture():
    """Only generated synthetic data; direct full solves verify algebra."""
    rng = np.random.default_rng(20261026)
    errs = []
    missing_checks = []
    for n in (24, 41, 60):
        for p in (1, 5):
            for k in (1, 17, 53):
                x = rng.normal(size=(n, p))
                y = rng.normal(size=n)
                g = rng.normal(size=(24, p))
                raw = rng.normal(size=(n, k))
                obs = rng.random((n, k)) > 0.08
                ct = np.where(obs, raw, 0.0)
                cg = rng.normal(size=(24, k))
                eligible = np.ones(k, bool)
                eligible[-1] = False
                if k > 1:
                    ct[:, 0] = 0
                b = ridge_base(x, y)
                pred, par = schur_additions(b, ct, obs, eligible, g, cg)
                for j in np.flatnonzero(par['eligible']):
                    model, status = M.fit_transfer(np.c_[x, ct[:, j]], y, method='ridge')
                    expected = model.predict(np.c_[g, cg[:, j]])
                    errs.append(float(np.max(np.abs(expected - pred[:, j]))))
                np.testing.assert_allclose(pred[:, ~par['eligible']], np.tile(b['ym'] + (g - b['mean']) / b['scale'] @ b['beta'], ((~par['eligible']).sum(), 1)).T, atol=1e-12)
                kk = min(k, 10)
                aug = np.c_[x, ct[:, :kk]]
                fit, status = M.fit_transfer(aug, y, method='ridge')
                direct = ridge_base(aug, y)
                gg = np.c_[g, cg[:, :kk]]
                errs.append(float(np.max(np.abs(fit.predict(gg) - (direct['ym'] + (gg - direct['mean']) / direct['scale'] @ direct['beta'])))))
    n, p, k = (60, 5, 11)
    x = rng.normal(size=(n, p))
    y = rng.normal(size=n)
    g = rng.normal(size=(24, p))
    g[4, 0] = np.nan
    ct = rng.normal(size=(n, k))
    obs = rng.random((n, k)) > 0.1
    ct = np.where(obs, ct, 0.0)
    cg = rng.normal(size=(24, k))
    gv = np.ones((k, 24), bool)
    gv[2, 7:] = False
    cg[7:, 2] = np.nan
    base = ridge_base(x, y)
    z, params = schur_additions(base, ct, obs, np.ones(k, bool), g, cg)
    cl = np.linspace(0.5, 1.5, 12)
    sd = 0.7
    season = np.expm1(cl[G % 12])
    basez = base['ym'] + (g - base['mean']) / base['scale'] @ base['beta']
    bp, bs = C.transfer(basez, y, cl, sd, G, season, True)
    W['base'] = dict(feature_count=np.array([p]), fit=np.array([True]), predictions=bp[None, :], xg=g[None, :, :], feature_mean=base['mean'][None, :], feature_scale=base['scale'][None, :], target_mean=np.array([base['ym']]), target_z=y[None, :], target_sd=np.array([sd]), target_log_calendar=cl[None, :], seasonal=season[None, :])
    W['cp'] = dict(g_anomaly=cg.T, g_valid=gv)
    params['candidate_eligible'] = params['eligible']
    readback = full_precision_single(0, params, np.arange(k))
    for j in range(k):
        model, _ = M.fit_transfer(np.c_[x, ct[:, j]], y, method='ridge')
        direct, sup = C.transfer(model.predict(np.c_[g, cg[:, j]]), y, cl, sd, G, season, True)
        direct[~gv[j] | ~sup] = bp[~gv[j] | ~sup]
        errs.append(float(np.max(np.abs(readback[j] - direct))))
    np.testing.assert_array_equal(readback[2, 7:], bp[7:])
    np.testing.assert_array_equal(readback[:, 4], np.repeat(bp[4], k))
    params.update(candidate_only_parameters(ct, y, obs, np.ones(k, bool)))
    augmented, route = full_precision_single(0, params, np.arange(k), return_branch=True)
    assert (route[:, 4] == 2).all() and (not route[2, 7:].any())
    for j in range(k):
        fit, _ = M.fit_transfer(ct[:, j, None], y, method='ridge')
        rv, rs = C.transfer(fit.predict(cg[:, j, None]), y, cl, sd, G, season, True)
        errs.append(float(abs(augmented[j, 4] - rv[4])))
    W['base']['fit'][0] = False
    W['base']['predictions'][0] = season
    rescued, route = full_precision_single(0, params, np.arange(k), return_branch=True)
    for j in range(k):
        fit, _ = M.fit_transfer(ct[:, j, None], y, method='ridge')
        rv, rs = C.transfer(fit.predict(cg[:, j, None]), y, cl, sd, G, season, True)
        rv[~gv[j]] = season[~gv[j]]
        errs.append(float(np.max(np.abs(rescued[j] - rv))))
    assert (route[0] == 2).all()
    np.testing.assert_array_equal(rescued[2, 7:], season[7:])
    chosen = np.arange(10)
    jh = ct[:, :10]
    fit, _ = M.fit_transfer(jh, y, method='ridge')
    tag = 'test__rescue__'
    jpar = {tag + 'mean': fit.feature_mean, tag + 'scale': fit.feature_scale, tag + 'coef': fit.coefficients, tag + 'target_mean': np.array(fit.target_mean), tag + 'active_candidate_positions': chosen}
    W['cp']['g_anomaly'][:, 6] = np.nan
    W['cp']['g_valid'][:, 6] = False
    jr, jroute = full_precision_layout(0, jpar, 'test', return_branch=True)
    jg = W['cp']['g_anomaly'][chosen].T
    jo = np.isfinite(jg)
    jg = np.where(jo, jg, fit.feature_mean)
    expected, es = C.transfer(fit.predict(jg), y, cl, sd, G, season, True)
    expected[~jo.any(1)] = season[~jo.any(1)]
    errs.append(float(np.max(np.abs(jr - expected))))
    assert jroute[6] == 0 and jr[6] == season[6]
    truth = np.arange(24, dtype=float) + np.sin(np.arange(24))
    pred = np.stack([truth, truth * 0.8 + 2])
    ms, good = metrics(pred, truth, np.zeros(12))
    np.testing.assert_allclose(ms[:, 1], 2 * ms[:, 2] * ms[:, 0] - ms[:, 2] ** 2 - ms[:, 3] ** 2, atol=1e-12)
    W.clear()
    assert max(errs) < 2e-12, max(errs)
    write_evaluation_protocol()
    out = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/SYNTHETIC_SCHUR_QA.json'
    js(out, dict(passed=True, comparisons=len(errs), maximum_absolute_prediction_difference=max(errs), missing_candidate_H_filled_zero_before_standardization=True, candidate_G_absence_exact_baseline_fallback=True, baseline_Q_absence_candidate_only_rescue_checked=True, baseline_fit_failure_candidate_only_rescue_checked=True, joint_missing_channels_training_mean_and_all_missing_fallback_checked=True, float64_frozen_parameter_readback_checked=True, NSE_decomposition_checked=True, no_observed_flow_read=True, code_sha256=sha(__file__)))
    print(json.dumps(json.loads(out.read_text(encoding='utf8')), indent=2))

def init_background():
    warnings.filterwarnings('ignore', category=RuntimeWarning)
    ev = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/evaluation_only/target_fixed_representative_complete_HG.csv', keep_default_na=False)
    mother = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/target_mother.csv', keep_default_na=False)
    cases = mother.set_index('raw_index').loc[ev.raw_index].reset_index()
    cases['mother_row'] = cases.row
    cases['row'] = np.arange(len(cases))
    assert len(cases) == 5914 and len(mother) == 17161
    roles = np.load(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/network_roles.npz', allow_pickle=False)
    raw = roles['background_raw']
    cand = roles['candidate_all_alias_raw']
    assert len(raw) == 16446 and (not np.isin(raw, cand).any())
    q = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', mmap_mode='r')
    sq = np.asarray(q[np.ix_(raw, HG)], float)
    cl, sd, z = C.prep(sq[:, :60], H)
    sm = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/background_sources.csv', keep_default_na=False).set_index('raw_index').loc[raw]
    W.update(cases=cases, Q=q, source_raw=raw, source_Q=sq, source_cl=cl, source_sd=sd, source_z=z, source_meta=sm, physical=roles['physical_group_raw_index'])
    with np.load(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/rainfall.npz', allow_pickle=False) as f:
        rain = {k: f[k] for k in ['station_ids', 'precip_mm_month', 'admission_mask']}
    W['rain'] = rain
    W['rain_pos'] = {s: i for i, s in enumerate(rain['station_ids'].astype(str))}

def background_one(i):
    e = W['cases'].iloc[i]
    raw = int(e.raw_index)
    target = np.asarray(W['Q'][raw, H], float)
    cl, sd, tz = C.prep(target[None, :], H)
    cl = cl[0]
    sd = float(sd[0])
    tz = tz[0]
    estim = bool(np.isfinite(target).all() and (target >= 0).all() and np.isfinite(cl).all() and np.isfinite(sd))
    if not estim:
        tz[:] = np.nan
    rawcal = np.array([np.nanmean(np.where(target[H % 12 == m] >= 0, target[H % 12 == m], np.nan)) for m in range(12)])
    seasonal = rawcal[G % 12]
    n, r = C.relation(W['source_z'], tz)
    dist = distance(float(e.latitude), float(e.longitude), W['source_meta'].latitude.to_numpy(float), W['source_meta'].longitude.to_numpy(float))
    own = W['physical'][W['source_raw']] == int(e.physical_group_raw_index)
    qual = np.flatnonzero(np.isfinite(r) & (r > 0) & np.isfinite(W['source_sd']) & ~own)
    order = C.ordering(W['source_raw'], qual, r, dist)
    count = np.zeros(84, np.int8)
    num = np.zeros(84)
    den = np.zeros(84)
    sel = np.full((84, 4), -1, np.int32)
    for j in order:
        vals = W['source_Q'][j]
        cc = W['source_cl'][j, HG % 12]
        take = np.isfinite(vals) & (vals >= 0) & np.isfinite(cc) & (count < 4)
        ii = np.flatnonzero(take)
        if len(ii):
            z = (np.log1p(vals[ii]) - cc[ii]) / W['source_sd'][j]
            sel[ii, count[ii]] = W['source_raw'][j]
            count[ii] += 1
            num[ii] += r[j] * z
            den[ii] += r[j]
        if (count == 4).all():
            break
    comp = np.divide(num, den, out=np.full(84, np.nan), where=den > 0)
    train = np.isfinite(comp[:60]) & np.isfinite(tz)
    hasp = False
    rp = W['rain_pos'].get(str(e.station_id))
    rain = None
    if rp is not None and W['rain']['admission_mask'][rp]:
        rain = M.prepare_precipitation_lags(W['rain']['precip_mm_month'][rp, 180:267], history_start_month=180, h_length=60, g_length=24)
        hasp = bool(rain.available)
    xh = comp[:60, None]
    xg = comp[60:, None]
    if hasp:
        xh = np.c_[xh, rain.h]
        xg = np.c_[xg, rain.g]
    model, status = M.fit_transfer(xh[train], tz[train], method='ridge', target_estimable=estim)
    usesP = hasp and model is not None
    if model is None and hasp:
        xh = comp[:60, None]
        xg = comp[60:, None]
        model, status = M.fit_transfer(xh[train], tz[train], method='ridge', target_estimable=estim)
    z = model.predict(xg) if model is not None else np.full(24, np.nan)
    pred, sup = C.transfer(z, tz, cl, sd, G, seasonal, model is not None)
    fx = np.full((60, 5), np.nan)
    fg = np.full((24, 5), np.nan)
    fx[:, :xh.shape[1]] = xh
    fg[:, :xg.shape[1]] = xg
    coef = np.full(5, np.nan)
    mean = coef.copy()
    scale = coef.copy()
    if model is not None:
        coef[:len(model.coefficients)] = model.coefficients
        mean[:len(model.feature_mean)] = model.feature_mean
        scale[:len(model.feature_scale)] = model.feature_scale
    assert not np.isin(sel[sel >= 0], np.flatnonzero(W['physical'] == int(e.physical_group_raw_index))).any()
    return (i, dict(xh=fx, xg=fg, train=train, target_z=tz, target_log_calendar=cl, target_sd=sd, seasonal=seasonal, raw_calendar=rawcal, predictions=pred, support=sup, fit=model is not None, uses_P=usesP, P_available=hasp, feature_count=xh.shape[1], coefficients=coef, feature_mean=mean, feature_scale=scale, target_mean=model.target_mean if model is not None else np.nan, source_count=count, selected_ids=sel, qualified_n=len(qual), target_estimable=estim))

def prepare_background(selection, workers):
    binding = production_gate(selection)
    out = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background'
    out.mkdir(parents=True, exist_ok=True)
    if (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/BACKGROUND_FROZEN.json').exists():
        verify(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/BACKGROUND_FROZEN.json')
        print('Already frozen background')
        return
    init_background()
    cases = W['cases']
    cases.to_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/cases.csv', index=False, encoding='utf-8-sig')
    N = len(cases)
    shapes = {'xh': ((N, 60, 5), 'float64'), 'xg': ((N, 24, 5), 'float64'), 'train': ((N, 60), 'bool'), 'target_z': ((N, 60), 'float64'), 'target_log_calendar': ((N, 12), 'float64'), 'target_sd': ((N,), 'float64'), 'seasonal': ((N, 24), 'float64'), 'raw_calendar': ((N, 12), 'float64'), 'predictions': ((N, 24), 'float64'), 'support': ((N, 24), 'bool'), 'fit': ((N,), 'bool'), 'uses_P': ((N,), 'bool'), 'P_available': ((N,), 'bool'), 'feature_count': ((N,), 'int8'), 'coefficients': ((N, 5), 'float64'), 'feature_mean': ((N, 5), 'float64'), 'feature_scale': ((N, 5), 'float64'), 'target_mean': ((N,), 'float64'), 'source_count': ((N, 84), 'int8'), 'selected_ids': ((N, 84, 4), 'int32'), 'qualified_n': ((N,), 'int32'), 'target_estimable': ((N,), 'bool')}
    mode = 'r+' if (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/done.npy').exists() else 'w+'
    if mode == 'r+':
        assert json.loads((_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/BINDING.json').read_text(encoding='utf8')) == binding
    else:
        js(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/BINDING.json', binding)
    arr = {k: np.lib.format.open_memmap(out / (k + '.npy'), mode=mode, shape=sh, dtype=dt) for k, (sh, dt) in shapes.items()}
    done = np.lib.format.open_memmap(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/done.npy', mode=mode, shape=(N,), dtype=bool)
    if mode == 'w+':
        done[:] = False
    todo = np.flatnonzero(~done).tolist()
    st = time.time()
    with ProcessPoolExecutor(max_workers=workers, initializer=init_background) as pool:
        for k, (i, res) in enumerate(pool.map(background_one, todo, chunksize=8), 1):
            for key, value in res.items():
                arr[key][i] = value
            done[i] = True
            if k % 100 == 0 or k == len(todo):
                for a in arr.values():
                    a.flush()
                done.flush()
                print(f'background {done.sum()}/{N} sec={time.time() - st:.1f}', flush=True)
    assert done.all()
    freeze(out, 'BACKGROUND_FROZEN.json', list(out.glob('*.npy')) + [_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/cases.csv', _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/BINDING.json'], status='BACKGROUND_BEFORE_CANDIDATE_ACCESS', target_G_truth_scored=False, binding=binding, N=N)

def init_eval():
    warnings.filterwarnings('ignore', category=RuntimeWarning)
    out = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background'
    W['cases'] = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/cases.csv', keep_default_na=False)
    W['base'] = {p.stem: np.load(p, mmap_mode='r') for p in out.glob('*.npy') if p.stem != 'done'}
    W['cand'] = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/candidate_locations.csv', keep_default_na=False)
    if (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/candidate_inputs/CANDIDATE_INPUTS_FROZEN.json').exists():
        with np.load(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/candidate_inputs/prepared.npz', allow_pickle=False) as z:
            W['cp'] = {k: z[k] for k in z.files}

def prepare_candidates(selection):
    binding = production_gate(selection)
    verify(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/BACKGROUND_FROZEN.json')
    assert json.loads((_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/BINDING.json').read_text(encoding='utf8')) == binding
    out = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/candidate_inputs'
    out.mkdir(parents=True, exist_ok=True)
    if (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/candidate_inputs/CANDIDATE_INPUTS_FROZEN.json').exists():
        verify(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/candidate_inputs/CANDIDATE_INPUTS_FROZEN.json')
        return
    cand = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/candidate_locations.csv', keep_default_na=False)
    raw = cand.raw_index.to_numpy(int)
    assert len(raw) == 4930
    Q = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', mmap_mode='r')
    h = np.asarray(Q[np.ix_(raw, H)], float)
    g = np.asarray(Q[np.ix_(raw, G)], float)
    cl, sd, z = C.prep(h, H)
    hvalid = np.isfinite(h) & (h >= 0)
    gvalid = np.isfinite(g) & (g >= 0)
    caln = np.stack([hvalid[:, H % 12 == m].sum(1) for m in range(12)], 1)
    eligible = (caln.min(1) >= 2) & (hvalid.sum(1) >= 24) & np.isfinite(sd) & np.isfinite(cl).all(1)
    gz = (np.log1p(np.where(gvalid, g, np.nan)) - cl[:, G % 12]) / sd[:, None]
    gvalid &= np.isfinite(gz)
    np.savez(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/candidate_inputs/prepared.npz', raw_index=raw, station_id=cand.station_id.to_numpy(str), h_anomaly=z, g_anomaly=gz, h_valid=hvalid, g_valid=gvalid, H_quality=eligible, calendar_counts=caln, log_calendar=cl, anomaly_sd=sd)
    pd.DataFrame(dict(station_id=cand.station_id, raw_index=raw, H_valid_months=hvalid.sum(1), H_min_calendar_count=caln.min(1), H_quality=eligible, G_report_months=gvalid.sum(1))).to_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/candidate_inputs/availability.csv', index=False)
    freeze(out, 'CANDIDATE_INPUTS_FROZEN.json', [_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/candidate_inputs/prepared.npz', _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/candidate_inputs/availability.csv'], binding=binding, source_H_only_transform=True, candidate_G_used_only_predictor=True, target_G_truth_scored=False)

def single_one(i):
    b = W['base']
    c = W['cp']
    out = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/single/blocks'
    path = out / f'target_{i:05d}.npz'
    N = len(c['raw_index'])
    eligible = np.zeros(N, bool)
    common = np.zeros(N, np.int16)
    cm = np.zeros(N)
    cs = np.ones(N)
    bc = np.zeros(N)
    p = int(b['feature_count'][i])
    bx = np.tile(np.asarray(b['coefficients'][i, :p])[:, None], (1, N))
    den = np.full(N, np.nan)
    if bool(b['fit'][i]):
        train = np.asarray(b['train'][i])
        x = np.asarray(b['xh'][i, train, :p])
        y = np.asarray(b['target_z'][i, train])
        base = ridge_base(x, y)
        np.testing.assert_allclose(base['beta'], b['coefficients'][i, :p], rtol=1e-11, atol=1e-12)
        ch = c['h_anomaly'][:, train].T
        obs = np.isfinite(ch)
        ch = np.where(obs, ch, 0.0)
        zg, par = schur_additions(base, ch, obs, c['H_quality'], np.asarray(b['xg'][i, :, :p]), c['g_anomaly'].T)
        eligible = par['eligible']
        common = par['common_observed_n']
        cm = par['candidate_mean']
        cs = par['candidate_scale']
        bc = par['candidate_coefficient']
        bx = par['base_coefficients']
        den = par['schur_denominator']
    par = dict(candidate_eligible=eligible, common_observed_n=common, candidate_mean=cm, candidate_scale=cs, candidate_coefficient=bc, base_coefficients=bx, schur_denominator=den)
    rescue = dict(rescue_mean=np.zeros(N), rescue_scale=np.ones(N), rescue_coefficient=np.zeros(N), rescue_target_mean=np.array(np.nan), rescue_eligible=np.zeros(N, bool), rescue_common_observed_n=np.zeros(N, np.int16))
    if bool(b['target_estimable'][i]):
        tr = np.isfinite(b['target_z'][i])
        ch = c['h_anomaly'][:, tr].T
        obs = np.isfinite(ch)
        ch = np.where(obs, ch, 0.0)
        rescue = candidate_only_parameters(ch, np.asarray(b['target_z'][i, tr]), obs, c['H_quality'])
    par.update(rescue)
    pred, branch = full_precision_single(i, par, np.arange(N), return_branch=True)
    atomic_npz(path, predictions=pred.astype(np.float32), input_branch=branch, **par)
    return (i, int(eligible.sum()))

def produce_single(selection, workers):
    prepare_candidates(selection)
    out = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/single'
    (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/single/blocks').mkdir(parents=True, exist_ok=True)
    if (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/single/PREDICTIONS_FROZEN.json').exists():
        verify(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/single/PREDICTIONS_FROZEN.json')
        print('Already frozen single')
        return
    binding = production_gate(selection)
    binding.update(background_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/BACKGROUND_FROZEN.json'), candidate_input_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/candidate_inputs/CANDIDATE_INPUTS_FROZEN.json'))
    if (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/single/BINDING.json').exists():
        assert json.loads((_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/single/BINDING.json').read_text(encoding='utf8')) == binding
    else:
        js(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/single/BINDING.json', binding)
    init_eval()
    N = len(W['cases'])
    todo = [i for i in range(N) if not (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/single/blocks' / f'target_{i:05d}.npz').exists()]
    st = time.time()
    with ProcessPoolExecutor(max_workers=workers, initializer=init_eval) as pool:
        for k, (i, n) in enumerate(pool.map(single_one, todo, chunksize=2), 1):
            if k % 100 == 0 or k == len(todo):
                print(f'single {N - len(todo) + k}/{N} sec={time.time() - st:.1f}', flush=True)
    files = sorted((_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/single/blocks').glob('target_*.npz'))
    assert len(files) == N
    freeze(out, 'PREDICTIONS_FROZEN.json', files + [_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/single/BINDING.json'], N=N, candidates=4930, L=24, status='ALL_SINGLE_PREDICTIONS_AND_FLOAT64_PARAMETERS_FROZEN_BEFORE_SCORING', binding=binding)

def load_layouts(path):
    df = pd.read_csv(path, keep_default_na=False)
    assert {'layout_id', 'candidate_raw_index'} <= set(df.columns), 'layouts CSV requires layout_id,candidate_raw_index (optional rank)'
    cand = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/candidate_locations.csv', keep_default_na=False)
    pos = {int(v): i for i, v in enumerate(cand.raw_index)}
    ans = {}
    for key, g in df.groupby('layout_id', sort=False):
        if 'rank' in g:
            g = g.sort_values('rank')
        assert g.candidate_raw_index.is_unique
        assert len(g) in (10, 25, 50), 'Frozen joint layouts must contain10,25or50 unique positions'
        ans[str(key)] = np.array([pos[int(v)] for v in g.candidate_raw_index], int)
    return ans

def layout_one(i):
    b = W['base']
    c = W['cp']
    layouts = W['layouts']
    p = int(b['feature_count'][i])
    pred = []
    params = {}
    added = []
    rescued = []
    branches = []
    for key, idx in layouts.items():
        counts = {'aug': 0, 'rescue': 0}
        for mode in ['aug', 'rescue']:
            if not bool(b['fit'][i] if mode == 'aug' else b['target_estimable'][i]):
                continue
            tr = np.asarray(b['train'][i]) if mode == 'aug' else np.isfinite(b['target_z'][i])
            ch = c['h_anomaly'][idx][:, tr].T
            obs = np.isfinite(ch)
            ch = np.where(obs, ch, 0.0)
            active = c['H_quality'][idx] & (obs.sum(0) >= 24) & (ch.std(0) > EPS)
            counts[mode] = int(active.sum())
            if active.any():
                chosen = idx[active]
                xh = np.c_[b['xh'][i, tr, :p], ch[:, active]] if mode == 'aug' else ch[:, active]
                model, status = M.fit_transfer(xh, np.asarray(b['target_z'][i, tr]), method='ridge')
                assert model is not None, status
                tag = key + '__' + mode + '__'
                params[tag + 'mean'] = model.feature_mean
                params[tag + 'scale'] = model.feature_scale
                params[tag + 'coef'] = model.coefficients
                params[tag + 'target_mean'] = np.array(model.target_mean)
                params[tag + 'active_candidate_positions'] = chosen
        pp, branch = full_precision_layout(i, params, key, return_branch=True)
        pred.append(pp)
        added.append(counts['aug'])
        rescued.append(counts['rescue'])
        branches.append(branch)
    atomic_npz(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/layouts/blocks' / f'target_{i:05d}.npz', predictions=np.stack(pred).astype(np.float32), active_candidate_n=np.array(added, np.int16), rescue_active_candidate_n=np.array(rescued, np.int16), input_branch=np.stack(branches), **params)
    return i

def init_layouts(path):
    init_eval()
    W['layouts'] = load_layouts(path)

def produce_layouts(selection, layouts_path, workers):
    layouts_path = Path(layouts_path).resolve()
    require_layout_in_selection(selection, layouts_path)
    prepare_candidates(selection)
    layouts = load_layouts(layouts_path)
    out = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/layouts'
    (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/layouts/blocks').mkdir(parents=True, exist_ok=True)
    if (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/layouts/PREDICTIONS_FROZEN.json').exists():
        verify(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/layouts/PREDICTIONS_FROZEN.json')
        return
    binding = production_gate(selection)
    binding.update(layouts_path=str(layouts_path), layouts_sha256=sha(layouts_path), background_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/BACKGROUND_FROZEN.json'), candidate_input_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/candidate_inputs/CANDIDATE_INPUTS_FROZEN.json'))
    if (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/layouts/BINDING.json').exists():
        assert json.loads((_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/layouts/BINDING.json').read_text(encoding='utf8')) == binding
    else:
        js(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/layouts/BINDING.json', binding)
    N = len(pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/cases.csv'))
    todo = [i for i in range(N) if not (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/layouts/blocks' / f'target_{i:05d}.npz').exists()]
    st = time.time()
    with ProcessPoolExecutor(max_workers=workers, initializer=init_layouts, initargs=(layouts_path,)) as pool:
        for k, i in enumerate(pool.map(layout_one, todo, chunksize=4), 1):
            if k % 100 == 0 or k == len(todo):
                print(f'layouts {N - len(todo) + k}/{N} sec={time.time() - st:.1f}', flush=True)
    files = sorted((_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/layouts/blocks').glob('target_*.npz'))
    assert len(files) == N
    freeze(out, 'PREDICTIONS_FROZEN.json', files + [_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/layouts/BINDING.json', layouts_path], N=N, L=24, layout_order=list(layouts), status='ALL_LAYOUT_PREDICTIONS_AND_FLOAT64_PARAMETERS_FROZEN_BEFORE_SCORING', binding=binding)

def metrics(pred, truth, raw_calendar):
    pred = np.asarray(pred, float)
    truth = np.asarray(truth, float)
    yc = truth - truth.mean()
    sd = truth.std()
    pc = pred - pred.mean(-1, keepdims=True)
    psd = pred.std(-1)
    valid = bool(np.isfinite(truth).all() and (truth >= 0).all() and (sd > 0))
    with np.errstate(divide='ignore', invalid='ignore'):
        r = np.sum(pc * yc, axis=-1) / (24 * psd * sd)
        nse = 1 - np.mean((pred - truth) ** 2, axis=-1) / sd ** 2
        alpha = psd / sd
        delta = (pred.mean(-1) - truth.mean()) / sd
        da = truth - raw_calendar[G % 12]
        dp = pred - raw_calendar[G % 12]
        dac = da - da.mean()
        dpc = dp - dp.mean(-1, keepdims=True)
        dr = np.sum(dpc * dac, axis=-1) / np.sqrt(np.sum(dpc * dpc, axis=-1) * np.sum(dac * dac))
    out = np.stack([np.clip(r, -1, 1), nse, alpha, delta, np.clip(dr, -1, 1)], axis=-1)
    if not valid:
        out[:] = np.nan
    out[~np.isfinite(pred).all(-1)] = np.nan
    return (out, valid)

def full_precision_single(i, par, positions, return_branch=False):
    b = W['base']
    c = W['cp']
    p = int(b['feature_count'][i])
    pred = np.tile(b['predictions'][i], (len(positions), 1)).astype(float)
    branch = np.zeros(pred.shape, np.uint8)
    available = baseline_available_months(i)
    modes = []
    if bool(b['fit'][i]):
        xg = (np.asarray(b['xg'][i, :, :p]) - b['feature_mean'][i, :p]) / b['feature_scale'][i, :p]
        z = b['target_mean'][i] + xg @ par['base_coefficients'][:, positions] + (c['g_anomaly'][positions].T - par['candidate_mean'][positions]) / par['candidate_scale'][positions] * par['candidate_coefficient'][positions]
        modes.append((1, z.T, par['candidate_eligible'][positions, None] & available[None, :]))
    if 'rescue_eligible' in par:
        z = par['rescue_target_mean'] + (c['g_anomaly'][positions] - par['rescue_mean'][positions, None]) / par['rescue_scale'][positions, None] * par['rescue_coefficient'][positions, None]
        modes.append((2, z, par['rescue_eligible'][positions, None] & ~available[None, :]))
    for number, z, domain in modes:
        good = domain & c['g_valid'][positions] & np.isfinite(z)
        if not good.any():
            continue
        zz = np.clip(z, np.nanmin(b['target_z'][i]) - 3, np.nanmax(b['target_z'][i]) + 3)
        vals = np.maximum(np.expm1(np.minimum(zz * b['target_sd'][i] + b['target_log_calendar'][i, G % 12], 50)), 0)
        pred[good] = vals[good]
        branch[good] = number
    return (pred, branch) if return_branch else pred

def full_precision_layout(i, par, key, return_branch=False):
    b = W['base']
    c = W['cp']
    pred = np.asarray(b['predictions'][i]).copy()
    branch = np.zeros(24, np.uint8)
    available = baseline_available_months(i)
    p = int(b['feature_count'][i])
    for number, mode in [(1, 'aug'), (2, 'rescue')]:
        tag = key + '__' + mode + '__'
        if tag + 'coef' not in par:
            continue
        chosen = par[tag + 'active_candidate_positions']
        cg = c['g_anomaly'][chosen].T
        ok = np.isfinite(cg)
        offset = p if mode == 'aug' else 0
        cg = np.where(ok, cg, par[tag + 'mean'][offset:])
        xg = np.c_[b['xg'][i, :, :p], cg] if mode == 'aug' else cg
        z = (xg - par[tag + 'mean']) / par[tag + 'scale'] @ par[tag + 'coef'] + par[tag + 'target_mean']
        pg, ss = C.transfer(z, np.asarray(b['target_z'][i]), np.asarray(b['target_log_calendar'][i]), float(b['target_sd'][i]), G, np.asarray(b['seasonal'][i]), True)
        use = ok.any(1) & ss & (available if mode == 'aug' else ~available)
        pred[use] = pg[use]
        branch[use] = number
    return (pred, branch) if return_branch else pred

def score(kind, qa_path):
    out = OUT / kind
    fr = verify(out / 'PREDICTIONS_FROZEN.json')
    qa = json.loads(Path(qa_path).read_text(encoding='utf8'))
    assert qa.get('passed') and qa.get('prediction_freeze_sha256') == sha(out / 'PREDICTIONS_FROZEN.json'), 'Independent prediction QA required before opening targetG'
    if (out / 'SCORES_FROZEN.json').exists():
        verify(out / 'SCORES_FROZEN.json')
        return
    verify(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/BACKGROUND_FROZEN.json')
    verify(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/candidate_inputs/CANDIDATE_INPUTS_FROZEN.json')
    binding = fr['binding']
    current = production_gate(binding['selection_freeze'])
    assert all((binding[k] == v for k, v in current.items())), 'Frozen production inputs/code changed'
    assert binding['background_sha256'] == sha(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/background/BACKGROUND_FROZEN.json') and binding['candidate_input_sha256'] == sha(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/evaluation/candidate_inputs/CANDIDATE_INPUTS_FROZEN.json')
    init_eval()
    cases = W['cases']
    b = W['base']
    c = W['cp']
    N = len(cases)
    A = 4930 if kind == 'single' else len(fr['layout_order'])
    names = c['station_id'].astype(str).tolist() if kind == 'single' else fr['layout_order']
    availability = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/evaluation_only/target_future_availability.csv', keep_default_na=False).set_index('raw_index').loc[cases.raw_index]
    domain_hg = (availability.fixed_representative_H_nonnegative_complete & availability.fixed_representative_G_nonnegative_complete).to_numpy(bool)
    Q = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', mmap_mode='r')
    truth = np.asarray(Q[np.ix_(cases.raw_index.to_numpy(int), G)], float)
    arr = np.lib.format.open_memmap(out / 'metrics.npy', mode='w+', shape=(N, A, 5), dtype='float64')
    success = np.lib.format.open_memmap(out / 'success.npy', mode='w+', shape=(N, A), dtype=bool)
    operational = np.lib.format.open_memmap(out / 'new_channel_used.npy', mode='w+', shape=(N, A), dtype=bool)
    branchcounts = np.lib.format.open_memmap(out / 'branch_month_counts.npy', mode='w+', shape=(N, A, 2), dtype='int8')
    baseline_available = np.stack([baseline_available_months(i) for i in range(N)])
    bs = np.full((N, 5), np.nan)
    bp = np.zeros(N, bool)
    valid = np.zeros(N, bool)
    strict = np.zeros(N, bool)
    metric_defined = np.zeros(N, bool)
    boundary = []
    roundoff = []
    for i in range(N):
        bm, v = metrics(np.asarray(b['predictions'][i])[None, :], truth[i], np.asarray(b['raw_calendar'][i]))
        bs[i] = bm[0]
        valid[i] = domain_hg[i]
        metric_defined[i] = v
        strict[i] = valid[i] and cases.station_id.iloc[i] not in RISK
        base_support = bool(b['fit'][i] and b['support'][i].any())
        bp[i] = strict[i] and base_support and (bm[0, 0] > 0.7)
        with np.load(out / 'blocks' / f'target_{i:05d}.npz', allow_pickle=False) as z:
            par = {k: z[k] for k in z.files}
        stored_metrics, _ = metrics(par['predictions'], truth[i], np.asarray(b['raw_calendar'][i]))
        if kind == 'single':
            exact, branch = full_precision_single(i, par, np.arange(A), return_branch=True)
        else:
            rb = [full_precision_layout(i, par, key, return_branch=True) for key in names]
            exact = np.stack([x[0] for x in rb])
            branch = np.stack([x[1] for x in rb])
        np.testing.assert_array_equal(branch, par['input_branch'])
        used = (branch > 0).any(1)
        branchcounts[i, :, 0] = (branch == 1).sum(1)
        branchcounts[i, :, 1] = (branch == 2).sum(1)
        met, _ = metrics(exact, truth[i], np.asarray(b['raw_calendar'][i]))
        np.testing.assert_array_equal(exact[~used], np.tile(b['predictions'][i], ((~used).sum(), 1)))
        met[~used] = bm[0]
        audit = np.flatnonzero((np.abs(met[:, 0] - 0.7) <= 1e-05) | (np.abs(stored_metrics[:, 0] - 0.7) <= 1e-05) | ((met[:, 0] > 0.7) != (stored_metrics[:, 0] > 0.7)))
        for j in audit:
            r0, r1 = (stored_metrics[j, 0], met[j, 0])
            boundary.append(dict(target_row=i, arm=int(j), r_float32=r0, r_float64=r1, pass_changed=bool((r0 > 0.7) != (r1 > 0.7))))
        arr[i] = met
        operational[i] = used
        success[i] = strict[i] & (base_support | used) & (met[:, 0] > 0.7)
        if (i + 1) % 500 == 0:
            print(f'score {kind} {i + 1}/{N}', flush=True)
    for x in (arr, success, operational, branchcounts):
        x.flush()
    assert strict.sum() == 5905, 'Primary validation domain may not shrink for constant-flow outcomes'
    np.savez(out / 'baseline_metrics.npz', metrics=bs, success=bp, nonnegative_HG_domain=valid, truth_variability_metrics_defined=metric_defined, identity_strict=strict, baseline_available_G_months=baseline_available, raw_index=cases.raw_index.to_numpy(int), mother_row=cases.mother_row.to_numpy(int))
    pd.DataFrame(boundary, columns=['target_row', 'arm', 'r_float32', 'r_float64', 'pass_changed']).to_csv(out / 'threshold_precision_audit.csv', index=False)
    records = []
    domain_records = []
    boot_records = []
    mother = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/target_mother.csv', keep_default_na=False)
    for region, mask in [('Global', np.ones(N, bool))] + [(v, cases.continent.eq(v).to_numpy()) for v in sorted(cases.continent.unique())]:
        mother_n = len(mother) if region == 'Global' else int(mother.continent.eq(region).sum())
        evmask = mask & strict
        validn = int(evmask.sum())
        bn = int(bp[mask].sum())
        for j, name in enumerate(names):
            sp = np.asarray(success[:, j])
            new = int((mask & sp & ~bp).sum())
            lost = int((mask & ~sp & bp).sum())
            paired = evmask & np.isfinite(arr[:, j, 0]) & np.isfinite(bs[:, 0])
            changes = np.asarray(arr[:, j, 0]) - bs[:, 0]
            records.append(dict(region=region, arm=name, arm_index=j, mother_n=mother_n, future_complete_n=int(mask.sum()), strict_evaluable_n=validn, baseline_pass_n=bn, pass_n=int(sp[mask].sum()), new_passes=new, lost_passes=lost, net_passes=new - lost, pass_pct_strict_evaluable=100 * sp[mask].sum() / validn if validn else np.nan, net_pct_strict_evaluable=100 * (new - lost) / validn if validn else np.nan, new_channel_used_n=int((mask & operational[:, j]).sum()), paired_r_n=int(paired.sum()), mean_r_gain=float(np.mean(changes[paired])) if paired.any() else np.nan, median_r_gain=float(np.median(changes[paired])) if paired.any() else np.nan, median_r=float(np.nanmedian(arr[evmask, j, 0])) if validn else np.nan, median_NSE=float(np.nanmedian(arr[evmask, j, 1])) if validn else np.nan, median_abs_alpha_error=float(np.nanmedian(np.abs(arr[evmask, j, 2] - 1))) if validn else np.nan, median_abs_delta_error=float(np.nanmedian(np.abs(arr[evmask, j, 3]))) if validn else np.nan, median_deseasonal_r=float(np.nanmedian(arr[evmask, j, 4])) if validn else np.nan, precision_denominator='strict_evaluable_n;mother_n_descriptive_not_unvalidated_success_rate'))
            for domain, dm in [('baseline_available_all24', baseline_available.all(1)), ('rescue_needed_any_month', ~baseline_available.all(1)), ('baseline_unavailable_all24', ~baseline_available.any(1))]:
                use = evmask & dm
                nn = int(use.sum())
                nr = int((use & sp & ~bp).sum())
                nl = int((use & ~sp & bp).sum())
                pr = use & np.isfinite(arr[:, j, 0]) & np.isfinite(bs[:, 0])
                domain_records.append(dict(region=region, arm=name, domain=domain, n=nn, baseline_pass_n=int(bp[use].sum()), pass_n=int(sp[use].sum()), new_passes=nr, lost_passes=nl, net_passes=nr - nl, net_percentage_points=100 * (nr - nl) / nn if nn else np.nan, baseline_available_months=int(baseline_available[use].sum()), potential_rescue_months=int((~baseline_available[use]).sum()), augmented_input_months=int(branchcounts[use, j, 0].sum()), rescue_input_months=int(branchcounts[use, j, 1].sum()), targets_with_actual_rescue=int((use & (branchcounts[:, j, 1] > 0)).sum()), paired_r_n=int(pr.sum()), mean_r_gain=float(np.mean(changes[pr])) if pr.any() else np.nan, median_r_gain=float(np.median(changes[pr])) if pr.any() else np.nan, domain_defined_without_G_truth=True))
            if kind == 'layouts':
                for metric, values, ok in [('pass_pp', 100 * (sp.astype(float) - bp), evmask), ('r', changes, paired), ('NSE', np.asarray(arr[:, j, 1]) - bs[:, 1], evmask & np.isfinite(arr[:, j, 1]) & np.isfinite(bs[:, 1])), ('abs_alpha_error', np.abs(bs[:, 2] - 1) - np.abs(np.asarray(arr[:, j, 2]) - 1), evmask & np.isfinite(arr[:, j, 2]) & np.isfinite(bs[:, 2])), ('abs_delta_error', np.abs(bs[:, 3]) - np.abs(np.asarray(arr[:, j, 3])), evmask & np.isfinite(arr[:, j, 3]) & np.isfinite(bs[:, 3]))]:
                    cells, cc = np.unique(cases.loc[ok, 'spatial_cell'].astype(str).to_numpy(), return_inverse=True)
                    K = len(cells)
                    seed = int(hashlib.sha256(('|global1995|' + region + '|' + metric + '|' + ','.join(cells)).encode()).hexdigest()[:8], 16)
                    low = high = np.nan
                    if K >= 5:
                        draw = np.random.default_rng(seed).multinomial(K, np.ones(K) / K, size=2000)
                        den = np.bincount(cc, minlength=K)
                        num = np.bincount(cc, weights=values[ok], minlength=K)
                        vals = draw @ num / (draw @ den)
                        low, high = np.quantile(vals, [0.025, 0.975])
                    boot_records.append(dict(region=region, arm=name, metric=metric, paired_n=int(ok.sum()), spatial_cells=K, mean_gain=float(np.mean(values[ok])) if ok.any() else np.nan, ci025=low, ci975=high, bootstrap_seed=seed, bootstrap_replicates=2000, equal_station_weight=True))
    pd.DataFrame(records).to_csv(out / 'summary_by_candidate_or_layout_and_continent.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(domain_records).to_csv(out / 'baseline_available_and_rescue_domains.csv', index=False, encoding='utf-8-sig')
    scorefiles = [out / p for p in ['metrics.npy', 'success.npy', 'new_channel_used.npy', 'branch_month_counts.npy', 'baseline_metrics.npz', 'threshold_precision_audit.csv', 'summary_by_candidate_or_layout_and_continent.csv', 'baseline_available_and_rescue_domains.csv']]
    if kind == 'layouts':
        pd.DataFrame(boot_records).to_csv(out / 'paired_spatial_bootstrap.csv', index=False)
        scorefiles.append(out / 'paired_spatial_bootstrap.csv')
    freeze(out, 'SCORES_FROZEN.json', scorefiles, metric_order=['r', 'NSE', 'alpha', 'delta', 'deseasonal_r'], branch_order=['augmented', 'candidate_only_rescue'], N=N, arms=A, strict_evaluable=int(strict.sum()), invalid_truth=int((~valid).sum()), pending_identity=int((valid & ~strict).sum()), constant_or_undefined_truth_retained_in_denominator=int((strict & ~metric_defined).sum()), prediction_freeze_sha256=sha(out / 'PREDICTIONS_FROZEN.json'), threshold_near_count=len(boundary), all_metrics_frozen_coefficient_float64_recomputed=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('step', choices=['fixture', 'prepare_background', 'produce_single', 'score_single', 'produce_layouts', 'score_layouts'])
    ap.add_argument('--selection-freeze')
    ap.add_argument('--layouts')
    ap.add_argument('--prediction-qa')
    ap.add_argument('--workers', type=int, default=4)
    a = ap.parse_args()
    if a.step == 'fixture':
        fixture()
        return
    if a.step == 'prepare_background':
        prepare_background(a.selection_freeze, a.workers)
    elif a.step == 'produce_single':
        produce_single(a.selection_freeze, a.workers)
    elif a.step == 'produce_layouts':
        produce_layouts(a.selection_freeze, a.layouts, a.workers)
    elif a.step.startswith('score_'):
        score(a.step.removeprefix('score_'), a.prediction_qa)
if __name__ == '__main__':
    main()
