"""Pre-1995-only global roles; future masks are isolated evaluation metadata.

No flow magnitudes, predictions or performance are loaded.
"""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))

def _release_path(kind, relative):
    import os as _release_os
    from pathlib import Path as _ReleasePath
    code_root = _PROJECT_ROOT
    root = code_root if kind == 'code' else _ReleasePath(_release_os.environ.get('STREAMFLOW_DATA_ROOT', str(code_root / 'data')))
    return str(root / relative)
from pathlib import Path
import sys, json, hashlib, time
from datetime import datetime, timezone
ROOT = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60'
OUT = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design'
SEL = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs'
EV = _PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/evaluation_only'
CODE = _PROJECT_ROOT
pass
import numpy as np, pandas as pd
GDATA = _PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data'
PREV = _PROJECT_ROOT / 'workflows/monitoring/location_selection'
CAT = Path(_release_path('data', 'gsim/catalogs/GSIM_catchment_characteristics.csv'))
RISK = ['GB_0000239', 'GB_0000240', 'GB_0000241', 'GB_0000242']
PRE_END = 180
H_END = 240
G_END = 264

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def js(p, x):
    Path(p).write_text(json.dumps(x, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')

def main():
    start = time.time()
    for p in [OUT, SEL, EV]:
        p.mkdir(exist_ok=True, parents=True)
    assert not (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/DESIGN_FROZEN.json').exists()
    files = [_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_finite_mask.npy', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_negative_mask.npy', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/station_ids.npy', _PROJECT_ROOT / 'workflows/monitoring/location_selection/census/physical_identity_map.csv', _PROJECT_ROOT / 'workflows/monitoring/location_selection/census/metadata_enrichment/global_station_metadata.csv', _PROJECT_ROOT / 'workflows/monitoring/location_selection/design/source_inventory.csv', _PROJECT_ROOT / 'workflows/monitoring/location_selection/design/STATIC_CHOICES_FROZEN.json', CAT]
    protocol = dict(created_utc=datetime.now(timezone.utc).isoformat(), selection_time='1995-01 before anyH observation', pre=[0, 180], pre_dates=['1980-01', '1994-12'], H=[180, 240], H_dates=['1995-01', '1999-12'], G=[240, 264], G_dates=['2000-01', '2001-12'], calendar_rationale='Middle-of-archive five-year accumulation followed by two-year future check, explicitly approved; no performance-based window search. Mask preflight counts were known.', target_mother='All30959 catalogue IDs grouped by complete confirmed physical components; exclude every pseudo-new candidate physical component; require >=1 QC20-finite nonnegative pre observation under one ID. Per physical group choose among pre-eligible IDs: non-twin-listed first, more valid pre months next, then stationID lexical. No H/G availability, variance, scores, or coordinate eligibility gate.', background='Re-census all30959 with >=12 QC20-finite nonnegative PRE months; exclude candidate components and pending British aliases. One representative per physical group selected with same pre-only ordering among eligible IDs. Old19800 retained-source domain is not reused as admission because it used whole-archive criteria.', candidates='Exactly4930 previously frozen static simulated candidate physical positions; all physical aliases blocked from pre selector. Their membership was originally drawn from the retrospective full archive/source catalogue, so it is an after-the-fact experimental location inventory, not a historical1995 candidate discovery.', future='H/G complete flags only in evaluation_only. Fixed pre target representative never swapped for a later-complete alias. Alias alternatives listed as separate sensitivity; original7364 whole-window availability count separate from pre target mother.', selector='Only static features and pre masks for non-candidates. No candidate pre/H/G runoff values, no future availability fields in selector_inputs. Data manifest gives original Q path but restricted per-stage access is mandatory.', attributes='Officialarea.meta is km2; header area is not a replacement. Official static catchment attribute inventory is supplied, but historical availability at1995 is not established; derived/current human variables need explicit timestamp review before being used as retrospective predictors.', inputs={str(p): sha(p) for p in files}, code_sha256=sha(__file__), reads_flow_magnitudes=False, reads_scores=False)
    js(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/DESIGN_PROTOCOL.json', protocol)
    ids = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/station_ids.npy', allow_pickle=False).astype(str)
    qm = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_finite_mask.npy', mmap_mode='r')
    neg = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_negative_mask.npy', mmap_mode='r')
    assert len(ids) == 30959 and qm.shape == neg.shape == (30959, 432) and (qm.dtype == neg.dtype == bool)
    ident = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/census/physical_identity_map.csv', keep_default_na=False)
    allowed = ['raw_index', 'station_id', 'physical_group_raw_index', 'physical_group_id', 'physical_component_size', 'twin_listed', 'source_pending_alias_excluded', 'all_same_station_exclusion_raw_indices', 'all_same_station_exclusion_ids', 'latitude', 'longitude', 'kg_major', 'kg_code', 'spatial_cell', 'valid_coordinates', 'header_river', 'header_station', 'official_area_km2', 'official_area_source', 'official_area_band', 'official_estimated_area_km2', 'official_catchment_quality', 'official_suspect_coordinates', 'country_display', 'continent_display']
    meta = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/census/metadata_enrichment/global_station_metadata.csv', keep_default_na=False, usecols=allowed, low_memory=False)
    np.testing.assert_array_equal(ids, meta.station_id.to_numpy(str))
    np.testing.assert_array_equal(ids, ident.station_id.to_numpy(str))
    meta['country'] = meta.country_display
    meta['continent'] = meta.continent_display
    meta['listed_twin'] = meta.twin_listed.astype(str).str.lower().eq('true')
    inv = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/source_inventory.csv', keep_default_na=False, usecols=['raw_index', 'station_id', 'physical_group_id', 'withheld'])
    assert len(inv) == 24730 and inv.physical_group_id.is_unique
    candidates = inv[inv.withheld.astype(str).str.lower().eq('true')].copy()
    assert len(candidates) == 4930
    cgroups = set(candidates.physical_group_id)
    candidate_all = meta.physical_group_id.isin(cgroups).to_numpy()
    roots, groupcode = np.unique(meta.physical_group_raw_index.to_numpy(int), return_inverse=True)
    P = len(roots)
    pre = np.asarray(qm[:, :PRE_END] & ~neg[:, :PRE_END])
    pre_n = pre.sum(axis=1)
    meta['pre_valid_nonnegative_months'] = pre_n
    meta['pre_calendar_months_represented'] = [int(np.sum(np.bincount(np.flatnonzero(row) % 12, minlength=12) > 0)) for row in pre]
    meta['pre_at_least60'] = pre_n >= 60
    meta['candidate_physical_component'] = candidate_all
    meta['pending_alias_target'] = meta.station_id.isin(RISK)
    order = ['physical_group_id', 'listed_twin', 'pre_valid_nonnegative_months', 'station_id']
    ascending = [True, True, False, True]
    target_pre_eligible = ~candidate_all & (pre_n >= 1)
    T = meta[target_pre_eligible].sort_values(order, ascending=ascending).drop_duplicates('physical_group_id').sort_values('raw_index').copy().reset_index(drop=True)
    background_eligible = ~candidate_all & (pre_n >= 12) & ~meta.pending_alias_target.to_numpy()
    B = meta[background_eligible].sort_values(order, ascending=ascending).drop_duplicates('physical_group_id').sort_values('raw_index').copy().reset_index(drop=True)
    C = meta.iloc[candidates.raw_index.to_numpy(int)].copy().sort_values('raw_index').reset_index(drop=True)
    assert len(C) == 4930 and (not set(T.physical_group_id) & cgroups) and (not set(B.physical_group_id) & cgroups)
    assert T.physical_group_id.is_unique and B.physical_group_id.is_unique and C.physical_group_id.is_unique
    for df in [T, B, C]:
        df['row'] = np.arange(len(df))
    for k, v in [('pre_start', 0), ('pre_end', 180), ('history_start', 180), ('history_end', 240), ('gap_start', 240), ('gap_end', 264), ('H', 60), ('L', 24), ('anchor', 240)]:
        T[k] = v
    T['case_id'] = [hashlib.sha256(f'GLOBAL_NETWORK1995|{s}|pre180|H60|G24'.encode()).hexdigest()[:28] for s in T.station_id]
    T['pre_information_state'] = np.where(T.pre_valid_nonnegative_months.ge(60), 'pre_ge60', 'pre_1_to59_retained')
    staticcols = [c for c in allowed if c not in ['source_pending_alias_excluded', 'twin_listed']] + ['country', 'continent']
    static = meta[staticcols].copy()
    attrs = pd.read_csv(CAT, keep_default_na=False, low_memory=False).rename(columns={'gsim.no': 'station_id'})
    assert attrs.station_id.is_unique
    joined = static.merge(attrs, on='station_id', how='left', validate='one_to_one', suffixes=('', '_official_catalogue'))
    featurecols = [c for c in attrs if c != 'station_id']
    inventory = []
    for col in featurecols:
        values = attrs[col]
        num = pd.to_numeric(values, errors='coerce')
        missing = values.astype(str).isin(['', 'NA', 'NaN', 'nan'])
        group = 'physical_geometry_or_terrain' if col in ['long.org', 'lat.org', 'long.new', 'lat.new', 'dist.km', 'area.meta', 'area.est', 'quality', 'altitude.meta', 'altitude.dem'] or col.startswith(('ele.', 'slp.', 'lithology.', 'soil.', 'sb.', 'scl.', 'snd.', 'slt.')) else 'climate_or_landcover' if col in ['climate.type', 'landcover.type'] or col.startswith(('tp.', 'ir.')) else 'human_or_other_static'
        inventory.append(dict(column=col, category=group, nonmissing_rows=int((~missing).sum()), numeric_rows=int(num.notna().sum()), unique_nonmissing=int(values[~missing].nunique()), source=CAT.name, allowed_now='inventory_only_not_automatically_predictor', historical_t0_alignment='not_verified_1995', notes='area.meta standardized km2' if col == 'area.meta' else ''))
    pd.DataFrame(inventory).to_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/static_attribute_inventory.csv', index=False, encoding='utf-8-sig')
    joined.to_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/all_static_station_metadata.csv', index=False, encoding='utf-8-sig')
    cstatic = joined.set_index('raw_index').loc[C.raw_index].reset_index()
    cstatic['row'] = np.arange(len(C))
    cstatic['inventory_origin'] = 'frozen4930_retrospective_pseudo_new_positions'
    cstatic.to_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/candidate_locations.csv', index=False, encoding='utf-8-sig')
    T.to_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/target_mother.csv', index=False, encoding='utf-8-sig')
    T.to_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/target_cases.csv', index=False, encoding='utf-8-sig')
    B.to_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/background_sources.csv', index=False, encoding='utf-8-sig')
    B.to_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/background_sources.csv', index=False, encoding='utf-8-sig')
    roles = meta[['raw_index', 'station_id', 'physical_group_raw_index', 'physical_group_id', 'all_same_station_exclusion_raw_indices', 'all_same_station_exclusion_ids', 'country', 'continent', 'kg_major', 'spatial_cell', 'pre_valid_nonnegative_months', 'pre_calendar_months_represented', 'valid_coordinates', 'pre_at_least60', 'pending_alias_target']].copy()
    roles['candidate_physical_component'] = candidate_all
    roles['target_pre_eligible_ID'] = target_pre_eligible
    roles['target_representative'] = roles.raw_index.isin(T.raw_index)
    roles['background_pre_eligible_ID'] = background_eligible
    roles['background_representative'] = roles.raw_index.isin(B.raw_index)
    roles['target_role_reason'] = np.where(candidate_all, 'excluded_candidate_physical_component', np.where(pre_n == 0, 'no_pre_nonnegative_QC20_observation', np.where(roles.target_representative, 'pre_only_target_representative', 'pre_eligible_same_physical_alias_not_representative')))
    roles.to_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/evaluation_only/all30959_role_and_pre_availability_ledger.csv', index=False, encoding='utf-8-sig')
    selector_mask = pre.copy()
    selector_mask[candidate_all] = False
    np.save(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/noncandidate_pre_valid_mask.npy', selector_mask, allow_pickle=False)
    np.save(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/background_pre_valid_mask.npy', selector_mask[B.raw_index.to_numpy(int)], allow_pickle=False)
    np.save(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/target_pre_valid_mask.npy', selector_mask[T.raw_index.to_numpy(int)], allow_pickle=False)
    np.savez(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/network_roles.npz', all_station_ids=ids, physical_group_raw_index=meta.physical_group_raw_index.to_numpy(np.int32), background_raw=B.raw_index.to_numpy(np.int32), target_raw=T.raw_index.to_numpy(np.int32), candidate_raw=C.raw_index.to_numpy(np.int32), candidate_all_alias_raw=np.flatnonzero(candidate_all).astype(np.int32), selection_month_indices=np.arange(PRE_END, dtype=np.int16))
    hc = np.all(qm[:, PRE_END:H_END], axis=1)
    gc = np.all(qm[:, H_END:G_END], axis=1)
    hg = hc & gc
    hnn = np.all(qm[:, PRE_END:H_END] & ~neg[:, PRE_END:H_END], axis=1)
    gnn = np.all(qm[:, H_END:G_END] & ~neg[:, H_END:G_END], axis=1)

    def group_any(flag):
        a = np.zeros(P, bool)
        np.logical_or.at(a, groupcode, flag)
        return a
    aliasH = group_any(hc)
    aliasG = group_any(gc)
    aliasHG = group_any(hg)
    for name, df in [('target', T), ('candidate', C), ('background', B)]:
        row = df.raw_index.to_numpy(int)
        g = groupcode[row]
        ev = df[['row', 'raw_index', 'station_id', 'physical_group_raw_index', 'physical_group_id', 'continent', 'country', 'kg_major', 'spatial_cell', 'valid_coordinates', 'pre_valid_nonnegative_months', 'pre_at_least60']].copy()
        ev['fixed_representative_H_complete'] = hc[row]
        ev['fixed_representative_G_complete'] = gc[row]
        ev['fixed_representative_HG_complete'] = hg[row]
        ev['fixed_representative_H_nonnegative_complete'] = hnn[row]
        ev['fixed_representative_G_nonnegative_complete'] = gnn[row]
        ev['any_single_alias_HG_complete'] = aliasHG[g]
        ev['fixed_incomplete_but_single_alias_complete'] = ~hg[row] & aliasHG[g]
        ev['future_data_role'] = 'evaluation_only_not_site_selector'
        ev.to_csv(EV / f'{name}_future_availability.csv', index=False, encoding='utf-8-sig')
        if name == 'target':
            ev.loc[hg[row]].to_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/evaluation_only/target_fixed_representative_complete_HG.csv', index=False, encoding='utf-8-sig')
            ev.loc[~hg[row] & aliasHG[g]].to_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/evaluation_only/target_alias_completeness_sensitivity.csv', index=False, encoding='utf-8-sig')
    totals = []
    for name, df in [('target_mother', T), ('background', B), ('candidate', C)]:
        rows = df.raw_index.to_numpy(int)
        for dim in ['Global', 'continent', 'country', 'kg_major']:
            gl = [('Global', np.ones(len(df), bool))] if dim == 'Global' else [(s, df[dim].eq(s).to_numpy()) for s in sorted(df[dim].unique())]
            for label, sel in gl:
                rr = rows[sel]
                totals.append(dict(role=name, dimension=dim, level=label, n=int(sel.sum()), pre_ge60=int((pre_n[rr] >= 60).sum()), pre_ge12=int((pre_n[rr] >= 12).sum()), pre_any=int((pre_n[rr] >= 1).sum()), valid_coordinates=int(df.loc[sel, 'valid_coordinates'].sum()), evaluation_H_complete=int(hc[rr].sum()), evaluation_G_complete=int(gc[rr].sum()), evaluation_HG_complete=int(hg[rr].sum()), evaluation_fixed_incomplete_alias_complete=int((~hg[rr] & aliasHG[groupcode[rr]]).sum())))
    pd.DataFrame(totals).to_csv(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/role_representativeness_and_evaluation_counts.csv', index=False, encoding='utf-8-sig')
    wholeHG = group_any(hg)
    candidategrp = np.isin(roots, meta.loc[candidate_all, 'physical_group_raw_index'].unique())
    np.savez_compressed(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/evaluation_only/future_complete_masks_NOT_FOR_SELECTION.npz', station_ids=ids, H_complete=hc, G_complete=gc, HG_complete=hg, H_nonnegative_complete=hnn, G_nonnegative_complete=gnn)
    qpath = _PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy'
    rawpath = _PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/raw_Q.npy'
    js(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/DATA_ACCESS_MANIFEST.json', dict(QC20_flow_original_path=str(qpath), raw_flow_original_path=str(rawpath), flow_shape=[30959, 432], dtype='float64', station_order_path=str(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/station_ids.npy'), pre_allowed_month_slice=[0, 180], pre_forbidden_raw_indices_file=str(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/network_roles.npz') + '::candidate_all_alias_raw', selector_masks=str(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/selector_inputs/noncandidate_pre_valid_mask.npy'), selection_must_not_access='all candidate flow; all target/backgroundH1995-1999 orG2000-2001; evaluation_only flags', future_fit_stage='after global layout freeze, H1995-1999 may be opened for accumulated-history calibration', evaluation_stage='G2000-2001 target truth only after prediction freeze and independent QA', flow_files_copied=False, flow_magnitudes_read=False))
    for name, minimum, actual in [('target', 1, T), ('background', 12, B)]:
        wanted = []
        for k in roots:
            rr = np.flatnonzero(meta.physical_group_raw_index.to_numpy(int) == k)
            rr = rr[~candidate_all[rr] & (pre_n[rr] >= minimum)]
            if name == 'background':
                rr = rr[~meta.pending_alias_target.to_numpy()[rr]]
            if len(rr):
                wanted.append(min(rr, key=lambda j: (bool(meta.listed_twin.iloc[j]), -int(pre_n[j]), ids[j])))
        assert sorted(wanted) == actual.raw_index.tolist()
    assert not selector_mask[candidate_all].any()
    assert selector_mask[:, :].shape == (30959, 180)
    assert not set(C.physical_group_id) & set(T.physical_group_id) and (not set(C.physical_group_id) & set(B.physical_group_id))
    assert all((sha(p) == h for p, h in protocol['inputs'].items()))
    summary = dict(status='PRE_ONLY_GLOBAL_1995_ROLES_FROZEN', raw_IDs=30959, physical_groups=P, candidate_positions=len(C), candidate_alias_IDs=int(candidate_all.sum()), target_mother=len(T), target_pre_ge60=int(T.pre_at_least60.sum()), background_sources=len(B), target_fixed_representative_HG_complete=int(hg[T.raw_index.to_numpy(int)].sum()), target_alias_only_HG_complete=int((~hg[T.raw_index.to_numpy(int)] & aliasHG[groupcode[T.raw_index.to_numpy(int)]]).sum()), whole_catalogue_HG_complete_physical=int(wholeHG.sum()), whole_catalogue_HG_complete_excluding_candidate_physical=int((wholeHG & ~candidategrp).sum()), candidate_HG_complete_evaluation_only=int(hg[C.raw_index.to_numpy(int)].sum()), target_missing_coordinates=int((~T.valid_coordinates.to_numpy(bool)).sum()), target_pending_aliases=int(T.pending_alias_target.sum()), flow_values_read=False, pre_only_role_QA_pass=True, seconds=time.time() - start)
    js(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/DESIGN_SUMMARY.json', summary)
    text = ['# 全球共同布局：1995年部署前角色准备', '', '共同选址时点为1995年1月之前；pre为1980—1994年，新增位置积累的共同历史为1995—1999年，后续检验为2000—2001年。选择这个中段时间安排用于固定五年示例，尚未读取新重构成绩或选择布局。', '', f'部署前目标母集合为{len(T):,}个物理站，依据部署前至少1个月QC20非负有效观测确定，其中{int(T.pre_at_least60.sum()):,}站具有至少60个月pre记录。全球背景来源重新从全部目录按pre至少12个月非负有效观测确定，共{len(B):,}个物理站；不沿用旧试验按全档案筛出的19,800站作为资格。', '', '每个物理组优先非twin_listed条目，其次pre有效月较多，最后ID字典序。代表在观察未来H/G完整性之前固定。未来完整的别名不会替换母代表，只另记敏感性。坐标缺失、pre少于60或未来缺观测均保留状态，不按其预期成绩删站。', '', f'固定母代表中有{int(hg[T.raw_index.to_numpy(int)].sum()):,}站在H60+G24具有完整QC20记录，作为未来可检验子集；母代表不完整但别名完整有{int((~hg[T.raw_index.to_numpy(int)] & aliasHG[groupcode[T.raw_index.to_numpy(int)]]).sum())}站。原共同窗7,364个完整物理站是另一种只看未来完整性的统计，不能替代本轮部署前目标母集合。', '', '4930个模拟新位置沿用此前冻结的静态库存，所有同物理别名从背景和目标中排除。其库存最初来自事后完整档案，不能宣称是在1995年历史资料中发现的真实未建站地点。candidate H/G完整性仅用于说明可验证范围，不能参与选址或更换候选。', '', 'selector_inputs仅提供静态属性和非candidate的pre布尔掩码。没有候选流量值，也没有任何未来H/G可用性字段；这些标记单列evaluation_only。DATA_ACCESS_MANIFEST记录原始流量路径和后续分阶段读取约束，本步骤没有读取流量大小。', '', 'GSIM官方流域特征的可用列盘点见static_attribute_inventory.csv。area.meta为官方km²；header面积不可替代。气候、地形以及人类活动等静态字段虽可列出，但其1995年历史可获得性尚未逐项确认，不能不经审查全部当作当年可得变量。', '', '所有地区人数见role_representativeness_and_evaluation_counts.csv；不按国家或流域设置布设配额。此次只准备角色、时间及资料，尚未运行选址收益模型或生成新布局。']
    (_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/全球固定时间与部署前角色_准备说明.md').write_text('\n'.join(text) + '\n', encoding='utf8')
    js(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/DESIGN_FROZEN.json', dict(passed=True, summary=summary, protocol_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/network_gain_H60/design/DESIGN_PROTOCOL.json'), code_sha256=sha(__file__), files={str(p): sha(p) for p in OUT.rglob('*') if p.is_file() and p.name != 'DESIGN_FROZEN.json'}, all_source_hashes_unchanged=True, no_future_eligibility_in_selector=True))
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
if __name__ == '__main__':
    main()
