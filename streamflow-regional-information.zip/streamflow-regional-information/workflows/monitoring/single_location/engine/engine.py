"""Pure numerical kernels for one added, complete synchronous source.

No real-data files or held-out target values are read by prediction functions.
Candidates are evaluated individually, never cumulatively. Their extra channel
does not compete with the old K4 composite or pass a covariance-proxy gate.
All model and transformation parameters are estimated from supplied training
arrays. The caller owns date/identity roles, source selection, design freezes,
development selection and final-test isolation.
"""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os
import sys
import json
import hashlib
import importlib.util
for _key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_key] = '1'
sys.dont_write_bytecode = True
HERE = _PROJECT_ROOT / 'workflows/monitoring/single_location/engine'
CODE = _PROJECT_ROOT
pass
import numpy as np
CORE_PATH = _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/run_outage.py'
MODEL_PATH = _PROJECT_ROOT / 'workflows/rainfall/global_inputs/design_review/transfer_model.py'
_spec = importlib.util.spec_from_file_location('direct_siting_transform_core', CORE_PATH)
C = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(C)
pass
import workflows.rainfall.global_inputs.design_review.transfer_model as M
LAMBDA = 0.1
EPS = 1e-12
MIN_CANDIDATE_ROWS = 24
NUMERIC_TOLERANCE = 1e-12

def dependency_hashes():
    """Called by production registration; binds unchanged imported kernels."""
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (_PROJECT_ROOT / 'workflows/monitoring/single_location/engine/engine.py', CORE_PATH, MODEL_PATH)}

def prepare_candidate_channels(raw_training, raw_prediction, training_months, prediction_months):
    """Transform candidate rows using training values only, once per window.

    Inputs are C×H and C×L. Returned features are H×C and L×C. Prediction
    availability is retained per month, not used to choose H quality or fit.
    Complete-record experiments should independently fix their candidate frame
    from availability masks; this helper never fabricates missing observations.
    """
    h = np.asarray(raw_training, float)
    v = np.asarray(raw_prediction, float)
    hm = np.asarray(training_months, int)
    vm = np.asarray(prediction_months, int)
    if h.ndim != 2 or v.ndim != 2 or h.shape[0] != v.shape[0]:
        raise ValueError('Candidate arrays must be C×H and C×L')
    if h.shape[1] != len(hm) or v.shape[1] != len(vm):
        raise ValueError('Candidate date dimensions disagree')
    cl, sd, z = C.prep(h, hm)
    good_h = np.isfinite(h) & (h >= 0)
    calendar_n = np.stack([good_h[:, hm % 12 == m].sum(1) for m in range(12)], axis=1)
    quality = good_h.all(1) & (good_h.sum(1) >= MIN_CANDIDATE_ROWS) & (calendar_n >= 2).all(1) & np.isfinite(cl).all(1) & np.isfinite(sd)
    good_v = np.isfinite(v) & (v >= 0)
    zv = np.full(v.shape, np.nan)
    valid = good_v & np.isfinite(cl[:, vm % 12]) & np.isfinite(sd[:, None])
    logged = np.full(v.shape, np.nan)
    logged[good_v] = np.log1p(v[good_v])
    np.divide(logged - cl[:, vm % 12], sd[:, None], out=zv, where=valid)
    return dict(train=z.T, predict=zv.T, training_quality=quality, training_observed=good_h.T, prediction_observed=good_v.T, log_calendar=cl, anomaly_sd=sd, calendar_n=calendar_n, training_months=hm.copy(), prediction_months=vm.copy())

def prepare_target(raw_training, training_months, prediction_months):
    h = np.asarray(raw_training, float)
    hm = np.asarray(training_months, int)
    vm = np.asarray(prediction_months, int)
    if h.shape != (len(hm),):
        raise ValueError('Target training shape mismatch')
    cl, sd, z = C.prep(h[None, :], hm)
    cl, sd, z = (cl[0], float(sd[0]), z[0])
    estimable = bool(np.isfinite(h).all() and (h >= 0).all() and np.isfinite(cl).all() and np.isfinite(sd))
    if not estimable:
        z = np.full(h.shape, np.nan)
    usable = np.where(np.isfinite(h) & (h >= 0), h, np.nan)
    raw_calendar = np.array([np.nanmean(usable[hm % 12 == m]) for m in range(12)])
    return dict(z=z, log_calendar=cl, sd=sd, raw_calendar=raw_calendar, fallback=raw_calendar[vm % 12], estimable=estimable, training_months=hm.copy(), prediction_months=vm.copy())

def ridge_base(x, y):
    """Equivalent to the original fixed standardized ridge, with an intercept."""
    x, y = (np.asarray(x, float), np.asarray(y, float))
    if x.ndim != 2 or y.shape != (len(x),) or len(y) < 12 or (x.shape[1] < 1):
        raise ValueError('Invalid baseline ridge dimensions')
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError('Baseline ridge input must be finite')
    mean, sd = (x.mean(0), x.std(0))
    scale = np.where(sd > EPS, sd, 1.0)
    z = (x - mean) / scale
    ym = float(y.mean())
    yc = y - ym
    a = z.T @ z + len(y) * LAMBDA * np.eye(x.shape[1])
    inv = np.linalg.inv(a)
    beta = np.linalg.solve(a, z.T @ yc)
    return dict(mean=mean, scale=scale, z=z, ym=ym, yc=yc, inv=inv, beta=beta, n=len(y))

def schur_additions(base, candidate_training, candidate_prediction, eligible, x_prediction):
    """Fit C separate one-column additions on exactly the baseline rows.

    Returns L×C standardized target predictions and float64 parameters. No
    candidate-positive-correlation requirement or precomputed information gate.
    Invalid candidate columns are inert; missing prediction reports stay NaN.
    """
    ct = np.asarray(candidate_training, float)
    cv = np.asarray(candidate_prediction, float)
    xv = np.asarray(x_prediction, float)
    eligible = np.asarray(eligible, bool).copy()
    if ct.ndim != 2 or cv.ndim != 2 or ct.shape[1] != cv.shape[1] or (len(ct) != base['n']):
        raise ValueError('Schur dimensions disagree')
    finite_h = np.isfinite(ct).all(0)
    safe = np.where(np.isfinite(ct), ct, 0.0)
    mean, sd = (safe.mean(0), safe.std(0))
    eligible &= finite_h & (sd > EPS) & (base['n'] >= MIN_CANDIDATE_ROWS)
    scale = np.where(sd > EPS, sd, 1.0)
    z = (safe - mean) / scale
    cross = base['z'].T @ z
    invcross = base['inv'] @ cross
    denominator = np.sum(z * z, axis=0) + base['n'] * LAMBDA - np.sum(cross * invcross, axis=0)
    coefficient = (z.T @ base['yc'] - cross.T @ base['beta']) / denominator
    eligible &= np.isfinite(coefficient) & np.isfinite(denominator) & (denominator > 0)
    coefficient = np.where(eligible, coefficient, 0.0)
    base_coefficients = base['beta'][:, None] - invcross * coefficient[None, :]
    pred = base['ym'] + (xv - base['mean']) / base['scale'] @ base_coefficients
    pred += (cv - mean) / scale * coefficient
    base_pred = base['ym'] + (xv - base['mean']) / base['scale'] @ base['beta']
    pred[:, ~eligible] = base_pred[:, None]
    return (pred, dict(candidate_mean=mean, candidate_scale=scale, candidate_coefficient=coefficient, base_coefficients=base_coefficients, eligible=eligible, schur_denominator=denominator))

def candidate_only(candidate_training, candidate_prediction, y, eligible):
    """One-channel rescue fits on all finite target-H rows; no Q required."""
    h, v, y = (np.asarray(candidate_training, float), np.asarray(candidate_prediction, float), np.asarray(y, float))
    count = h.shape[1]
    pred = np.full((len(v), count), np.nan)
    good = np.asarray(eligible, bool).copy()
    good &= np.isfinite(h).all(0)
    if len(y) < MIN_CANDIDATE_ROWS or not np.isfinite(y).all():
        good[:] = False
    safe = np.where(np.isfinite(h), h, 0.0)
    mean, sd = (safe.mean(0), safe.std(0))
    scale = np.where(sd > EPS, sd, 1.0)
    good &= sd > EPS
    z = (safe - mean) / scale
    ym = float(np.mean(y)) if len(y) else np.nan
    coef = z.T @ (y - ym) / (np.sum(z * z, axis=0) + len(y) * LAMBDA) if len(y) else np.zeros(count)
    good &= np.isfinite(coef)
    pred[:, good] = ym + (v[:, good] - mean[good]) / scale[good] * coef[good]
    return (pred, dict(candidate_mean=mean, candidate_scale=scale, candidate_coefficient=coef, target_mean=ym, eligible=good))

def inverse_many(z, target):
    """Apply unchanged target-H guards to L×C predictions; return C×L."""
    z = np.asarray(z, float)
    if z.ndim != 2 or z.shape[0] != len(target['prediction_months']):
        raise ValueError('Inverse prediction dimensions disagree')
    base = np.broadcast_to(target['fallback'][:, None], z.shape).copy()
    support = np.zeros(z.shape, bool)
    if not target['estimable']:
        return (base.T, support.T)
    vals = target['z'][np.isfinite(target['z'])]
    months = target['prediction_months']
    cl = target['log_calendar'][months % 12, None]
    support = np.isfinite(z) & np.isfinite(cl)
    guarded = np.clip(np.where(support, z, 0.0), vals.min() - 3, vals.max() + 3)
    pred = np.maximum(np.expm1(np.minimum(guarded * target['sd'] + cl, 50)), 0.0)
    pred[~support] = base[~support]
    return (pred.T, support.T)

def predict_all_candidates(x_training, x_prediction, raw_target_training, training_months, prediction_months, candidate_inputs, target_physical_id, candidate_physical_ids, candidate_allowed=None):
    """Baseline and one-source-at-a-time predictions; no target future input.

    x_training/x_prediction are the fixed existing Q or QP feature arrays,
    constructed by the caller from training-only transforms/source selection.
    Candidate features come from prepare_candidate_channels for the same dates.
    Branch: 0 exact baseline; 1 baseline-plus-single-source; 2 source-only rescue.
    Physical target aliases are ineligible even if accidentally passed by caller.
    """
    xh, xv = (np.asarray(x_training, float), np.asarray(x_prediction, float))
    hm, vm = (np.asarray(training_months, int), np.asarray(prediction_months, int))
    if xh.ndim != 2 or xv.ndim != 2 or xh.shape[1] != xv.shape[1] or (len(xh) != len(hm)) or (len(xv) != len(vm)):
        raise ValueError('Baseline feature dimensions disagree')
    ch, cv = (np.asarray(candidate_inputs['train'], float), np.asarray(candidate_inputs['predict'], float))
    if not np.array_equal(hm, candidate_inputs['training_months']) or not np.array_equal(vm, candidate_inputs['prediction_months']):
        raise ValueError('Candidate and target dates differ')
    count = ch.shape[1]
    ids = np.asarray(candidate_physical_ids)
    if ids.shape != (count,):
        raise ValueError('Candidate identity shape mismatch')
    allowed = np.ones(count, bool) if candidate_allowed is None else np.asarray(candidate_allowed, bool).copy()
    if allowed.shape != (count,):
        raise ValueError('Candidate allowed mask mismatch')
    allowed &= ids != target_physical_id
    quality = np.asarray(candidate_inputs['training_quality'], bool) & allowed
    t = prepare_target(raw_target_training, hm, vm)
    train = np.isfinite(t['z']) & np.isfinite(xh).all(1)
    fit, _ = M.fit_transfer(xh[train], t['z'][train], method='ridge', target_estimable=t['estimable'])
    base_z = fit.predict(xv) if fit is not None else np.full(len(vm), np.nan)
    baseline, base_support = C.transfer(base_z, t['z'], t['log_calendar'], t['sd'], vm, t['fallback'], fit is not None)
    predictions = np.broadcast_to(baseline, (count, len(vm))).copy()
    support = np.broadcast_to(base_support, predictions.shape).copy()
    branch = np.zeros(predictions.shape, np.int8)
    params = {}
    augmented_eligible = np.zeros(count, bool)
    if fit is not None:
        b = ridge_base(xh[train], t['z'][train])
        z, ap = schur_additions(b, ch[train], cv, quality, xv)
        q, s = inverse_many(z, t)
        augmented_eligible = ap['eligible']
        use = s & augmented_eligible[:, None] & np.isfinite(xv).all(1)[None, :] & np.asarray(candidate_inputs['prediction_observed'], bool).T
        predictions[use], support[use], branch[use] = (q[use], True, 1)
        params['augmented'] = ap
    target_rows = np.isfinite(t['z'])
    z, rp = candidate_only(ch[target_rows], cv, t['z'][target_rows], quality & t['estimable'])
    q, s = inverse_many(z, t)
    missing_baseline = ~(bool(fit is not None) & np.isfinite(xv).all(1))
    rescue = s & rp['eligible'][:, None] & missing_baseline[None, :] & np.asarray(candidate_inputs['prediction_observed'], bool).T
    predictions[rescue], support[rescue], branch[rescue] = (q[rescue], True, 2)
    params['rescue'] = rp
    assert not branch[~allowed].any()
    unchanged = branch == 0
    np.testing.assert_array_equal(predictions[unchanged], np.broadcast_to(baseline, predictions.shape)[unchanged])
    return dict(baseline=baseline, baseline_support=base_support, baseline_fit=bool(fit is not None), predictions=predictions, support=support, branch=branch, training_mask=train, target_estimable=t['estimable'], target_transform=t, candidate_allowed=allowed, candidate_H_quality=quality, augmented_eligible=augmented_eligible, rescue_eligible=rp['eligible'], parameters=params)

def score_predictions(predictions, truth, support):
    """Explicit evaluation API, separate from prediction. Row-wise raw r only."""
    p = np.atleast_2d(np.asarray(predictions, float))
    y = np.asarray(truth, float)
    s = np.asarray(support, bool)
    if s.ndim == 1:
        s = s[None, :]
    if p.shape[1:] != y.shape or s.shape != p.shape:
        raise ValueError('Scoring arrays disagree')
    valid_y = bool(np.isfinite(y).all() and (y >= 0).all())
    yc = y - y.mean()
    ys = float(yc @ yc)
    finite = np.isfinite(p).all(1) & (p >= 0).all(1)
    pc = p - p.mean(1, keepdims=True)
    ps = np.sum(pc * pc, axis=1)
    den = np.sqrt(ps * ys)
    r = np.divide(pc @ yc, den, out=np.full(len(p), np.nan), where=den > 1e-24)
    r = np.clip(r, -1, 1)
    r[~finite | (not valid_y)] = np.nan
    eligible = valid_y & (ys > 1e-24) & finite & np.isfinite(r) & s.any(1)
    return dict(r=r, eligible=eligible, success=eligible & (r > 0.7), support_months=s.sum(1))

def development_use_mask(baseline_score, added_scores):
    """Historical-only use decision. Must be frozen before final target G.

    Same raw-r criterion for every supported target/candidate. An unsupported
    or undefined baseline needs a supported candidate above r>.7 before entry.
    This is a development choice and its development gains are optimistic.
    Final evaluation must apply this stored mask without looking at test truth.
    """
    br = float(np.asarray(baseline_score['r']).ravel()[0])
    be = bool(np.asarray(baseline_score['eligible']).ravel()[0])
    ar = np.asarray(added_scores['r'], float)
    ok = np.asarray(added_scores['eligible'], bool) & np.isfinite(ar)
    return ok & (ar > br + NUMERIC_TOLERANCE if be and np.isfinite(br) else ar > 0.7)

def apply_use_mask(result, use_mask):
    """Keep both forced and historical-gated scenarios without refitting."""
    use = np.asarray(use_mask, bool)
    if use.shape != (len(result['predictions']),):
        raise ValueError('Use mask shape mismatch')
    pred = np.where(use[:, None], result['predictions'], result['baseline'][None, :])
    support = np.where(use[:, None], result['support'], result['baseline_support'][None, :])
    return dict(predictions=pred, support=support, branch=np.where(use[:, None], result['branch'], 0))

def synthetic():
    """Direct normal-equation checks and leakage guards; generated data only."""
    rng = np.random.default_rng(20261026)
    errors = []
    trials = 0
    for h in (36, 60):
        hm = np.arange(53, 53 + h)
        vm = np.arange(53 + h, 53 + h + 24)
        th = np.exp(2 + 0.3 * np.sin(hm / 4) + rng.normal(0, 0.2, h))
        ch = np.exp(2 + rng.normal(0, 0.4, (17, h)))
        cv = np.exp(2 + rng.normal(0, 0.4, (17, 24)))
        ch[0] = 5.0
        ids = np.arange(17)
        c = prepare_candidate_channels(ch, cv, hm, vm)
        for p in (1, 5):
            xh, xv = (rng.normal(size=(h, p)), rng.normal(size=(24, p)))
            xh[0] = np.nan
            xv[2] = np.nan
            out = predict_all_candidates(xh, xv, th, hm, vm, c, 1, ids)
            t, rows = (out['target_transform'], out['training_mask'])
            for j in np.flatnonzero(out['augmented_eligible']):
                model, _ = M.fit_transfer(np.c_[xh[rows], c['train'][rows, j]], t['z'][rows], method='ridge')
                z = model.predict(np.c_[xv, c['predict'][:, j]])
                expected, supported = C.transfer(z, t['z'], t['log_calendar'], t['sd'], vm, t['fallback'], True)
                use = out['branch'][j] == 1
                errors.append(float(np.max(np.abs(out['predictions'][j, use] - expected[use]))))
                rr = np.isfinite(t['z'])
                rescue, _ = M.fit_transfer(c['train'][rr, j, None], t['z'][rr], method='ridge')
                rz = rescue.predict(c['predict'][:, j, None])
                expected_r, _ = C.transfer(rz, t['z'], t['log_calendar'], t['sd'], vm, t['fallback'], True)
                errors.append(float(abs(out['predictions'][j, 2] - expected_r[2])))
                trials += 1
            assert not out['branch'][0].any() and (not out['branch'][1].any())
            assert out['branch'][2:, 2].max() == 2
            nox = predict_all_candidates(np.full_like(xh, np.nan), np.full_like(xv, np.nan), th, hm, vm, c, 1, ids)
            assert not nox['baseline_fit'] and (nox['branch'][2:] == 2).all()
            import inspect
            assert 'truth' not in inspect.signature(predict_all_candidates).parameters
            poison = dict(c)
            poison['predict'] = c['predict'].copy()
            poison['predict'][:, 1] = 1e+20
            same = predict_all_candidates(xh, xv, th, hm, vm, poison, 1, ids)
            np.testing.assert_array_equal(out['predictions'], same['predictions'])
            missing = dict(c)
            missing['predict'] = c['predict'].copy()
            missing['prediction_observed'] = c['prediction_observed'].copy()
            missing['predict'][5, 3] = np.nan
            missing['prediction_observed'][5, 3] = False
            mm = predict_all_candidates(xh, xv, th, hm, vm, missing, 1, ids)
            assert mm['branch'][3, 5] == 0 and mm['predictions'][3, 5] == mm['baseline'][5]
    truth = np.arange(24, dtype=float) + np.sin(np.arange(24))
    scored = score_predictions(np.stack([truth, truth[::-1], np.ones(24)]), truth, np.ones((3, 24), bool))
    assert scored['success'].tolist() == [True, False, False]
    assert np.isnan(scored['r'][2])
    trial = dict(r=np.array([0.6, 0.8, 0.9]), eligible=np.array([True, True, False]))
    assert development_use_mask(dict(r=[np.nan], eligible=[False]), trial).tolist() == [False, True, False]
    assert development_use_mask(dict(r=[0.99], eligible=[False]), trial).tolist() == [False, True, False]
    assert development_use_mask(dict(r=[0.7], eligible=[True]), trial).tolist() == [False, True, False]
    assert max(errors) < 1e-10
    info = dict(status='PASS', synthetic_only=True, real_data_read=False, comparisons=trials, max_absolute_raw_prediction_difference=max(errors), checks=['Schur_vs_individual_full_ridge', 'same_training_rows', 'candidate_only_rescue', 'self_identity_inert', 'constant_candidate_inert', 'missing_candidate_exact_baseline', 'target_test_truth_absent_from_prediction_API', 'constant_truth_score_undefined'], dependency_hashes=dependency_hashes())
    (_PROJECT_ROOT / 'workflows/monitoring/single_location/engine/SYNTHETIC_QA.json').write_text(json.dumps(info, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    print(json.dumps(info, ensure_ascii=False), flush=True)
if __name__ == '__main__':
    synthetic()
