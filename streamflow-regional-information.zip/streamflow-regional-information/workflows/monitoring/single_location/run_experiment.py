"""Direct single-location optimization, with separate development and test.

Development sees H36 -> V24 outcomes, evaluates every candidate and stores
per-target use decisions. Final prediction sees only H60 target observations
and the already-selected candidate's synchronous reports. This script never
scores final target G; an independently reviewed evaluator must do that after
the final prediction receipt is frozen. No old files are modified.
"""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os
import sys
import json
import hashlib
import time
import argparse
import warnings
from datetime import datetime, timezone
from concurrent.futures import ProcessPoolExecutor
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
sys.dont_write_bytecode = True
ROOT = _PROJECT_ROOT / 'workflows/monitoring/single_location'
CODE = _PROJECT_ROOT
pass
pass
import numpy as np
import pandas as pd
import workflows.monitoring.single_location.engine.engine as E
C, M = (E.C, E.M)
DESIGN = _PROJECT_ROOT / 'workflows/monitoring/single_location/design'
QFILE = _PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy'
PFILE = _PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/rainfall.npz'
FREEZE = _PROJECT_ROOT / 'workflows/monitoring/single_location/CODE_INPUTS_FROZEN.json'
STATE = {}

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    C.js(path, value)

def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))

def table(path):
    return pd.read_csv(path, keep_default_na=False)

def truth(s):
    return s.astype(str).str.lower().isin(['true', '1']).to_numpy()

def check(path):
    d = read(path)
    for name, digest in d['files'].items():
        p = Path(name) if Path(name).is_absolute() else Path(path).parent / name
        assert sha(p) == digest, str(p)
    return d

def freeze(folder, name, paths, **extra):
    folder = Path(folder)
    save(folder / name, dict(created_at_utc=datetime.now(timezone.utc).isoformat(), files={p.name: sha(p) for p in paths}, **extra))

def calendar():
    d = read(_PROJECT_ROOT / 'workflows/monitoring/single_location/design/DESIGN_PROTOCOL.json')['calendar']
    return {k: np.arange(*d[k]) for k in ['train', 'selection', 'H', 'G']}

def register():
    assert not FREEZE.exists(), 'Do not overwrite a registered experiment'
    d = check(_PROJECT_ROOT / 'workflows/monitoring/single_location/design/DESIGN_FROZEN.json')
    t, b, c = (table(DESIGN / f'{name}.csv') for name in ['targets', 'background', 'candidates'])
    cal = calendar()
    assert len(t) == 5229 and len(c) == 1279 and (len(b) == 25889)
    assert len(cal['train']) == 36 and len(cal['selection']) == 24 and (len(cal['H']) == 60) and (len(cal['G']) == 24)
    assert np.array_equal(np.r_[cal['train'], cal['selection']], cal['H'])
    assert cal['H'][-1] + 1 == cal['G'][0]
    with np.load(PFILE, allow_pickle=False) as z:
        pos = {s: i for i, s in enumerate(z['station_ids'].astype(str))}
        p = z['precip_mm_month']
        admission = z['admission_mask'].astype(bool)
        geometry = z['geometry_warning'].astype(bool)
        records = []
        start, end = (int(cal['H'][0]), int(cal['G'][-1]) + 4)
        for e in t.itertuples():
            j = pos.get(str(e.station_id), -1)
            good = j >= 0 and bool(admission[j])
            complete = bool(j >= 0 and np.isfinite(p[j, start:end]).all() and (p[j, start:end] >= 0).all())
            records.append(dict(row=int(e.row), station_id=e.station_id, rain_position=j, P_admitted=good, P_required_HG_complete=complete, uses_P=good and complete, geometry_warning=bool(geometry[j]) if j >= 0 else False, no_P_reason='available' if good and complete else 'not_in_rain_inventory' if j < 0 else 'not_admitted' if not good else 'required_period_incomplete'))
    inv = _PROJECT_ROOT / 'workflows/monitoring/single_location/input_inventory'
    inv.mkdir(exist_ok=True)
    pd.DataFrame(records).to_csv(_PROJECT_ROOT / 'workflows/monitoring/single_location/input_inventory/precipitation_availability.csv', index=False, encoding='utf-8-sig')
    suspects = b.loc[truth(b.official_suspect_coordinates)]
    assert len(suspects) == 18
    suspects.to_csv(_PROJECT_ROOT / 'workflows/monitoring/single_location/input_inventory/excluded_official_suspect_background.csv', index=False, encoding='utf-8-sig')
    proto = dict(date='2026-10-26', status='FIXED_BEFORE_DIRECT_DEVELOPMENT_SEARCH', calendar={k: [int(v[0]), int(v[-1]) + 1] for k, v in cal.items()}, targets=5229, target_mother=25893, candidate_inventory=4930, complete_candidates=1279, background_inventory=25889, official_suspect_background_excluded=18, usable_background_inventory=25871, purpose='Find one actual complete-observation location with largest development reconstruction benefit over the same global fixed target cohort.', roles='All4930 candidate physical components were removed from background before any candidate search. Complete1279 are the searchable observed-location validation frame. Not additional observations outside the fullGSIM network, and not proof these sites are currently ungauged.', observed_scope='H2008-2012 with train2008-2010 and development2011-2012; final targetG2013-2014 not used to rank candidates or decide target use in this round. Dates may overlap previously analysed project data: no claim that the final period was never seen in the project.', background='All design B except18 official suspect coordinates; target entire physical component omitted; finite coordinates; H-only log1p calendar/anomalySD, positive r with>=12 common months, rank(-r)+rank(distance), monthlyK4 positive-r composite.', target_risk='One official suspect target stays mother denominator and is flagged; report exclusion sensitivity later.', precipitation='Original independently admitted ERA5-Land target basin monthlyP, log1p lag0..3. A mask-only inventory over H antecedent3+H60+G24 fixes Q or QP pertarget in both development and final. Incomplete/notadmittedP keeps target withQ; no-P never called P ineffective. Retrospective future availability is known by design, not a deployable forecast of data availability.', candidate_use='Every candidate is an extra independent column, never competing for existingK4, no1% covariance proxy gate, no positive-correlation filter. CompleteH candidate needs>=24 finite paired training rows and>=2 samples/calendar plus nonzero anomalySD. Same baseline training rows for augmentation; candidate-only rescue if existing predictor unavailable.', model='Fixed standardized ridge lambda.1 and original training-only inverse guards; no hyperparameter/model search. Added and baseline targets use the same fit interval and target transforms.', gate='Development baseline actual eligible and finite r: use candidate only if supported candidate r exceeds baseline by>1e-12. Baseline not eligible/undefined: supported candidate must have devr>.7. Store this mask then apply unchanged to final predictions. Developer-gated development results are selected/optimistic, not evidence of future gain.', objective='Primary maximize gated development new_pass minus lost_pass, rawmonthlyr>.7 with actual prediction support. Tie: largest mean delta-r over fixed development-baseline-failed and finite-r targets; then numeric candidate raw_index. Fixed difficult denominator includes zero change for targets notusingcandidate. Undefined candidate r on a defined baseline receives worst r=-1 only for ranking tie bookkeeping and is counted explicitly; raw reported correlations remain unknown.', controls='Store forced-input ranking separately. Freeze bestgated, bestforced and five distinct hash-random candidates independent of scores. Every selected location is evaluated with forced and stored-dev-gated usage, no final selecting ofbestmethod/location.', selection_safety='No target finalG is used as target truth for prediction, candidate ranking, use selection or scoring. Final background materialization includes other targets as legitimate synchronous sources; each target and its whole physical identity are excluded from its own selected inputs. Development target truth is allowed for empirical optimization. Final targetG evaluation is separate after independent predictionQA.', outputs='All-target×all-candidate development score/use arrays; complete global ranking; frozen selected IDs/coordinates and usage masks; final raw predictions for frozen locations only; positive/negative/unknown retained.', exclusions='No topology,new models,budget objectives,manuscript/figures/cloud. First stage one addedlocation; no multistation/global-optimum claim.')
    save(_PROJECT_ROOT / 'workflows/monitoring/single_location/PROTOCOL.json', proto)
    paths = [_PROJECT_ROOT / 'workflows/monitoring/single_location/run_experiment.py', _PROJECT_ROOT / 'workflows/monitoring/single_location/engine/engine.py', _PROJECT_ROOT / 'workflows/monitoring/single_location/engine/SYNTHETIC_QA.json', _PROJECT_ROOT / 'workflows/monitoring/single_location/PROTOCOL.json', _PROJECT_ROOT / 'workflows/monitoring/single_location/design/DESIGN_FROZEN.json', _PROJECT_ROOT / 'workflows/monitoring/single_location/input_inventory/precipitation_availability.csv', _PROJECT_ROOT / 'workflows/monitoring/single_location/input_inventory/excluded_official_suspect_background.csv', QFILE, PFILE, E.CORE_PATH, E.MODEL_PATH]
    save(FREEZE, dict(files={str(p.resolve()): sha(p) for p in paths}, target_final_G_used_as_truth=False))
    print('REGISTERED_DIRECT_SINGLE_POSITION', flush=True)

def init(mode):
    warnings.filterwarnings('ignore', category=RuntimeWarning)
    t, b, c = (table(DESIGN / f'{name}.csv') for name in ['targets', 'background', 'candidates'])
    b = b.loc[~truth(b.official_suspect_coordinates)].copy()
    assert len(b) == 25871
    cal = calendar()
    h, v = (cal['train'], cal['selection']) if mode == 'dev' else (cal['H'], cal['G'])
    positions = np.arange(len(c))
    if mode == 'final':
        check(_PROJECT_ROOT / 'workflows/monitoring/single_location/selection/SELECTION_FROZEN.json')
        selected = table(_PROJECT_ROOT / 'workflows/monitoring/single_location/selection/selected_positions.csv')
        positions = np.sort(selected.candidate_position.unique().astype(int))
        np.testing.assert_array_equal(positions, np.asarray(read(_PROJECT_ROOT / 'workflows/monitoring/single_location/selection/SELECTION_META.json')['final_unique_positions'], int))
        c = c.iloc[positions].copy()
    q = np.load(QFILE, mmap_mode='r')
    br = b.raw_index.to_numpy(int)
    cr = c.raw_index.to_numpy(int)
    with np.load(_PROJECT_ROOT / 'workflows/monitoring/single_location/design/network_roles.npz', allow_pickle=False) as roles:
        assert not np.isin(br, roles['candidate_all_alias_raw']).any()
    assert not np.isin(t.physical_group_raw_index.to_numpy(int), c.physical_group_raw_index.to_numpy(int)).any()
    hm = np.r_[h, v]
    bq = np.asarray(q[np.ix_(br, hm)], float)
    cl, sd, bz = C.prep(bq[:, :len(h)], h)
    cp = E.prepare_candidate_channels(np.asarray(q[np.ix_(cr, h)], float), np.asarray(q[np.ix_(cr, v)], float), h, v)
    with np.load(PFILE, allow_pickle=False) as z:
        rain = z['precip_mm_month'].copy()
    pmeta = table(_PROJECT_ROOT / 'workflows/monitoring/single_location/input_inventory/precipitation_availability.csv')
    assert np.array_equal(t.station_id, pmeta.station_id)
    STATE.update(mode=mode, targets=t, background=b, candidates=c, positions=positions, Q=q, h=h, v=v, months=hm, background_Q=bq, background_cl=cl, background_sd=sd, background_z=bz, background_raw=br, candidate_inputs=cp, rain=rain, pmeta=pmeta)
    if mode == 'final':
        STATE['dev_use'] = np.load(_PROJECT_ROOT / 'workflows/monitoring/single_location/selection/selected_use_masks.npy', mmap_mode='r')
        assert STATE['dev_use'].shape == (len(t), len(positions))

def baseline_features(i):
    e = STATE['targets'].iloc[i]
    h, v, months = (STATE['h'], STATE['v'], STATE['months'])
    raw = int(e.raw_index)
    th = np.asarray(STATE['Q'][raw, h], float)
    target = E.prepare_target(th, h, v)
    _, r = C.relation(STATE['background_z'], target['z'])
    b = STATE['background']
    a, bb = np.deg2rad([float(e.latitude), float(e.longitude)])
    c, d = (np.deg2rad(b.latitude.to_numpy(float)), np.deg2rad(b.longitude.to_numpy(float)))
    dist = 12742 * np.arcsin(np.sqrt(np.clip(np.sin((c - a) / 2) ** 2 + np.cos(a) * np.cos(c) * np.sin((d - bb) / 2) ** 2, 0, 1)))
    same = b.physical_group_raw_index.to_numpy(int) == int(e.physical_group_raw_index)
    good = np.flatnonzero(np.isfinite(r) & (r > 0) & np.isfinite(STATE['background_sd']) & np.isfinite(dist) & ~same)
    order = C.ordering(STATE['background_raw'], good, r, dist)
    count = np.zeros(len(months), np.int8)
    num = np.zeros(len(months))
    den = np.zeros(len(months))
    ids = np.full((len(months), 4), -1, np.int32)
    for j in order:
        values = STATE['background_Q'][j]
        cc = STATE['background_cl'][j, months % 12]
        take = np.isfinite(values) & (values >= 0) & np.isfinite(cc) & (count < 4)
        ii = np.flatnonzero(take)
        if len(ii):
            zz = (np.log1p(values[ii]) - cc[ii]) / STATE['background_sd'][j]
            ids[ii, count[ii]] = STATE['background_raw'][j]
            count[ii] += 1
            num[ii] += r[j] * zz
            den[ii] += r[j]
        if (count == 4).all():
            break
    comp = np.divide(num, den, out=np.full(len(months), np.nan), where=den > 0)
    xh, xv = (comp[:len(h), None], comp[len(h):, None])
    pm = STATE['pmeta'].iloc[i]
    usesp = str(pm.uses_P).lower() == 'true'
    if usesp:
        p = int(pm.rain_position)
        start = int(h[0])
        stop = int(v[-1]) + 4
        pp = M.prepare_precipitation_lags(STATE['rain'][p, start:stop], history_start_month=start, h_length=len(h), g_length=len(v))
        assert pp.available
        xh = np.c_[xh, pp.h]
        xv = np.c_[xv, pp.g]
    assert not np.isin(ids[ids >= 0], b.loc[same, 'raw_index'].to_numpy(int)).any()
    return (e, th, xh, xv, dict(selected_background=ids, source_counts=count, qualified_background=len(good), uses_P=usesp, target_official_suspect=str(e.official_suspect_coordinates).lower() == 'true'))

def compute(i):
    e, th, xh, xv, meta = baseline_features(i)
    result = E.predict_all_candidates(xh, xv, th, STATE['h'], STATE['v'], STATE['candidate_inputs'], int(e.physical_group_raw_index), STATE['candidates'].physical_group_raw_index.to_numpy(int))
    shared = dict(row=np.array(i), baseline=result['baseline'], baseline_support=result['baseline_support'], baseline_fit=np.array(result['baseline_fit']), target_estimable=np.array(result['target_estimable']), training_mask=result['training_mask'], augmented_eligible=result['augmented_eligible'], rescue_eligible=result['rescue_eligible'], **meta)
    if STATE['mode'] == 'dev':
        y = np.asarray(STATE['Q'][int(e.raw_index), STATE['v']], float)
        bs = E.score_predictions(result['baseline'], y, result['baseline_support'])
        ad = E.score_predictions(result['predictions'], y, result['support'])
        use = E.development_use_mask(bs, ad)
        return dict(**shared, baseline_r=bs['r'][0], baseline_eligible=bs['eligible'][0], baseline_success=bs['success'][0], forced_r=ad['r'], forced_eligible=ad['eligible'], forced_success=ad['success'], use=use, added_used_months=np.sum(result['branch'] > 0, axis=1), rescue_months=np.sum(result['branch'] == 2, axis=1))
    use = np.asarray(STATE['dev_use'][i], bool)
    gated = E.apply_use_mask(result, use)
    return dict(**shared, forced_predictions=result['predictions'], forced_support=result['support'], forced_branch=result['branch'], gated_predictions=gated['predictions'], gated_support=gated['support'], gated_branch=gated['branch'], frozen_use=use, candidate_positions=STATE['positions'])

def work(i):
    out = compute(i)
    folder = ROOT / ('development' if STATE['mode'] == 'dev' else 'final_predictions') / 'blocks'
    path = folder / f'{i:05d}.npz'
    temp = path.with_suffix('.temp.npz')
    np.savez_compressed(temp, **out)
    os.replace(temp, path)
    return i

def produce(mode, workers):
    check(FREEZE)
    check(_PROJECT_ROOT / 'workflows/monitoring/single_location/design/DESIGN_FROZEN.json')
    folder = ROOT / ('development' if mode == 'dev' else 'final_predictions')
    receipt = 'DEVELOPMENT_FROZEN.json' if mode == 'dev' else 'PREDICTIONS_FROZEN.json'
    assert not (folder / receipt).exists()
    if mode == 'final':
        check(_PROJECT_ROOT / 'workflows/monitoring/single_location/selection/SELECTION_FROZEN.json')
    (folder / 'blocks').mkdir(parents=True, exist_ok=True)
    n = len(table(_PROJECT_ROOT / 'workflows/monitoring/single_location/design/targets.csv'))
    todo = [i for i in range(n) if not (folder / 'blocks' / f'{i:05d}.npz').exists()]
    binding = dict(code_inputs_sha256=sha(FREEZE), design_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/single_location/design/DESIGN_FROZEN.json'), mode=mode)
    if mode == 'final':
        binding['selection_sha256'] = sha(_PROJECT_ROOT / 'workflows/monitoring/single_location/selection/SELECTION_FROZEN.json')
    if (folder / 'BINDING.json').exists():
        assert read(folder / 'BINDING.json') == binding
    else:
        save(folder / 'BINDING.json', binding)
    st = time.time()
    with ProcessPoolExecutor(max_workers=workers, initializer=init, initargs=(mode,)) as pool:
        for k, i in enumerate(pool.map(work, todo, chunksize=8), 1):
            if k % 250 == 0 or k == len(todo):
                print(f'{mode} {n - len(todo) + k}/{n}; sec={time.time() - st:.1f}', flush=True)

def assemble(mode):
    check(FREEZE)
    folder = ROOT / ('development' if mode == 'dev' else 'final_predictions')
    receipt = 'DEVELOPMENT_FROZEN.json' if mode == 'dev' else 'PREDICTIONS_FROZEN.json'
    assert not (folder / receipt).exists()
    n = len(table(_PROJECT_ROOT / 'workflows/monitoring/single_location/design/targets.csv'))
    with np.load(folder / 'blocks/00000.npz', allow_pickle=False) as z:
        spec = {k: (z[k].shape, z[k].dtype) for k in z.files}
    arrays = {k: np.lib.format.open_memmap(folder / f'{k}.npy', mode='w+', dtype=dt, shape=(n,) + shape) for k, (shape, dt) in spec.items()}
    hashes = {}
    for i in range(n):
        path = folder / 'blocks' / f'{i:05d}.npz'
        hashes[path.name] = sha(path)
        with np.load(path, allow_pickle=False) as z:
            assert int(z['row']) == i
            for k in arrays:
                arrays[k][i] = z[k]
    for a in arrays.values():
        a.flush()
    save(folder / 'BLOCK_HASHES.json', hashes)
    paths = [folder / f'{k}.npy' for k in arrays] + [folder / 'BLOCK_HASHES.json', folder / 'BINDING.json']
    freeze(folder, receipt, paths, status='DEVELOPMENT_ALL_CANDIDATES_FROZEN' if mode == 'dev' else 'FINAL_PREDICTIONS_BEFORE_TARGET_G_SCORING', N=n, C=int(arrays['forced_r'].shape[1]) if mode == 'dev' else int(arrays['forced_predictions'].shape[1]), target_final_G_used_as_truth=False, selection_not_based_on_final_G=True, code_inputs_sha256=sha(FREEZE), selection_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/single_location/selection/SELECTION_FROZEN.json') if mode == 'final' else None)
    print(receipt, flush=True)

def select():
    check(FREEZE)
    check(_PROJECT_ROOT / 'workflows/monitoring/single_location/development/DEVELOPMENT_FROZEN.json')
    out = _PROJECT_ROOT / 'workflows/monitoring/single_location/selection'
    out.mkdir(exist_ok=True)
    assert not (_PROJECT_ROOT / 'workflows/monitoring/single_location/selection/SELECTION_FROZEN.json').exists()
    d = _PROJECT_ROOT / 'workflows/monitoring/single_location/development'
    c = table(_PROJECT_ROOT / 'workflows/monitoring/single_location/design/candidates.csv')
    t = table(_PROJECT_ROOT / 'workflows/monitoring/single_location/design/targets.csv')
    ar = np.load(_PROJECT_ROOT / 'workflows/monitoring/single_location/development/forced_r.npy', mmap_mode='r')
    ap = np.load(_PROJECT_ROOT / 'workflows/monitoring/single_location/development/forced_success.npy', mmap_mode='r')
    use = np.load(_PROJECT_ROOT / 'workflows/monitoring/single_location/development/use.npy', mmap_mode='r')
    br = np.load(_PROJECT_ROOT / 'workflows/monitoring/single_location/development/baseline_r.npy')
    bp = np.load(_PROJECT_ROOT / 'workflows/monitoring/single_location/development/baseline_success.npy')
    assert ar.shape == ap.shape == use.shape == (len(t), len(c))
    difficult = ~bp & np.isfinite(br)
    ranking = c.copy()
    ranking['candidate_position'] = np.arange(len(c))
    for name, gate in [('gated', np.asarray(use)), ('forced', np.ones(use.shape, bool))]:
        passes = np.where(gate, ap, bp[:, None])
        new = np.sum(passes & ~bp[:, None], axis=0)
        lost = np.sum(~passes & bp[:, None], axis=0)
        effective = np.where(gate, ar, br[:, None])
        tie = np.where(np.isfinite(effective[difficult]), effective[difficult], -1) - br[difficult, None]
        ranking[f'{name}_new_pass'] = new
        ranking[f'{name}_lost_pass'] = lost
        ranking[f'{name}_net_pass'] = new - lost
        ranking[f'{name}_difficult_mean_delta_r'] = np.mean(tie, axis=0) if difficult.any() else np.zeros(len(c))
        ranking[f'{name}_difficult_undefined_added_n'] = np.sum(~np.isfinite(effective[difficult]), axis=0)
    ranking['dev_used_targets'] = use.sum(0)
    ranking['baseline_development_pass_n'] = int(bp.sum())
    ranking['difficult_fixed_finite_baseline_n'] = int(difficult.sum())
    selected = []
    for strategy in ['gated', 'forced']:
        order = ranking.sort_values([f'{strategy}_net_pass', f'{strategy}_difficult_mean_delta_r', 'raw_index'], ascending=[False, False, True])
        r = order.iloc[0]
        selected.append(dict(selection_rule=f'direct_{strategy}', candidate_position=int(r.candidate_position), raw_index=int(r.raw_index), station_id=r.station_id, latitude=r.latitude, longitude=r.longitude))
        ranks = np.empty(len(ranking), int)
        ranks[order.candidate_position.to_numpy(int)] = np.arange(1, len(ranking) + 1)
        ranking[f'{strategy}_rank'] = ranks
    used = set()
    for seed in range(20261026, 20261031):
        values = [(hashlib.sha256(f'{seed}:{int(r.raw_index)}'.encode()).hexdigest(), int(r.candidate_position)) for r in ranking.itertuples() if int(r.candidate_position) not in used]
        _, j = min(values)
        used.add(j)
        r = ranking.iloc[j]
        selected.append(dict(selection_rule=f'random_{seed}', candidate_position=j, raw_index=int(r.raw_index), station_id=r.station_id, latitude=r.latitude, longitude=r.longitude))
    ranking.to_csv(_PROJECT_ROOT / 'workflows/monitoring/single_location/selection/candidate_ranking.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(selected).to_csv(_PROJECT_ROOT / 'workflows/monitoring/single_location/selection/selected_positions.csv', index=False, encoding='utf-8-sig')
    positions = np.sort(np.unique([r['candidate_position'] for r in selected]))
    np.save(_PROJECT_ROOT / 'workflows/monitoring/single_location/selection/selected_use_masks.npy', np.asarray(use[:, positions]))
    save(_PROJECT_ROOT / 'workflows/monitoring/single_location/selection/SELECTION_META.json', dict(N=len(t), C=len(c), baseline_pass=int(bp.sum()), difficult_finite_baseline_n=int(difficult.sum()), final_unique_positions=positions, rule_count=len(selected), target_final_G_used_as_truth=False, development_is_optimistic=True, dev_code_inputs_sha256=sha(FREEZE), development_freeze_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/single_location/development/DEVELOPMENT_FROZEN.json')))
    paths = [_PROJECT_ROOT / 'workflows/monitoring/single_location/selection/candidate_ranking.csv', _PROJECT_ROOT / 'workflows/monitoring/single_location/selection/selected_positions.csv', _PROJECT_ROOT / 'workflows/monitoring/single_location/selection/selected_use_masks.npy', _PROJECT_ROOT / 'workflows/monitoring/single_location/selection/SELECTION_META.json']
    freeze(out, 'SELECTION_FROZEN.json', paths, status='POSITIONS_AND_TARGET_USE_FIXED_BEFORE_FINAL_TARGET_G', target_final_G_used_as_truth=False, development_freeze_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/single_location/development/DEVELOPMENT_FROZEN.json'), full_use_array_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/single_location/development/use.npy'), code_inputs_sha256=sha(FREEZE))
    print('SINGLE_POSITION_SELECTION_FROZEN', flush=True)
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('step', choices=['register', 'dev', 'assemble_dev', 'select', 'final', 'assemble_final'])
    ap.add_argument('--workers', type=int, default=8)
    args = ap.parse_args()
    if args.step in ['dev', 'final']:
        produce(args.step, args.workers)
    elif args.step == 'assemble_dev':
        assemble('dev')
    elif args.step == 'assemble_final':
        assemble('final')
    else:
        globals()[args.step]()
