"""Global one-location interventions. Target G truth is read by scoring only."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib, importlib.util, argparse, time, warnings
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[k] = '1'
sys.dont_write_bytecode = True
ROOT = _PROJECT_ROOT / 'workflows/monitoring/location_selection'
CODE = _PROJECT_ROOT
pass
POLD = _PROJECT_ROOT / 'workflows/rainfall/global_inputs'
pass
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from concurrent.futures import ProcessPoolExecutor
from functools import lru_cache
import workflows.rainfall.global_inputs.design_review.transfer_model as M
spec = importlib.util.spec_from_file_location('oldsource', _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/run_outage.py')
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)
D = _PROJECT_ROOT / 'workflows/monitoring/location_selection/design'
G = {}
NETWORKS = ['FULL', 'REDUCED', 'NEAREST_24', 'NEAREST_36', 'NEAREST_60', 'CLIMATE_NEAREST_24', 'CLIMATE_NEAREST_36', 'CLIMATE_NEAREST_60']
METHODS = ['ridge', 'rbf_ridge']
INPUTS = ['Q', 'QP']
DURATIONS = [24, 36, 60]

def sha(p):
    return C.sha(p)

def js(p, d):
    Path(p).parent.mkdir(exist_ok=True, parents=True)
    C.js(p, d)

def distance(lat, lon, lats, lons):
    a, b = np.deg2rad([lat, lon])
    c, d = (np.deg2rad(lats), np.deg2rad(lons))
    return 12742 * np.arcsin(np.sqrt(np.clip(np.sin((c - a) / 2) ** 2 + np.cos(a) * np.cos(c) * np.sin((d - b) / 2) ** 2, 0, 1)))

def verify_freeze(path):
    x = json.loads(Path(path).read_text(encoding='utf8'))
    for k in ['files', 'outputs']:
        for p, h in x.get(k, {}).items():
            assert sha(p) == h, (path, p)
    return x

def register():
    verify_freeze(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/STATIC_CHOICES_FROZEN.json')
    verify_freeze(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/INPUTS_FROZEN.json')
    q = json.loads((_PROJECT_ROOT / 'workflows/monitoring/location_selection/audit/STATIC_CHOICES_V3_INDEPENDENT_QA.json').read_text(encoding='utf8'))
    assert q['passed'] and q['static_freeze_sha256'] == sha(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/STATIC_CHOICES_FROZEN.json')
    rainqa = json.loads((_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/RAINFALL_INDEPENDENT_QA.json').read_text(encoding='utf8'))
    assert rainqa['passed'] and rainqa['input_freeze_sha256'] == sha(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/INPUTS_FROZEN.json')
    binds = [_PROJECT_ROOT / 'workflows/monitoring/location_selection/census/metadata_enrichment/global_station_metadata.csv', _PROJECT_ROOT / 'workflows/monitoring/location_selection/PRESCORE_STATIC_AMENDMENTS.md']
    js(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/STATIC_METADATA_INPUT_BINDING.json', dict(files={str(p): sha(p) for p in binds}, reason='Explicitly bind official Namibia display labels read during static-v3 selection; all prior static versions unscored.'))
    paths = [_PROJECT_ROOT / 'workflows/monitoring/location_selection/source/run_trial.py', _PROJECT_ROOT / 'workflows/monitoring/location_selection/design/STATIC_CHOICES_FROZEN.json', _PROJECT_ROOT / 'workflows/monitoring/location_selection/design/STATIC_METADATA_INPUT_BINDING.json', _PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/INPUTS_FROZEN.json', _PROJECT_ROOT / 'workflows/monitoring/location_selection/EXECUTION_SCOPE.md', _PROJECT_ROOT / 'workflows/monitoring/location_selection/PRESCORE_STATIC_AMENDMENTS.md', C.OLD / 'global_data/QC20_Q.npy', C.OLD / 'design/all_station_roles.csv', Path(C.__file__), _PROJECT_ROOT / 'workflows/rainfall/global_inputs/design_review/transfer_model.py']
    paths += list(D.glob('*_cases.csv')) + list(D.glob('*_static_choices.csv')) + [_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/source_inventory.csv', _PROJECT_ROOT / 'workflows/monitoring/location_selection/design/network_roles.npz', _PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/rainfall.npz']
    paths += [_PROJECT_ROOT / 'workflows/monitoring/location_selection/audit/STATIC_CHOICES_V3_INDEPENDENT_QA.json', _PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/RAINFALL_INDEPENDENT_QA.json']
    protocol = dict(date='2026-10-26', purpose='Global target-by-target one-location supplementation, not a joint globally optimized network', cohorts={'long120': 'original8898 H60/G120 unchanged anchors', 'short24': 'all15274 eligible physical targets H60/G24, latest complete window'}, networks=NETWORKS, methods=METHODS, inputs=INPUTS, H=60, candidate_rule='Static locations and climate only, frozen before candidate H/G access. Full confirmed physical components omitted from base and target. Pending fourGB aliases absent from full source pool. One candidate per target, no availability/performance-based replacement.', source_trial='20 percent per continent x climate physical-source layer; no block or radius cutoff. FULL excludes target/aliases only, REDUCED additionally excludes all candidate components. Single selected candidate opened only within its last24/36/60 H months and future G.', source_qualification='Old sources: positive H anomaly r with>=12 common months; source/target log1p calendar transforms H only. New: >=24 pairs, >=2 observations in each calendar month, finite positive SD and positive H r. Qualification after commissioning; not site selection.', composite='Monthly up to4 positive-r-weighted standardized anomalies. Insert new source using frozen old-r and distance rank anchors; absent or unselected new source leaves old order, inputs and predictions unchanged.', H_training='Target fixed60 and source baseline fixed60. The REDUCED finite H-composite mask is retained for every added-site arm, even if candidate could fill missing H. FULL retains own mask. P and Q use same baseline H rows. No target G in fit or selection.', rainfall='Only frozen admitted full-catchment ERA5-Land. Actual monthly logP lag0..3; missing/failed P model falls back Q, unchanged cohort. No new product or imputation.', transfer='Inherited fixed standardized ridge lambda0.1 and fixed RBF lambda0.1, same targetH z-range+-3/log50 guards and H seasonal fallback. No tuning or additional processor.', outcome='Raw monthly r>0.7 with actual estimable fit and>=1 supported scored month. Every case retained in mother denominator; unestimable, constant or incomplete result reported separately. Seasonal baseline numeric pass descriptive; deseasonal r, NSE, alpha,delta secondary.', geography='Official Namibia country and continent restored before selection. Whole sample and per continent/climate; report station-weighted plus equal represented continents/cells separately. They are not global population estimates.', inference='2000 paired5degree spatial-cell bootstrap; new and lost passes, continuous changes; low-representation regions remain explicit. Common evaluated subsets and candidate-evaluable subsets separate from mother denominator.', interpretation='Each target receives one location in a separate counterfactual. Aggregate success is performance of this rule across cases, not simultaneous joint-network construction gain. Existing locations are retrospective analogues for monitoring/restart/sharing. Not 1980-2015 historical measurements created by future stations. No oracle/optimization on G.', gate='Prediction arrays frozen before target G scoring; independent QA before scoring. Historical G periods may have appeared in previous experiments; not new blind validation.')
    js(_PROJECT_ROOT / 'workflows/monitoring/location_selection/PROTOCOL.json', protocol)
    paths.append(_PROJECT_ROOT / 'workflows/monitoring/location_selection/PROTOCOL.json')
    js(_PROJECT_ROOT / 'workflows/monitoring/location_selection/CODE_INPUTS_FROZEN.json', dict(files={str(p): sha(p) for p in paths}, new_target_G_scored=False))
    print('REGISTERED_GLOBAL_TRIAL', flush=True)

def init(cohort):
    warnings.filterwarnings('ignore', category=RuntimeWarning)
    C.init()
    G['cohort'] = cohort
    G['cases'] = pd.read_csv(D / (cohort + '_cases.csv'), keep_default_na=False)
    choices = pd.read_csv(D / (cohort + '_static_choices.csv'), keep_default_na=False)
    G['choice'] = np.stack([choices[choices.rule.eq(s)].sort_values('row').candidate_raw_index.to_numpy(int) for s in ['NEAREST', 'CLIMATE_NEAREST']], axis=1)
    network = np.load(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/network_roles.npz', allow_pickle=False)
    raw = network['full_raw']
    G['raw'] = raw
    G['pos'] = {int(j): i for i, j in enumerate(raw)}
    G['hidden'] = np.isin(raw, network['withheld_raw'])
    G['source'] = dict(raw=raw, Q=np.asarray(C.G['Q'][raw]), lat=C.G['meta'].iloc[raw].latitude.to_numpy(float), lon=C.G['meta'].iloc[raw].longitude.to_numpy(float))
    with np.load(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/rainfall.npz', allow_pickle=False) as f:
        rz = {k: f[k] for k in ['station_ids', 'precip_mm_month', 'admission_mask']}
    G['rain'] = rz
    G['rainpos'] = {s: i for i, s in enumerate(rz['station_ids'].astype(str))}
    G['sourceprep_calls'] = 0
    sourceprep.cache_clear()

@lru_cache(maxsize=6)
def sourceprep(start):
    h = np.arange(int(start), int(start) + 60)
    G['sourceprep_calls'] += 1
    return C.prep(G['source']['Q'][:, h], h)

def anchored(old, value, descending=False):
    x = -old if descending else old
    v = -value if descending else value
    s = np.sort(x)
    return 0.5 * (np.searchsorted(s, v, side='left') + np.searchsorted(s, v, side='right')) + 0.5

def combine_insert(q, oldr, dist, cl, sd, months, candidate, rr, cc, ss, enable):
    """Old source relative ordering is unchanged by an unselected candidate."""
    f = G['source']
    raw = G['raw']
    orank = rankdata(-oldr[q], method='average')
    drank = rankdata(dist[q], method='average')
    cr = anchored(oldr[q], rr, True) if len(q) else 1.0
    cd = anchored(dist[q], dist[candidate]) if len(q) else 1.0
    inds = np.r_[q, candidate]
    ranks = np.r_[orank, cr]
    scores = np.r_[orank + drank, cr + cd]
    order = inds[np.lexsort((raw[inds], ranks, scores))]
    cnt = np.zeros(len(months), np.int8)
    num = np.zeros(len(months))
    den = np.zeros(len(months))
    ids = np.full((len(months), 4), -1, np.int32)
    for j in order:
        new = j == candidate
        v = f['Q'][j, months]
        means = cc[months % 12] if new else cl[j, months % 12]
        ssj = ss if new else sd[j]
        rj = rr if new else oldr[j]
        take = np.isfinite(v) & (v >= 0) & np.isfinite(means) & (cnt < 4)
        if new:
            take &= months >= enable
        if take.any():
            k = np.flatnonzero(take)
            z = (np.log1p(v[k]) - means[k]) / ssj
            ids[k, cnt[k]] = raw[j]
            cnt[k] += 1
            num[k] += rj * z
            den[k] += rj
        if (cnt == 4).all():
            break
    return (np.divide(num, den, out=np.full(len(months), np.nan), where=den > 0), cnt, ids)

def fit(comp, train, tz, tc, sd, g, base, estim, rain, hasp):
    pp = np.full((2, 2, len(g)), np.nan)
    sup = np.zeros_like(pp, dtype=bool)
    fits = np.zeros((2, 2), bool)
    usep = np.zeros((2, 2), bool)
    xh = comp[:60, None]
    xg = comp[60:, None]
    for mi, m in enumerate(METHODS):
        qm, _ = M.fit_transfer(xh[train], tz[train], method=m, target_estimable=estim)
        pm = None
        if hasp:
            pm, _ = M.fit_transfer(np.column_stack([xh, rain.h])[train], tz[train], method=m, target_estimable=estim)
        for ci, model in enumerate([qm, pm if pm is not None else qm]):
            fits[mi, ci] = model is not None
            usep[mi, ci] = ci == 1 and pm is not None
            xx = np.column_stack([xg, rain.g]) if usep[mi, ci] else xg
            predz = model.predict(xx) if model is not None else np.full(len(g), np.nan)
            pp[mi, ci], sup[mi, ci] = C.transfer(predz, tz, tc, sd, g, base, model is not None)
    return (pp, sup, fits, usep)

def work(i):
    e = G['cases'].iloc[i]
    raw = int(e.raw_index)
    h = np.arange(int(e.history_start), int(e.history_end))
    g = np.arange(int(e.gap_start), int(e.gap_end))
    mm = np.r_[h, g]
    L = len(g)
    target = np.asarray(C.G['Q'][raw, h])
    tc, ts, tzz = C.prep(target[None, :], h)
    tc = tc[0]
    sd = float(ts[0])
    tz = tzz[0]
    estim = bool(np.isfinite(target).all() and (target >= 0).all() and np.isfinite(tc).all() and np.isfinite(sd))
    if not estim:
        tz = np.full(60, np.nan)
    rawcal = np.array([np.nanmean(target[h % 12 == m]) for m in range(12)])
    base = rawcal[g % 12]
    cl, ss, zh = sourceprep(int(e.history_start))
    n, r = C.relation(zh, tz)
    dist = distance(float(e.latitude), float(e.longitude), G['source']['lat'], G['source']['lon'])
    exclude = json.loads(e.all_same_station_exclusion_raw_indices)
    good = np.isfinite(r) & (r > 0) & np.isfinite(ss) & ~np.isin(G['raw'], exclude)
    qfull = np.flatnonzero(good)
    qreduced = np.flatnonzero(good & ~G['hidden'])
    fullorder = C.ordering(G['raw'], qfull, r, dist)
    redorder = C.ordering(G['raw'], qreduced, r, dist)
    comp = np.full((8, 60 + L), np.nan)
    cnt = np.zeros((8, 60 + L), np.int8)
    ids = np.full((8, 60 + L, 4), -1, np.int32)
    for a, q in [(0, fullorder), (1, redorder)]:
        comp[a], cnt[a], ids[a] = C.combine(G['source'], q, r, cl, ss, mm)
    train = np.array([np.isfinite(tz) & np.isfinite(comp[0, :60]), np.isfinite(tz) & np.isfinite(comp[1, :60])])
    ri = G['rainpos'][e.station_id]
    rz = G['rain']
    rp = rz['precip_mm_month'][ri, int(e.history_start):int(e.gap_end) + 3]
    rain = M.prepare_precipitation_lags(rp, history_start_month=int(e.history_start), h_length=60, g_length=L)
    hasp = bool(rz['admission_mask'][ri]) and rain.available
    pred = np.full((8, 2, 2, L), np.nan)
    sup = np.zeros_like(pred, dtype=bool)
    fits = np.zeros((8, 2, 2), bool)
    usep = np.zeros_like(fits)
    for a in (0, 1):
        pred[a], sup[a], fits[a], usep[a] = fit(comp[a], train[a], tz, tc, sd, g, base, estim, rain, hasp)
    info = np.full((2, 3, 12), np.nan)
    memo = {}
    for rule in range(2):
        candraw = int(G['choice'][i, rule])
        cj = G['pos'].get(candraw, -1)
        for li, lh in enumerate(DURATIONS):
            a = 2 + rule * 3 + li
            key = (candraw, lh)
            if key in memo:
                other, oldinfo = memo[key]
                comp[a] = comp[other]
                cnt[a] = cnt[other]
                ids[a] = ids[other]
                pred[a] = pred[other]
                sup[a] = sup[other]
                fits[a] = fits[other]
                usep[a] = usep[other]
                info[rule, li] = oldinfo
                continue
            enabled = int(h[-lh])
            status = 0
            nn = 0
            calendar_min = 0
            rr = np.nan
            qualified = False
            graw = 0
            gtransform = 0
            if cj >= 0:
                assert G['hidden'][cj] and candraw not in exclude
                hv = G['source']['Q'][cj, h[-lh:]]
                cc, sdnew, znew = C.prep(hv[None, :], h[-lh:])
                cc = cc[0]
                sdnew = float(sdnew[0])
                znew = znew[0]
                padded = np.full((1, 60), np.nan)
                padded[0, -lh:] = znew
                nnn, rrr = C.relation(padded, tz)
                nn = int(nnn[0])
                rr = float(rrr[0])
                calendar_min = int(min((np.sum(np.isfinite(hv[h[-lh:] % 12 == m]) & (hv[h[-lh:] % 12 == m] >= 0)) for m in range(12))))
                status = 1 if nn < 24 or calendar_min < 2 else 2 if not np.isfinite(rr) or not np.isfinite(sdnew) else 3 if rr <= 0 else 4
                qualified = status == 4
                gv = G['source']['Q'][cj, g]
                graw = int((np.isfinite(gv) & (gv >= 0)).sum())
                gtransform = int((np.isfinite(gv) & (gv >= 0) & np.isfinite(cc[g % 12])).sum())
            if qualified:
                comp[a], cnt[a], ids[a] = combine_insert(qreduced, r, dist, cl, ss, mm, cj, rr, cc, sdnew, enabled)
                assert np.all(np.isfinite(comp[a, :60])[train[1]])
                assert not (ids[a, mm < enabled] == candraw).any()
            else:
                comp[a] = comp[1]
                cnt[a] = cnt[1]
                ids[a] = ids[1]
            usedh = int((ids[a, :60] == candraw).sum()) if cj >= 0 else 0
            usedg = int((ids[a, 60:] == candraw).sum()) if cj >= 0 else 0
            if usedh + usedg == 0:
                np.testing.assert_allclose(comp[a], comp[1], rtol=0, atol=0, equal_nan=True)
                pred[a] = pred[1]
                sup[a] = sup[1]
                fits[a] = fits[1]
                usep[a] = usep[1]
            else:
                pred[a], sup[a], fits[a], usep[a] = fit(comp[a], train[1], tz, tc, sd, g, base, estim, rain, hasp)
            info[rule, li] = [candraw, lh, nn, calendar_min, rr, int(qualified), usedh, usedg, graw, gtransform, status, enabled]
            memo[key] = (a, info[rule, li].copy())
    assert not np.isin(ids, exclude).any()
    assert not np.isin(ids[1], G['raw'][G['hidden']]).any()
    return (i, pred, sup, fits, usep, comp, cnt, ids, train, info, base, rawcal, np.array([estim, hasp, int(train[0].sum()), int(train[1].sum()), len(qfull), len(qreduced)], float))

def produce(cohort, workers):
    fr = verify_freeze(_PROJECT_ROOT / 'workflows/monitoring/location_selection/CODE_INPUTS_FROZEN.json')
    verify_freeze(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/STATIC_METADATA_INPUT_BINDING.json')
    out = _PROJECT_ROOT / 'workflows/monitoring/location_selection/predictions' / cohort
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'PREDICTIONS_FROZEN.json').exists():
        print('Already frozen', cohort)
        return
    c = pd.read_csv(D / (cohort + '_cases.csv'))
    N = len(c)
    L = int(c.L.iloc[0])
    assert c.L.eq(L).all()
    shapes = {'predictions': ((N, 8, 2, 2, L), 'float64'), 'support': ((N, 8, 2, 2, L), 'bool'), 'fit': ((N, 8, 2, 2), 'bool'), 'uses_P': ((N, 8, 2, 2), 'bool'), 'composites': ((N, 8, 60 + L), 'float64'), 'counts': ((N, 8, 60 + L), 'int8'), 'selected_ids': ((N, 8, 60 + L, 4), 'int32'), 'training_mask': ((N, 2, 60), 'bool'), 'candidate_info': ((N, 2, 3, 12), 'float64'), 'seasonal_baseline': ((N, L), 'float64'), 'target_raw_calendar': ((N, 12), 'float64'), 'input_meta': ((N, 6), 'float64')}
    mode = 'r+' if (out / 'done.npy').exists() else 'w+'
    arrays = {k: np.lib.format.open_memmap(out / (k + '.npy'), mode=mode, dtype=dt, shape=sp) for k, (sp, dt) in shapes.items()}
    done = np.lib.format.open_memmap(out / 'done.npy', mode=mode, dtype='bool', shape=(N,))
    if mode == 'w+':
        done[:] = False
        done.flush()
        js(out / 'PRODUCTION_BINDING.json', dict(code_freeze_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/location_selection/CODE_INPUTS_FROZEN.json'), cohort=cohort, N=N, L=L))
    else:
        assert json.loads((out / 'PRODUCTION_BINDING.json').read_text())['code_freeze_sha256'] == sha(_PROJECT_ROOT / 'workflows/monitoring/location_selection/CODE_INPUTS_FROZEN.json')
    todo = np.flatnonzero(~done).tolist()
    st = time.time()
    batch = []
    with ProcessPoolExecutor(max_workers=workers, initializer=init, initargs=(cohort,)) as pool:
        for k, result in enumerate(pool.map(work, todo, chunksize=4), 1):
            row, *values = result
            for name, value in zip(shapes, values):
                arrays[name][row] = value
            batch.append(row)
            if k % 100 == 0 or k == len(todo):
                for arr in arrays.values():
                    arr.flush()
                done[batch] = True
                done.flush()
                batch = []
                print(f'{cohort}: {int(done.sum())}/{N}; elapsed {time.time() - st:.1f}s', flush=True)
    assert done.all()
    files = [out / (k + '.npy') for k in shapes] + [out / 'done.npy', out / 'PRODUCTION_BINDING.json', D / (cohort + '_cases.csv'), D / (cohort + '_static_choices.csv')]
    js(out / 'PREDICTIONS_FROZEN.json', dict(status='ALL_PREDICTIONS_FROZEN_BEFORE_TARGET_G_SCORING', cohort=cohort, N=N, L=L, networks=NETWORKS, methods=METHODS, inputs=INPUTS, seconds=time.time() - st, files={str(p): sha(p) for p in files}, candidate_info_columns=['candidate_raw', 'common_history', 'paired_H', 'calendar_min_n', 'historical_r', 'qualified', 'used_H_slots', 'used_G_slots', 'raw_G_reports', 'transformable_G_reports', 'qualification_status', 'enabled_month'], input_meta_columns=['target_estimable', 'P_available', 'full_training_n', 'reduced_training_n', 'full_qualified', 'reduced_qualified']))
    print('FROZEN', cohort, flush=True)
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('step', choices=['register', 'produce'])
    ap.add_argument('--cohort', choices=['long120', 'short24'], default='long120')
    ap.add_argument('--workers', type=int, default=4)
    a = ap.parse_args()
    register() if a.step == 'register' else produce(a.cohort, a.workers)
