"""Reuse verified basin rainfall for all registered global cases; no flow reads."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))

def _release_path(kind, relative):
    import os as _release_os
    from pathlib import Path as _ReleasePath
    code_root = _PROJECT_ROOT
    root = code_root if kind == 'code' else _ReleasePath(_release_os.environ.get('STREAMFLOW_DATA_ROOT', str(code_root.parent / 'inputs')))
    return str(root / relative)
from pathlib import Path
import os, sys, json, hashlib, time
from datetime import datetime, timezone
for k in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '1'
import numpy as np, pandas as pd
from scipy import sparse
from pyproj import Geod
ROOT = _PROJECT_ROOT / 'workflows/monitoring/location_selection'
DES = _PROJECT_ROOT / 'workflows/monitoring/location_selection/design'
OUT = _PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs'
P = _PROJECT_ROOT / 'data'
OLD = _PROJECT_ROOT / 'workflows/rainfall/global_inputs'
W = _PROJECT_ROOT / 'data/meteorology'
T = _PROJECT_ROOT / 'data/meteorology/station_inputs'
F = _PROJECT_ROOT / 'data/meteorology/catchment_forcing'
GEOD = Geod(ellps='WGS84')

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(x)
    return h.hexdigest()

def js(p, x):
    Path(p).write_text(json.dumps(x, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')

def flag(x):
    return str(x).lower() == 'true'

def main():
    start = time.time()
    OUT.mkdir(exist_ok=True, parents=True)
    assert not (_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/INPUTS_FROZEN.json').exists()
    static = json.loads((_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/STATIC_CHOICES_FROZEN.json').read_text(encoding='utf8'))
    assert all((sha(p) == h for p, h in static['outputs'].items()))
    op = _PROJECT_ROOT / 'workflows/rainfall/global_inputs/final_inputs/global8898_tp_197910_201512_ADMITTED.npz'
    olp = _PROJECT_ROOT / 'workflows/rainfall/global_inputs/final_inputs/global8898_precipitation_admission_ledger.csv'
    mp = _PROJECT_ROOT / 'data/meteorology/station_inputs/weather_1994_2025.npz'
    rp = _PROJECT_ROOT / 'data/meteorology/station_inputs/station_registry.csv'
    fp = _PROJECT_ROOT / 'data/meteorology/catchment_forcing/global_catchment_forcing_1994_2025.npz'
    gp = _PROJECT_ROOT / 'data/meteorology/catchment_forcing/catchment_geometry_audit.csv'
    wp = _PROJECT_ROOT / 'data/meteorology/catchment_forcing/global_catchment_grid_weights.npz'
    wm = _PROJECT_ROOT / 'data/meteorology/catchment_forcing/weight_manifest.json'
    inputs = [op, olp, mp, rp, fp, gp, wp, wm, _PROJECT_ROOT / 'workflows/monitoring/location_selection/design/STATIC_CHOICES_FROZEN.json', _PROJECT_ROOT / 'workflows/monitoring/location_selection/design/long120_cases.csv', _PROJECT_ROOT / 'workflows/monitoring/location_selection/design/short24_cases.csv', _PROJECT_ROOT / 'workflows/monitoring/location_selection/source/rain_prepare.py']
    hashes = {str(p): sha(p) for p in inputs}
    js(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/RAIN_PREPARATION_PROTOCOL.json', dict(registered_utc=datetime.now(timezone.utc).isoformat(), source_hashes=hashes, cohorts=['long120_all8898', 'short24_all15274'], old8898='Reuse exact same435-month values/admission/warning metadata; previous rejection remains rejection, no opportunistic replacement from master.', additional='Only original_screened_full_catchment master matching original forcing all384 tp values exactly, with original geometry state screened_full_catchment and source_quality_area_and_outlet_checks_pass; forcing dates/units and weight_sha verified. WGS84 original outlet distance <=10m. Sparse weights finite/nonnegative, sum within3e-6 of1, exact6,483,600 grid columns.', temporal='Only1994-01..2015-12 existing master values inserted; earlier dates unknown. Need all calendar months Hstart-3 throughGend including lag history. No extraction, temporal interpolation or Q-based filter.', coverage='Newmaster forcing valid_area_fraction>=0.95 each month; lower-coverage existing values replaced by NaN in model input and raw coverage preserved. Whole mother retained; source geometry admission and case-window availability distinct.', warning='Original agency/reach warnings retained and stratified; not outcome-filtered. Old8898 geometry rejection never re-admitted.', units='ERA5-Land tp mm/month; no days or area multiplication.', target_flow_or_score_reads=False, model_input_admission_requires_independent_QA=True))
    cases = {name: pd.read_csv(DES / f'{name}_cases.csv', keep_default_na=False, low_memory=False) for name in ['long120', 'short24']}
    assert len(cases['long120']) == 8898 and len(cases['short24']) == 15274
    allcases = pd.concat(cases.values(), ignore_index=True)
    ids = allcases.drop_duplicates('station_id').sort_values('raw_index').reset_index(drop=True)
    assert ids.station_id.is_unique and ids.raw_index.is_unique
    lookup = {s: i for i, s in enumerate(ids.station_id)}
    n = len(ids)
    periods = pd.period_range('1979-10', '2015-12', freq='M').astype(str).to_numpy(str)
    values = np.full((n, 435), np.nan, np.float32)
    admit = np.zeros(n, bool)
    warn = np.zeros(n, bool)
    coverage = np.full((n, 435), np.nan, np.float32)
    origins = np.full(n, 'NO_ADMITTED_EXISTING_INPUT', dtype=object)
    reasons = np.full(n, 'no_previously_admitted_source', dtype=object)
    agency = np.zeros(n, bool)
    reach = np.zeros(n, bool)
    oz = np.load(op, allow_pickle=False)
    ol = pd.read_csv(olp, keep_default_na=False, low_memory=False).set_index('station_id')
    assert str(oz['units']) == 'mm/month' and len(set(oz['station_ids'].astype(str))) == 8898
    np.testing.assert_array_equal(oz['periods'].astype(str), periods)
    oldv = oz['precip_mm_month']
    olda = oz['admission_mask']
    oldw = oz['geometry_warning_mask']
    oldagency = oz['agency_area_warning_mask']
    oldreach = oz['reach_scope_warning_mask']
    for j, s in enumerate(oz['station_ids'].astype(str)):
        if s not in lookup:
            continue
        i = lookup[s]
        values[i] = oldv[j]
        admit[i] = bool(olda[j])
        warn[i] = bool(oldw[j])
        agency[i] = bool(oldagency[j])
        reach[i] = bool(oldreach[j])
        origins[i] = 'old8898_admitted' if admit[i] else 'old8898_rejected'
        reasons[i] = str(ol.loc[s, 'admission_reason'])
        assert flag(ol.loc[s, 'admission_mask']) == admit[i] and flag(ol.loc[s, 'geometry_warning']) == warn[i]
    mz = np.load(mp, allow_pickle=False)
    fz = np.load(fp, allow_pickle=False)
    mids = mz['station_ids'].astype(str)
    fids = fz['station_ids'].astype(str)
    assert len(set(mids)) == len(mids) and len(set(fids)) == len(fids)
    mi = {s: i for i, s in enumerate(mids)}
    fi = {s: i for i, s in enumerate(fids)}
    mk = list(mz['variable_names'].astype(str)).index('tp')
    fk = list(fz['variable_names'].astype(str)).index('tp')
    mv = mz['values'][:, :, mk]
    fv = fz['values'][:, :, fk]
    cv = fz['valid_area_fraction'][:, :, fk]
    assert str(fz['units'][fk]) == 'mm/month', str(fz['units'][fk])
    assert fz['periods'].astype(str).tolist() == mz['periods'].astype(str).tolist() == pd.period_range('1994-01', '2025-12', freq='M').astype(str).tolist()
    assert str(fz['weight_sha256']) == hashes[str(wp)]
    weights = sparse.load_npz(wp).tocsr()
    assert weights.shape == (len(fids), 1801 * 3600)
    assert np.isfinite(weights.data).all() and (weights.data >= 0).all()
    rc = ['station_id', 'forcing_input_origin', 'forcing_geometry_status', 'geometry_source', 'original_catchment_path', 'original_gsim_latitude', 'original_gsim_longitude', 'baseline_reach_scope_review_signal', 'unresolved_agency_area_signal_after_registered_input_correction']
    reg = pd.read_csv(rp, usecols=rc, keep_default_na=False, low_memory=False).set_index('station_id')
    geo = pd.read_csv(gp, keep_default_na=False, low_memory=False).set_index('station_id')
    assert reg.index.is_unique and geo.index.is_unique
    lineage = []
    inspected = []
    for e in ids.itertuples():
        s = e.station_id
        i = lookup[s]
        if origins[i] != 'NO_ADMITTED_EXISTING_INPUT':
            continue
        rec = dict(station_id=s, raw_index=int(e.raw_index), in_master=s in mi, in_original_forcing=s in fi, in_registry=s in reg.index, in_geometry_audit=s in geo.index)
        missing = [key for key in ['in_master', 'in_original_forcing', 'in_registry', 'in_geometry_audit'] if not rec[key]]
        if missing:
            reasons[i] = 'unavailable:' + ','.join(missing)
            rec['decision_reason'] = reasons[i]
            inspected.append(rec)
            continue
        rr = reg.loc[s]
        gg = geo.loc[s]
        wrong = []
        if str(rr.forcing_input_origin) != 'original_screened_full_catchment':
            wrong.append('master_origin_not_original_screened')
        if str(rr.forcing_geometry_status) != 'screened_full_catchment':
            wrong.append('registry_geometry_not_screened')
        if str(gg.forcing_geometry_status) != 'screened_full_catchment':
            wrong.append('original_geometry_not_screened')
        if str(gg.reason) != 'source_quality_area_and_outlet_checks_pass':
            wrong.append('original_geometry_screen_not_passed')
        rec.update(forcing_input_origin=str(rr.forcing_input_origin), registry_geometry_status=str(rr.forcing_geometry_status), original_geometry_status=str(gg.forcing_geometry_status), original_geometry_reason=str(gg.reason))
        if wrong:
            reasons[i] = 'not_admitted:' + ','.join(wrong)
            rec['decision_reason'] = reasons[i]
            inspected.append(rec)
            continue
        assert np.array_equal(mv[mi[s]], fv[fi[s]], equal_nan=True), s
        ws = float(weights[fi[s]].astype(np.float64).sum())
        assert abs(ws - 1) < 3e-06, (s, ws)
        dd = abs(GEOD.inv(float(e.longitude), float(e.latitude), float(rr.original_gsim_longitude), float(rr.original_gsim_latitude))[2])
        if not dd <= 10:
            reasons[i] = 'not_admitted:WGS84_outlet_distance_exceeds10m'
            rec.update(coordinate_distance_m=dd, decision_reason=reasons[i])
            inspected.append(rec)
            continue
        vals = mv[mi[s], :264]
        cov = cv[fi[s], :264]
        ok = np.isfinite(cov) & (cov >= 0.95)
        values[i, 171:] = np.where(ok, vals, np.nan)
        coverage[i, 171:] = cov
        admit[i] = True
        agency[i] = flag(rr.unresolved_agency_area_signal_after_registered_input_correction)
        reach[i] = flag(rr.baseline_reach_scope_review_signal)
        warn[i] = agency[i] | reach[i]
        origins[i] = 'master_original_screened_full_catchment'
        reasons[i] = 'geometry_weight_and_384month_lineage_verified_window_pending'
        rec.update(coordinate_distance_m=dd, weight_sum=ws, full_tp_array_exact_match=True, low_coverage_months_1994_2015=int((~ok).sum()), decision_reason=reasons[i])
        inspected.append(rec)
        lineage.append(dict(station_id=s, master_row=mi[s], forcing_row=fi[s], weight_row=fi[s], weight_sum=ws, weight_nnz=int(weights[fi[s]].nnz), weight_sha256=hashes[str(wp)], coordinate_distance_m=dd, full_tp_array_exact_match=True, geometry_reason=str(gg.reason), original_catchment_path=str(rr.original_catchment_path), agency_warning=bool(agency[i]), reach_warning=bool(reach[i]), low_coverage_months_1994_2015=int((~ok).sum())))
    np.savez_compressed(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/rainfall.npz', station_ids=ids.station_id.to_numpy(str), raw_index=ids.raw_index.to_numpy(np.int32), precip_mm_month=values, admission_mask=admit, geometry_warning=warn, periods=periods, units=np.array('mm/month'), source_product=np.array('ERA5-Land/monthly_averaged_reanalysis'), agency_area_warning=agency, reach_scope_warning=reach, valid_area_fraction_new_master=coverage)
    ledger = ids[['station_id', 'raw_index', 'continent', 'country', 'kg_major']].copy()
    ledger['admitted_geometry_source'] = admit
    ledger['geometry_warning'] = warn
    ledger['agency_area_warning'] = agency
    ledger['reach_scope_warning'] = reach
    ledger['origin'] = origins
    ledger['admission_reason'] = reasons
    ledger['finite_precipitation_months'] = np.isfinite(values).sum(1)
    ledger.to_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/rainfall_ledger.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(lineage).to_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/extra_master_lineage.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(inspected).to_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/additional_source_screen_all.csv', index=False, encoding='utf-8-sig')
    summaries = []
    allad = []
    for name, c in cases.items():
        rows = []
        for e in c.itertuples():
            i = lookup[e.station_id]
            startidx = int(e.history_start)
            endidx = int(e.gap_end) + 3
            v = values[i, startidx:endidx]
            assert len(v) == 60 + int(e.L) + 3
            complete = bool(np.isfinite(v).all() and (v >= 0).all())
            available = bool(admit[i] and complete)
            reason = 'AVAILABLE' if available else 'source_not_admitted:' + str(reasons[i]) if not admit[i] else 'required_dates_outside_existing_master_1994plus' if origins[i].startswith('master') and startidx < 171 else 'required_precipitation_missing_or_low_area_coverage_or_negative'
            finite = np.isfinite(v)
            missingmonths = periods[startidx:endidx][~finite].tolist()
            rows.append(dict(cohort=name, row=int(e.row), station_id=e.station_id, raw_index=int(e.raw_index), continent=e.continent, country=e.country, kg_major=e.kg_major, spatial_cell=e.spatial_cell, rain_row=i, admitted=bool(admit[i]), complete_required_window=complete, available=available, geometry_warning=bool(warn[i]), agency_area_warning=bool(agency[i]), reach_scope_warning=bool(reach[i]), origin=str(origins[i]), availability_reason=reason, required_start=periods[startidx], required_end=periods[endidx - 1], required_months=len(v), available_required_months=int(finite.sum()), negative_required_months=int((v < 0).sum()), missing_required_months=json.dumps(missingmonths), history_start=int(e.history_start), gap_start=int(e.gap_start), gap_end=int(e.gap_end), G=int(e.L)))
        ad = pd.DataFrame(rows)
        ad.to_csv(OUT / f'{name}_rainfall_admission.csv', index=False, encoding='utf-8-sig')
        allad.append(ad)
        for dim in ['Global', 'continent', 'country', 'kg_major', 'spatial_cell', 'availability_reason']:
            zz = [('Global', ad)] if dim == 'Global' else list(ad.groupby(dim, sort=True))
            for label, z in zz:
                summaries.append(dict(cohort=name, dimension=dim, level=label, total_targets=len(z), rainfall_available=int(z.available.sum()), available_pct=100 * z.available.mean(), geometry_admitted=int(z.admitted.sum()), geometry_warning_available=int((z.available & z.geometry_warning).sum()), original8898_available=int((z.available & z.origin.eq('old8898_admitted')).sum()), additional_master_available=int((z.available & z.origin.eq('master_original_screened_full_catchment')).sum())))
    pd.DataFrame(summaries).to_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/rainfall_representativeness_by_cohort_and_stratum.csv', index=False, encoding='utf-8-sig')
    finalfiles = [p for p in OUT.iterdir() if p.is_file()]
    assert all((sha(p) == h for p, h in hashes.items())), 'Source changed during preparation'
    js(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/INPUTS_FROZEN.json', dict(status='ALL_EXISTING_ADMITTED_FULL_BASIN_RAINFALL_BOUND_PENDING_INDEPENDENT_QA', target_flow_read=False, source_scores_read=False, design_version='design', unique_station_IDs=n, geometry_admitted=int(admit.sum()), master_added=len(lineage), elapsed_seconds=time.time() - start, files={str(p): sha(p) for p in finalfiles}, source_hashes=hashes, model_use_requires_independent_QA=True))
    print(pd.DataFrame(summaries).query("dimension=='Global'").to_string(index=False), flush=True)
if __name__ == '__main__':
    main()
