"""Static, outcome-blind site selection and reuse of admitted basin rainfall."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))

def _release_path(kind, relative):
    import os as _release_os
    from pathlib import Path as _ReleasePath
    code_root = _PROJECT_ROOT
    root = code_root if kind == 'code' else _ReleasePath(_release_os.environ.get('STREAMFLOW_DATA_ROOT', str(code_root / 'data')))
    return str(root / relative)
from pathlib import Path
import os, sys, json, hashlib, argparse
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[k] = '1'
sys.dont_write_bytecode = True
ROOT = _PROJECT_ROOT / 'workflows/monitoring/location_selection'
CODE = _PROJECT_ROOT
pass
import numpy as np
import pandas as pd
OLD = _PROJECT_ROOT / 'workflows/regional_dependence/global_design'
POLD = _PROJECT_ROOT / 'workflows/rainfall/global_inputs'
OUT = _PROJECT_ROOT / 'workflows/monitoring/location_selection/design'
RISK = ['GB_0000239', 'GB_0000240', 'GB_0000241', 'GB_0000242']
CAT = Path(_release_path('data', 'gsim/catalogs/GSIM_catchment_characteristics.csv'))

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def js(p, d):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    Path(p).write_text(json.dumps(d, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf8')

def dist(a, b, c, d):
    a, b = np.deg2rad([a, b])
    c, d = (np.deg2rad(c), np.deg2rad(d))
    return 12742 * np.arcsin(np.sqrt(np.clip(np.sin((c - a) / 2) ** 2 + np.cos(a) * np.cos(c) * np.sin((d - b) / 2) ** 2, 0, 1)))

def static():
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/STATIC_CHOICES_FROZEN.json').exists()
    meta = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/all_station_roles.csv', keep_default_na=False)
    ident = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/census/physical_identity_map.csv', keep_default_na=False)
    assert np.array_equal(meta.station_id, ident.station_id)
    cols = ['physical_group_raw_index', 'physical_group_id', 'physical_component_size', 'all_same_station_exclusion_raw_indices', 'all_same_station_exclusion_ids']
    for k in cols:
        meta[k] = ident[k]
    attrs = pd.read_csv(CAT, usecols=['gsim.no', 'area.meta'], keep_default_na=False).set_index('gsim.no')
    meta['official_area_km2'] = pd.to_numeric(meta.station_id.map(attrs['area.meta']), errors='coerce')
    meta['latitude'] = pd.to_numeric(meta.latitude, errors='coerce')
    meta['longitude'] = pd.to_numeric(meta.longitude, errors='coerce')
    meta['kg_major'] = meta.kg_major.where(meta.kg_major.isin(list('ABCDE')), 'Unknown')
    meta['continent'] = meta.continent.replace('', 'Unknown')
    official = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/census/metadata_enrichment/global_station_metadata.csv', keep_default_na=False)
    assert np.array_equal(meta.station_id, official.station_id)
    meta['original_continent'] = meta.continent
    meta['original_country'] = meta.country
    meta['continent'] = official.continent_display.to_numpy()
    meta['country'] = official.country_display.to_numpy()
    raw = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/predictions/source_cache/source_raw_indices.npy')
    raw = raw[~meta.iloc[raw].station_id.isin(RISK).to_numpy()]
    inventory = meta.iloc[raw].copy()
    inventory['raw_index'] = raw
    phys = inventory.sort_values('raw_index').drop_duplicates('physical_group_id').copy()
    phys['hash'] = phys.physical_group_id.map(lambda s: hashlib.sha256(('global_siting|' + s).encode()).hexdigest())
    phys['stratum'] = phys.continent + '|' + phys.kg_major
    phys['withheld'] = False
    strata = []
    for label, g in phys.groupby('stratum', sort=True):
        chosen = g.sort_values(['hash', 'physical_group_id']).index[:int(np.floor(0.2 * len(g)))]
        phys.loc[chosen, 'withheld'] = True
        strata.append(dict(stratum=label, physical_sources=len(g), withheld=len(chosen)))
    hidden = set(phys.loc[phys.withheld, 'physical_group_id'])
    inventory['withheld'] = inventory.physical_group_id.isin(hidden)
    inventory.to_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/source_inventory.csv', index=False, encoding='utf-8-sig')
    phys.to_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/physical_source_inventory.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(strata).to_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/source_strata.csv', index=False)
    candidates = phys[phys.withheld].copy().sort_values('raw_index').reset_index(drop=True)
    candidates['valid_coordinates'] = candidates.latitude.between(-90, 90) & candidates.longitude.between(-180, 180)
    candidates.to_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/candidate_locations.csv', index=False, encoding='utf-8-sig')
    np.savez(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/network_roles.npz', full_raw=raw.astype(np.int32), withheld_raw=inventory.loc[inventory.withheld, 'raw_index'].to_numpy(np.int32), retained_raw=inventory.loc[~inventory.withheld, 'raw_index'].to_numpy(np.int32))
    old = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/cases.csv', keep_default_na=False)
    cohorts = {'long120': old, 'short24': pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/census/cases_G24.csv', keep_default_na=False)}
    outputs = []
    for name, df in cohorts.items():
        df = df.copy().reset_index(drop=True)
        df['row'] = np.arange(len(df))
        df['cohort'] = name
        mm = meta.iloc[df.raw_index.to_numpy(int)]
        for k in ['station_id', 'physical_group_id', 'physical_group_raw_index', 'latitude', 'longitude', 'continent', 'country', 'kg_major', 'kg_code', 'spatial_cell', 'header_river', 'header_station', 'official_area_km2', 'all_same_station_exclusion_raw_indices', 'all_same_station_exclusion_ids']:
            df[k] = mm[k].to_numpy()
        df['L'] = df.gap_end.astype(int) - df.gap_start.astype(int)
        df['H'] = df.history_end.astype(int) - df.history_start.astype(int)
        assert df.H.eq(60).all() and df.L.eq(120 if name == 'long120' else 24).all()
        df['pending_alias_target'] = df.station_id.isin(RISK)
        rec = []
        for e in df.itertuples():
            d = dist(float(e.latitude), float(e.longitude), candidates.latitude.to_numpy(float), candidates.longitude.to_numpy(float))
            valid = candidates.valid_coordinates.to_numpy() & (candidates.physical_group_id.to_numpy() != e.physical_group_id) & np.isfinite(d)
            q = np.flatnonzero(valid)
            near = int(q[np.lexsort((candidates.raw_index.to_numpy()[q], d[q]))[0]]) if len(q) else -1
            ca = candidates.official_area_km2.to_numpy(float)
            area = float(e.official_area_km2)
            static_ok = valid & (candidates.kg_major.to_numpy() == e.kg_major) & (e.kg_major in list('ABCDE'))
            qq = np.flatnonzero(static_ok)
            clim = int(qq[np.lexsort((candidates.raw_index.to_numpy()[qq], d[qq]))[0]]) if len(qq) else near
            for rule, j in [('NEAREST', near), ('CLIMATE_NEAREST', clim)]:
                rec.append(dict(row=int(e.row), target_id=e.station_id, rule=rule, candidate_row=j, candidate_raw_index=int(candidates.raw_index.iloc[j]) if j >= 0 else -1, candidate_id=str(candidates.station_id.iloc[j]) if j >= 0 else '', candidate_physical_id=str(candidates.physical_group_id.iloc[j]) if j >= 0 else '', latitude=float(candidates.latitude.iloc[j]) if j >= 0 else np.nan, longitude=float(candidates.longitude.iloc[j]) if j >= 0 else np.nan, candidate_river=str(candidates.header_river.iloc[j]) if j >= 0 else '', candidate_name=str(candidates.header_station.iloc[j]) if j >= 0 else '', candidate_continent=str(candidates.continent.iloc[j]) if j >= 0 else '', candidate_kg_major=str(candidates.kg_major.iloc[j]) if j >= 0 else '', distance_km=float(d[j]) if j >= 0 else np.nan, climate_matching_candidates=int(len(qq)), fallback_to_nearest=bool(rule == 'CLIMATE_NEAREST' and (not len(qq))), same_two_rules=near == clim, selection_used_candidate_runoff=False))
        p = OUT / (name + '_cases.csv')
        df.to_csv(p, index=False, encoding='utf-8-sig')
        outputs.append(p)
        p = OUT / (name + '_static_choices.csv')
        pd.DataFrame(rec).to_csv(p, index=False, encoding='utf-8-sig')
        outputs.append(p)
    inputs = [_PROJECT_ROOT / 'workflows/monitoring/location_selection/source/prepare_trial.py', _PROJECT_ROOT / 'workflows/monitoring/location_selection/EXECUTION_SCOPE.md', _PROJECT_ROOT / 'workflows/regional_dependence/global_design/design/all_station_roles.csv', _PROJECT_ROOT / 'workflows/monitoring/location_selection/census/physical_identity_map.csv', _PROJECT_ROOT / 'workflows/monitoring/location_selection/census/cases_G24.csv', _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/cases.csv', CAT, _PROJECT_ROOT / 'workflows/regional_dependence/global_design/predictions/source_cache/source_raw_indices.npy']
    outputs += list(OUT.glob('*inventory.csv')) + [_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/source_strata.csv', _PROJECT_ROOT / 'workflows/monitoring/location_selection/design/candidate_locations.csv', _PROJECT_ROOT / 'workflows/monitoring/location_selection/design/network_roles.npz']
    js(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/STATIC_CHOICES_FROZEN.json', dict(status='STATIC_LOCATIONS_FROZEN_BEFORE_CANDIDATE_FLOW_ACCESS', source_entries=len(raw), source_physical=len(phys), withheld_physical=len(candidates), withheld_entries=int(inventory.withheld.sum()), methods=['NEAREST', 'CLIMATE_NEAREST'], fraction=0.2, selection_runoff_reads=0, inputs={str(p): sha(p) for p in inputs}, outputs={str(p): sha(p) for p in outputs}))
    print('STATIC FROZEN', len(raw), len(candidates), [(k, len(v)) for k, v in cohorts.items()], flush=True)

def rain():
    (_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs').mkdir(exist_ok=True)
    assert (_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/STATIC_CHOICES_FROZEN.json').exists()
    freeze = json.loads((_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/STATIC_CHOICES_FROZEN.json').read_text(encoding='utf8'))
    assert all((sha(p) == h for p, h in freeze['outputs'].items()))
    allcases = pd.concat([pd.read_csv(OUT / (n + '_cases.csv'), keep_default_na=False) for n in ['long120', 'short24']], ignore_index=True)
    ids = allcases.drop_duplicates('station_id').sort_values('raw_index')
    n = len(ids)
    lookup = {s: i for i, s in enumerate(ids.station_id)}
    values = np.full((n, 435), np.nan, np.float32)
    admit = np.zeros(n, bool)
    warn = np.zeros(n, bool)
    origins = np.full(n, 'NO_ADMITTED_EXISTING_INPUT', dtype=object)
    op = _PROJECT_ROOT / 'workflows/rainfall/global_inputs/final_inputs/global8898_tp_197910_201512_ADMITTED.npz'
    oz = np.load(op, allow_pickle=False)
    for j, s in enumerate(oz['station_ids'].astype(str)):
        if s in lookup:
            i = lookup[s]
            values[i] = oz['precip_mm_month'][j]
            admit[i] = bool(oz['admission_mask'][j])
            warn[i] = bool(oz['geometry_warning_mask'][j])
            origins[i] = 'old8898_admitted' if admit[i] else 'old8898_rejected'
    pbase = _PROJECT_ROOT / 'data/meteorology'
    train = _PROJECT_ROOT / 'data/meteorology/station_inputs'
    force = _PROJECT_ROOT / 'data/meteorology/catchment_forcing'
    mp = _PROJECT_ROOT / 'data/meteorology/station_inputs/weather_1994_2025.npz'
    rp = _PROJECT_ROOT / 'data/meteorology/station_inputs/station_registry.csv'
    fp = _PROJECT_ROOT / 'data/meteorology/catchment_forcing/global_catchment_forcing_1994_2025.npz'
    gp = _PROJECT_ROOT / 'data/meteorology/catchment_forcing/catchment_geometry_audit.csv'
    mz = np.load(mp, allow_pickle=False)
    fz = np.load(fp, allow_pickle=False)
    mv = mz['values'][:, :, list(mz['variable_names'].astype(str)).index('tp')]
    fv = fz['values'][:, :, list(fz['variable_names'].astype(str)).index('tp')]
    mi = {s: i for i, s in enumerate(mz['station_ids'].astype(str))}
    fi = {s: i for i, s in enumerate(fz['station_ids'].astype(str))}
    rc = ['station_id', 'forcing_input_origin', 'forcing_geometry_status', 'original_gsim_latitude', 'original_gsim_longitude', 'baseline_reach_scope_review_signal', 'unresolved_agency_area_signal_after_registered_input_correction']
    reg = pd.read_csv(rp, usecols=rc, keep_default_na=False).set_index('station_id')
    geo = pd.read_csv(gp, keep_default_na=False).set_index('station_id')
    assert mz['periods'].astype(str)[:264].tolist() == pd.period_range('1994-01', '2015-12', freq='M').astype(str).tolist()
    assert fz['periods'].astype(str).tolist() == mz['periods'].astype(str).tolist()
    lineage = []
    for e in ids.itertuples():
        s = e.station_id
        i = lookup[s]
        if origins[i] != 'NO_ADMITTED_EXISTING_INPUT':
            continue
        if s not in mi or s not in fi or s not in reg.index or (s not in geo.index):
            continue
        rr = reg.loc[s]
        gg = geo.loc[s]
        if str(rr.forcing_input_origin) != 'original_screened_full_catchment' or str(rr.forcing_geometry_status) != 'screened_full_catchment' or str(gg.reason) != 'source_quality_area_and_outlet_checks_pass':
            continue
        assert np.array_equal(mv[mi[s]], fv[fi[s]], equal_nan=True), s
        dd = float(dist(e.latitude, e.longitude, float(rr.original_gsim_latitude), float(rr.original_gsim_longitude)))
        assert dd <= 0.02, (s, dd)
        values[i, 171:] = mv[mi[s], :264]
        admit[i] = True
        warn[i] = str(rr.baseline_reach_scope_review_signal).lower() == 'true' or str(rr.unresolved_agency_area_signal_after_registered_input_correction).lower() == 'true'
        origins[i] = 'master_original_screened_full_catchment'
        lineage.append(dict(station_id=s, master_row=mi[s], forcing_row=fi[s], coordinate_distance_km=dd, full_tp_array_exact_match=True))
    p = _PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/rainfall.npz'
    np.savez_compressed(p, station_ids=ids.station_id.to_numpy(str), raw_index=ids.raw_index.to_numpy(np.int32), precip_mm_month=values, admission_mask=admit, geometry_warning=warn, periods=pd.period_range('1979-10', '2015-12', freq='M').astype(str).to_numpy(str))
    ledger = ids[['station_id', 'raw_index', 'continent', 'country', 'kg_major']].copy()
    ledger['admitted_geometry_source'] = admit
    ledger['geometry_warning'] = warn
    ledger['origin'] = origins
    ledger.to_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/rainfall_ledger.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(lineage).to_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/extra_master_lineage.csv', index=False)
    for name in ['long120', 'short24']:
        c = pd.read_csv(OUT / (name + '_cases.csv'), keep_default_na=False)
        rows = []
        for e in c.itertuples():
            i = lookup[e.station_id]
            v = values[i, int(e.history_start):int(e.gap_end) + 3]
            complete = bool(np.isfinite(v).all() and (v >= 0).all())
            rows.append(dict(row=e.row, station_id=e.station_id, continent=e.continent, kg_major=e.kg_major, rain_row=i, admitted=bool(admit[i]), complete_required_window=complete, available=bool(admit[i] and complete), geometry_warning=bool(warn[i]), origin=str(origins[i])))
        pd.DataFrame(rows).to_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs' / (name + '_rainfall_admission.csv'), index=False)
    files = [p, _PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/rainfall_ledger.csv', _PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/extra_master_lineage.csv'] + list((_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs').glob('*_rainfall_admission.csv'))
    js(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/INPUTS_FROZEN.json', dict(status='EXISTING_ADMITTED_FULL_BASIN_RAINFALL_BOUND', target_flow_read=False, files={str(p): sha(p) for p in files}, source_hashes={str(p): sha(p) for p in [op, mp, rp, fp, gp, _PROJECT_ROOT / 'workflows/monitoring/location_selection/source/prepare_trial.py']}))
    print('RAIN BOUND', n, int(admit.sum()), 'extra', len(lineage), flush=True)
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('step', choices=['static', 'rain'])
    a = ap.parse_args()
    globals()[a.step]()
