from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib, argparse, time, warnings
for key in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[key] = '1'
ROOT = _PROJECT_ROOT / 'workflows/monitoring/location_selection'
CODE = _PROJECT_ROOT
pass
pass
sys.dont_write_bytecode = True
import numpy as np, pandas as pd
from workflows.monitoring.location_selection.audit.audit_prediction_math import prepare, correlations
warnings.filterwarnings('ignore', category=RuntimeWarning)

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(x)
    return h.hexdigest()

def read(p):
    return pd.read_csv(p, keep_default_na=False, low_memory=False)

def main(cohort):
    t = time.time()
    D = _PROJECT_ROOT / 'workflows/monitoring/location_selection/design'
    P = _PROJECT_ROOT / 'workflows/monitoring/location_selection/predictions' / cohort
    freeze = json.loads((P / 'PREDICTIONS_FROZEN.json').read_text(encoding='utf8'))
    for p, h in freeze['files'].items():
        assert sha(p) == h, p
    code = json.loads((_PROJECT_ROOT / 'workflows/monitoring/location_selection/CODE_INPUTS_FROZEN.json').read_text(encoding='utf8'))
    for p, h in code['files'].items():
        assert sha(p) == h, p
    maths = json.loads((_PROJECT_ROOT / 'workflows/monitoring/location_selection/audit/PREDICTION_MATH_GUARDS_QA.json').read_text(encoding='utf8'))
    assert maths['passed'] and maths['production_code_sha256'] == sha(_PROJECT_ROOT / 'workflows/monitoring/location_selection/source/run_trial.py')
    cases = read(D / f'{cohort}_cases.csv')
    choice = read(D / f'{cohort}_static_choices.csv')
    N = len(cases)
    L = int(cases.L.iloc[0])
    arrays = {k: np.load(P / f'{k}.npy', mmap_mode='r') for k in ['predictions', 'support', 'fit', 'uses_P', 'composites', 'counts', 'selected_ids', 'training_mask', 'candidate_info', 'seasonal_baseline', 'target_raw_calendar', 'input_meta', 'done']}
    assert arrays['done'].all() and len(arrays['done']) == N
    net = np.load(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/network_roles.npz')
    full = np.zeros(30959, bool)
    full[net['full_raw']] = True
    hidden = np.zeros(30959, bool)
    hidden[net['withheld_raw']] = True
    Q = np.load(_PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy', mmap_mode='r')
    rain = read(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs' / f'{cohort}_rainfall_admission.csv')
    np.testing.assert_array_equal(arrays['input_meta'][:, 1].astype(bool), rain.available.to_numpy(bool))
    choices = np.stack([choice[choice.rule.eq(r)].sort_values('row').candidate_raw_index.to_numpy(int) for r in ['NEAREST', 'CLIMATE_NEAREST']], axis=1)
    static_same = choice[choice.rule.eq('NEAREST')].sort_values('row').same_two_rules.to_numpy(bool)
    slots = 0
    max_comp = 0.0
    max_new_r = 0.0
    unused = 0
    used = 0
    poison_noaccess = True
    near_zero = []
    for i, e in enumerate(cases.itertuples()):
        h = np.arange(int(e.history_start), int(e.history_end))
        g = np.arange(int(e.gap_start), int(e.gap_end))
        mm = np.r_[h, g]
        ids = np.asarray(arrays['selected_ids'][i])
        counts = np.asarray(arrays['counts'][i])
        comp = np.asarray(arrays['composites'][i])
        valid = ids >= 0
        ex = json.loads(e.all_same_station_exclusion_raw_indices)
        assert not np.isin(ids, ex).any()
        assert full[ids[valid]].all()
        slots += int(valid.sum())
        np.testing.assert_array_equal(valid.sum(2), counts)
        assert np.all(valid == (np.arange(4)[None, None, :] < counts[:, :, None]))
        assert not hidden[ids[1][ids[1] >= 0]].any()
        assert np.isfinite(comp[counts > 0]).all() and np.isnan(comp[counts == 0]).all()
        th = np.asarray(Q[e.raw_index, h])
        tc, ts, tzz = prepare(th[None, :], h)
        tz = tzz[0]
        estim = bool(np.isfinite(th).all() and (th >= 0).all() and np.isfinite(tc).all() and np.isfinite(ts[0]))
        if not estim:
            tz[:] = np.nan
        assert estim == bool(arrays['input_meta'][i, 0])
        cal = np.array([np.nanmean(th[h % 12 == m]) for m in range(12)])
        np.testing.assert_array_equal(cal, arrays['target_raw_calendar'][i])
        np.testing.assert_array_equal(cal[g % 12], arrays['seasonal_baseline'][i])
        for base in [0, 1]:
            train = np.isfinite(tz) & np.isfinite(comp[base, :60])
            np.testing.assert_array_equal(train, arrays['training_mask'][i, base])
            assert train.sum() == arrays['input_meta'][i, 2 + base]
        unique = np.unique(ids[valid])
        unique = np.union1d(unique, choices[i]).astype(int)
        uq = np.asarray(Q[unique])
        cl, sd, z = prepare(uq[:, h], h)
        nn, rr = correlations(z, tz)
        post_new = {}
        for rule in range(2):
            cand = int(choices[i, rule])
            u = int(np.searchsorted(unique, cand))
            assert unique[u] == cand and hidden[cand] and (cand not in ex)
            for li, hl in enumerate([24, 36, 60]):
                a = 2 + 3 * rule + li
                ci = np.asarray(arrays['candidate_info'][i, rule, li])
                hv = uq[u, h[-hl:]]
                c, s, zn = prepare(hv[None, :], h[-hl:])
                pad = np.full((1, 60), np.nan)
                pad[0, -hl:] = zn[0]
                n, r = correlations(pad, tz)
                cm = min((np.sum(np.isfinite(hv[h[-hl:] % 12 == m]) & (hv[h[-hl:] % 12 == m] >= 0)) for m in range(12)))
                status = 1 if n[0] < 24 or cm < 2 else 2 if not np.isfinite(r[0]) or not np.isfinite(s[0]) else 3 if r[0] <= 0 else 4
                if status != int(ci[10]) and status in [3, 4] and (int(ci[10]) in [3, 4]):
                    assert abs(r[0]) < 1e-12 and abs(ci[4]) < 1e-12
                    near_zero.append(dict(row=i, station_id=e.station_id, rule=rule, common_history=hl, independent_centered_r=float(r[0]), production_moment_r=float(ci[4]), selected_H_slots=int(ci[6]), selected_G_slots=int(ci[7])))
                    status = int(ci[10])
                pred_info = np.array([cand, hl, n[0], cm, r[0], int(status == 4), np.sum(ids[a, :60] == cand), np.sum(ids[a, 60:] == cand), np.sum(np.isfinite(uq[u, g]) & (uq[u, g] >= 0)), np.sum(np.isfinite(uq[u, g]) & (uq[u, g] >= 0) & np.isfinite(c[0, g % 12])), status, h[-hl]], float)
                np.testing.assert_allclose(ci, pred_info, rtol=0, atol=1e-10, equal_nan=True)
                if np.isfinite(r[0]):
                    max_new_r = max(max_new_r, abs(r[0] - ci[4]))
                active = ids[a][ids[a] >= 0]
                assert np.all(~hidden[active] | (active == cand))
                assert not (ids[a, mm < h[-hl]] == cand).any()
                if pred_info[6] + pred_info[7] == 0:
                    unused += 1
                    for name in ['predictions', 'support', 'fit', 'uses_P', 'composites', 'counts', 'selected_ids']:
                        np.testing.assert_array_equal(arrays[name][i, a], arrays[name][i, 1])
                else:
                    used += 1
                    assert status == 4
                post_new[a] = (cand, c[0], s[0], float(ci[4]) if abs(r[0]) < 1e-12 and np.isfinite(ci[4]) else r[0])
        for a in range(8):
            sid = ids[a]
            ok = sid >= 0
            j = np.searchsorted(unique, np.maximum(sid, unique[0]))
            j = np.minimum(j, len(unique) - 1)
            months = np.broadcast_to(mm[:, None], sid.shape)
            v = uq[j, months]
            means = cl[j, months % 12]
            scales = sd[j]
            weights = rr[j]
            if a >= 2:
                cand, c, s, r = post_new[a]
                new = sid == cand
                means = np.where(new, c[months % 12], means)
                scales = np.where(new, s, scales)
                weights = np.where(new, r, weights)
            assert np.isfinite(v[ok]).all() and (v[ok] >= 0).all()
            assert np.isfinite(weights[ok]).all() and (weights[ok] > 0).all()
            zz = (np.log1p(np.maximum(v, 0)) - means) / scales
            den = np.where(ok, weights, 0).sum(1)
            numer = np.where(ok, weights * zz, 0).sum(1)
            expected = np.divide(numer, den, out=np.full(len(mm), np.nan), where=den > 0)
            np.testing.assert_allclose(comp[a], expected, rtol=1e-09, atol=1e-09, equal_nan=True)
            if np.isfinite(expected).any():
                max_comp = max(max_comp, float(np.nanmax(abs(comp[a] - expected))))
            for method in range(2):
                fit = arrays['fit'][i, a, method]
                support = arrays['support'][i, a, method]
                p = arrays['predictions'][i, a, method]
                assert not np.isinf(p).any()
                for inp in range(2):
                    if not fit[inp]:
                        assert not support[inp].any()
                        np.testing.assert_array_equal(p[inp], arrays['seasonal_baseline'][i])
                    assert np.isfinite(p[inp][support[inp]]).all()
                assert not arrays['uses_P'][i, a, method, 0]
                if not arrays['uses_P'][i, a, method, 1]:
                    np.testing.assert_array_equal(p[0], p[1])
                    np.testing.assert_array_equal(support[0], support[1])
                    assert fit[0] == fit[1]
        if static_same[i]:
            for name in ['predictions', 'support', 'fit', 'uses_P', 'composites', 'counts', 'selected_ids']:
                np.testing.assert_array_equal(arrays[name][i, 2:5], arrays[name][i, 5:8])
        if (i + 1) % 2000 == 0:
            print(cohort, 'AUDITED', i + 1, '/', N, 'seconds', round(time.time() - t, 1), flush=True)
    pd.DataFrame(near_zero).to_csv(_PROJECT_ROOT / 'workflows/monitoring/location_selection/audit' / f'NUMERICAL_ZERO_BOUNDARY_{cohort}.csv', index=False)
    report = dict(passed=True, cohort=cohort, N=N, L=L, all_selected_source_slots=slots, all_candidate_duration_conditions=N * 6, used_candidate_conditions=used, unchanged_unused_conditions=unused, max_composite_absolute_difference=max_comp, max_candidate_H_r_difference=max_new_r, numerical_zero_boundary_rows=len(near_zero), numerical_zero_boundary_used_rows=sum((x['selected_H_slots'] + x['selected_G_slots'] > 0 for x in near_zero)), all_target_alias_and_withheld_exclusions=True, all_new_source_enabling_and_qualification=True, all_common_training_masks=True, all_no_P_fallbacks=True, all_same_rule_outputs_equal=True, target_G_not_scored=True, prediction_freeze_sha256=sha(P / 'PREDICTIONS_FROZEN.json'), math_guard_report_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/location_selection/audit/PREDICTION_MATH_GUARDS_QA.json'), audit_code_sha256=sha(__file__), seconds=time.time() - t)
    (_PROJECT_ROOT / 'workflows/monitoring/location_selection/audit' / f'PREDICTIONS_{cohort}_INDEPENDENT_QA.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('cohort', choices=['long120', 'short24'])
    a = p.parse_args()
    main(a.cohort)
