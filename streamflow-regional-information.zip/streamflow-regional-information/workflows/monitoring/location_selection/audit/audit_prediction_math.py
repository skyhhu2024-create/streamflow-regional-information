from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib, importlib.util, time, warnings
for key in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[key] = '1'
ROOT = _PROJECT_ROOT / 'workflows/monitoring/location_selection'
CODE = _PROJECT_ROOT
pass
sys.dont_write_bytecode = True
import numpy as np, pandas as pd
from scipy.stats import rankdata
spec = importlib.util.spec_from_file_location('trial_to_audit', _PROJECT_ROOT / 'workflows/monitoring/location_selection/source/run_trial.py')
R = importlib.util.module_from_spec(spec)
spec.loader.exec_module(R)
warnings.filterwarnings('ignore', category=RuntimeWarning)

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(x)
    return h.hexdigest()

def prepare(q, months):
    x = np.where(np.isfinite(q) & (q >= 0), np.log1p(np.maximum(q, 0)), np.nan)
    avg = np.full((len(q), 12), np.nan)
    for m in range(12):
        ix = months % 12 == m
        count = np.isfinite(x[:, ix]).sum(1)
        avg[:, m] = np.divide(np.nansum(x[:, ix], 1), count, out=np.full(len(q), np.nan), where=count > 0)
    res = x - avg[:, months % 12]
    scale = np.nanstd(res, axis=1)
    scale[scale <= 1e-12] = np.nan
    return (avg, scale, res / scale[:, None])

def correlations(z, t):
    valid = np.isfinite(z) & np.isfinite(t)[None, :]
    n = valid.sum(1)
    zx = np.where(valid, z, 0)
    ty = np.where(valid, t[None, :], 0)
    zm = np.divide(zx.sum(1), n, out=np.zeros(len(z)), where=n > 0)
    tm = np.divide(ty.sum(1), n, out=np.zeros(len(z)), where=n > 0)
    a = np.where(valid, z - zm[:, None], 0)
    b = np.where(valid, t[None, :] - tm[:, None], 0)
    aa = (a * a).sum(1)
    bb = (b * b).sum(1)
    rr = np.divide((a * b).sum(1), np.sqrt(aa * bb), out=np.full(len(z), np.nan), where=(n >= 12) & (aa > 1e-24) & (bb > 1e-24))
    return (n, np.clip(rr, -1, 1))

def model_predict(x, y, g, method):
    if len(y) < 12 or not np.isfinite(x).all() or (not np.isfinite(y).all()):
        return None
    mean = x.mean(0)
    scale = x.std(0)
    scale = np.where(scale > 1e-12, scale, 1.0)
    a = (x - mean) / scale
    yc = y - y.mean()
    valid = np.isfinite(g).all(1)
    b = (g[valid] - mean) / scale
    output = np.full(len(g), np.nan)
    n, p = a.shape
    if method == 'ridge':
        augmented = np.vstack([a, np.sqrt(n * 0.1) * np.eye(p)])
        rhs = np.r_[yc, np.zeros(p)]
        coef = np.linalg.lstsq(augmented, rhs, rcond=None)[0]
        output[valid] = b @ coef + y.mean()
    else:
        d = ((a[:, None, :] - a[None, :, :]) ** 2).sum(2)
        kernel = np.exp(-d / p)
        coef = np.linalg.solve(kernel + n * 0.1 * np.eye(n), yc)
        dg = ((b[:, None, :] - a[None, :, :]) ** 2).sum(2)
        output[valid] = np.exp(-dg / p) @ coef + y.mean()
    return output

def replay(i, got):
    e = R.G['cases'].iloc[i]
    h = np.arange(e.history_start, e.history_end)
    g = np.arange(e.gap_start, e.gap_end)
    mm = np.r_[h, g]
    raw = R.G['raw']
    q = R.G['source']['Q']
    target = np.asarray(R.C.G['Q'][int(e.raw_index), h])
    tc, ts, tzz = prepare(target[None, :], h)
    tc = tc[0]
    ts = ts[0]
    tz = tzz[0]
    estim = np.isfinite(target).all() and (target >= 0).all() and np.isfinite(tc).all() and np.isfinite(ts)
    if not estim:
        tz[:] = np.nan
    cal = np.array([np.nanmean(target[h % 12 == m]) for m in range(12)])
    base = cal[g % 12]
    cl, sd, zh = prepare(q[:, h], h)
    nn, rr = correlations(zh, tz)
    la = np.deg2rad(R.G['source']['lat'])
    lo = np.deg2rad(R.G['source']['lon'])
    a, b = np.deg2rad([e.latitude, e.longitude])
    hv = np.clip(np.sin((la - a) / 2) ** 2 + np.cos(la) * np.cos(a) * np.sin((lo - b) / 2) ** 2, 0, 1)
    dist = 12742 * np.arctan2(np.sqrt(hv), np.sqrt(1 - hv))
    aliases = json.loads(e.all_same_station_exclusion_raw_indices)
    qual = np.isfinite(rr) & (rr > 0) & np.isfinite(sd) & ~np.isin(raw, aliases)
    full = np.flatnonzero(qual)
    red = np.flatnonzero(qual & ~R.G['hidden'])

    def order(which):
        rk = rankdata(-rr[which])
        dk = rankdata(dist[which])
        return which[np.lexsort((raw[which], rk, rk + dk))]

    def composite(which, new=None):
        result = np.full(len(mm), np.nan)
        cnt = np.zeros(len(mm), np.int8)
        ids = np.full((len(mm), 4), -1, np.int32)
        for k, m in enumerate(mm):
            selected = []
            weights = []
            z = []
            for j in which:
                if new is not None and j == new['j']:
                    if m < new['enabled']:
                        continue
                    c, s, w = (new['calendar'][m % 12], new['scale'], new['r'])
                else:
                    c, s, w = (cl[j, m % 12], sd[j], rr[j])
                v = q[j, m]
                if np.isfinite(v) and v >= 0 and np.isfinite(c):
                    selected.append(raw[j])
                    weights.append(w)
                    z.append((np.log1p(v) - c) / s)
                if len(selected) == 4:
                    break
            if selected:
                cnt[k] = len(selected)
                ids[k, :len(selected)] = selected
                result[k] = sum((w * x for w, x in zip(weights, z))) / sum(weights)
        return (result, cnt, ids)
    comps = np.full_like(got[5], np.nan)
    counts = np.zeros_like(got[6])
    ids = np.full_like(got[7], -1)
    comps[0], counts[0], ids[0] = composite(order(full))
    comps[1], counts[1], ids[1] = composite(order(red))
    train = np.array([np.isfinite(tz) & np.isfinite(comps[0, :60]), np.isfinite(tz) & np.isfinite(comps[1, :60])])
    for rule in range(2):
        candidate = int(R.G['choice'][i, rule])
        j = R.G['pos'][candidate]
        for li, L in enumerate([24, 36, 60]):
            ai = 2 + 3 * rule + li
            hv = q[j, h[-L:]]
            c, s, z = prepare(hv[None, :], h[-L:])
            pad = np.full((1, 60), np.nan)
            pad[0, -L:] = z[0]
            nc, rc = correlations(pad, tz)
            cm = min((np.sum(np.isfinite(hv[h[-L:] % 12 == m]) & (hv[h[-L:] % 12 == m] >= 0)) for m in range(12)))
            qualified = nc[0] >= 24 and cm >= 2 and np.isfinite(rc[0]) and (rc[0] > 0) and np.isfinite(s[0])
            assert bool(got[9][rule, li, 5]) == qualified
            if not qualified:
                comps[ai], counts[ai], ids[ai] = (comps[1], counts[1], ids[1])
                continue
            rk = rankdata(-rr[red])
            dk = rankdata(dist[red])
            xr = float(np.sum(rr[red] > rc[0]) + 0.5 * np.sum(rr[red] == rc[0]) + 0.5) if len(red) else 1.0
            xd = float(np.sum(dist[red] < dist[j]) + 0.5 * np.sum(dist[red] == dist[j]) + 0.5) if len(red) else 1.0
            pool = np.r_[red, j]
            ranks = np.r_[rk, xr]
            scores = np.r_[rk + dk, xr + xd]
            seq = pool[np.lexsort((raw[pool], ranks, scores))]
            comps[ai], counts[ai], ids[ai] = composite(seq, dict(j=j, enabled=h[-L], calendar=c[0], scale=s[0], r=rc[0]))
    np.testing.assert_array_equal(ids, got[7])
    np.testing.assert_array_equal(counts, got[6])
    np.testing.assert_array_equal(train, got[8])
    np.testing.assert_allclose(comps, got[5], rtol=2e-10, atol=2e-10, equal_nan=True)
    ri = R.G['rainpos'][e.station_id]
    rain = R.G['rain']
    pp = np.asarray(rain['precip_mm_month'][ri, int(e.history_start):int(e.gap_end) + 3], dtype=np.float64)
    hasp = bool(rain['admission_mask'][ri]) and np.isfinite(pp).all() and (pp >= 0).all()
    logp = np.where(np.isfinite(pp) & (pp >= 0), np.log1p(np.maximum(pp, 0)), np.nan)
    lags = np.stack([logp[3 - j:3 - j + len(mm)] for j in range(4)], axis=1)
    pred = np.full_like(got[1], np.nan)
    support = np.zeros_like(got[2])
    fits = np.zeros_like(got[3])
    for a in range(8):
        mask = train[0 if a == 0 else 1]
        for method_idx, method in enumerate(['ridge', 'rbf_ridge']):
            for inp in range(2):
                xx = np.c_[comps[a], lags] if inp and hasp else comps[a, :, None]
                zz = model_predict(xx[:60][mask], tz[mask], xx[60:], method) if estim else None
                fits[a, method_idx, inp] = zz is not None
                if zz is None:
                    pred[a, method_idx, inp] = base
                    continue
                ok = np.isfinite(zz) & np.isfinite(tc[g % 12])
                support[a, method_idx, inp] = ok
                bounded = np.clip(zz, np.nanmin(tz) - 3, np.nanmax(tz) + 3)
                ans = np.maximum(np.expm1(np.minimum(bounded * ts + tc[g % 12], 50)), 0)
                ans[~ok] = base[~ok]
                pred[a, method_idx, inp] = ans
    np.testing.assert_array_equal(fits, got[3])
    np.testing.assert_array_equal(support, got[2])
    np.testing.assert_allclose(pred, got[1], rtol=1e-09, atol=1e-07, equal_nan=True)
    return dict(station_id=e.station_id, row=i, continent=e.continent, max_prediction_absolute_difference=float(np.nanmax(abs(pred - got[1]))), max_composite_absolute_difference=float(np.nanmax(abs(comps - got[5]))), same_source_ids=True)

def same(got, other, indices=None):
    if indices is None:
        indices = range(1, len(got))
    for j in indices:
        np.testing.assert_allclose(got[j], other[j], rtol=0, atol=0, equal_nan=True)

def guard(i):
    e = R.G['cases'].iloc[i]
    h = np.arange(e.history_start, e.history_end)
    g = np.arange(e.gap_start, e.gap_end)
    baseline = R.work(i)
    src = R.G['source']['Q']
    orig = src.copy()
    raw = R.G['raw']
    exclude = json.loads(e.all_same_station_exclusion_raw_indices)
    for v in exclude:
        j = R.G['pos'].get(v)
        if j is not None:
            src[j, g] = 1e+19
    R.sourceprep.cache_clear()
    same(baseline, R.work(i))
    src[:] = orig
    R.sourceprep.cache_clear()
    src[R.G['hidden']] = np.nan
    R.sourceprep.cache_clear()
    test = R.work(i)
    for j in [1, 2, 3, 4, 5, 6, 7]:
        np.testing.assert_allclose(baseline[j][1], test[j][1], rtol=0, atol=0, equal_nan=True)
    np.testing.assert_array_equal(baseline[8][1], test[8][1])
    src[:] = orig
    R.sourceprep.cache_clear()
    outside = np.ones(432, bool)
    outside[np.r_[h, g]] = False
    src[:, outside] = np.nan
    R.sourceprep.cache_clear()
    same(baseline, R.work(i))
    src[:] = orig
    R.sourceprep.cache_clear()
    src[:, g] = np.where(np.isfinite(src[:, g]), src[:, g] * 1.31 + 2, src[:, g])
    test = R.work(i)
    np.testing.assert_allclose(baseline[5][:, :60], test[5][:, :60], rtol=0, atol=0, equal_nan=True)
    np.testing.assert_array_equal(baseline[8], test[8])
    src[:] = orig
    R.sourceprep.cache_clear()
    return dict(station_id=e.station_id, target_alias_G_invariance=True, withheld_all_HG_reduced_invariance=True, outside_window_invariance=True, source_G_no_H_effect=True)

def main():
    t = time.time()
    rainqa = json.loads((_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/RAINFALL_INDEPENDENT_QA.json').read_text(encoding='utf8'))
    assert rainqa['passed']
    rows = []
    guards = []
    for cohort in ['long120', 'short24']:
        R.init(cohort)
        cases = R.G['cases']
        chosen = []
        for continent in ['Africa', 'Asia', 'Europe', 'NorthAmerica', 'Oceania', 'SouthAmerica']:
            ii = np.flatnonzero(cases.continent.to_numpy(str) == continent)
            if len(ii):
                chosen.append(int(ii[0]))
        for i in chosen:
            got = R.work(i)
            record = replay(i, got)
            record['cohort'] = cohort
            rows.append(record)
            print('MATH', cohort, record['station_id'], record['max_prediction_absolute_difference'], flush=True)
        guards.append(dict(cohort=cohort, **guard(chosen[0])))
    output = dict(passed=True, independent_math_cases=rows, guards=guards, selection='First raw-index case from every represented major continent, chosen without G values or scores', production_code_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/location_selection/source/run_trial.py'), audit_code_sha256=sha(__file__), rain_input_freeze_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/INPUTS_FROZEN.json'), seconds=time.time() - t)
    (_PROJECT_ROOT / 'workflows/monitoring/location_selection/audit/PREDICTION_MATH_GUARDS_QA.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    print('ALL_MATH_AND_GUARDS_PASS', time.time() - t, flush=True)
if __name__ == '__main__':
    main()
