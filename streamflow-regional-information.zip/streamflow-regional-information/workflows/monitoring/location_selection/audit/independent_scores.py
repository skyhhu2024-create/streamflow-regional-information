"""Independent metric/statistic replay, gated by frozen predictions and reviewer QA.

Does not import production metric/scoring functions and never selects stations.
"""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib, argparse
for k in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '1'
ROOT = _PROJECT_ROOT / 'workflows/monitoring/location_selection'
CODE = _PROJECT_ROOT
pass
import numpy as np, pandas as pd
NETWORKS = ['FULL', 'REDUCED', 'NEAREST_24', 'NEAREST_36', 'NEAREST_60', 'CLIMATE_NEAREST_24', 'CLIMATE_NEAREST_36', 'CLIMATE_NEAREST_60']
METHODS = ['ridge', 'rbf_ridge']
INPUTS = ['Q', 'QP']
KEYS = [(n, m, p) for n in NETWORKS for m in METHODS for p in INPUTS]
QPATH = _PROJECT_ROOT / 'workflows/regional_dependence/global_design/global_data/QC20_Q.npy'
D = _PROJECT_ROOT / 'workflows/monitoring/location_selection/design'
A = _PROJECT_ROOT / 'workflows/monitoring/location_selection/audit'

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def js(p, x):
    Path(p).write_text(json.dumps(x, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')

def correlation(x, y):
    dx = x - np.mean(x, axis=1, keepdims=True)
    dy = y - np.mean(y, axis=1, keepdims=True)
    nx = np.linalg.norm(dx, axis=1)
    ny = np.linalg.norm(dy, axis=1)
    valid = np.all(np.isfinite(x), axis=1) & np.all(np.isfinite(y), axis=1) & np.any(x != x[:, 0, None], axis=1) & np.any(y != y[:, 0, None], axis=1) & (nx > 0) & (ny > 0)
    result = np.full(len(x), np.nan)
    result[valid] = np.einsum('ij,ij->i', dx[valid] / nx[valid, None], dy[valid] / ny[valid, None])
    return np.clip(result, -1, 1)

def independent_metric(p, y):
    finite = np.all(np.isfinite(y), axis=1) & np.all(y >= 0, axis=1) & np.any(y != y[:, 0, None], axis=1)
    sy = np.std(y, axis=1, ddof=0)
    sp = np.std(p, axis=1, ddof=0)
    sy[np.all(y == y[:, 0, None], axis=1)] = 0
    sp[np.all(p == p[:, 0, None], axis=1)] = 0
    finite &= sy > 0
    ok = finite & np.all(np.isfinite(p), axis=1)
    r = correlation(p, y)
    r[~ok] = np.nan
    ns = np.full(len(y), np.nan)
    alpha = np.full(len(y), np.nan)
    delta = np.full(len(y), np.nan)
    ns[ok] = 1 - np.mean(((p[ok] - y[ok]) / sy[ok, None]) ** 2, axis=1)
    alpha[ok] = sp[ok] / sy[ok]
    delta[ok] = np.mean(p[ok] - y[ok], axis=1) / sy[ok]
    return dict(r=r, NSE=ns, alpha=alpha, delta=delta, valid_truth=finite)

def compare(a, b, name, atol=2e-11, rtol=2e-11):
    a = np.asarray(a)
    b = np.asarray(b)
    if a.dtype.kind == 'b' or b.dtype.kind == 'b':
        assert np.array_equal(a.astype(bool), b.astype(bool)), name
        return dict(name=name, n=len(a), max_abs_difference=0.0)
    a = a.astype(float)
    b = b.astype(float)
    assert np.array_equal(np.isnan(a), np.isnan(b)), name + ' NaN locations'
    assert np.array_equal(np.isposinf(a), np.isposinf(b)) and np.array_equal(np.isneginf(a), np.isneginf(b)), name + ' inf locations'
    keep = np.isfinite(a) & np.isfinite(b)
    np.testing.assert_allclose(a[keep], b[keep], rtol=rtol, atol=atol, err_msg=name)
    return dict(name=name, n=len(a), max_abs_difference=float(np.max(np.abs(a[keep] - b[keep]))) if keep.any() else 0.0)

def gate(cohort):
    pr = _PROJECT_ROOT / 'workflows/monitoring/location_selection/predictions' / cohort
    ar = _PROJECT_ROOT / 'workflows/monitoring/location_selection/analysis' / cohort
    pf = pr / 'PREDICTIONS_FROZEN.json'
    qa = A / f'PREDICTIONS_{cohort}_INDEPENDENT_QA.json'
    assert pf.exists() and qa.exists(), 'No truth access before prediction freeze and independent QA'
    q = json.loads(qa.read_text(encoding='utf8'))
    assert q['passed'] and q['prediction_freeze_sha256'] == sha(pf)
    f = json.loads(pf.read_text(encoding='utf8'))
    assert all((sha(p) == h for p, h in f['files'].items()))
    sf = ar / 'SCORES_FROZEN.json'
    assert sf.exists()
    s = json.loads(sf.read_text(encoding='utf8'))
    assert s['prediction_freeze_sha256'] == sha(pf)
    assert all((sha(p) == h for p, h in s['files'].items()))
    scoring_registration = json.loads((_PROJECT_ROOT / 'workflows/monitoring/location_selection/SCORING_CODE_FROZEN.json').read_text(encoding='utf8'))
    assert all((sha(p) == h for p, h in scoring_registration['files'].items()))
    assert s['score_code_sha256'] == sha(_PROJECT_ROOT / 'workflows/monitoring/location_selection/source/score_trial.py')
    return (pr, ar, pf, sf)

def metrics(cohort):
    pr, ar, pf, sf = gate(cohort)
    c = pd.read_csv(D / f'{cohort}_cases.csv', keep_default_na=False, low_memory=False)
    N = len(c)
    L = int(c.L.iloc[0])
    q = np.load(QPATH, mmap_mode='r')
    y = np.stack([q[int(e.raw_index), int(e.gap_start):int(e.gap_end)] for e in c.itertuples()])
    expected_cal = np.stack([np.array([np.mean(q[int(e.raw_index), np.arange(int(e.history_start), int(e.history_end))[np.arange(int(e.history_start), int(e.history_end)) % 12 == j]]) for j in range(12)]) for e in c.itertuples()])
    cal = np.load(pr / 'target_raw_calendar.npy')
    checks = [compare(cal.ravel(), expected_cal.ravel(), 'H-only raw calendar')]
    seasons = np.stack([expected_cal[i, np.arange(int(e.gap_start), int(e.gap_end)) % 12] for i, e in enumerate(c.itertuples())])
    baseline = np.load(pr / 'seasonal_baseline.npy')
    checks.append(compare(baseline.ravel(), seasons.ravel(), 'seasonal fallback values'))
    bm = independent_metric(baseline, y)
    btable = pd.read_csv(ar / 'seasonal_baseline.csv', keep_default_na=False, na_values=[''])
    assert btable.station_id.tolist() == c.station_id.tolist()
    for k in bm:
        checks.append(compare(btable[k].to_numpy(), bm[k], 'baseline ' + k))
    bpass = np.isfinite(bm['r']) & (bm['r'] > 0.7)
    checks.append(compare(btable.numeric_pass07.to_numpy(), bpass, 'baseline numeric pass'))
    p = np.load(pr / 'predictions.npy', mmap_mode='r')
    support = np.load(pr / 'support.npy', mmap_mode='r')
    fit = np.load(pr / 'fit.npy')
    up = np.load(pr / 'uses_P.npy')
    im = np.load(pr / 'input_meta.npy')
    table = pd.read_csv(ar / 'scores_long.csv.gz', keep_default_na=False, na_values=[''], low_memory=False)
    assert len(table) == N * 32 and p.shape == (N, 8, 2, 2, L)
    groups = {k: z.sort_values('row') for k, z in table.groupby(['network', 'method', 'inputs'], sort=False)}
    arrays = {k: [] for k in ['r', 'NSE', 'alpha', 'delta', 'valid_truth', 'anomaly_r', 'support_months', 'fit_estimable', 'evaluable', 'uses_P', 'P_available', 'pass06', 'pass07', 'pass08']}
    for ni, network in enumerate(NETWORKS):
        for mi, method in enumerate(METHODS):
            for pi, inp in enumerate(INPUTS):
                key = (network, method, inp)
                v = np.asarray(p[:, ni, mi, pi])
                row = groups[key]
                assert row.row.to_numpy().tolist() == list(range(N)) and row.station_id.tolist() == c.station_id.tolist()
                got = independent_metric(v, y)
                got['anomaly_r'] = correlation(v - seasons, y - seasons)
                got['support_months'] = np.count_nonzero(support[:, ni, mi, pi], axis=1)
                got['fit_estimable'] = fit[:, ni, mi, pi]
                got['uses_P'] = up[:, ni, mi, pi]
                got['P_available'] = im[:, 1].astype(bool)
                got['evaluable'] = got['valid_truth'] & np.isfinite(got['r']) & np.all(np.isfinite(v), axis=1) & got['fit_estimable'] & (got['support_months'] >= 1)
                for cut in [0.6, 0.7, 0.8]:
                    got[f'pass{int(10 * cut):02d}'] = got['evaluable'] & (got['r'] > cut)
                for k in got:
                    checks.append(compare(row[k].to_numpy(), got[k], str(key) + ' ' + k))
                    arrays[k].append(got[k])
                checks.append(compare(row.seasonal_r.to_numpy(), bm['r'], str(key) + ' seasonal r'))
                checks.append(compare(row.seasonal_numeric_pass07.to_numpy(), bpass, str(key) + ' seasonal pass'))
    path = A / f'independent_metrics_{cohort}.npz'
    np.savez_compressed(path, **{k: np.stack(v) for k, v in arrays.items()}, seasonal_r=bm['r'], seasonal_pass07=bpass, station_ids=c.station_id.to_numpy(str), keys=np.array(['|'.join(k) for k in KEYS]))
    pd.DataFrame(checks).to_csv(A / f'INDEPENDENT_SCORE_DIFFERENCES_{cohort}.csv', index=False)
    js(A / f'INDEPENDENT_SCORE_METRICS_{cohort}.json', dict(passed=True, cohort=cohort, N=N, L=L, all_arm_scores_checked=N * 32, arms=32, prediction_freeze_sha256=sha(pf), scores_freeze_sha256=sha(sf), independent_metrics_sha256=sha(path), max_metric_absolute_difference=max((x['max_abs_difference'] for x in checks)), all_missing_and_validity_flags_exact=True, all_pass06_pass07_pass08_exact=True, code_sha256=sha(__file__), target_G_access_after_independent_QA_gate=True))
    print('INDEPENDENT_METRICS_PASS', cohort, N * 32, flush=True)

def synthetic():
    y = np.tile(np.arange(1, 5, dtype=float), (6, 1))
    p = y.copy()
    p[1] = p[1, ::-1]
    p[2] = 2
    p[3, 0] = np.nan
    y[4] = 3
    y[5, 0] = -1
    z = independent_metric(p, y)
    np.testing.assert_allclose(z['r'][:2], [1, -1])
    assert np.isnan(z['r'][2:]).all()
    assert z['NSE'][0] == 1 and z['NSE'][1] == -3 and (z['alpha'][2] == 0)
    assert z['valid_truth'].tolist() == [True, True, True, True, False, False]
    js(_PROJECT_ROOT / 'workflows/monitoring/location_selection/audit/INDEPENDENT_SCORE_SYNTHETIC_QA.json', dict(passed=True, cases='perfect,anticorrelation,constant_prediction,missing_prediction,constant_truth,negative_truth', target_G_read=False, code_sha256=sha(__file__)))
    print('SYNTHETIC_PASS', flush=True)

def statistics(cohort):
    pr, ar, pf, sf = gate(cohort)
    done = json.loads((ar / 'ANALYSIS_COMPLETE.json').read_text(encoding='utf8'))
    assert done['scores_frozen_sha256'] == sha(sf) and all((sha(p) == h for p, h in done['files'].items()))
    mq = json.loads((A / f'INDEPENDENT_SCORE_METRICS_{cohort}.json').read_text(encoding='utf8'))
    assert mq['passed'] and mq['prediction_freeze_sha256'] == sha(pf) and (mq['scores_freeze_sha256'] == sha(sf))
    path = A / f'independent_metrics_{cohort}.npz'
    assert sha(path) == mq['independent_metrics_sha256']
    with np.load(path, allow_pickle=False) as f:
        arr = {k: f[k] for k in f.files}
    cases = pd.read_csv(D / f'{cohort}_cases.csv', keep_default_na=False, low_memory=False)
    N = len(cases)
    np.testing.assert_array_equal(arr['station_ids'], cases.station_id.to_numpy(str))
    keyidx = {k: i for i, k in enumerate(KEYS)}
    choices = pd.read_csv(D / f'{cohort}_static_choices.csv', keep_default_na=False)
    climate = choices[choices.rule.eq('CLIMATE_NEAREST')].sort_values('row')
    ci = np.load(pr / 'candidate_info.npy', mmap_mode='r')
    masks = {('all', 'all'): np.ones(N, bool), ('input', 'P_available'): arr['P_available'][0].astype(bool), ('input', 'P_unavailable'): ~arr['P_available'][0].astype(bool), ('selection', 'different_static_locations'): ~climate.same_two_rules.to_numpy(bool), ('selection', 'climate_nonfallback'): ~climate.fallback_to_nearest.to_numpy(bool)}
    for dim, col in [('continent', 'continent'), ('climate', 'kg_major')]:
        for s in cases[col].unique():
            masks[dim, s] = cases[col].eq(s).to_numpy()
    summary = pd.read_csv(ar / 'summary_by_stratum.csv', keep_default_na=False, na_values=[''])
    summary_checks = []
    for row in summary.itertuples():
        k = keyidx[row.network, row.method, row.inputs]
        mask = masks[row.dimension, row.stratum]
        valid = mask & arr['evaluable'][k]
        assert row.n == int(mask.sum()) and row.evaluable == int(valid.sum()) and (row.passed == int(arr['pass07'][k, mask].sum()))
        assert row.spatial_cells == cases.loc[mask, 'spatial_cell'].nunique() and row.P_used == int(arr['uses_P'][k, mask].sum())
        vals = {'pass_pct': 100 * np.mean(arr['pass07'][k, mask]) if mask.any() else np.nan, 'pass06_pct': 100 * np.mean(arr['pass06'][k, mask]) if mask.any() else np.nan, 'pass08_pct': 100 * np.mean(arr['pass08'][k, mask]) if mask.any() else np.nan, 'seasonal_numeric_pass_pct': 100 * np.mean(arr['seasonal_pass07'][mask]) if mask.any() else np.nan, 'median_r': np.nanmedian(arr['r'][k, valid]) if valid.any() else np.nan, 'median_anomaly_r': np.nanmedian(arr['anomaly_r'][k, valid]) if valid.any() else np.nan, 'median_NSE': np.nanmedian(arr['NSE'][k, valid]) if valid.any() else np.nan, 'median_abs_alpha_error': np.nanmedian(np.abs(arr['alpha'][k, valid] - 1)) if valid.any() else np.nan, 'median_abs_delta_error': np.nanmedian(np.abs(arr['delta'][k, valid])) if valid.any() else np.nan}
        for name, v in vals.items():
            summary_checks.append(compare([getattr(row, name)], [v], str((row.network, row.method, row.inputs, row.dimension, row.stratum, name))))
    balance = pd.read_csv(ar / 'descriptive_balanced_weightings.csv')
    for row in balance.itertuples():
        k = keyidx[row.network, row.method, row.inputs]
        if row.weighting == 'equal_represented_continents':
            labs = cases.continent
            mask = cases.continent.isin(['Africa', 'Asia', 'Europe', 'NorthAmerica', 'Oceania', 'SouthAmerica']).to_numpy()
        else:
            labs = cases.spatial_cell
            mask = np.ones(N, bool)
        means = [float(np.mean(arr['pass07'][k, mask & labs.eq(s).to_numpy()])) for s in sorted(labs[mask].unique())]
        assert row.units == len(means)
        compare([row.pass_pct], [100 * np.mean(means)], 'balanced ' + str(k))
    cells, globalcode = np.unique(cases.spatial_cell.to_numpy(str), return_inverse=True)
    paired = pd.read_csv(ar / 'paired_spatial_bootstrap.csv', keep_default_na=False, na_values=[''])
    statchecks = []
    cichecks = []
    bootcache = {}
    rounding_signs = []
    for ix, row in enumerate(paired.itertuples()):
        ia = keyidx[row.network, row.method, row.inputs]
        ib = keyidx[row.reference, row.method, row.reference_inputs]
        if row.dimension == 'candidate':
            rule = 0 if row.network.startswith('NEAREST') else 1
            di = [24, 36, 60].index(int(row.network.rsplit('_', 1)[1]))
            cc = ci[:, rule, di]
            mask = (cc[:, 2] >= 24) & (cc[:, 3] >= 2) & (cc[:, 8] == int(cases.L.iloc[0]))
        else:
            mask = masks[row.dimension, row.stratum]
        aa = arr['pass07'][ia].astype(bool)
        bb = arr['pass07'][ib].astype(bool)
        new = int((mask & aa & ~bb).sum())
        lost = int((mask & ~aa & bb).sum())
        assert row.mother_n == mask.sum() and row.new_success == new and (row.lost_success == lost) and (row.new_lost_denominator == 'mother_n')
        pairvalid = mask & arr['evaluable'][ia] & arr['evaluable'][ib]
        assert row.paired_evaluable_n == int(pairvalid.sum())
        delta = arr[row.metric][ia].astype(float) - arr[row.metric][ib].astype(float)
        valid = mask & np.isfinite(delta)
        if row.metric != 'pass07':
            valid &= pairvalid
        assert row.n == int(valid.sum())
        represented = tuple(sorted(set(globalcode[valid].tolist())))
        K = len(represented)
        seed = int(hashlib.sha256(('|' + cohort + '|' + ','.join(map(str, represented))).encode()).hexdigest()[:8], 16)
        assert row.spatial_cells == K and row.bootstrap_seed == seed
        f = 100 if row.metric == 'pass07' else 1
        vals = {'mean_gain': f * np.mean(delta[valid]) if valid.any() else np.nan, 'median_gain': f * np.median(delta[valid]) if valid.any() else np.nan, 'positive_pct': 100 * np.mean(delta[valid] > 0) if valid.any() else np.nan, 'negative_pct': 100 * np.mean(delta[valid] < 0) if valid.any() else np.nan}
        for name, val in vals.items():
            if name in ['positive_pct', 'negative_pct'] and valid.any() and (not np.isclose(getattr(row, name), val, rtol=2e-11, atol=2e-11)):
                signs = np.abs(delta[valid]) < 1e-12
                bound = 100 * signs.sum() / valid.sum()
                assert abs(getattr(row, name) - val) <= bound + 1e-10
                rounding_signs.append(dict(row=ix, metric=row.metric, field=name, production=float(getattr(row, name)), independent=float(val), max_pct_from_tiny_differences=float(bound)))
            else:
                statchecks.append(compare([getattr(row, name)], [val], f'paired{ix} ' + name))
        core = row.contrast in ['one_location_addition', 'rain_added', 'source_withholding'] and row.dimension in ['all', 'continent']
        if not core:
            continue
        if represented:
            if represented not in bootcache:
                bootcache[represented] = np.random.default_rng(seed).multinomial(K, [1 / K] * K, size=2000)
            draw = bootcache[represented]
            numerator = np.array([np.sum(delta[valid & (globalcode == j)]) for j in represented])
            denominator = np.array([np.count_nonzero(valid & (globalcode == j)) for j in represented])
            boot = draw @ numerator / (draw @ denominator)
            lo, hi = f * np.quantile(boot, [0.025, 0.975]) if K >= 5 else [np.nan, np.nan]
        else:
            lo = hi = np.nan
        assert row.CI_status == ('cluster_interval' if K >= 5 else 'too_few_cells_descriptive_only')
        cichecks.append(compare([row.ci025, row.ci975], [lo, hi], f'bootstrap2000 {ix}', atol=2e-09, rtol=2e-09))
    pd.DataFrame(rounding_signs).to_csv(A / f'INDEPENDENT_ZERO_DIFFERENCE_ROUNDOFF_{cohort}.csv', index=False)
    pd.DataFrame(cichecks).to_csv(A / f'INDEPENDENT_BOOTSTRAP_DIFFERENCES_{cohort}.csv', index=False)
    positions = pd.read_csv(ar / 'all_target_candidate_duration_results.csv.gz', keep_default_na=False, na_values=[''], low_memory=False)
    assert len(positions) == N * 6
    for (rule, duration), t in positions.groupby(['rule', 'common_history_months']):
        t = t.sort_values('row')
        choice = choices[choices.rule.eq(rule)].sort_values('row')
        assert t.target_id.tolist() == cases.station_id.tolist() and t.candidate_id.fillna('').tolist() == choice.candidate_id.tolist()
        compare(t.latitude.to_numpy(), pd.to_numeric(choice.latitude, errors='coerce').to_numpy(), 'candidate latitude')
        compare(t.longitude.to_numpy(), pd.to_numeric(choice.longitude, errors='coerce').to_numpy(), 'candidate longitude')
        ia = keyidx[f'{rule}_{duration}', 'ridge', 'QP']
        ib = keyidx['REDUCED', 'ridge', 'QP']
        compare(t.paired_r_gain.to_numpy(), arr['r'][ia] - arr['r'][ib], 'position r gain')
        compare(t.new_pass.to_numpy(), arr['pass07'][ia] & ~arr['pass07'][ib], 'position new pass')
        compare(t.lost_pass.to_numpy(), ~arr['pass07'][ia] & arr['pass07'][ib], 'position lost pass')
    qa = dict(passed=True, cohort=cohort, N=N, all_arm_summary_rows_checked=len(summary), all_paired_rows_point_estimates_and_denominators_checked=len(paired), core_bootstrap_rows_independently_repeated=len(cichecks), bootstrap_replicates=2000, bootstrap_scope='global and all reported continents, addition/rain/withholding, all3 metrics and bothprocessors', coordinate_target_pairs_checked=len(positions), roundoff_only_sign_comparisons=len(rounding_signs), all_primary_success_counts_exact=True, analysis_complete_sha256=sha(ar / 'ANALYSIS_COMPLETE.json'), score_metrics_qa_sha256=sha(A / f'INDEPENDENT_SCORE_METRICS_{cohort}.json'), code_sha256=sha(__file__))
    js(A / f'INDEPENDENT_SCORE_STATISTICS_{cohort}.json', qa)
    print('INDEPENDENT_STATISTICS_PASS', cohort, len(paired), len(cichecks), flush=True)
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('step', choices=['synthetic', 'metrics', 'statistics'])
    ap.add_argument('--cohort', choices=['long120', 'short24'])
    a = ap.parse_args()
    if a.step == 'synthetic':
        synthetic()
    else:
        assert a.cohort
        globals()[a.step](a.cohort)
