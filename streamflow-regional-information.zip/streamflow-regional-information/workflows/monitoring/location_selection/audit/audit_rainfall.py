from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib, time
for k in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[k] = '1'
import numpy as np, pandas as pd
from scipy import sparse
from pyproj import Geod
ROOT = _PROJECT_ROOT / 'workflows/monitoring/location_selection'
I = _PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs'
D = _PROJECT_ROOT / 'workflows/monitoring/location_selection/design'
O = _PROJECT_ROOT / 'workflows/monitoring/location_selection/audit'

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def read(p):
    return pd.read_csv(p, keep_default_na=False, low_memory=False)

def boolean(x):
    return str(x).lower() == 'true'

def main():
    begin = time.time()
    frozen = json.loads((_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/INPUTS_FROZEN.json').read_text(encoding='utf8'))
    for key in ('files', 'source_hashes'):
        for p, h in frozen[key].items():
            assert sha(p) == h, (key, p)
    paths = [Path(p) for p in frozen['source_hashes']]
    byname = {p.name: p for p in paths}
    z = np.load(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/rainfall.npz', allow_pickle=False)
    current = {k: z[k] for k in z.files}
    ledger = read(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/rainfall_ledger.csv')
    ids = current['station_ids'].astype(str)
    lookup = {s: i for i, s in enumerate(ids)}
    assert len(ids) == len(lookup) and list(ids) == ledger.station_id.tolist()
    np.testing.assert_array_equal(current['raw_index'], ledger.raw_index)
    periods = np.array([str(p) for p in pd.period_range('1979-10', '2015-12', freq='M')])
    np.testing.assert_array_equal(current['periods'].astype(str), periods)
    assert str(current['units']) == 'mm/month'
    values = current['precip_mm_month']
    admit = current['admission_mask']
    warn = current['geometry_warning']
    np.testing.assert_array_equal(admit, ledger.admitted_geometry_source.to_numpy(bool))
    np.testing.assert_array_equal(warn, ledger.geometry_warning.to_numpy(bool))
    np.testing.assert_array_equal(warn, current['agency_area_warning'] | current['reach_scope_warning'])
    z = np.load(byname['global8898_tp_197910_201512_ADMITTED.npz'], allow_pickle=False)
    old = {k: z[k] for k in z.files}
    oldcount = 0
    for j, s in enumerate(old['station_ids'].astype(str)):
        i = lookup[s]
        oldcount += 1
        np.testing.assert_array_equal(values[i], old['precip_mm_month'][j])
        for ours, theirs in [('admission_mask', 'admission_mask'), ('geometry_warning', 'geometry_warning_mask'), ('agency_area_warning', 'agency_area_warning_mask'), ('reach_scope_warning', 'reach_scope_warning_mask')]:
            assert bool(current[ours][i]) == bool(old[theirs][j])
        assert ledger.origin.iloc[i] == ('old8898_admitted' if old['admission_mask'][j] else 'old8898_rejected')
    assert oldcount == 8898
    master = np.load(byname['weather_1994_2025.npz'], allow_pickle=False)
    force = np.load(byname['global_catchment_forcing_1994_2025.npz'], allow_pickle=False)
    mr = {s: i for i, s in enumerate(master['station_ids'].astype(str))}
    fr = {s: i for i, s in enumerate(force['station_ids'].astype(str))}
    mk = list(master['variable_names'].astype(str)).index('tp')
    fk = list(force['variable_names'].astype(str)).index('tp')
    assert str(force['units'][fk]) == 'mm/month'
    np.testing.assert_array_equal(force['periods'].astype(str), master['periods'].astype(str))
    assert force['periods'].astype(str).tolist() == [str(p) for p in pd.period_range('1994-01', '2025-12', freq='M')]
    weights = sparse.load_npz(byname['global_catchment_grid_weights.npz']).tocsr()
    assert str(force['weight_sha256']) == sha(byname['global_catchment_grid_weights.npz'])
    assert weights.shape == (len(fr), 1801 * 3600) and np.isfinite(weights.data).all() and (weights.data >= 0).all()
    reg = read(byname['station_registry.csv']).set_index('station_id')
    geo = read(byname['catchment_geometry_audit.csv']).set_index('station_id')
    extra = read(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/extra_master_lineage.csv')
    screen = read(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/additional_source_screen_all.csv')
    added = set(extra.station_id)
    oldids = set(old['station_ids'].astype(str))
    assert not added & oldids
    assert len(screen) == len(ids) - len(oldids)
    mastervalues = master['values'][:, :, mk]
    forcevalues = force['values'][:, :, fk]
    coverage = force['valid_area_fraction'][:, :, fk]
    geod = Geod(ellps='WGS84')
    latlon = pd.concat([read(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/long120_cases.csv'), read(_PROJECT_ROOT / 'workflows/monitoring/location_selection/design/short24_cases.csv')]).drop_duplicates('station_id').set_index('station_id')
    max_distance = 0.0
    min_weight = 1.0
    max_weight = 1.0
    total_masked = 0
    admission_counts = {}
    for s in ids:
        if s in oldids:
            continue
        i = lookup[s]
        available = s in mr and s in fr and (s in reg.index) and (s in geo.index)
        qualify = False
        if available:
            r = reg.loc[s]
            g = geo.loc[s]
            qualify = str(r.forcing_input_origin) == 'original_screened_full_catchment' and str(r.forcing_geometry_status) == 'screened_full_catchment' and (str(g.forcing_geometry_status) == 'screened_full_catchment') and (str(g.reason) == 'source_quality_area_and_outlet_checks_pass')
            if qualify:
                e = latlon.loc[s]
                distance = abs(geod.inv(float(e.longitude), float(e.latitude), float(r.original_gsim_longitude), float(r.original_gsim_latitude))[2])
                qualify = distance <= 10
        assert bool(admit[i]) == qualify, (s, admit[i], qualify)
        assert (s in added) == qualify
        if not qualify:
            assert np.isnan(values[i]).all(), s
            continue
        max_distance = max(max_distance, distance)
        mv = mastervalues[mr[s]]
        fv = forcevalues[fr[s]]
        cv = coverage[fr[s], :264]
        np.testing.assert_array_equal(mv, fv)
        good = np.isfinite(cv) & (cv >= 0.95)
        expected = np.where(good, mv[:264], np.nan).astype(np.float32)
        np.testing.assert_array_equal(values[i, 171:], expected)
        np.testing.assert_array_equal(current['valid_area_fraction_new_master'][i, 171:], cv)
        assert np.isnan(values[i, :171]).all()
        ws = float(weights[fr[s]].astype('float64').sum())
        assert abs(ws - 1) < 3e-06
        min_weight = min(min_weight, ws)
        max_weight = max(max_weight, ws)
        total_masked += int((~good).sum())
        assert current['agency_area_warning'][i] == boolean(r.unresolved_agency_area_signal_after_registered_input_correction)
        assert current['reach_scope_warning'][i] == boolean(r.baseline_reach_scope_review_signal)
        assert ledger.origin.iloc[i] == 'master_original_screened_full_catchment'
    for name in ['long120', 'short24']:
        cases = read(D / f'{name}_cases.csv')
        tab = read(I / f'{name}_rainfall_admission.csv')
        assert len(cases) == len(tab)
        for e in cases.itertuples():
            i = lookup[e.station_id]
            row = tab.iloc[e.row]
            assert row.station_id == e.station_id and int(row.rain_row) == i
            dates = np.arange(int(e.history_start), int(e.gap_end) + 3)
            v = values[i, dates]
            assert len(v) == 60 + int(e.L) + 3
            complete = np.isfinite(v).all() and (v >= 0).all()
            assert bool(row.complete_required_window) == complete
            assert bool(row.available) == bool(admit[i] and complete)
            assert json.loads(row.missing_required_months) == periods[dates[~np.isfinite(v)]].tolist()
            assert row.required_start == periods[dates[0]] and row.required_end == periods[dates[-1]]
        admission_counts[name] = {'targets': len(cases), 'rain_available': int(tab.available.sum()), 'geometry_admitted': int(tab.admitted.sum()), 'new_master_available': int((tab.available & tab.origin.eq('master_original_screened_full_catchment')).sum()), 'warnings_available': int((tab.available & tab.geometry_warning).sum())}
    report = {'passed': True, 'scope': 'Every frozen rainfall source, reused/added value, geometry admission, weight lineage and all case windows independently replayed', 'unique_target_ids': len(ids), 'old8898_exact_rows': oldcount, 'new_master_rows': len(extra), 'new_master_low_coverage_months_masked': total_masked, 'max_new_outlet_distance_m': max_distance, 'new_weight_row_sum_range': [min_weight, max_weight], 'cohorts': admission_counts, 'target_streamflow_or_scores_read': False, 'units_verified': 'mm/month', 'rain_freeze_sha256': sha(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/INPUTS_FROZEN.json'), 'input_freeze_sha256': sha(_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/INPUTS_FROZEN.json'), 'audit_script_sha256': sha(__file__), 'seconds': time.time() - begin}
    (_PROJECT_ROOT / 'workflows/monitoring/location_selection/audit/RAINFALL_INDEPENDENT_QA.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    (_PROJECT_ROOT / 'workflows/monitoring/location_selection/inputs/RAINFALL_INDEPENDENT_QA.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
