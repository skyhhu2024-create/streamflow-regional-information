"""Prospective source-position replay; build all predictions before scoring.

New sources are verified physical locations absent from the frozen GSIM
catalogue. No target G values, scores, or G-dependent site selection are used.
"""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
import os, sys, json, hashlib, importlib.util, argparse, time, warnings
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
sys.dont_write_bytecode = True
HERE = _PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_source'
ROOT = _PROJECT_ROOT / 'workflows/monitoring/external_locations'
CODE = _PROJECT_ROOT
pass
PREV = _PROJECT_ROOT / 'workflows/rainfall/global_inputs'
pass
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from concurrent.futures import ProcessPoolExecutor
import workflows.rainfall.global_inputs.design_review.transfer_model as M
R3 = _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage'
spec = importlib.util.spec_from_file_location('r3_core', _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/run_outage.py')
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)
OLD = C.OLD
ID = _PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified'
OUT = _PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions'
ARMS = ['STRICT_BASE', 'FULL_BASE', 'STRICT_H24', 'STRICT_H36', 'STRICT_H60', 'BRIDGE_H24', 'BRIDGE_H36', 'BRIDGE_H60', 'FULL_H24', 'FULL_H36', 'FULL_H60']
METHODS = ['ridge', 'rbf_ridge']
N = 8898
OFFSET = 40000
G = {}

def verify(path, base=None):
    d = json.loads(Path(path).read_text(encoding='utf8'))
    for p, h in d['files'].items():
        pp = Path(p) if Path(p).is_absolute() else Path(base or Path(path).parent) / p
        assert C.sha(pp) == (h['sha256'] if isinstance(h, dict) else h), str(pp)
    return d

def anchored_rank(old, values, descending=False):
    x = -np.asarray(old) if descending else np.asarray(old)
    v = -np.asarray(values) if descending else np.asarray(values)
    s = np.sort(x)
    return (np.searchsorted(s, v, side='left') + np.searchsorted(s, v, side='right')) * 0.5 + 0.5

def init():
    warnings.filterwarnings('ignore', category=RuntimeWarning)
    C.init()
    G['cases'] = pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/cases.csv')
    a = np.load(_PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/candidate_values.npz', allow_pickle=False)
    G['sites'] = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/candidate_sources.csv', dtype={'grdc_id': str})
    assert np.array_equal(a['grdc_ids'].astype(str), G['sites'].grdc_id.to_numpy(str))
    G['ext'] = np.asarray(a['Q_m3s'], float)
    assert G['ext'].shape == (len(G['sites']), 432)
    G['efold'] = G['sites'].outer_fold.to_numpy(int)
    assert np.all(~np.isfinite(G['ext']) | (G['ext'] >= 0))
    assert (G['sites'].identity_evidence_grade == 'A_CATALOGUE_CORROBORATED_DISTINCT').all()
    assert (G['sites'].all_same_station_exclusion_ids.map(json.loads).map(len) == 0).all()
    G['eids'] = OFFSET + np.arange(len(G['sites']))
    G['raw'] = C.G['source_raw']
    G['allQ'] = np.asarray(C.G['Q'][G['raw']])
    G['oldmeta'] = C.G['meta'].iloc[G['raw']]
    G['oldfold'] = G['oldmeta'].outer_fold.to_numpy(int)
    G['p'] = np.load(_PROJECT_ROOT / 'workflows/rainfall/global_inputs/prepared_inputs/PRECIPITATION_H_ONLY_INPUTS.npz')
    for key in ('target_Hz', 'target_H_log_calendar', 'target_H_anomaly_sd', 'target_H_raw_calendar', 'input_meta'):
        G[key] = np.load(_PROJECT_ROOT / 'workflows/rainfall/global_inputs/prepared_inputs' / (key + '.npy'), mmap_mode='r')
    G['oldcomp'] = np.load(_PROJECT_ROOT / 'workflows/rainfall/global_inputs/prepared_inputs/composites.npy', mmap_mode='r')
    G['oldids'] = np.load(_PROJECT_ROOT / 'workflows/rainfall/global_inputs/prepared_inputs/source_ids_HG.npy', mmap_mode='r')
    G['oldpred'] = np.load(_PROJECT_ROOT / 'workflows/rainfall/global_inputs/predictions/predictions.npy', mmap_mode='r')
    G['oldsup'] = np.load(_PROJECT_ROOT / 'workflows/rainfall/global_inputs/predictions/support.npy', mmap_mode='r')
    G['oldfit'] = np.load(_PROJECT_ROOT / 'workflows/rainfall/global_inputs/predictions/flags.npy', mmap_mode='r')
    meta = C.G['meta']
    lookup = {s: i for i, s in enumerate(meta.station_id.astype(str))}
    adj = {}
    tw = pd.read_csv(_PROJECT_ROOT / 'data/gsim_near_duplicates_checked.csv')
    for e in tw[tw.twin.astype(str).str.lower().eq('true')].itertuples():
        if e.a in lookup and e.b in lookup:
            a, b = (lookup[e.a], lookup[e.b])
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
    G['aliases'] = {}
    for root in adj:
        seen = {root}
        todo = [root]
        while todo:
            for nxt in adj.get(todo.pop(), ()):
                if nxt not in seen:
                    seen.add(nxt)
                    todo.append(nxt)
        G['aliases'][root] = seen

def distance(lat, lon, lats, lons):
    a, b = np.deg2rad([lat, lon])
    c, d = (np.deg2rad(lats), np.deg2rad(lons))
    return 6371 * 2 * np.arcsin(np.sqrt(np.clip(np.sin((c - a) / 2) ** 2 + np.cos(a) * np.cos(c) * np.sin((d - b) / 2) ** 2, 0, 1)))

def join_order(oldq, oldr, oldd, extq, er, ed):
    rr = rankdata(-oldr[oldq], method='average')
    dd = rankdata(oldd[oldq], method='average')
    if len(oldq):
        xr = anchored_rank(oldr[oldq], er[extq], True)
        xd = anchored_rank(oldd[oldq], ed[extq])
    else:
        xr = rankdata(-er[extq])
        xd = rankdata(ed[extq])
    idx = np.r_[oldq, len(oldr) + extq]
    raw = np.r_[G['raw'][oldq], G['eids'][extq]]
    rrank = np.r_[rr, xr]
    score = np.r_[rr + dd, xr + xd]
    return idx[np.lexsort((raw, rrank, score))]

def combine(order, r, cl, sd, months, enable, skip=-1):
    no = len(G['raw'])
    n = len(months)
    cnt = np.zeros(n, np.int8)
    num = np.zeros(n)
    den = np.zeros(n)
    ids = np.full((n, 4), -1, np.int32)
    for j in order:
        external = j >= no
        ei = j - no
        sid = int(G['eids'][ei]) if external else int(G['raw'][j])
        if sid == skip:
            continue
        raw = G['ext'][ei, months] if external else G['allQ'][j, months]
        ok = np.isfinite(raw) & (raw >= 0) & np.isfinite(cl[j, months % 12]) & (cnt < 4)
        if external:
            ok &= months >= enable
        if ok.any():
            p = np.flatnonzero(ok)
            z = (np.log1p(raw[p]) - cl[j, months[p] % 12]) / sd[j]
            ids[p, cnt[p]] = sid
            cnt[p] += 1
            num[p] += r[j] * z
            den[p] += r[j]
        if (cnt == 4).all():
            break
    return (np.divide(num, den, out=np.full(n, np.nan), where=den > 0), cnt, ids)

def fit(i, comp, training, g):
    """Same fixed processors and P fallback as the frozen QP experiment."""
    tz = G['target_Hz'][i]
    est = bool(G['input_meta'][i, 4])
    p = G['p']
    ph, pg = (p['p_h'][i], p['p_g'][i])
    hasp = bool(p['p_available'][i])
    xh = comp[:60, None]
    xg = comp[60:, None]
    pp = np.full((2, 120), np.nan)
    sup = np.zeros((2, 120), bool)
    fits = np.zeros(2, bool)
    tc = G['target_H_log_calendar'][i]
    sd = G['target_H_anomaly_sd'][i]
    baseline = G['target_H_raw_calendar'][i, g % 12]
    for mi, m in enumerate(METHODS):
        q, reason = M.fit_transfer(xh[training], tz[training], method=m, target_estimable=est)
        model = q
        xx = xg
        if hasp:
            model, _ = M.fit_transfer(np.column_stack([xh, ph])[training], tz[training], method=m, target_estimable=est)
            if model is not None:
                xx = np.column_stack([xg, pg])
            else:
                model = q
        fits[mi] = model is not None
        zz = model.predict(xx) if fits[mi] else np.full(120, np.nan)
        pp[mi], sup[mi] = C.transfer(zz, tz, tc, sd, g, baseline, fits[mi])
    return (pp, sup, fits)

def work(i):
    e = G['cases'].iloc[i]
    raw = int(e.raw_index)
    h = np.arange(int(e.history_start), int(e.history_end))
    g = np.arange(int(e.gap_start), int(e.gap_end))
    mm = np.r_[h, g]
    tz = G['target_Hz'][i]
    cl, sd, zh = C.prep(G['allQ'][:, h], h)
    n, r = C.relation(zh, tz)
    od = distance(float(e.latitude), float(e.longitude), G['oldmeta'].latitude.to_numpy(float), G['oldmeta'].longitude.to_numpy(float))
    ed = distance(float(e.latitude), float(e.longitude), G['sites'].latitude.to_numpy(float), G['sites'].longitude.to_numpy(float))
    same = np.isin(G['raw'], list(G['aliases'].get(raw, {raw})))
    basic = np.isfinite(r) & (r > 0) & np.isfinite(sd) & ~same
    qfull = np.flatnonzero(basic)
    qstrict = np.flatnonzero(basic & (G['oldfold'] != int(e.outer_fold)))
    orders = {p: join_order(q, r, od, np.empty(0, int), np.empty(0), np.empty(0)) for p, q in [('STRICT', qstrict), ('FULL', qfull)]}
    comps = np.full((11, 180), np.nan)
    counts = np.zeros((11, 180), np.int8)
    ids = np.full((11, 180, 4), -1, np.int32)
    pred = np.full((11, 2, 120), np.nan)
    sup = np.zeros((11, 2, 120), bool)
    fits = np.zeros((11, 2), bool)
    masks = np.zeros((11, 60), bool)
    quals = np.zeros((3, len(G['sites'])), bool)
    er_out = np.full((3, len(G['sites'])), np.nan)
    nn_out = np.zeros((3, len(G['sites'])), np.int8)
    qameta = []
    abrec = []
    abp = []
    absup = []
    abfit = []
    for a, p in [(0, 'STRICT'), (1, 'FULL')]:
        comps[a], counts[a], ids[a] = combine(orders[p], r, cl, sd, mm, 9999)
        masks[a] = np.isfinite(tz) & np.isfinite(comps[a, :60])
        pred[a], sup[a], fits[a] = fit(i, comps[a], masks[a], g)
    np.testing.assert_allclose(comps[0], G['oldcomp'][i, 0], rtol=0, atol=0, equal_nan=True)
    assert np.array_equal(ids[0], G['oldids'][i, 0])
    np.testing.assert_allclose(pred[0], G['oldpred'][i, :, 1], rtol=0, atol=0, equal_nan=True)
    assert np.array_equal(sup[0], G['oldsup'][i, :, 1]) and np.array_equal(fits[0], G['oldfit'][i, :, 1, 0])
    for li, L in enumerate((24, 36, 60)):
        hh = h[-L:]
        eh = G['ext'][:, hh]
        ec, es, ez = C.prep(eh, hh)
        zz = np.full((len(G['sites']), 60), np.nan)
        zz[:, -L:] = ez
        en, er = C.relation(zz, tz)
        monthcounts = np.stack([np.isfinite(eh[:, hh % 12 == m]).sum(1) for m in range(12)], axis=1)
        good = (en >= 24) & (monthcounts >= 2).all(1) & np.isfinite(er) & (er > 0) & np.isfinite(es) & np.isfinite(ec).all(1)
        quals[li] = good
        er_out[li] = er
        nn_out[li] = en
        rr = np.r_[r, er]
        cc = np.r_[cl, ec]
        ss = np.r_[sd, es]
        for pi, p in enumerate(('STRICT', 'BRIDGE', 'FULL')):
            a = 2 + 3 * pi + li
            b = 1 if p == 'FULL' else 0
            q = qfull if p == 'FULL' else qstrict
            eg = good & (G['efold'] != int(e.outer_fold)) if p == 'STRICT' else good
            eq = np.flatnonzero(eg)
            order = join_order(q, r, od, eq, er, ed)
            comps[a], counts[a], ids[a] = combine(order, rr, cc, ss, mm, int(hh[0]))
            assert np.all(counts[a] >= counts[b])
            masks[a] = np.isfinite(tz) & np.isfinite(comps[a, :60])
            assert np.all(~masks[b] | masks[a])
            masks[a] = masks[b]
            pred[a], sup[a], fits[a] = fit(i, comps[a], masks[a], g)
            used = np.unique(ids[a][ids[a] >= OFFSET])
            early = mm < int(hh[0])
            assert not (ids[a, early] >= OFFSET).any()
            if not len(used):
                np.testing.assert_allclose(comps[a], comps[b], rtol=0, atol=0, equal_nan=True)
                np.testing.assert_allclose(pred[a], pred[b], rtol=0, atol=0, equal_nan=True)
            assert not np.isin(ids[a], list(G['aliases'].get(raw, {raw}))).any()
            if p == 'STRICT' and len(used):
                assert (G['efold'][used - OFFSET] != int(e.outer_fold)).all()
            qameta.append(dict(row=i, arm=ARMS[a], new_H_months=L, qualified_new=len(eq), used_new=len(used), new_H_slots=int((ids[a, :60] >= OFFSET).sum()), new_G_slots=int((ids[a, 60:] >= OFFSET).sum()), changed_H_months=int(np.any(ids[a, :60] != ids[b, :60], axis=1).sum()), changed_G_months=int(np.any(ids[a, 60:] != ids[b, 60:], axis=1).sum()), same_cell_new_G_slots=int(sum((np.sum(ids[a, 60:] == u) for u in used if str(G['sites'].spatial_cell.iloc[u - OFFSET]) == str(e.spatial_cell))))))
            if p != 'BRIDGE':
                for u in used:
                    ac, acn, acid = combine(order, rr, cc, ss, mm, int(hh[0]), skip=int(u))
                    assert np.all(np.isfinite(ac[:60])[masks[b]])
                    ap, asu, af = fit(i, ac, masks[b], g)
                    abrec.append(dict(row=i, arm=ARMS[a], arm_index=a, new_H_months=L, physical_source_id=str(G['sites'].grdc_id.iloc[u - OFFSET]), source_internal_id=int(u), selected_H_months=int(np.any(ids[a, :60] == u, axis=1).sum()), selected_G_months=int(np.any(ids[a, 60:] == u, axis=1).sum()), removed_source_remaining_slots=int(np.sum(acid == u))))
                    abp.append(ap)
                    absup.append(asu)
                    abfit.append(af)
    tmp = _PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/case_cache' / f'{i:05d}.npz'
    np.savez_compressed(tmp, composites=comps, counts=counts, selected_ids=ids, predictions=pred, support=sup, fit_estimable=fits, training_mask=masks, qualified_external=quals, external_r=er_out, external_pairs=nn_out, ablation_predictions=np.array(abp).reshape(-1, 2, 120), ablation_support=np.array(absup, dtype=bool).reshape(-1, 2, 120), ablation_fit=np.array(abfit, dtype=bool).reshape(-1, 2), ablation_records=np.array([json.dumps(x) for x in abrec], dtype=str), input_records=np.array([json.dumps(x) for x in qameta], dtype=str))
    return (i, len(abrec))

def synthetic():
    x = np.array([0.1, 0.1, 0.3, 0.7])
    np.testing.assert_array_equal(anchored_rank(x, x), rankdata(x))
    np.testing.assert_array_equal(anchored_rank(x, x, True), rankdata(-x))
    assert anchored_rank(x, np.array([0.05, 0.8])).tolist() == [0.5, 4.5]
    C.js(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_source/SYNTHETIC_CHECKS.json', dict(passed=True, checks=['old_value_average_tie_rank_exact', 'new_between_level_rank', 'no_G_read']))

def register():
    assert not (_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/PREDICTIONS_FROZEN.json').exists()
    iq = json.loads((_PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/INDEPENDENT_INTERFACE_QA.json').read_text(encoding='utf8'))
    assert iq['status'].startswith('PASS_') and iq['raw_value_matrix_replay_exact']
    im = json.loads((_PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/DELIVERY_MANIFEST.json').read_text(encoding='utf8'))
    assert all((C.sha(ID / p) == h for p, h in im.items()))
    syn = json.loads((_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_source/SYNTHETIC_CHECKS.json').read_text())
    assert syn['passed']
    p = dict(N=N, H=60, G=120, arms=ARMS, methods=METHODS, common_new_history_months=[24, 36, 60], purpose='Verified external physical locations as historical analogues of added monitoring. Not contemporary engineering siting or global optimum.', candidates='All identity-admitted candidates, fixed before any new target G scoring. Whole8898 targets retained; no target-G skill to pick sites or periods.', policies={'STRICT': 'Original GSIM fold-isolated source domain; new physical sites also fold-isolated.', 'BRIDGE': 'Original GSIM fold-isolated domain plus all independently verified external sites; identifies external proximity effect under original source isolation.', 'FULL': 'All original24734 GSIM QC candidates, explicit target and entire known physical twin component excluded; plus all independently verified external sites. Operational source configuration, not old spatially independent test.'}, comparisons='STRICT and BRIDGE compare STRICT_BASE; FULL compares FULL_BASE. FULL_BASE minus STRICT_BASE is existing source-domain change, not new-station benefit.', new_H='New station invisible before H end minus24/36/60. New log1p calendarmean/anomalySD and target-H anomaly r from that shared period only; require>=24 paired months and>=2 values for every calendar month, positive r and finite SD. No G truth in selection.', old_H='Target and old GSIM transforms remain fixed original H60. New-source G synchronous values only; actual missing reports remain missing.', selection='Anchor old-qualified r and distance average ranks. New-source rank=count(old strictly better)+0.5*count(old equal)+0.5. Merge by summed ranks,r rank,stable source ID. Old relative order never changes; no used new source means exact baseline.', model='Original monthly positive-r weighted K4 composite, unchanged dimension. Fixed ridge lambda.1 and fixed RBF sensitivity. Same old baseline H training rows in every common-history arm; H domain cannot shrink. Admitted P retained; no new precipitation changes.', guard='Identical old logQ inverse/clip and seasonal fallback. Failed fits, missing inputs and negative outcomes remain in the mother denominator.', attribution='For STRICT/FULL at every duration, remove each actually selected new physical site individually and rebuild/refit under fixed H rules. Conditional contribution in the new network, not standalone deployment gain; contributions are not additive. Unselected sources provably zero under anchored ranks.', duration='Earliest tested24/36/60 level showing benefit; report later reversals. Does not prove exact continuous minimum or guaranteed local future outcome.', inference='Raw monthly r>.7 with support+estimability; .6/.8, H-deseasonal r and alpha/delta auxiliary.2000 spatial-cluster bootstrap, new/lost passes. All-region counts reflect coverage, not population estimates.', freeze='All predictions and leave-one-source-out products frozen then independent pre-score QA. No new tuning based on G. Previously used G periods are retrospective tests, not new blind evidence.')
    C.js(_PROJECT_ROOT / 'workflows/monitoring/external_locations/TRIAL_PROTOCOL.json', p)
    files = [_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_source/run_trial.py', _PROJECT_ROOT / 'workflows/monitoring/external_locations/TRIAL_PROTOCOL.json', _PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_source/SYNTHETIC_CHECKS.json', _PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/DELIVERY_MANIFEST.json', _PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/INDEPENDENT_INTERFACE_QA.json', _PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/candidate_sources.csv', _PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/candidate_values.npz', _PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/BASELINE_INPUT_REUSE_QA.json', _PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/BASELINE_REUSE_INDEX.csv', _PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/analyze_observation_trial.py', _PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/trial_score_core.py', _PROJECT_ROOT / 'workflows/rainfall/global_inputs/design_review/transfer_model.py', _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/run_outage.py', _PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/cases.csv', _PROJECT_ROOT / 'data/gsim_near_duplicates_checked.csv', _PROJECT_ROOT / 'workflows/rainfall/global_inputs/prepared_inputs/COMPOSITES_FROZEN.json', _PROJECT_ROOT / 'workflows/rainfall/global_inputs/prepared_inputs/PRECIPITATION_PREPARED.json', _PROJECT_ROOT / 'workflows/rainfall/global_inputs/predictions/PREDICTIONS_FROZEN.json', OLD / 'predictions/source_cache/source_raw_indices.npy', OLD / 'global_data/QC20_Q.npy', OLD / 'design/all_station_roles.csv']
    C.js(_PROJECT_ROOT / 'workflows/monitoring/external_locations/TRIAL_CODE_INPUTS_FROZEN.json', dict(files={str(p): C.sha(p) for p in files}, target_G_scored=False))
    print('REGISTERED_POSITION_DURATION_TRIAL', flush=True)

def produce(workers=4, limit=None):
    verify(_PROJECT_ROOT / 'workflows/monitoring/external_locations/TRIAL_CODE_INPUTS_FROZEN.json')
    OUT.mkdir(exist_ok=True)
    (_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/case_cache').mkdir(exist_ok=True)
    assert not (_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/PREDICTIONS_FROZEN.json').exists()
    jobs = [i for i in range(N if limit is None else limit) if not (_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/case_cache' / f'{i:05d}.npz').exists()]
    st = time.time()
    with ProcessPoolExecutor(max_workers=workers, initializer=init) as pool:
        for c, (i, k) in enumerate(pool.map(work, jobs, chunksize=2), 1):
            if c % 100 == 0 or c == len(jobs):
                print(f'Position trial {c}/{len(jobs)}, row={i}, ablations={k}, seconds={time.time() - st:.1f}', flush=True)

def assemble():
    verify(_PROJECT_ROOT / 'workflows/monitoring/external_locations/TRIAL_CODE_INPUTS_FROZEN.json')
    assert not (_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/PREDICTIONS_FROZEN.json').exists()
    shapes = {'composites': ((N, 11, 180), 'float64'), 'counts': ((N, 11, 180), 'int8'), 'selected_ids': ((N, 11, 180, 4), 'int32'), 'predictions': ((N, 11, 2, 120), 'float64'), 'support': ((N, 11, 2, 120), 'bool'), 'fit_estimable': ((N, 11, 2), 'bool'), 'training_mask': ((N, 11, 60), 'bool')}
    arr = {k: np.lib.format.open_memmap(OUT / (k + '.npy'), mode='w+', shape=sh, dtype=dt) for k, (sh, dt) in shapes.items()}
    inp = []
    abl = []
    ap = []
    asu = []
    af = []
    for i in range(N):
        z = np.load(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/case_cache' / f'{i:05d}.npz', allow_pickle=False)
        for k in arr:
            arr[k][i] = z[k]
        inp.extend((json.loads(x) for x in z['input_records']))
        for x in z['ablation_records']:
            r = json.loads(x)
            r['ablation_index'] = len(abl)
            abl.append(r)
        if len(z['ablation_records']):
            ap.append(z['ablation_predictions'])
            asu.append(z['ablation_support'])
            af.append(z['ablation_fit'])
    for a in arr.values():
        a.flush()
    pd.DataFrame(inp).to_csv(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/input_changes.csv', index=False)
    pd.DataFrame(abl).to_csv(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/ablation_index.csv', index=False)
    np.save(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/ablation_predictions.npy', np.concatenate(ap) if ap else np.empty((0, 2, 120)))
    np.save(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/ablation_support.npy', np.concatenate(asu) if asu else np.empty((0, 2, 120), bool))
    np.save(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/ablation_fit_estimable.npy', np.concatenate(af) if af else np.empty((0, 2), bool))
    pd.read_csv(_PROJECT_ROOT / 'workflows/regional_dependence/conditional_support/source_outage/cases.csv').to_csv(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/cases.csv', index=False)
    pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/candidate_sources.csv').to_csv(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/physical_locations.csv', index=False)
    C.js(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/SCORING_INTERFACE.json', dict(N=N, G=120, H=60, arms=ARMS, methods=METHODS, predictions='predictions.npy', support='support.npy', fit_estimable='fit_estimable.npy', training_mask='training_mask.npy', cases_file=str(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/cases.csv'), code_freeze_file=str(_PROJECT_ROOT / 'workflows/monitoring/external_locations/TRIAL_CODE_INPUTS_FROZEN.json'), ablation_index='ablation_index.csv', ablation_predictions='ablation_predictions.npy', ablation_support='ablation_support.npy', ablation_fit_estimable='ablation_fit_estimable.npy', input_changes='input_changes.csv', physical_source_id_meaning='GRDC official ID; internal selected ID=40000+row of physical_locations', attribution='Paired current new-network minus rebuilt/refitted network with one used source removed. Conditional, not additive and not single-station addition.'))
    files = [p for p in OUT.iterdir() if p.is_file()]
    C.js(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/PREDICTIONS_FROZEN.json', dict(status='ALL8898_LOCATION_DURATION_PREDICTIONS_AND_LOSO_BEFORE_NEW_SCORING', methods=METHODS, arms=ARMS, ablation_pairs=len(abl), code_freeze_sha256=C.sha(_PROJECT_ROOT / 'workflows/monitoring/external_locations/TRIAL_CODE_INPUTS_FROZEN.json'), files={p.name: C.sha(p) for p in files}))
    print(f'PREDICTIONS_FROZEN: {N} targets, {len(abl)} source-removal pairs', flush=True)
if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('step', choices=['synthetic', 'register', 'produce', 'assemble'])
    p.add_argument('--workers', type=int, default=4)
    p.add_argument('--limit', type=int)
    a = p.parse_args()
    if a.step == 'produce':
        produce(a.workers, a.limit)
    else:
        globals()[a.step]()
