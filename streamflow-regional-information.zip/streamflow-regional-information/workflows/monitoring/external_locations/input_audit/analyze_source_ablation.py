"""Score frozen leave-one-new-source-out predictions only after release.

Conditional contribution is current-network minus rebuilt/refitted network
without that source. It is NOT standalone site-deployment benefit and cannot
be summed across sources. No source/arm selection or fitting occurs here.
"""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
from datetime import datetime, timezone
import argparse, json, sys
sys.dont_write_bytecode = True
import workflows.monitoring.external_locations.input_audit.analyze_observation_trial as A
from workflows.monitoring.external_locations.input_audit.trial_score_core import metrics, paired, transition, synthetic_checks
import numpy as np
import pandas as pd
HERE = A.HERE
ROOT = A.ROOT
PRED = A.PRED
OUT = ROOT / 'source_contribution_analysis'
POLICIES = ['STRICT', 'FULL']
DURATIONS = [24, 36, 60]
OFFSET = 40000
GAIN = [('r', 1), ('H_deseasonal_r', 1), ('absolute_alpha_error', -1), ('absolute_delta_error', -1), ('NSE', 1)]

def guard(authorized):
    spec, freeze, qa = A.guard(authorized)
    assert qa.get('loso_scoring_code_sha256') == A.sha(__file__), 'Independent QA must freeze this LOSO scorer.'
    listed = {str(A.resolve(p, PRED).resolve()) for p in freeze['files']}
    for key in ['ablation_index', 'ablation_predictions', 'ablation_support', 'ablation_fit_estimable']:
        assert str(A.resolve(spec[key], PRED).resolve()) in listed
    complete = A.read(A.OUT / 'ANALYSIS_COMPLETE.json')
    assert complete['status'] == 'COMPLETE_FIXED8898_OBSERVATION_LOCATION_TRIAL'
    auth = A.read(A.OUT / 'SCORING_AUTHORIZATION.json')
    assert auth['prediction_freeze_sha256'] == A.sha(PRED / 'PREDICTIONS_FROZEN.json')
    entry = complete['output_files']['scores_long.csv.gz']
    assert A.sha(A.OUT / 'scores_long.csv.gz') == entry['sha256']
    return (spec, freeze, qa)

def zero_fill_gains(main, marginal, metric, direction):
    val = np.zeros(A.N, float)
    eligible = A.truth(main.eligible).copy()
    if len(marginal):
        row = marginal.row.to_numpy(int)
        val[row] = direction * (marginal[metric + '_new'].to_numpy() - marginal[metric + '_without'].to_numpy())
        eligible[row] = A.truth(marginal.eligible_new) & A.truth(marginal.eligible_without)
    return (val, eligible)

def summarize_duration(site):
    records = []
    for (sid, policy, method), g in site.groupby(['physical_source_id', 'policy', 'method'], sort=False):
        g = g.set_index('new_H_months').reindex(DURATIONS)
        nets = g.net_conditional_r07.to_numpy(float)
        means = g.r_mean_gain_all_mothers.to_numpy(float)
        good = np.isfinite(nets) & (nets > 0)
        pos = np.isfinite(means) & (means > 1e-12)
        first = int(np.flatnonzero(good)[0]) if good.any() else None
        records.append(dict(physical_source_id=sid, policy=policy, method=method, earliest_tested_H_with_positive_net_r07=DURATIONS[first] if first is not None else None, earliest_tested_H_with_positive_mean_r=DURATIONS[np.flatnonzero(pos)[0]] if pos.any() else None, later_negative_net_r07_after_first_gain=bool((nets[first + 1:] < 0).any()) if first is not None else False, net_conditional_r07_H24=nets[0], net_conditional_r07_H36=nets[1], net_conditional_r07_H60=nets[2], mean_r_gain_H24=means[0], mean_r_gain_H36=means[1], mean_r_gain_H60=means[2], net_r07_non_decreasing_over_tested_durations=bool(np.isfinite(nets).all() and (np.diff(nets) >= 0).all()), interpretation='Earliest positive TESTED common-history condition, not a guaranteed or exact minimum.'))
    return pd.DataFrame(records)

def synthetic_loso_checks():
    result = synthetic_checks()
    main = pd.DataFrame({'eligible': np.ones(A.N, bool)})
    marginal = pd.DataFrame({'row': [1, 2], 'r_new': [0.8, 0.5], 'r_without': [0.7, 0.6], 'eligible_new': [True, True], 'eligible_without': [True, False]})
    gain, eligible = zero_fill_gains(main, marginal, 'r', 1)
    assert np.isclose(gain[1], 0.1) and np.isclose(gain[2], -0.1)
    assert np.count_nonzero(gain) == 2 and (not eligible[2]) and eligible[0]
    site = pd.DataFrame([dict(physical_source_id='synthetic_source', policy='STRICT', method='ridge', new_H_months=h, net_conditional_r07=n, r_mean_gain_all_mothers=v) for h, n, v in [(24, 1, 0.01), (36, 2, 0.02), (60, -1, -0.01)]])
    stable = summarize_duration(site).iloc[0]
    assert stable.earliest_tested_H_with_positive_net_r07 == 24
    assert stable.later_negative_net_r07_after_first_gain
    assert not stable.net_r07_non_decreasing_over_tested_durations
    result['checks'] += ['unused source is zero deletion effect', 'selected unevaluable effect remains excluded from continuous statistics', 'later negative duration reversals retained', 'earliest tested duration not continuous minimum']
    result['loso_scoring_code_sha256'] = A.sha(__file__)
    return result

def run(authorized=False):
    spec, freeze, qa = guard(authorized)
    assert not (OUT / 'ABLATION_ANALYSIS_COMPLETE.json').exists(), 'Do not overwrite completed attribution.'
    OUT.mkdir(exist_ok=True)
    A.save(OUT / 'SCORING_AUTHORIZATION.json', dict(created_at_utc=datetime.now(timezone.utc).isoformat(), prediction_freeze_sha256=A.sha(PRED / 'PREDICTIONS_FROZEN.json'), pre_score_QA_sha256=A.sha(HERE / 'PRE_SCORING_QA_PASS.json'), script_sha256=A.sha(__file__), scientific_estimand='Current-network minus fixed-rules source-removal replay, refit on same H rows.', standalone_deployment_effect=False, additive_site_benefits=False))
    cases = pd.read_csv(A.resolve(spec['cases_file'], ROOT))
    loc = pd.read_csv(PRED / 'physical_locations.csv', dtype={'grdc_id': str})
    assert len(cases) == A.N and loc.grdc_id.is_unique
    index = pd.read_csv(A.resolve(spec['ablation_index'], PRED), dtype={'physical_source_id': str})
    assert np.array_equal(index.ablation_index, np.arange(len(index)))
    assert not index.duplicated(['row', 'arm', 'physical_source_id']).any()
    assert index.removed_source_remaining_slots.eq(0).all()
    assert np.array_equal(index.physical_source_id, loc.grdc_id.to_numpy()[index.source_internal_id.to_numpy(int) - OFFSET])
    for r in index.itertuples():
        assert r.arm == A.ARMS[r.arm_index] and r.arm.split('_')[0] in POLICIES
        assert r.new_H_months in DURATIONS and r.arm.endswith(f'H{r.new_H_months}')
    p = np.load(A.resolve(spec['ablation_predictions'], PRED), mmap_mode='r')
    support = np.load(A.resolve(spec['ablation_support'], PRED), mmap_mode='r')
    fit = np.load(A.resolve(spec['ablation_fit_estimable'], PRED), mmap_mode='r')
    assert p.shape == support.shape == (len(index), 2, 120) and fit.shape == (len(index), 2)
    scores = pd.read_csv(A.OUT / 'scores_long.csv.gz', low_memory=False)
    models = {(m, a): g.sort_values('row').reset_index(drop=True) for (m, a), g in scores.groupby(['method', 'arm'])}
    q = np.load(A.OLD / 'global_data/QC20_Q.npy', mmap_mode='r')
    target = np.stack([q[int(e.raw_index), int(e.gap_start):int(e.gap_end)] for e in cases.itertuples()])
    cal = np.load(A.PREV / 'prepared_inputs/target_H_raw_calendar.npy')
    seasonal = cal[np.arange(A.N)[:, None], (cases.gap_start.to_numpy()[:, None] + np.arange(120)) % 12]
    rows = index.row.to_numpy(int)
    frames = []
    for mi, method in enumerate(A.METHODS):
        chunks = []
        for begin in range(0, len(index), 2000):
            end = min(begin + 2000, len(index))
            rr = rows[begin:end]
            chunks.append(pd.DataFrame(metrics(target[rr], p[begin:end, mi], seasonal[rr], fit[begin:end, mi], support[begin:end, mi])))
        without = pd.concat(chunks, ignore_index=True) if chunks else pd.DataFrame()
        current = []
        baseline = []
        for r in index.itertuples():
            current.append(models[method, r.arm].iloc[r.row])
            baseline.append(models[method, 'FULL_BASE' if r.arm.startswith('FULL') else 'STRICT_BASE'].iloc[r.row])
        current = pd.DataFrame(current).reset_index(drop=True)
        baseline = pd.DataFrame(baseline).reset_index(drop=True)
        f = index.copy()
        f['method'] = method
        f['policy'] = f.arm.str.split('_').str[0]
        for name in ['station_id', 'continent', 'country', 'kg_major', 'latitude', 'longitude', 'case_id']:
            f['target_' + name] = cases[name].to_numpy()[rows]
        for metric in ['r', 'H_deseasonal_r', 'alpha', 'delta', 'absolute_alpha_error', 'absolute_delta_error', 'NSE', 'eligible', 'r06_pass', 'r07_pass', 'r08_pass', 'support_months', 'actual_model_estimable']:
            f[metric + '_baseline'] = baseline[metric].to_numpy()
            f[metric + '_new'] = current[metric].to_numpy()
            f[metric + '_without'] = without[metric].to_numpy()
        for metric, direction in GAIN:
            f[metric + '_conditional_gain'] = direction * (f[metric + '_new'] - f[metric + '_without'])
            f[metric + '_network_gain_vs_baseline'] = direction * (f[metric + '_new'] - f[metric + '_baseline'])
        full = A.truth(current.r07_pass)
        removed = A.truth(without.r07_pass)
        old = A.truth(baseline.r07_pass)
        f['conditional_additional_r07'] = full & ~removed
        f['conditional_lost_r07'] = ~full & removed
        f['network_recovered_vs_baseline'] = full & ~old
        f['source_necessary_for_this_network_recovery'] = full & ~old & ~removed
        f['source_responsible_for_this_network_loss'] = ~full & old & removed
        f['new_network_lost_vs_baseline'] = ~full & old
        f['conditional_effect_not_standalone'] = True
        frames.append(f)
    detail = pd.concat(frames, ignore_index=True)
    detail.to_csv(OUT / 'target_source_conditional_contributions.csv.gz', index=False)
    named, cells = np.unique(cases.spatial_cell.astype(str), return_inverse=True)
    drawfile = A.OUT / 'bootstrap_spatial_cell_draws.npz'
    assert A.sha(drawfile) == A.read(A.OUT / 'ANALYSIS_COMPLETE.json')['output_files'][drawfile.name]['sha256']
    saved = np.load(drawfile, allow_pickle=True)
    draws = saved['draws']
    assert np.array_equal(named, saved['spatial_cells'].astype(str)) and len(draws) == 2000
    allmask = np.ones(A.N, bool)
    siterows = []
    cirows = []
    source_meta = loc.set_index('grdc_id')
    for method in A.METHODS:
        for policy in POLICIES:
            for H in DURATIONS:
                arm = f'{policy}_H{H}'
                main = models[method, arm]
                for sid in loc.grdc_id.astype(str):
                    g = detail.loc[(detail.method == method) & (detail.arm == arm) & (detail.physical_source_id == sid)]
                    selected = np.zeros(A.N, bool)
                    selected[g.row.to_numpy(int)] = True
                    mainpass = A.truth(main.r07_pass)
                    withoutpass = mainpass.copy()
                    withoutpass[g.row.to_numpy(int)] = A.truth(g.r07_pass_without)
                    changes = transition(mainpass, withoutpass, allmask)
                    raw, elig = zero_fill_gains(main, g, 'r', 1)
                    rawsum = paired(raw, elig, allmask, cells, draws)
                    rawsel = paired(raw, elig, selected, cells, draws)
                    m = source_meta.loc[sid]
                    rec = dict(physical_source_id=sid, policy=policy, method=method, new_H_months=H, source_country=m.country, source_river=m.river, source_name=m['name'], source_latitude=m.latitude, source_longitude=m.longitude, mother_targets=A.N, selected_targets=len(g), selected_G_targets=int((g.selected_G_months > 0).sum()), selected_H_only_targets=int(((g.selected_H_months > 0) & (g.selected_G_months == 0)).sum()), additional_r07=changes['new_pass'], lost_r07=changes['lost_pass'], net_conditional_r07=changes['new_pass'] - changes['lost_pass'], necessary_for_network_recovery_vs_baseline=int(g.source_necessary_for_this_network_recovery.sum()), responsible_for_network_loss_vs_baseline=int(g.source_responsible_for_this_network_loss.sum()), r_mean_gain_all_mothers=rawsum['mean_gain'], r_mean_gain_selected=rawsel['mean_gain'], r_median_gain_selected=rawsel['median_gain'], r_mean_gain_all_mothers_ci025=rawsum['mean_gain_ci025'], r_mean_gain_all_mothers_ci975=rawsum['mean_gain_ci975'], positive_selected_r_pct=rawsel['positive_pct'], negative_selected_r_pct=rawsel['negative_pct'], interpretation='Conditional deletion effect; unused targets have zero deletion effect; not a standalone added-station effect.')
                    siterows.append(rec)
                    for metric, direction in GAIN:
                        value, ok = zero_fill_gains(main, g, metric, direction)
                        for name, mask in [('all8898', allmask), ('source_selected_targets', selected)]:
                            cirows.append(dict(physical_source_id=sid, policy=policy, method=method, new_H_months=H, metric=metric, subset=name, **paired(value, ok, mask, cells, draws)))
                    for threshold in ['r06', 'r07', 'r08']:
                        original = A.truth(main[threshold + '_pass'])
                        wo = original.copy()
                        wo[g.row.to_numpy(int)] = A.truth(g[threshold + '_pass_without'])
                        cirows.append(dict(physical_source_id=sid, policy=policy, method=method, new_H_months=H, metric=threshold + '_pass', subset='all8898', **paired(original.astype(float) - wo.astype(float), allmask, allmask, cells, draws, binary=True)))
    site = pd.DataFrame(siterows)
    site.to_csv(OUT / 'site_by_duration_conditional_summary.csv', index=False)
    pd.DataFrame(cirows).to_csv(OUT / 'site_conditional_mean_bootstrap.csv', index=False)
    summarize_duration(site).to_csv(OUT / 'site_duration_stability.csv', index=False)
    tr = []
    for key, g in detail.groupby(['physical_source_id', 'policy', 'method', 'row'], sort=False):
        lookup = {int(e.new_H_months): e for e in g.itertuples()}
        rr = dict(zip(['physical_source_id', 'policy', 'method', 'row'], key))
        vals = []
        nets = []
        for H in DURATIONS:
            e = lookup.get(H)
            value = float(e.r_conditional_gain) if e else 0.0
            net = int(e.conditional_additional_r07) - int(e.conditional_lost_r07) if e else 0
            rr[f'selected_H{H}'] = e is not None
            rr[f'r_conditional_gain_H{H}'] = value
            rr[f'r07_conditional_net_H{H}'] = net
            vals.append(value)
            nets.append(net)
        rr['any_positive_to_negative_r_reversal'] = any((np.isfinite(vals[i]) and np.isfinite(vals[j]) and (vals[i] > 1e-12) and (vals[j] < -1e-12) for i in range(3) for j in range(i + 1, 3)))
        rr['any_positive_to_negative_r07_reversal'] = any((nets[i] > 0 and nets[j] < 0 for i in range(3) for j in range(i + 1, 3)))
        tr.append(rr)
    pd.DataFrame(tr).to_csv(OUT / 'target_site_duration_stability.csv.gz', index=False)
    selected_ids = np.load(PRED / 'selected_ids.npy', mmap_mode='r')
    ledger = []
    for policy in POLICIES:
        for H in DURATIONS:
            ai = A.ARMS.index(f'{policy}_H{H}')
            ids = selected_ids[:, ai]
            row, month, slot = np.where(ids >= OFFSET)
            df = pd.DataFrame(dict(row=row, physical_source_id=loc.grdc_id.to_numpy()[ids[row, month, slot] - OFFSET], absolute_month=cases.history_start.to_numpy()[row] + month, period=np.where(month < 60, 'H', 'G')))
            for (sid, period), g in df.groupby(['physical_source_id', 'period']):
                ledger.append(dict(physical_source_id=sid, policy=policy, new_H_months=H, period=period, unique_source_months=int(g.absolute_month.nunique()), reused_target_months=len(g), unique_targets=int(g.row.nunique())))
    pd.DataFrame(ledger).to_csv(OUT / 'source_month_use_ledger.csv', index=False)
    files = {p.name: dict(sha256=A.sha(p), bytes=p.stat().st_size) for p in OUT.iterdir() if p.is_file()}
    A.save(OUT / 'ABLATION_ANALYSIS_COMPLETE.json', dict(status='COMPLETE_CONDITIONAL_NEW_SOURCE_DELETION_ANALYSIS', mother_N=A.N, physical_locations=len(loc), ablation_target_source_rows=len(index), methods=A.METHODS, detailed_score_rows=len(detail), site_duration_method_rows=len(site), all_locations_retained_including_never_selected=True, not_standalone_site_addition=True, site_contributions_not_additive=True, source_unselected_zero_is_only_conditional_deletion_effect=True, hypothetical_future_outcome_guaranteed=False, output_files=files))
    print('SOURCE_ABLATION_ANALYSIS_COMPLETE', flush=True)
if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--authorized-after-freeze', action='store_true')
    p.add_argument('--synthetic-check', action='store_true')
    a = p.parse_args()
    if a.synthetic_check:
        r = synthetic_loso_checks()
        A.save(HERE / 'LOSO_SCORING_SYNTHETIC_QA.json', r)
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        run(a.authorized_after_freeze)
