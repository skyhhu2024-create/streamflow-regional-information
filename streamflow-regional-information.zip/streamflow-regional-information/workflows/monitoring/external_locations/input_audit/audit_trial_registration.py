"""Independent static and identity-input checks; no new fitting/scoring."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
from datetime import datetime, timezone
import sys, json, hashlib
sys.dont_write_bytecode = True
HERE = _PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit'
ROOT = _PROJECT_ROOT / 'workflows/monitoring/external_locations'
CODE = _PROJECT_ROOT
pass
import numpy as np
import pandas as pd

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def read(p):
    return json.loads(Path(p).read_text(encoding='utf8'))

def main():
    reg = _PROJECT_ROOT / 'workflows/monitoring/external_locations/registration_history'
    am = read(_PROJECT_ROOT / 'workflows/monitoring/external_locations/registration_history/AMENDMENT_001_DOCUMENTATION_ONLY.json')
    initial = _PROJECT_ROOT / 'workflows/monitoring/external_locations/registration_history/initial_TRIAL_CODE_INPUTS_FROZEN.json'
    current = _PROJECT_ROOT / 'workflows/monitoring/external_locations/TRIAL_CODE_INPUTS_FROZEN.json'
    oldid = _PROJECT_ROOT / 'workflows/monitoring/external_locations/registration_history/initial_IDENTITY_DELIVERY_MANIFEST.json'
    newid = _PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/DELIVERY_MANIFEST.json'
    assert sha(initial) == am['original_code_freeze'] and sha(current) == am['amended_code_freeze']
    assert sha(oldid) == am['original_identity_manifest'] and sha(newid) == am['new_identity_manifest']
    i, c = (read(initial), read(current))
    oi, ci = (read(oldid), read(newid))
    assert set(ci) - set(oi) == {am['added_document']} and (not set(oi) - set(ci))
    assert all((ci[k] == v for k, v in oi.items()))
    changes = {k: (i['files'].get(k), c['files'].get(k)) for k in set(i['files']) | set(c['files']) if i['files'].get(k) != c['files'].get(k)}
    assert len(changes) == 1 and Path(next(iter(changes))).name == 'DELIVERY_MANIFEST.json'
    for k, h in c['files'].items():
        assert sha(k) == h
    for k, h in ci.items():
        assert sha(_PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified' / k) == h
    for k, h in am['cache_sha256'].items():
        assert sha(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/case_cache' / k) == h
    meta = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/candidate_sources.csv', dtype={'grdc_id': str})
    z = np.load(_PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/candidate_values.npz', allow_pickle=False)
    assert len(meta) == 109 and meta.grdc_id.is_unique and meta.physical_group_id.is_unique
    assert np.array_equal(meta.grdc_id.astype(str), z['grdc_ids'].astype(str))
    assert z['Q_m3s'].shape == (109, 432)
    assert (meta.identity_evidence_grade == 'A_CATALOGUE_CORROBORATED_DISTINCT').all()
    assert meta.all_same_station_exclusion_ids.map(json.loads).map(len).eq(0).all()
    assert meta.canonical_GSIM_raw_index.isna().all() and meta.canonical_GSIM_ids.isna().all()
    assert (meta.canonical_discharge_unit == 'm3/s').all()
    assert meta.formal_identifier_key.is_unique
    assert np.isfinite(meta.latitude).all() and np.isfinite(meta.longitude).all()
    expectedcell = [f'{int(np.floor(lat / 5))}:{int(np.floor(lon / 5))}' for lat, lon in zip(meta.latitude, meta.longitude)]
    expectedfold = [int(hashlib.sha256(('R3GLOBAL_outer|' + x).encode()).hexdigest()[:16], 16) % 4 for x in expectedcell]
    assert np.array_equal(expectedcell, meta.spatial_cell.astype(str)) and np.array_equal(expectedfold, meta.outer_fold)
    assert np.all(~np.isfinite(z['Q_m3s']) | (z['Q_m3s'] >= 0))
    iq = read(_PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/INDEPENDENT_INTERFACE_QA.json')
    assert iq['raw_value_matrix_replay_exact'] and iq['all_months_and_folds_match']
    assert iq['input_matrix_sha256'] == sha(_PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/candidate_values.npz')
    report = dict(status='PASS_PREPREDICTION_REGISTRATION_AND_IDENTITY_INTERFACE_REVIEW', passed=True, checked_at_utc=datetime.now(timezone.utc).isoformat(), audit_script_sha256=sha(__file__), current_code_freeze_sha256=sha(current), original_code_freeze_sha256=sha(initial), documentation_only_amendment_independently_verified=True, frozen_manifest_only_changed_path=next(iter(changes)), original_identity_manifest_records_unchanged=True, additional_document=am['added_document'], first10_cache_hashes_preserved=True, admitted_physical_locations=109, country_counts={str(k): int(v) for k, v in meta.country.value_counts().items()}, all109_source_ID_order_units_physical_groups_and_spatial_folds_checked=True, matrix_matches_independent_native_parser_QA=True, input_monthly_values_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/candidate_values.npz'), current_production_code_sha256=sha(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_source/run_trial.py'), no_new_fit_or_prediction_or_target_G_scoring=True, pending_prediction_QA=['Every source slot and corresponding H visibility', 'STRICT baseline exact replay', '24/36/60 transforms and source eligibility from permitted H only', 'Fixed matched baseline training rows', 'No-self/full-twin and strict-fold isolation', 'New-source-absent exact fallback', 'Independent composite/model replays and target-G poisoning test', 'Ablation removed source and same training mask'])
    (_PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/REGISTRATION_AND_IDENTITY_INPUT_QA.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
