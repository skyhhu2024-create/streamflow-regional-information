"""Independent pre-score audit. Never evaluates target G truth or skill."""
from pathlib import Path as _PackagePath
import sys as _package_sys
_PROJECT_ROOT = next((p for p in _PackagePath(__file__).resolve().parents if (p / 'pyproject.toml').is_file()))
for _package_location in (_PROJECT_ROOT, _PROJECT_ROOT / 'src'):
    if str(_package_location) not in _package_sys.path:
        _package_sys.path.insert(0, str(_package_location))
from pathlib import Path
from datetime import datetime, timezone
import os, sys, json, hashlib, warnings
for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[k] = '1'
sys.dont_write_bytecode = True
HERE = _PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit'
ROOT = _PROJECT_ROOT / 'workflows/monitoring/external_locations'
CODE = _PROJECT_ROOT
pass
import numpy as np
import pandas as pd
from scipy.stats import rankdata
import workflows.monitoring.external_locations.input_audit.analyze_observation_trial as A
N = 8898
OFFSET = 40000
PREV = A.PREV
OLD = A.OLD
PRED = _PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions'
warnings.filterwarnings('ignore', category=RuntimeWarning)

def close(x, y):
    np.testing.assert_allclose(x, y, rtol=1e-09, atol=1e-08, equal_nan=True)

def prep(raw, months):
    v = np.full_like(raw, np.nan, dtype=float)
    ok = np.isfinite(raw) & (raw >= 0)
    v[ok] = np.log1p(raw[ok])
    cl = np.stack([np.nanmean(v[:, months % 12 == m], axis=1) for m in range(12)], axis=1)
    an = v - cl[:, months % 12]
    sd = np.nanstd(an, axis=1)
    sd[sd <= 1e-12] = np.nan
    return (cl, sd, an / sd[:, None])

def rel(z, y):
    good = np.isfinite(z) & np.isfinite(y)[None, :]
    n = good.sum(1)
    r = np.full(len(z), np.nan)
    for j in np.flatnonzero(n >= 12):
        x = z[j, good[j]]
        v = y[good[j]]
        x = x - x.mean()
        v = v - v.mean()
        den = np.sqrt(np.sum(x * x) * np.sum(v * v))
        if den > 1e-24:
            r[j] = np.clip(np.sum(x * v) / den, -1, 1)
    return (n, r)

def independent_fit(h, y, g, method, estimable):
    if not estimable or len(y) < 12 or (not np.isfinite(h).all()) or (not np.isfinite(y).all()):
        return (np.full(len(g), np.nan), False)
    mu = h.mean(0)
    sd = h.std(0)
    sd[sd <= 1e-12] = 1
    hh = (h - mu) / sd
    offset = y.mean()
    yc = y - offset
    ok = np.isfinite(g).all(1)
    gg = (g[ok] - mu) / sd
    out = np.full(len(g), np.nan)
    n, d = h.shape
    if method == 0:
        coef = np.linalg.solve(hh.T @ hh + n * 0.1 * np.eye(d), hh.T @ yc)
        out[ok] = gg @ coef + offset
    else:
        train = np.maximum((hh * hh).sum(1)[:, None] + (hh * hh).sum(1)[None, :] - 2 * hh @ hh.T, 0)
        test = np.maximum((gg * gg).sum(1)[:, None] + (hh * hh).sum(1)[None, :] - 2 * gg @ hh.T, 0)
        coef = np.linalg.solve(np.exp(-train / d) + n * 0.1 * np.eye(n), yc)
        out[ok] = np.exp(-test / d) @ coef + offset
    out[~np.isfinite(out)] = np.nan
    return (out, True)

def invert(z, fit, tz, cal, sd, months, base):
    if not fit:
        return (base.copy(), np.zeros(len(base), bool))
    ok = np.isfinite(z) & np.isfinite(cal[months % 12])
    valid = tz[np.isfinite(tz)]
    clamped = np.where(ok, np.clip(z, valid.min() - 3, valid.max() + 3), 0)
    p = np.maximum(np.expm1(np.minimum(clamped * sd + cal[months % 12], 50)), 0)
    p[~ok] = base[~ok]
    return (p, ok)

def main():
    freeze_path = _PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/PREDICTIONS_FROZEN.json'
    assert freeze_path.exists(), 'Wait for all main and source-deletion predictions.'
    frozen = A.verify(freeze_path, PRED)
    codepath = _PROJECT_ROOT / 'workflows/monitoring/external_locations/TRIAL_CODE_INPUTS_FROZEN.json'
    A.verify(codepath, ROOT)
    assert frozen['code_freeze_sha256'] == A.sha(codepath)
    assert frozen['arms'] == A.ARMS and frozen['methods'] == A.METHODS
    for name in ['REGISTRATION_AND_IDENTITY_INPUT_QA.json', 'VISIBILITY_POISONING_QA.json']:
        receipt = A.read(HERE / name)
        assert receipt['passed']
        key = 'current_code_freeze_sha256' if name.startswith('REGISTRATION') else 'code_freeze_sha256'
        assert receipt[key] == A.sha(codepath)
    baseline = A.read(_PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/BASELINE_INPUT_REUSE_QA.json')
    assert baseline['passed']
    for name, entry in baseline['frozen_dependency_files'].items():
        assert A.sha(name) == entry['sha256']
    cases = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/cases.csv')
    oldcases = pd.read_csv(PREV / 'prepared_inputs/cases.csv')
    for col in ['station_id', 'raw_index', 'row', 'case_id', 'history_start', 'history_end', 'gap_start', 'gap_end', 'outer_fold', 'spatial_cell']:
        assert np.array_equal(cases[col], oldcases[col])
    loc = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/physical_locations.csv', dtype={'grdc_id': str})
    assert len(loc) == 109 and loc.grdc_id.is_unique
    arrays = {k: np.load(PRED / (k + '.npy'), mmap_mode='r') for k in ['predictions', 'support', 'fit_estimable', 'training_mask', 'selected_ids', 'composites', 'counts']}
    ids = arrays['selected_ids']
    comp = arrays['composites']
    cnt = arrays['counts']
    pred = arrays['predictions']
    sup = arrays['support']
    fit = arrays['fit_estimable']
    train = arrays['training_mask']
    assert ids.shape == (N, 11, 180, 4) and pred.shape == sup.shape == (N, 11, 2, 120)
    assert fit.shape == (N, 11, 2) and train.shape == (N, 11, 60)
    assert np.array_equal((ids >= 0).sum(3), cnt)
    oldpred = np.load(PREV / 'predictions/predictions.npy', mmap_mode='r')[:, :, 1]
    olds = np.load(PREV / 'predictions/support.npy', mmap_mode='r')[:, :, 1]
    oldf = np.load(PREV / 'predictions/flags.npy', mmap_mode='r')[:, :, 1, 0]
    np.testing.assert_allclose(pred[:, 0], oldpred, rtol=0, atol=0, equal_nan=True)
    assert np.array_equal(sup[:, 0], olds) and np.array_equal(fit[:, 0], oldf)
    assert np.array_equal(ids[:, 0], np.load(PREV / 'prepared_inputs/source_ids_HG.npy', mmap_mode='r')[:, 0])
    np.testing.assert_allclose(comp[:, 0], np.load(PREV / 'prepared_inputs/composites.npy', mmap_mode='r')[:, 0], rtol=0, atol=0, equal_nan=True)
    meta = pd.read_csv(OLD / 'design/all_station_roles.csv', low_memory=False)
    candidate = A.truth(meta.global_source_candidate)
    twins = pd.read_csv(_PROJECT_ROOT / 'data/gsim_near_duplicates_checked.csv')
    lookup = dict(zip(meta.station_id, np.arange(len(meta))))
    adj = {}
    for r in twins.loc[A.truth(twins.twin)].itertuples():
        if r.a in lookup and r.b in lookup:
            a, b = (lookup[r.a], lookup[r.b])
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
    aliases = {}
    for raw in cases.raw_index:
        seen = {int(raw)}
        todo = [int(raw)]
        while todo:
            for v in adj.get(todo.pop(), ()):
                if v not in seen:
                    seen.add(v)
                    todo.append(v)
        aliases[int(raw)] = seen
    external = np.load(_PROJECT_ROOT / 'workflows/monitoring/external_locations/identity_verified/candidate_values.npz')['Q_m3s']
    q = np.load(OLD / 'global_data/QC20_Q.npy', mmap_mode='r')
    tz = np.load(PREV / 'prepared_inputs/target_Hz.npy')
    cal = np.load(PREV / 'prepared_inputs/target_H_log_calendar.npy')
    sd = np.load(PREV / 'prepared_inputs/target_H_anomaly_sd.npy')
    rawcal = np.load(PREV / 'prepared_inputs/target_H_raw_calendar.npy')
    emeta = np.load(PREV / 'prepared_inputs/input_meta.npy')
    rain = np.load(PREV / 'prepared_inputs/PRECIPITATION_H_ONLY_INPUTS.npz')
    extchecks = set()
    expected_ablation = set()
    used_rows = set()
    fallback_counts = {}
    for ai, arm in enumerate(A.ARMS):
        x = ids[:, ai]
        valid = x >= 0
        old = valid & (x < OFFSET)
        new = x >= OFFSET
        assert ((x == -1) | old | new).all() and (x[old] < len(meta)).all() and (x[new] < OFFSET + len(loc)).all()
        assert candidate[x[old]].all()
        sortedx = np.sort(x, axis=2)
        assert not ((np.diff(sortedx, axis=2) == 0) & (sortedx[:, :, :-1] >= 0)).any()
        rr, mm, ss = np.where(old)
        assert not (x[rr, mm, ss] == cases.raw_index.to_numpy()[rr]).any()
        if arm.startswith('STRICT'):
            assert (meta.outer_fold.to_numpy()[x[rr, mm, ss]] != cases.outer_fold.to_numpy()[rr]).all()
        dates = cases.history_start.to_numpy()[rr] + mm
        value = q[x[rr, mm, ss], dates]
        assert np.isfinite(value).all() and (value >= 0).all()
        for row in range(N):
            if len(aliases[int(cases.raw_index.iloc[row])]) > 1:
                assert not np.isin(x[row], list(aliases[int(cases.raw_index.iloc[row])])).any()
        nr, nm, ns = np.where(new)
        ee = x[nr, nm, ns] - OFFSET
        if ai < 2:
            assert not len(nr)
        else:
            H = int(arm.rsplit('H', 1)[1])
            b = 1 if arm.startswith('FULL') else 0
            assert (nm >= 60 - H).all()
            if arm.startswith('STRICT'):
                assert (loc.outer_fold.to_numpy()[ee] != cases.outer_fold.to_numpy()[nr]).all()
            ev = external[ee, cases.history_start.to_numpy()[nr] + nm]
            assert np.isfinite(ev).all() and (ev >= 0).all()
            assert np.array_equal(train[:, ai], train[:, b]) and (cnt[:, ai] >= cnt[:, b]).all()
            used = new.any((1, 2))
            unused = ~used
            used_rows.update(np.flatnonzero(used).tolist())
            fallback_counts[arm] = int(unused.sum())
            np.testing.assert_allclose(pred[unused, ai], pred[unused, b], rtol=0, atol=0, equal_nan=True)
            np.testing.assert_allclose(comp[unused, ai], comp[unused, b], rtol=0, atol=0, equal_nan=True)
            for row, eid in np.unique(np.column_stack([nr, ee]), axis=0):
                extchecks.add((int(row), H, int(eid)))
                if not arm.startswith('BRIDGE'):
                    expected_ablation.add((int(row), ai, OFFSET + int(eid)))
        assert not (sup[:, ai] & ~fit[:, ai, :, None]).any()
        assert (pred[:, ai][np.broadcast_to(fit[:, ai, :, None], pred[:, ai].shape)] >= 0).all()
        for row in range(N):
            g = np.arange(int(cases.gap_start.iloc[row]), int(cases.gap_end.iloc[row]))
            base = rawcal[row, g % 12]
            for mi in range(2):
                mask = ~sup[row, ai, mi]
                np.testing.assert_allclose(pred[row, ai, mi, mask], base[mask], rtol=0, atol=0, equal_nan=True)
    for row, H, eid in sorted(extchecks):
        e = cases.iloc[row]
        hh = np.arange(int(e.history_end) - H, int(e.history_end))
        eh = external[eid, hh][None, :]
        ec, es, ez = prep(eh, hh)
        n, r = rel(ez, tz[row, -H:])
        assert n[0] >= 24 and np.isfinite(es[0]) and np.isfinite(ec).all() and (r[0] > 0)
        assert all((np.isfinite(eh[0, hh % 12 == m]).sum() >= 2 for m in range(12)))
    index = pd.read_csv(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/ablation_index.csv', dtype={'physical_source_id': str})
    assert np.array_equal(index.ablation_index, np.arange(len(index)))
    got = set(zip(index.row.astype(int), index.arm_index.astype(int), index.source_internal_id.astype(int)))
    assert len(got) == len(index) and got == expected_ablation
    assert index.removed_source_remaining_slots.eq(0).all()
    for e in index.itertuples():
        assert A.ARMS[e.arm_index] == e.arm and e.physical_source_id == str(loc.grdc_id.iloc[e.source_internal_id - OFFSET])
        assert e.selected_H_months == np.any(ids[e.row, e.arm_index, :60] == e.source_internal_id, axis=1).sum()
        assert e.selected_G_months == np.any(ids[e.row, e.arm_index, 60:] == e.source_internal_id, axis=1).sum()
    selected = set([0, 1, 4200, 8843, 8860, 8897])
    for ai in range(2, 11):
        used = np.flatnonzero((ids[:, ai] >= OFFSET).any((1, 2)))
        if len(used):
            selected.add(int(used[0]))
            selected.add(int(used[-1]))
    replay = []
    for row in sorted(selected):
        e = cases.iloc[row]
        h = np.arange(int(e.history_start), int(e.history_end))
        g = np.arange(int(e.gap_start), int(e.gap_end))
        mm = np.r_[h, g]
        cache = {}
        for ai, arm in enumerate(A.ARMS):
            H = int(arm.rsplit('H', 1)[1]) if ai >= 2 else 60
            for source in np.unique(ids[row, ai][ids[row, ai] >= 0]):
                key = (int(source), H if source >= OFFSET else 60)
                if key in cache:
                    continue
                hh = h[-key[1]:]
                raw = external[source - OFFSET, hh] if source >= OFFSET else q[source, hh]
                c, s, z = prep(raw[None, :], hh)
                nn, rr = rel(z, tz[row, -key[1]:])
                assert rr[0] > 0 and nn[0] >= (24 if source >= OFFSET else 12)
                values = external[source - OFFSET, mm] if source >= OFFSET else q[source, mm]
                cache[key] = ((np.log1p(values) - c[0, mm % 12]) / s[0], rr[0])
            expected = np.full(180, np.nan)
            for t in range(180):
                sources = ids[row, ai, t]
                sources = sources[sources >= 0]
                if len(sources):
                    numerator = denominator = 0.0
                    for source in sources:
                        z, w = cache[int(source), H if source >= OFFSET else 60]
                        numerator += w * z[t]
                        denominator += w
                    expected[t] = numerator / denominator
            close(expected, comp[row, ai])
            use = train[row, ai]
            base = rawcal[row, g % 12]
            for method in range(2):
                hh = expected[:60, None]
                gg = expected[60:, None]
                if rain['p_available'][row]:
                    hh = np.column_stack([hh, rain['p_h'][row]])
                    gg = np.column_stack([gg, rain['p_g'][row]])
                zz, estimated = independent_fit(hh[use], tz[row, use], gg, method, bool(emeta[row, 4]))
                pp, ss = invert(zz, estimated, tz[row], cal[row], sd[row], g, base)
                close(pp, pred[row, ai, method])
                assert np.array_equal(ss, sup[row, ai, method]) and estimated == fit[row, ai, method]
            replay.append(dict(row=row, station_id=e.station_id, arm=arm, methods_checked=2))
    abp = np.load(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/ablation_predictions.npy', mmap_mode='r')
    absup = np.load(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/ablation_support.npy', mmap_mode='r')
    abfit = np.load(_PROJECT_ROOT / 'workflows/monitoring/external_locations/trial_predictions/ablation_fit_estimable.npy', mmap_mode='r')
    poison = A.read(_PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/VISIBILITY_POISONING_QA.json')
    for item in poison['selected_cases']:
        row = item['row']
        z = np.load(_PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/visibility_poisoning_scratch' / f'{row:05d}_original/case_cache' / f'{row:05d}.npz')
        np.testing.assert_allclose(z['predictions'], pred[row], rtol=0, atol=0, equal_nan=True)
        sub = index.loc[index.row == row]
        np.testing.assert_allclose(z['ablation_predictions'], abp[sub.ablation_index], rtol=0, atol=0, equal_nan=True)
        assert np.array_equal(z['ablation_support'], absup[sub.ablation_index]) and np.array_equal(z['ablation_fit'], abfit[sub.ablation_index])
    A.verify(freeze_path, PRED)
    A.verify(codepath, ROOT)
    report = dict(status='PASS_FROZEN_LOCATION_DURATION_PREDICTIONS_PRE_SCORING_QA', passed=True, checked_at_utc=datetime.now(timezone.utc).isoformat(), audit_script_sha256=A.sha(__file__), predictions_freeze_sha256=A.sha(freeze_path), code_freeze_sha256=A.sha(codepath), scoring_code_sha256=A.sha(_PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/analyze_observation_trial.py'), scoring_core_sha256=A.sha(_PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/trial_score_core.py'), loso_scoring_code_sha256=A.sha(_PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/analyze_source_ablation.py'), mother_N=N, all_source_slots_checked=int(ids.size), physical_locations=len(loc), all_actual_external_H_qualification_pairs_checked=len(extchecks), all_source_deletion_pairs_present_and_unique=len(index), strict_baseline_matches_previous_QP_exactly=True, every_baseline_training_mask_preserved=True, new_source_H_visibility_checked=True, self_twin_and_policy_specific_fold_exclusion_checked=True, all_source_reports_used_are_finite_nonnegative=True, new_source_unselected_fallback_exact_counts=fallback_counts, independent_composite_and_two_processor_replay=replay, visibility_poisoning_QA_sha256=A.sha(_PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/VISIBILITY_POISONING_QA.json'), target_G_truth_scored_or_evaluated=False, source_or_frozen_production_files_modified=False, evidence_boundary='Prior target periods already assessed; location sample107ZA+US1+AU1; strict/bridge/full policies remain separate.')
    A.save(_PROJECT_ROOT / 'workflows/monitoring/external_locations/input_audit/PRE_SCORING_QA_PASS.json', report)
    print(json.dumps({k: v for k, v in report.items() if k != 'independent_composite_and_two_processor_replay'}, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
