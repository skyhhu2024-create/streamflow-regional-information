"""Score user-supplied frozen monthly predictions, with paired spatial summaries.

This wrapper does not fit a reconstruction or download observations. See
docs/WATER_METRICS.md for CSV/NPZ contracts and the interpretation of intervals.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from streamflow_info.water_metrics import evaluate_case, VERSION

CONTINUOUS = ('drought_hss', 'drought_hss_chance', 'drought_hss_excess',
              'drought_count_ratio', 'deficit_ratio', 'deficit_abs_ratio_error',
              'deficit_abs_error_hmean_normalized', 'water_rel_error', 'water_abs_rel_error')
BINARY = ('deficit_within_25pct', 'deficit_within_50pct',
          'water_within_10pct', 'water_within_20pct')
REQUIRED = ('case_id', 'arm', 'date', 'phase', 'observed', 'predicted', 'spatial_cell')


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, np.ndarray)):
        return [clean(v) for v in value]
    if isinstance(value, np.generic):
        return clean(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def save_json(path, value):
    Path(path).write_text(json.dumps(clean(value), indent=2, allow_nan=False) + '\n', encoding='utf-8')


class SpatialBootstrap:
    """Integer block weights, equal target weighting within each sampled block.

    The median/mean algorithms are copied from the study summary implementation.
    The constructor validates user-supplied arrays; it does not infer geography.
    """
    def __init__(self, cells, draws):
        self.cells = np.asarray(cells, str)
        if self.cells.ndim != 1 or not len(self.cells) or len(set(self.cells)) != len(self.cells):
            raise ValueError('Spatial cells must be a nonempty unique ordered vector.')
        raw = np.asarray(draws)
        if raw.ndim != 2 or raw.shape[0] < 2 or raw.shape[1] != len(self.cells):
            raise ValueError('Bootstrap columns must match the ordered spatial cells.')
        if not np.isfinite(raw).all() or np.any(raw < 0) or np.any(raw != np.floor(raw)):
            raise ValueError('Bootstrap weights must be nonnegative integers.')
        if not np.all(raw.sum(axis=1) == len(self.cells)):
            raise ValueError('Each draw must sample the registered number of spatial cells.')
        self.draws = raw.astype(np.int32)
        self.cache = {}

    def key(self, kind, values, indices):
        h = hashlib.sha256()
        h.update(np.ascontiguousarray(values, dtype=np.float64).tobytes())
        h.update(np.ascontiguousarray(indices, dtype=np.int32).tobytes())
        return kind, h.hexdigest()

    def median(self, values, indices):
        values, indices = np.asarray(values, float), np.asarray(indices, int)
        key = self.key('median', values, indices)
        if key in self.cache:
            return self.cache[key]
        out = np.full(len(self.draws), np.nan)
        if len(values):
            assert np.isfinite(values).all()
            order = np.argsort(values, kind='stable')
            v, ix = values[order], indices[order]
            for start in range(0, len(self.draws), 100):
                weights = self.draws[start:start + 100, ix]
                n = weights.sum(1)
                cumulative = weights.cumsum(1)
                lo = np.maximum((n - 1) // 2, 0) + 1
                hi = n // 2 + 1
                lower = np.argmax(cumulative >= lo[:, None], axis=1)
                upper = np.argmax(cumulative >= hi[:, None], axis=1)
                out[start:start + len(weights)] = np.where(n > 0, (v[lower] + v[upper]) / 2, np.nan)
        self.cache[key] = out
        return out

    def mean(self, values, indices):
        values, indices = np.asarray(values, float), np.asarray(indices, int)
        key = self.key('mean', values, indices)
        if key in self.cache:
            return self.cache[key]
        assert np.isfinite(values).all()
        sums = np.bincount(indices, weights=values, minlength=len(self.cells))
        counts = np.bincount(indices, minlength=len(self.cells))
        denominator = self.draws @ counts
        out = np.divide(self.draws @ sums, denominator,
                        out=np.full(len(self.draws), np.nan), where=denominator > 0)
        self.cache[key] = out
        return out


def interval(values):
    values = np.asarray(values, float)
    valid = values[np.isfinite(values)]
    lo, hi = np.percentile(valid, [2.5, 97.5]) if len(valid) else (np.nan, np.nan)
    return dict(ci_low=lo, ci_high=hi, valid_bootstrap_draws=len(valid))


def load_npz(path):
    """Convert the documented dense NPZ schema to the same long CSV schema."""
    with np.load(path, allow_pickle=False) as z:
        case_ids = z['case_id'].astype(str)
        arms = z['arm_names'].astype(str)
        h, o, p = z['history'], z['observed'], z['predicted']
        hd, gd = z['history_dates'], z['gap_dates']
        cells = z['spatial_cell'].astype(str)
    n, a = len(case_ids), len(arms)
    if h.shape != (n, 60) or o.shape != (n, 120) or p.shape != (n, a, 120):
        raise ValueError('Expected history (n,60), observed (n,120), predicted (n,arms,120).')
    if case_ids.shape != (n,) or cells.shape != (n,) or arms.shape != (a,):
        raise ValueError('IDs, cells and arm names must be one-dimensional.')
    if len(set(case_ids)) != n or len(set(arms)) != a:
        raise ValueError('Duplicate case IDs or arm names in NPZ.')
    if hd.shape == (60,):
        hd = np.broadcast_to(hd, (n, 60))
    if gd.shape == (120,):
        gd = np.broadcast_to(gd, (n, 120))
    if hd.shape != (n, 60) or gd.shape != (n, 120):
        raise ValueError('Date arrays must align with histories/gaps or be shared one-dimensional dates.')
    records = []
    for i in range(n):
        for j, arm in enumerate(arms):
            for phase, dates, obs, pred in (
                ('history', hd[i], h[i], np.full(60, np.nan)),
                ('gap', gd[i], o[i], p[i, j]),
            ):
                records.append(pd.DataFrame(dict(case_id=case_ids[i], arm=arm, date=dates.astype(str),
                                                 phase=phase, observed=obs, predicted=pred,
                                                 spatial_cell=cells[i])))
    return pd.concat(records, ignore_index=True)


def score_frame(frame):
    missing = set(REQUIRED) - set(frame)
    if missing:
        raise ValueError('Missing columns: ' + ', '.join(sorted(missing)))
    if frame.empty or frame[list(('case_id', 'arm', 'date', 'phase', 'spatial_cell'))].isna().any().any():
        raise ValueError('Registry fields must be nonempty.')
    frame = frame.copy()
    for col in ('case_id', 'arm', 'spatial_cell'):
        frame[col] = frame[col].astype(str)
        if frame[col].str.strip().eq('').any():
            raise ValueError(f'Empty registry field: {col}')
    if not set(frame.phase).issubset({'history', 'gap'}):
        raise ValueError('phase must be history or gap.')
    frame['date'] = pd.to_datetime(frame.date, errors='raise').values.astype('datetime64[M]')
    if frame.duplicated(['case_id', 'arm', 'date']).any():
        raise ValueError('Duplicate case/arm/month records.')
    for col in ('observed', 'predicted'):
        frame[col] = pd.to_numeric(frame[col], errors='raise')
    arms = sorted(frame.arm.unique())
    records = []
    for case_id, group in frame.groupby('case_id', sort=True):
        if set(group.arm) != set(arms) or group.spatial_cell.nunique() != 1:
            raise ValueError('Every registered case must have every arm and one fixed spatial cell.')
        truth_reference = None
        for arm, g in group.groupby('arm', sort=True):
            g = g.sort_values('date')
            h, t = g[g.phase == 'history'], g[g.phase == 'gap']
            if len(h) != 60 or len(t) != 120:
                raise ValueError(f'{case_id}/{arm}: require exactly 60 history and 120 gap rows.')
            common = g[['date', 'phase', 'observed']].reset_index(drop=True)
            if truth_reference is not None and not common.equals(truth_reference):
                raise ValueError(f'{case_id}: history, truth and dates must be identical across arms.')
            truth_reference = common
            metadata = {}
            for column in g.columns:
                if column.startswith('meta_'):
                    if g[column].nunique(dropna=False) != 1:
                        raise ValueError(f'{case_id}/{arm}: {column} must be constant within a case/arm.')
                    metadata[column] = g[column].iloc[0]
            for pct in (20, 10):
                row = evaluate_case(h.observed, h.date, t.observed, t.predicted, t.date, pct)
                records.append(dict(case_id=case_id, arm=arm, spatial_cell=g.spatial_cell.iloc[0], **metadata, **row))
    return pd.DataFrame(records)


def summarize(scored, engine, contrasts):
    """Metric-specific finite denominators; A-minus-B paired effects."""
    lookup = {c: i for i, c in enumerate(engine.cells)}
    results, paired = [], []
    for (arm, pct), g in scored.groupby(['arm', 'drought_percentile'], sort=True):
        for metric in CONTINUOUS + BINARY:
            values = g[metric].to_numpy(float)
            valid = np.isfinite(values)
            v = values[valid]
            ix = g.spatial_cell.map(lookup).to_numpy(int)[valid]
            binary = metric in BINARY
            if binary and not np.isin(v, [0, 1]).all():
                raise ValueError('Non-binary tolerance result.')
            boots = engine.mean(v, ix) * 100 if binary else engine.median(v, ix)
            estimate = (np.mean(v) * 100 if binary else np.median(v)) if len(v) else np.nan
            results.append(dict(arm=arm, percentile=pct, metric=metric, registered_n=len(g),
                valid_n=len(v), unevaluated_n=len(g)-len(v), estimate=estimate,
                statistic='percent' if binary else 'median',
                known_pass_registered_percent=np.sum(v)/len(g)*100 if binary else np.nan,
                **interval(boots)))
    names = set(scored.arm)
    for contrast in contrasts:
        a, b = contrast['arm'], contrast['reference']
        if a not in names or b not in names or a == b:
            raise ValueError('Contrasts require two distinct input arm names.')
        for pct in (20, 10):
            sub = scored[scored.drought_percentile == pct]
            left = sub[sub.arm == a].set_index('case_id').sort_index()
            right = sub[sub.arm == b].set_index('case_id').sort_index()
            if not left.index.equals(right.index):
                raise ValueError('Contrasts must retain the same registered targets.')
            for metric in CONTINUOUS + BINARY:
                av, bv = left[metric].to_numpy(float), right[metric].to_numpy(float)
                valid = np.isfinite(av) & np.isfinite(bv)
                delta = av[valid]-bv[valid]
                ix = left.spatial_cell.map(lookup).to_numpy(int)[valid]
                binary = metric in BINARY
                boots = engine.mean(delta, ix)*100 if binary else engine.median(delta, ix)
                estimate = (np.mean(delta)*100 if binary else np.median(delta)) if len(delta) else np.nan
                paired.append(dict(arm=a, reference=b, percentile=pct, metric=metric,
                    registered_n=len(left), paired_n=int(valid.sum()), estimate=estimate,
                    statistic='net_percentage_points' if binary else 'median_within_target_difference',
                    new_passes=int(np.sum(delta > 0)) if binary else np.nan,
                    lost_passes=int(np.sum(delta < 0)) if binary else np.nan,
                    **interval(boots)))
    return pd.DataFrame(results), pd.DataFrame(paired)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True, help='Long CSV or dense NPZ; see documentation.')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--contrasts', type=Path, help='JSON list of {arm, reference} pairs, fixed before evaluating results.')
    parser.add_argument('--bootstrap-draws', type=Path, help='Optional frozen NPZ with spatial_cells and draws.')
    parser.add_argument('--resamples', type=int, default=2000)
    parser.add_argument('--seed', type=int, default=20261029)
    args = parser.parse_args(argv)
    if args.resamples < 2:
        parser.error('--resamples must be at least 2')
    if args.output.exists() and any(args.output.iterdir()):
        parser.error('Output directory must be empty; existing results are not overwritten.')
    frame = load_npz(args.input) if args.input.suffix.lower() == '.npz' else pd.read_csv(
        args.input, dtype={'case_id': str, 'arm': str, 'spatial_cell': str})
    scored = score_frame(frame)
    cells = np.sort(np.asarray(scored.spatial_cell.unique(), dtype=str))
    if args.bootstrap_draws:
        with np.load(args.bootstrap_draws, allow_pickle=False) as z:
            if not np.array_equal(cells, z['spatial_cells'].astype(str)):
                raise ValueError('Frozen cell order does not match the registered cohort.')
            draws = z['draws']
    else:
        draws = np.random.default_rng(args.seed).multinomial(len(cells), np.full(len(cells), 1/len(cells)), size=args.resamples)
    contrasts = json.loads(args.contrasts.read_text(encoding='utf-8')) if args.contrasts else []
    engine = SpatialBootstrap(cells, draws)
    summaries, paired = summarize(scored, engine, contrasts)
    args.output.mkdir(parents=True, exist_ok=True)
    scored.to_csv(args.output/'per_target_water_metrics.csv', index=False)
    summaries.to_csv(args.output/'water_summary.csv', index=False)
    if contrasts:
        paired.to_csv(args.output/'paired_water_effects.csv', index=False)
    np.savez_compressed(args.output/'bootstrap_draws.npz', spatial_cells=cells, draws=draws)
    save_json(args.output/'run.json', dict(metrics_version=VERSION,
        input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
        metric_source_sha256=hashlib.sha256((Path(__file__).resolve().parents[1]/'src/streamflow_info/water_metrics.py').read_bytes()).hexdigest(),
        evaluation_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        contrasts_file_sha256=hashlib.sha256(args.contrasts.read_bytes()).hexdigest() if args.contrasts else None,
        supplied_draws_sha256=hashlib.sha256(args.bootstrap_draws.read_bytes()).hexdigest() if args.bootstrap_draws else None,
        registered_targets=int(scored.case_id.nunique()), arms=sorted(scored.arm.unique()),
        spatial_cells=len(cells), bootstrap_draws=len(draws), generated_seed=None if args.bootstrap_draws else args.seed,
        percentiles=[20,10], contrasts=contrasts, no_refit=True,
        interpretation='User-supplied frozen predictions; not a reproduction of manuscript totals unless the original registered cohort and all required inputs are supplied.'))
    print(json.dumps(dict(output=str(args.output), targets=int(scored.case_id.nunique()), metric_rows=len(scored))))


if __name__ == '__main__':
    main()
