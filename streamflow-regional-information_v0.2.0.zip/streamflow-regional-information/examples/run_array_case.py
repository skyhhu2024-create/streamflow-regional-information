"""Reconstruct a user-supplied NPZ case without reading target gap truth."""
import argparse
from pathlib import Path
import numpy as np
from streamflow_info.case import run_forward_case
from streamflow_info.transfer import RainInputs


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    with np.load(args.input, allow_pickle=False) as data:
        inputs = {k: data[k] for k in ('target_history', 'source_flows', 'source_ids',
            'source_distances_km', 'target_physical_ids')}
        inputs['history_start_month'] = int(data['history_start_month'])
        for name in ('precipitation', 'excluded_source_ids'):
            if name in data:
                inputs[name] = data[name]
        if 'p_h' in data:
            inputs['prepared_precipitation'] = RainInputs(data['p_h'], data['p_g'],
                data['p_g_climatology'], data['p_calendar_logmean'],
                bool(data['p_available']), str(data['p_reason']),
                inputs['history_start_month']-3)
        result = run_forward_case(**inputs)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.output, **result)
    print(f'Predictions saved: {args.output}; target gap truth was not loaded.')
