"""Export one registered case from a user's LOCAL historical project archive.

This writes licensed observations to a user-selected local destination. The
export is not part of this repository and must not be redistributed without
the source permissions. No target G truth is exported by default.
"""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from streamflow_info.reconstruction import distances


def table(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def export(project_code, station_id, destination, include_truth=False):
    experiments = project_code/'V45/experiments'
    original = experiments/'r3_global_single_condition_20261022'
    final = experiments/'r4_full_source_gradient_20261026'
    previous = experiments/'r4_global_information_20261025'
    cases = table(experiments/'r4_observation_locations_20261025/trial_predictions/cases.csv')
    matched = [e for e in cases if e['station_id'] == station_id]
    if len(matched) != 1:
        raise ValueError('Station ID must match exactly one registered case.')
    e = matched[0]
    row, target = int(e['row']), int(e['raw_index'])
    h = np.arange(int(e['history_start']), int(e['history_end']))
    g = np.arange(int(e['gap_start']), int(e['gap_end']))
    if len(h) != 60 or len(g) != 120 or h[-1]+1 != g[0]:
        raise ValueError('Registered case does not match the final H60/G120 protocol.')
    q = np.load(original/'global_data/QC20_Q.npy', mmap_mode='r')
    source_ids = np.load(original/'predictions/source_cache/source_raw_indices.npy')
    exclusions = table(final/'design_review/recommended_source_exclusions.csv')
    excluded = np.array([int(z['raw_index']) for z in exclusions])
    source_ids = source_ids[~np.isin(source_ids, excluded)]
    metadata = table(original/'design/all_station_roles.csv')
    identity = table(experiments/'r4_global_siting_20261026/census/physical_identity_map.csv')
    groups = {int(z['raw_index']): int(z['physical_group_raw_index']) for z in identity}
    own = np.array([i for i, group in groups.items() if group == groups[target]], dtype=int)
    source_lat = np.array([float(metadata[i]['latitude']) for i in source_ids])
    source_lon = np.array([float(metadata[i]['longitude']) for i in source_ids])
    for i in source_ids:
        if int(metadata[i].get('raw_index', i)) != i:
            raise ValueError('Source metadata rows are not in the registered raw-index order.')
    months = np.r_[h, g]
    source_values = np.asarray(q[source_ids[:, None], months[None, :]])
    # Even though guarded by physical identity, never export target-alias G.
    source_values[np.isin(source_ids, own), len(h):] = np.nan
    data = dict(target_history=np.asarray(q[target, h]), source_flows=source_values,
        source_ids=source_ids, target_physical_ids=own,
        source_distances_km=distances(float(e['latitude']), float(e['longitude']),
                                     source_lat, source_lon),
        history_start_month=np.asarray(h[0]), station_id=np.asarray(station_id),
        registered_row=np.asarray(row), provenance=np.asarray('LOCAL_REGISTERED_OBSERVATIONS'))
    with np.load(previous/'prepared_inputs/PRECIPITATION_H_ONLY_INPUTS.npz', allow_pickle=False) as p:
        for name in ('p_h','p_g','p_g_climatology','p_calendar_logmean','p_available','p_reason'):
            data[name] = p[name][row]
    if include_truth:
        data['target_gap_truth'] = np.asarray(q[target, g])
    destination.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(destination, **data)
    receipt = dict(station_id=station_id, registered_row=row,
        history_start=int(h[0]), history_end=int(h[-1]+1),
        gap_start=int(g[0]), gap_end=int(g[-1]+1),
        source_rows=len(source_ids), physical_alias_count=len(own),
        target_gap_truth_exported=include_truth,
        target_alias_gap_reports_removed=True,
        precipitation_features='Frozen H-only preparation; no log inverse/retransform',
        redistribution='Observations remain subject to their source terms; do not commit this export.')
    destination.with_suffix('.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-code', type=Path, required=True,
                        help='Local code directory containing the historical V45 experiments.')
    parser.add_argument('--station-id', default='AR_0000001')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--include-truth', action='store_true',
                        help='Also export held-out target observations for separate local scoring.')
    args = parser.parse_args()
    export(args.project_code, args.station_id, args.output, args.include_truth)
