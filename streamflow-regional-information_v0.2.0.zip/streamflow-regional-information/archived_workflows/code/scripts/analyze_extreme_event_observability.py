# -*- coding: utf-8 -*-
"""Extreme-flow and selective-prediction audit from stored benchmark dumps."""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "results" / "raw"
OUT = ROOT / "results" / "extreme_observability"
MONTH_IDX = pd.date_range("1980-01-01", "2015-12-31", freq="MS")

MONTHLY_PAIRS = {
    "LSTM": ("lstm_single__unc", "lstm_donor__unc"),
    "BRITS": ("brits_single__unc", "brits_donor__unc"),
    "SAITS": ("saits_single__unc", "saits_donor__unc"),
}
DAILY_PAIRS = {
    "LSTM": ("caravan_daily_final_20260809_lstm_single", "caravan_daily_final_20260809_lstm_donor"),
    "BRITS": ("caravan_daily_final_20260809_brits_single", "caravan_daily_final_20260809_brits_donor"),
    "SAITS": ("caravan_daily_final_20260809_saits_single", "caravan_daily_final_20260809_saits_donor"),
}


def load_dump(tag: str) -> pd.DataFrame:
    d = pd.read_csv(RAW / tag / "predictions_long.csv")
    d.columns = [c.strip().lstrip("\ufeff") for c in d.columns]
    return d


def visible_thresholds_monthly(keys: pd.DataFrame) -> pd.DataFrame:
    ids = np.load(ROOT / "recoverability" / "ids.npy", allow_pickle=True).astype(str)
    raw = np.memmap(
        ROOT / "recoverability" / "Z.mm",
        dtype=np.float32,
        mode="r",
        shape=(len(ids), len(MONTH_IDX)),
    )
    sid_to_i = {sid: i for i, sid in enumerate(ids)}
    month_to_i = {date.strftime("%Y-%m"): i for i, date in enumerate(MONTH_IDX)}
    rows = []
    for sid, group in keys.groupby("station_id", sort=False):
        if sid not in sid_to_i:
            continue
        values = np.asarray(raw[sid_to_i[sid]], dtype=float).copy()
        hidden = [month_to_i[x] for x in group["date"].astype(str) if x in month_to_i]
        values[hidden] = np.nan
        values = values[np.isfinite(values)]
        if len(values) < 24:
            continue
        q10, q25, q75, q90 = np.quantile(values, [0.10, 0.25, 0.75, 0.90])
        rows.append((sid, q10, q25, q75, q90))
    return pd.DataFrame(rows, columns=["station_id", "q10", "q25", "q75", "q90"])


def visible_thresholds_daily(keys: pd.DataFrame) -> pd.DataFrame:
    cache = np.load(ROOT / "_cache_caravan_daily.npz", allow_pickle=True)
    raw = cache["flow"]
    ids = cache["sids"].astype(str)
    dates = cache["dates"].astype(str)
    sid_to_i = {sid: i for i, sid in enumerate(ids)}
    date_to_i = {date: i for i, date in enumerate(dates)}
    rows = []
    for sid, group in keys.groupby("station_id", sort=False):
        if sid not in sid_to_i:
            continue
        values = np.asarray(raw[:, sid_to_i[sid]], dtype=float).copy()
        hidden = [date_to_i[x] for x in group["date"].astype(str) if x in date_to_i]
        values[hidden] = np.nan
        values = values[np.isfinite(values)]
        if len(values) < 365:
            continue
        q10, q25, q75, q90 = np.quantile(values, [0.10, 0.25, 0.75, 0.90])
        rows.append((sid, q10, q25, q75, q90))
    return pd.DataFrame(rows, columns=["station_id", "q10", "q25", "q75", "q90"])


def add_daily_gap_ids(d: pd.DataFrame) -> pd.DataFrame:
    d = d.sort_values(["station_id", "date"]).copy()
    dt = pd.to_datetime(d["date"], format="%Y-%m-%d")
    new_gap = d["station_id"].ne(d["station_id"].shift()) | dt.diff().dt.days.ne(1)
    d["gap_id"] = d["station_id"].astype(str) + "_" + new_gap.groupby(d["station_id"]).cumsum().astype(str)
    return d


def f1_score(truth: np.ndarray, predicted: np.ndarray) -> float:
    tp = np.sum(truth & predicted)
    fp = np.sum(~truth & predicted)
    fn = np.sum(truth & ~predicted)
    den = 2 * tp + fp + fn
    return float(2 * tp / den) if den else np.nan


def nse(obs: np.ndarray, pred: np.ndarray) -> float:
    den = np.square(obs - obs.mean()).sum()
    return float(1 - np.square(obs - pred).sum() / den) if len(obs) >= 6 and den > 0 else np.nan


def station_metrics(group: pd.DataFrame, pred_col: str, scale: str) -> dict:
    obs = group["obs"].to_numpy(float)
    pred = np.clip(group[pred_col].to_numpy(float), 0, None)
    valid = np.isfinite(obs) & np.isfinite(pred)
    obs, pred = obs[valid], pred[valid]
    if len(obs) < 12:
        return {}
    q10 = float(group["q10"].iloc[0])
    q90 = float(group["q90"].iloc[0])
    iqr = max(float(group["q75"].iloc[0] - group["q25"].iloc[0]), 1e-6)
    high = obs >= q90
    low = obs <= q10
    pred_high = pred >= q90
    pred_low = pred <= q10
    out = {
        "n": len(obs),
        "n_high": int(high.sum()),
        "n_low": int(low.sum()),
        "nse": nse(obs, pred),
        "high_f1": f1_score(high, pred_high),
        "low_f1": f1_score(low, pred_low),
        "high_nmae": float(np.mean(np.abs(pred[high] - obs[high])) / iqr) if high.any() else np.nan,
        "low_log_mae": float(np.mean(np.abs(np.log1p(pred[low]) - np.log1p(np.clip(obs[low], 0, None))))) if low.any() else np.nan,
        "high_abs_bias": float(abs(np.sum(pred[high] - obs[high]) / np.sum(obs[high]))) if high.any() and np.sum(obs[high]) > 0 else np.nan,
    }
    timings = []
    unit = "D" if scale == "daily" else "M"
    for _, gap in group.loc[valid].groupby("gap_id", sort=False):
        if len(gap) < (7 if scale == "daily" else 3):
            continue
        go = gap["obs"].to_numpy(float)
        gp = gap[pred_col].to_numpy(float)
        if not (np.isfinite(go).all() and np.isfinite(gp).all()):
            continue
        od = gap["_date_dt"].iloc[int(np.argmax(go))]
        pd_ = gap["_date_dt"].iloc[int(np.argmax(gp))]
        if unit == "D":
            timings.append(abs((pd_ - od).days))
        else:
            timings.append(abs((pd_.year - od.year) * 12 + pd_.month - od.month))
    out["peak_timing_error"] = float(np.median(timings)) if timings else np.nan
    return out


def bootstrap_median(values: np.ndarray, seed: int, n_boot: int = 2000):
    values = values[np.isfinite(values)]
    if not len(values):
        return np.nan, np.nan, np.nan
    rng = np.random.default_rng(seed)
    med = float(np.median(values))
    boot = np.median(rng.choice(values, size=(n_boot, len(values)), replace=True), axis=1)
    return med, float(np.quantile(boot, 0.025)), float(np.quantile(boot, 0.975))


def analyse_pairs(scale: str, pairs: dict, thresholds: pd.DataFrame, run_id: str):
    station_rows = []
    summary_rows = []
    error_metrics = {"high_nmae", "low_log_mae", "high_abs_bias", "peak_timing_error"}
    metrics = ["nse", "high_f1", "low_f1", "high_nmae", "low_log_mae", "high_abs_bias", "peak_timing_error"]
    for pair_i, (architecture, (single_tag, donor_tag)) in enumerate(pairs.items()):
        single = load_dump(single_tag)
        donor = load_dump(donor_tag)
        if scale == "daily":
            single = add_daily_gap_ids(single)
            donor = add_daily_gap_ids(donor)
        keys = ["station_id", "date"]
        keep_single = keys + ["obs", "pred", "gap_id"]
        merged = single[keep_single].rename(columns={"pred": "pred_single", "gap_id": "gap_id_single"}).merge(
            donor[keep_single].rename(columns={"obs": "obs_donor", "pred": "pred_donor", "gap_id": "gap_id_donor"}),
            on=keys,
            how="inner",
            validate="one_to_one",
        )
        if not np.allclose(merged["obs"], merged["obs_donor"], equal_nan=True):
            raise AssertionError(f"truth mismatch for {scale} {architecture}")
        merged["gap_id"] = merged["gap_id_single"]
        merged["_date_dt"] = pd.to_datetime(merged["date"] )
        merged = merged.merge(thresholds, on="station_id", how="inner")
        for sid, group in merged.groupby("station_id", sort=False):
            one = station_metrics(group, "pred_single", scale)
            two = station_metrics(group, "pred_donor", scale)
            if not one or not two:
                continue
            row = {"scale": scale, "architecture": architecture, "station_id": sid}
            for metric in metrics:
                row[f"single_{metric}"] = one.get(metric, np.nan)
                row[f"donor_{metric}"] = two.get(metric, np.nan)
                if metric in error_metrics:
                    row[f"improvement_{metric}"] = one.get(metric, np.nan) - two.get(metric, np.nan)
                else:
                    row[f"improvement_{metric}"] = two.get(metric, np.nan) - one.get(metric, np.nan)
            station_rows.append(row)
        station_frame = pd.DataFrame([r for r in station_rows if r["scale"] == scale and r["architecture"] == architecture])
        for metric_i, metric in enumerate(metrics):
            values = station_frame[f"improvement_{metric}"].to_numpy(float)
            med, lo, hi = bootstrap_median(values, 1000 + pair_i * 100 + metric_i)
            summary_rows.append(
                {
                    "scale": scale,
                    "architecture": architecture,
                    "metric": metric,
                    "orientation": "positive = donor-aware better",
                    "n_stations": int(np.isfinite(values).sum()),
                    "median_improvement": med,
                    "ci_lo": lo,
                    "ci_hi": hi,
                    "win_pct": 100.0 * float(np.mean(values[np.isfinite(values)] > 0)),
                }
            )
    return pd.DataFrame(station_rows), pd.DataFrame(summary_rows)


def observability_risk_curve(run_id: str, monthly_thresholds: pd.DataFrame):
    dat = load_dump("stratified_idw")
    dat["_date_dt"] = pd.to_datetime(dat["date"])
    dat = dat.merge(monthly_thresholds, on="station_id", how="inner")
    info = pd.read_csv(
        ROOT / "recoverability" / "review_round2" / f"calibration_features_strict_{run_id}.csv"
    )
    info["rhat2"] = np.clip(info["rhat"], 0, None) ** 2
    rows = []
    for sid, group in dat.groupby("station_id", sort=False):
        metric = station_metrics(group, "pred", "monthly")
        if metric:
            rows.append({"station_id": sid, **metric})
    station = pd.DataFrame(rows).merge(info[["gsim_no", "rhat2"]], left_on="station_id", right_on="gsim_no", how="inner").dropna(subset=["rhat2"])
    station["information_quartile"] = pd.qcut(station["rhat2"], 4, labels=["Q1 lowest", "Q2", "Q3", "Q4 highest"], duplicates="drop")
    quartiles = station.groupby("information_quartile", observed=True).agg(
        n_stations=("station_id", "size"),
        median_rhat2=("rhat2", "median"),
        median_nse=("nse", "median"),
        median_high_f1=("high_f1", "median"),
        median_low_f1=("low_f1", "median"),
        median_high_nmae=("high_nmae", "median"),
        median_low_log_mae=("low_log_mae", "median"),
    ).reset_index()
    risk = []
    station = station.sort_values("rhat2", ascending=False)
    for coverage in [0.25, 0.50, 0.75, 1.00]:
        kept = station.iloc[: max(1, int(np.ceil(len(station) * coverage)))]
        risk.append(
            {
                "retained_fraction": coverage,
                "n_stations": len(kept),
                "minimum_rhat2": kept["rhat2"].min(),
                "median_nse": kept["nse"].median(),
                "median_high_f1": kept["high_f1"].median(),
                "median_low_f1": kept["low_f1"].median(),
                "median_high_nmae": kept["high_nmae"].median(),
                "median_low_log_mae": kept["low_log_mae"].median(),
            }
        )
    return station, quartiles, pd.DataFrame(risk)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)

    monthly_keys = load_dump("lstm_single__unc")[["station_id", "date"]].drop_duplicates()
    daily_keys = load_dump("caravan_daily_final_20260809_lstm_single")[["station_id", "date"]].drop_duplicates()
    monthly_thresholds = visible_thresholds_monthly(monthly_keys)
    daily_thresholds = visible_thresholds_daily(daily_keys)

    ms, mm = analyse_pairs("monthly", MONTHLY_PAIRS, monthly_thresholds, args.run_id)
    ds, dm = analyse_pairs("daily", DAILY_PAIRS, daily_thresholds, args.run_id)
    station = pd.concat([ms, ds], ignore_index=True)
    summary = pd.concat([mm, dm], ignore_index=True)
    obs_station, quartiles, risk = observability_risk_curve(args.run_id, monthly_thresholds)

    station.to_csv(OUT / f"matched_extreme_station_{args.run_id}.csv", index=False)
    summary.to_csv(OUT / f"matched_extreme_summary_{args.run_id}.csv", index=False)
    obs_station.to_csv(OUT / f"monthly_dat_observability_station_{args.run_id}.csv", index=False)
    quartiles.to_csv(OUT / f"monthly_dat_information_quartiles_{args.run_id}.csv", index=False)
    risk.to_csv(OUT / f"monthly_dat_selective_risk_{args.run_id}.csv", index=False)
    print("\nMatched donor-aware improvements (positive = better):")
    print(summary.to_string(index=False))
    print("\nMonthly DAT by visible-information quartile:")
    print(quartiles.to_string(index=False))
    print("\nSelective retention:")
    print(risk.to_string(index=False))


if __name__ == "__main__":
    main()