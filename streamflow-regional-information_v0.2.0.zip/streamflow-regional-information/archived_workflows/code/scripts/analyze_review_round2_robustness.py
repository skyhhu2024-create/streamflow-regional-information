# -*- coding: utf-8 -*-
"""Reviewer-round-2 robustness analyses for the archive-wide claim.

The script deliberately reuses the stored 1980--2015 GSIM matrix and the
published benchmark predictions.  It writes versioned CSV/JSON artefacts only;
it does not overwrite the current manuscript or headline products.

Analyses
--------
1. Recompute donor observability with an exact great-circle neighbour search.
2. One-at-a-time protocol sensitivity for radius, overlap, correlation cut-off,
   and maximum synchronous donor pool size.
3. Compare donor absence during real archive gaps with the benchmark's
   pseudo-gaps at the same evaluation stations.
4. Stratify recoverability by observed record length.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import time
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree


ROOT = Path(__file__).resolve().parents[1]
REC = ROOT / "recoverability"
IDX = pd.date_range("1980-01-01", "2015-12-31", freq="MS")
T = len(IDX)
EARTH_KM = 6371.0


@dataclass(frozen=True)
class Scenario:
    name: str
    radius_km: float = 800.0
    min_overlap: int = 24
    min_corr: float = 0.2
    composite_k: int = 4
    pool_k: int = 8


SCENARIOS = [
    Scenario("radius_400", radius_km=400),
    Scenario("baseline"),
    Scenario("radius_1200", radius_km=1200),
    Scenario("radius_1600", radius_km=1600),
    Scenario("overlap_12", min_overlap=12),
    Scenario("overlap_60", min_overlap=60),
    Scenario("corr_0.0", min_corr=0.0),
    Scenario("corr_0.1", min_corr=0.1),
    Scenario("corr_0.4", min_corr=0.4),
    Scenario("pool_4", pool_k=4),
    Scenario("pool_16", pool_k=16),
]


def nse_by_station(path: Path) -> pd.DataFrame:
    d = pd.read_csv(path, usecols=["station_id", "obs", "pred"])

    def one(g: pd.DataFrame) -> float:
        o = g["obs"].to_numpy(float)
        p = g["pred"].to_numpy(float)
        m = np.isfinite(o) & np.isfinite(p)
        o, p = o[m], p[m]
        if len(o) < 6:
            return np.nan
        den = np.square(o - o.mean()).sum()
        return 1.0 - np.square(o - p).sum() / den if den > 0 else np.nan

    return (
        d.groupby("station_id", sort=False)[["obs", "pred"]]
        .apply(one, include_groups=False)
        .rename("nse_dat")
        .dropna()
        .reset_index()
    )


def monotone_calibration(
    info: pd.DataFrame,
    cal_nse: pd.DataFrame,
    calibration_info: pd.DataFrame | None = None,
):
    feature_source = info if calibration_info is None else calibration_info
    cal = cal_nse.merge(
        feature_source[["gsim_no", "rhat"]],
        left_on="station_id",
        right_on="gsim_no",
    )
    cal["rhat2"] = np.clip(cal["rhat"], 0, None) ** 2
    cal = cal.dropna(subset=["rhat2", "nse_dat"])
    q = np.unique(np.quantile(cal["rhat2"], np.linspace(0, 1, 21)))
    bin_id = np.digitize(cal["rhat2"], q[1:-1])
    xs, ys = [], []
    for b in range(max(len(q) - 1, 0)):
        m = bin_id == b
        if m.sum() >= 10:
            xs.append(float(cal.loc[m, "rhat2"].median()))
            ys.append(float(cal.loc[m, "nse_dat"].median()))
    if len(xs) < 2:
        raise RuntimeError("too few calibration bins")
    xs = np.asarray(xs)
    ys = np.maximum.accumulate(np.asarray(ys))
    return cal, xs, ys


def summarise(
    info: pd.DataFrame,
    meta: pd.DataFrame,
    cal_nse: pd.DataFrame,
    scenario: Scenario,
    calibration_info: pd.DataFrame | None = None,
):
    d = info.merge(meta, on="gsim_no", how="left")
    cal_source = calibration_info
    if cal_source is not None:
        cal_source = cal_source.merge(meta, on="gsim_no", how="left")
    cal, xs, ys = monotone_calibration(d, cal_nse, cal_source)
    d["rhat2"] = np.clip(d["rhat"], 0, None) ** 2
    d["pred_nse"] = np.interp(d["rhat2"], xs, ys, left=ys[0], right=ys[-1])
    d.loc[d["rhat2"].isna(), "pred_nse"] = np.nan
    a = d[d["n_valid"] > 0].copy()
    a["n_miss_covered"] = a["n_miss_covered"].fillna(0)
    no_info = a["pred_nse"].isna()
    a["mm_no_info"] = np.where(no_info, a["n_missing"], 0)
    a["mm_uncov"] = np.where(~no_info, a["n_missing"] - a["n_miss_covered"], 0)
    covered = np.where(~no_info, a["n_miss_covered"], 0)
    a["mm_high"] = np.where(a["pred_nse"] >= 0.8, covered, 0)
    a["mm_mod"] = np.where(
        (a["pred_nse"] >= 0.5) & (a["pred_nse"] < 0.8), covered, 0
    )
    a["mm_poor"] = np.where(a["pred_nse"] < 0.5, covered, 0)

    rows = []
    for region, g in [("Global", a), *list(a.groupby("continent", dropna=False))]:
        total = float(g["n_missing"].sum())
        if total <= 0:
            continue
        unsupported = float((g["mm_no_info"] + g["mm_uncov"]).sum())
        good = float((g["mm_high"] + g["mm_mod"]).sum())
        rows.append(
            {
                **asdict(scenario),
                "region": str(region),
                "n_active_stations": int(len(g)),
                "n_calibration_stations": int(len(cal)),
                "missing_months": int(total),
                "unsupported_pct": 100 * unsupported / total,
                "pred_nse_ge_0_5_pct": 100 * good / total,
                "pred_nse_ge_0_8_pct": 100 * float(g["mm_high"].sum()) / total,
            }
        )
    return pd.DataFrame(rows), a, {"x": xs.tolist(), "y": ys.tolist(), "n": len(cal)}


def xyz(lat: np.ndarray, lon: np.ndarray) -> np.ndarray:
    la, lo = np.radians(lat), np.radians(lon)
    return np.column_stack((np.cos(la) * np.cos(lo), np.cos(la) * np.sin(lo), np.sin(la)))


def chord(radius_km: float) -> float:
    return 2.0 * math.sin(radius_km / (2.0 * EARTH_KM))


def great_circle_km(v1: np.ndarray, v2: np.ndarray) -> np.ndarray:
    dots = np.clip(v2 @ v1, -1.0, 1.0)
    return EARTH_KM * np.arccos(dots)


def prepare_matrix(ids: np.ndarray):
    z = np.memmap(REC / "Z.mm", dtype=np.float32, mode="r", shape=(len(ids), T))
    z = np.asarray(z)
    logz = np.log1p(np.maximum(z, 0)).astype(np.float32)
    logz[~np.isfinite(z)] = np.nan
    ly = logz.reshape(len(ids), T // 12, 12)
    clim = np.nanmean(ly, axis=1)
    za = (ly - clim[:, None, :]).reshape(len(ids), T)
    sd = np.nanstd(za, axis=1)
    sd[sd == 0] = np.nan
    zn = za / sd[:, None]
    vis = np.isfinite(zn)
    zn0 = np.where(vis, zn, 0.0).astype(np.float32)
    return z, zn, zn0, vis


def strict_target_standardize(raw: np.ndarray, excluded_t: np.ndarray):
    """Build target anomalies without using pseudo-gap truth.

    Excluded values are absent from both the monthly climatology/scale fit and
    the visible target series. Observations before and after an interior gap
    remain available, matching the retrospective reconstruction setting.
    """
    raw = np.asarray(raw, dtype=float)
    fit = np.isfinite(raw)
    excluded_t = np.asarray(excluded_t, dtype=int)
    excluded_t = excluded_t[(excluded_t >= 0) & (excluded_t < len(raw))]
    fit[excluded_t] = False

    logq = np.full(len(raw), np.nan, dtype=float)
    finite = np.isfinite(raw)
    logq[finite] = np.log1p(np.maximum(raw[finite], 0.0))
    month = np.arange(len(raw), dtype=int) % 12
    clim = np.full(12, np.nan, dtype=float)
    for m in range(12):
        values = logq[fit & (month == m)]
        if len(values):
            clim[m] = float(np.mean(values))
    anomaly = logq - clim[month]
    scale = float(np.nanstd(anomaly[fit]))
    if not np.isfinite(scale) or scale <= 0:
        return np.full(len(raw), np.nan), np.zeros(len(raw), dtype=bool)
    z = anomaly / scale
    visible = fit & np.isfinite(z)
    z[~visible] = np.nan
    return z, visible


def correlations(
    j: int,
    cand: np.ndarray,
    zn0: np.ndarray,
    vis: np.ndarray,
    target_z: np.ndarray | None = None,
    target_vis: np.ndarray | None = None,
):
    tv = vis[j] if target_vis is None else target_vis
    tz = zn0[j] if target_z is None else np.nan_to_num(target_z, nan=0.0)
    mask = vis[cand] & tv
    n = mask.sum(axis=1).astype(np.float32)
    xz = zn0[cand]
    sx = (xz * mask).sum(axis=1)
    sy = (tz * mask).sum(axis=1)
    sxx = (xz * xz * mask).sum(axis=1)
    syy = (tz * tz * mask).sum(axis=1)
    sxy = (xz * tz * mask).sum(axis=1)
    with np.errstate(invalid="ignore", divide="ignore"):
        cov = sxy - sx * sy / np.maximum(n, 1)
        vx = sxx - sx * sx / np.maximum(n, 1)
        vy = syy - sy * sy / np.maximum(n, 1)
        r = cov / np.sqrt(np.maximum(vx * vy, 1e-12))
    return n, r


def scenario_information(
    target_z: np.ndarray,
    target_vis: np.ndarray,
    cand: np.ndarray,
    dist: np.ndarray,
    overlap: np.ndarray,
    corr: np.ndarray,
    scenario: Scenario,
    zn0: np.ndarray,
    vis: np.ndarray,
):
    within = dist <= scenario.radius_km + 1e-8
    eligible = np.where(
        within
        & (overlap >= scenario.min_overlap)
        & np.isfinite(corr)
        & (corr >= scenario.min_corr)
    )[0]
    n_cand = int(within.sum())
    if len(eligible) == 0:
        return n_cand, 0, np.nan, np.nan, np.empty(0, dtype=int)
    order = eligible[np.argsort(-corr[eligible])]
    top = cand[order[: scenario.composite_k]]
    pool = cand[order[: scenario.pool_k]]
    count = vis[top].sum(axis=0)
    comp = np.where(
        count > 0,
        zn0[top].sum(axis=0) / np.maximum(count, 1),
        np.nan,
    )
    matched = target_vis & (count > 0)
    rhat = (
        float(np.corrcoef(comp[matched], target_z[matched])[0, 1])
        if matched.sum() >= scenario.min_overlap
        else np.nan
    )
    return n_cand, int(len(eligible)), float(corr[order[0]]), rhat, pool


def run(args):
    out_dir = REC / "review_round2"
    out_dir.mkdir(parents=True, exist_ok=True)
    tag = args.run_id
    ids = np.load(REC / "ids.npy", allow_pickle=True).astype(str)
    meta0 = pd.read_csv(ROOT / "global_station_meta_kg.csv")
    meta = meta0.rename(columns={"gsim.no": "gsim_no"}).copy()
    pos = meta.set_index("gsim_no").reindex(ids)
    lat = pos["latitude"].to_numpy(float)
    lon = pos["longitude"].to_numpy(float)
    ok = np.isfinite(lat) & np.isfinite(lon)
    vec = np.full((len(ids), 3), np.nan)
    vec[ok] = xyz(lat[ok], lon[ok])
    tree_idx = np.where(ok)[0]
    tree = cKDTree(vec[tree_idx])
    raw, zn, zn0, vis = prepare_matrix(ids)
    n_valid = vis.sum(axis=1)
    n_missing = (~vis).sum(axis=1)
    cal_nse = nse_by_station(ROOT / "results/raw/stratified_idw/predictions_long.csv")

    # Pseudo-gap keys define both the strict calibration mask and the
    # baseline real-vs-pseudo coverage audit.
    pseudo = pd.read_csv(
        ROOT / "results/raw/stratified_idw/predictions_long.csv",
        usecols=["station_id", "date"],
    ).drop_duplicates()
    pseudo["t"] = (
        (pd.to_datetime(pseudo["date"]).dt.year - IDX[0].year) * 12
        + pd.to_datetime(pseudo["date"]).dt.month
        - 1
    )
    pseudo_t = {
        k: g["t"].to_numpy(int) for k, g in pseudo.groupby("station_id", sort=False)
    }

    scenario_rows = {s.name: [] for s in SCENARIOS}
    strict_calibration_rows = {s.name: [] for s in SCENARIOS}
    pseudo_rows = []
    global_baseline_pool = {}
    audit_baseline_pool = {}
    t0 = time.time()
    max_radius = max(s.radius_km for s in SCENARIOS)

    for j in range(len(ids)):
        sid = ids[j]
        base = [sid, int(n_valid[j]), int(n_missing[j])]
        pt = pseudo_t.get(sid)
        if pt is not None:
            pt = np.unique(pt[(pt >= 0) & (pt < T)])
            strict_z, strict_vis = strict_target_standardize(raw[j], pt)
        else:
            strict_z, strict_vis = None, None

        if not ok[j] or n_valid[j] < min(s.min_overlap for s in SCENARIOS):
            for scenario in SCENARIOS:
                scenario_rows[scenario.name].append(base + [0, 0, np.nan, np.nan, 0])
                if pt is not None:
                    strict_calibration_rows[scenario.name].append(
                        [sid, np.nan, 0, np.nan, int(strict_vis.sum())]
                    )
            continue

        query = tree.query_ball_point(vec[j], r=chord(max_radius))
        cand = tree_idx[np.asarray(query, dtype=int)]
        cand = cand[cand != j]
        if len(cand):
            dist = great_circle_km(vec[j], vec[cand])
            keep = dist <= max_radius + 1e-8
            cand, dist = cand[keep], dist[keep]
            if len(cand) > 200:
                nearest = np.argsort(dist)[:200]
                cand, dist = cand[nearest], dist[nearest]
            overlap, corr = correlations(j, cand, zn0, vis)
            if pt is not None:
                strict_overlap, strict_corr = correlations(
                    j,
                    cand,
                    zn0,
                    vis,
                    target_z=strict_z,
                    target_vis=strict_vis,
                )
        else:
            dist = np.empty(0)
            overlap = np.empty(0)
            corr = np.empty(0)
            strict_overlap = np.empty(0)
            strict_corr = np.empty(0)

        for scenario in SCENARIOS:
            n_cand, n_elig, r_best, rhat, pool = scenario_information(
                zn[j], vis[j], cand, dist, overlap, corr, scenario, zn0, vis
            )
            missing = ~vis[j]
            n_cov = (
                int((missing & (vis[pool].sum(axis=0) > 0)).sum())
                if len(pool)
                else 0
            )
            scenario_rows[scenario.name].append(
                base + [n_cand, n_elig, r_best, rhat, n_cov]
            )

            audit_pool = pool
            if pt is not None:
                _, strict_n_elig, strict_r_best, strict_rhat, audit_pool = scenario_information(
                    strict_z,
                    strict_vis,
                    cand,
                    dist,
                    strict_overlap,
                    strict_corr,
                    scenario,
                    zn0,
                    vis,
                )
                strict_calibration_rows[scenario.name].append(
                    [sid, strict_rhat, strict_n_elig, strict_r_best, int(strict_vis.sum())]
                )
            if scenario.name == "baseline":
                global_baseline_pool[sid] = pool.copy()
                audit_baseline_pool[sid] = audit_pool.copy()

        if pt is not None:
            pool = audit_baseline_pool.get(sid, np.empty(0, dtype=int))
            pseudo_covered = (
                int((vis[pool][:, pt].sum(axis=0) > 0).sum())
                if len(pool) and len(pt)
                else 0
            )
            real = ~vis[j]
            real_covered = (
                int((real & (vis[pool].sum(axis=0) > 0)).sum()) if len(pool) else 0
            )
            pseudo_rows.append(
                {
                    "station_id": sid,
                    "n_pseudo_gap_months": int(len(pt)),
                    "n_pseudo_covered": pseudo_covered,
                    "n_real_missing_months": int(real.sum()),
                    "n_real_covered": real_covered,
                    "n_valid": int(n_valid[j]),
                    "has_eligible_donor": int(len(pool) > 0),
                    "selection_mode": "pseudo-gap-excluded retrospective",
                }
            )

        if j % 1000 == 0:
            print(f"[donors] {j}/{len(ids)} elapsed={time.time()-t0:.0f}s", flush=True)

    edge_rows = []
    for target_id, pool in global_baseline_pool.items():
        for rank, donor_index in enumerate(pool, start=1):
            edge_rows.append(
                {
                    "target_id": target_id,
                    "donor_id": ids[donor_index],
                    "donor_rank": rank,
                }
            )
    pd.DataFrame(edge_rows).to_csv(
        out_dir / f"baseline_pool_edges_{tag}.csv", index=False
    )

    cols = [
        "gsim_no", "n_valid", "n_missing", "n_cand", "n_elig",
        "r_best", "rhat", "n_miss_covered",
    ]
    strict_cols = ["gsim_no", "rhat", "n_elig", "r_best", "n_visible_strict"]
    all_summary, legacy_summaries, all_active = [], [], {}
    curves = {"strict_pseudogap_excluded": {}, "legacy_full_record": {}}
    for scenario in SCENARIOS:
        info = pd.DataFrame(scenario_rows[scenario.name], columns=cols)
        info["cov_frac"] = info["n_miss_covered"] / info["n_missing"].clip(lower=1)
        strict_info = pd.DataFrame(
            strict_calibration_rows[scenario.name], columns=strict_cols
        )

        summary, active, curve = summarise(
            info,
            meta,
            cal_nse,
            scenario,
            calibration_info=strict_info,
        )
        summary["calibration_mode"] = "pseudo-gap-excluded retrospective"
        legacy_summary, _, legacy_curve = summarise(
            info,
            meta,
            cal_nse,
            scenario,
            calibration_info=info[["gsim_no", "rhat"]],
        )
        legacy_summary["calibration_mode"] = "legacy full record"
        all_summary.append(summary)
        legacy_summaries.append(legacy_summary)
        curves["strict_pseudogap_excluded"][scenario.name] = curve
        curves["legacy_full_record"][scenario.name] = legacy_curve
        if scenario.name == "baseline":
            all_active[scenario.name] = active
            info.to_csv(out_dir / f"baseline_exact_stations_{tag}.csv", index=False)
            active.to_csv(
                out_dir / f"global_recoverability_strict_{tag}.csv", index=False
            )
            strict_info.to_csv(
                out_dir / f"calibration_features_strict_{tag}.csv", index=False
            )
            total_missing = float(active["n_missing"].sum())
            category_counts = pd.DataFrame(
                [
                    {"category": "high_fidelity", "station_months": int(active["mm_high"].sum())},
                    {"category": "useful", "station_months": int(active["mm_mod"].sum())},
                    {"category": "covered_low_skill", "station_months": int(active["mm_poor"].sum())},
                    {"category": "unsupported", "station_months": int((active["mm_no_info"] + active["mm_uncov"]).sum())},
                ]
            )
            category_counts["denominator_station_months"] = int(total_missing)
            category_counts["percent"] = 100.0 * category_counts["station_months"] / total_missing
            category_counts["run_id"] = tag
            category_counts["calibration_mode"] = "pseudo-gap-excluded retrospective"
            category_counts.to_csv(
                out_dir / f"archive_category_counts_{tag}.csv", index=False
            )

    summary = pd.concat(all_summary, ignore_index=True)
    legacy_summary = pd.concat(legacy_summaries, ignore_index=True)
    summary.to_csv(out_dir / f"protocol_sensitivity_{tag}.csv", index=False)
    legacy_summary.to_csv(
        out_dir / f"protocol_sensitivity_legacy_{tag}.csv", index=False
    )
    (out_dir / f"calibration_curves_{tag}.json").write_text(
        json.dumps(curves, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    sync = pd.DataFrame(pseudo_rows)
    sync.to_csv(out_dir / f"real_vs_pseudogap_stations_{tag}.csv", index=False)
    sync_summary = pd.DataFrame(
        [
            {
                "gap_type": "benchmark pseudo-gaps",
                "n_stations": len(sync),
                "n_months": int(sync["n_pseudo_gap_months"].sum()),
                "donor_absent_pct": 100
                * (1 - sync["n_pseudo_covered"].sum() / sync["n_pseudo_gap_months"].sum()),
            },
            {
                "gap_type": "real archive gaps at benchmark stations",
                "n_stations": int((sync["n_real_missing_months"] > 0).sum()),
                "n_months": int(sync["n_real_missing_months"].sum()),
                "donor_absent_pct": 100
                * (1 - sync["n_real_covered"].sum() / sync["n_real_missing_months"].sum()),
            },
        ]
    )
    sync_summary.to_csv(out_dir / f"real_vs_pseudogap_summary_{tag}.csv", index=False)

    active = all_active["baseline"].copy()
    active["record_bin"] = pd.cut(
        active["n_valid"],
        bins=[0, 59, 119, 239, 359, 431, np.inf],
        labels=["1-59", "60-119", "120-239", "240-359", "360-431", "432"],
        include_lowest=True,
    )
    rec_rows = []
    for label, g in active.groupby("record_bin", observed=True):
        total = g["n_missing"].sum()
        unsupported = (g["mm_no_info"] + g["mm_uncov"]).sum()
        good = (g["mm_high"] + g["mm_mod"]).sum()
        rec_rows.append(
            {
                "record_bin_observed_months": str(label),
                "n_stations": len(g),
                "missing_months": int(total),
                "unsupported_pct": 100 * unsupported / total if total else np.nan,
                "pred_nse_ge_0_5_pct": 100 * good / total if total else np.nan,
            }
        )
    pd.DataFrame(rec_rows).to_csv(out_dir / f"record_length_strata_{tag}.csv", index=False)

    print("\nProtocol sensitivity (headline regions):")
    print(
        summary[summary["region"].isin(["Global", "Africa", "Asia"])]
        [["name", "region", "unsupported_pct", "pred_nse_ge_0_5_pct", "n_calibration_stations"]]
        .to_string(index=False)
    )
    print("\nReal-vs-pseudo donor absence:")
    print(sync_summary.to_string(index=False))
    print(f"\n[DONE] {out_dir}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--run-id", default="20260814")
    args = p.parse_args()
    run(args)


if __name__ == "__main__":
    main()
