# -*- coding: utf-8 -*-
"""
跑所有经典基准（论文 5.6.2 对照表），无 torch 依赖，可直接本地运行得到真实数字。

  python scripts/run_baselines.py --series_dir <月序列目录> --static <静态表csv> [--limit N]

输出：测试集上各基准的 逐站 NSE/KGE 中位数、变率比 alpha 中位数、峰值段 NSE(逐站中位数+池化)。
"""
from __future__ import annotations
import os, sys, argparse
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.data.gsim_io import load_station_matrix, load_static
from src.data.dedup_gsim import drop_gsim_twins
from src.data.dataset import GapImputationDataset, split_stations
from src.baselines.classical import ALL_BASELINES
from src.utils.metrics import evaluate_by_station


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--series_dir", required=True)
    ap.add_argument("--static", default=None)
    ap.add_argument("--start", default="1980-01-01")
    ap.add_argument("--end", default="2015-12-31")
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--out", default="results_baselines.csv")
    ap.add_argument("--no_dedup", action="store_true",
                    help="不剔除 GSIM 孪生站（默认剔除，见 gsim_near_duplicates_checked.csv）")
    args = ap.parse_args()

    cfg = {
        "features": {"use_log1p": True, "deseasonalize": True, "per_station_standardize": True},
        "pseudo_gap": {"seed": 42, "gaps_per_station": 4,
                       "length_strata": [[1, 3], [4, 12], [13, 36]],
                       "min_context": 12, "edge_margin": 6},
        "donors": {"max_donors": 8, "max_distance_km": 800, "min_overlap_months": 24,
                   "min_precorr": 0.2, "precorr_window": 60},
        "split": {"test_station_frac": 0.15, "val_station_frac": 0.15, "seed": 7},
        "train": {"seq_pad": 6, "batch_size": 32},
    }
    flow = load_station_matrix(args.series_dir, args.start, args.end,
                               min_valid_months=60, min_days_available=20, limit=args.limit)
    if not args.no_dedup:
        flow = drop_gsim_twins(flow)
    static = (load_static(args.static) if (args.static and os.path.exists(args.static))
              else pd.DataFrame(index=flow.columns))
    _, _, test_s = split_stations(flow.columns, cfg["split"])
    ds = GapImputationDataset(flow, static, cfg)
    te = [g for g in ds.gaps if g.station_id in test_s]
    print(f">> 测试缺口数={len(te)}  站点数={len(test_s)}")

    rows = []
    for name, fn in ALL_BASELINES.items():
        obs_by, pred_by = {}, {}
        for gap in te:
            truth = ds.flow[gap.start:gap.end + 1, ds.station_ids.index(gap.station_id)]
            ok = np.isfinite(truth)
            if ok.sum() < 2:
                continue
            try:
                pred = fn(ds, gap)
            except Exception:
                continue
            sid = gap.station_id
            obs_by.setdefault(sid, []).append(truth[ok])
            pred_by.setdefault(sid, []).append(np.asarray(pred)[ok])
        obs_by = {k: np.concatenate(v) for k, v in obs_by.items()}
        pred_by = {k: np.concatenate(v) for k, v in pred_by.items()}
        _, s = evaluate_by_station(obs_by, pred_by, peak_quantile=0.9)
        rows.append({
            "method": name,
            "NSE_med": s.get("NSE_median", np.nan),
            "KGE_med": s.get("KGE_median", np.nan),
            "alpha_med": s.get("alpha_median", np.nan),
            "peakNSE_med": s.get("peak_NSE_median", np.nan),
            "peakNSE_pool": s.get("peak_NSE_pooled", np.nan),
            "n_stations": s.get("n_stations", 0),
        })

    df = pd.DataFrame(rows)
    pd.set_option("display.width", 140)
    print("\n===== 经典基准对照表（测试集）=====")
    print(df.to_string(index=False,
          formatters={c: (lambda x: f"{x:.3f}") for c in
                      ["NSE_med", "KGE_med", "alpha_med", "peakNSE_med", "peakNSE_pool"]}))
    df.to_csv(args.out, index=False)
    print(f"\n[OK] 已保存 {args.out}")
    print("注：MG-STGAI(两阶段)请用 train_full.py 结果填入同一表对比。")


if __name__ == "__main__":
    main()
