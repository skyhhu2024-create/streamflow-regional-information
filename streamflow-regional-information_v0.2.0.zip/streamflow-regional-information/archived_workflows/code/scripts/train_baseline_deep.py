# -*- coding: utf-8 -*-
"""
Unified trainer for deep baselines, same leakage-safe protocol + per-station eval.

  python scripts/train_baseline_deep.py --model lstm|brits|saits|grin \
         --series_dir <dir> --static <csv> [--use_donor] [--epochs 50] [--limit 400] [--smoke]

Loss = masked Huber on target anomaly z (+ bidirectional consistency for brits).
Reports test-set per-station NSE/KGE/alpha medians and peak-segment NSE,
directly comparable to MG-STGAI and the classical baselines.
"""
from __future__ import annotations
import os, sys, argparse, time, csv, re
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.data.gsim_io import load_station_matrix, load_static
from src.data.dedup_gsim import drop_gsim_twins
from src.data.dataset import GapImputationDataset, split_stations
from src.train.collate import collate_numpy, to_torch
from src.utils.metrics import evaluate_by_station, nse
from src.utils.results_log import append_result, save_run_outputs


def make_cfg(smoke, leak_mode="none"):
    return {
        "features": {"use_log1p": True, "deseasonalize": True,
                     "per_station_standardize": True, "leak_mode": leak_mode},
        "pseudo_gap": {"seed": 42, "gaps_per_station": 2 if smoke else 4,
                       "length_strata": [[1, 3], [4, 12], [13, 36]],
                       "min_context": 12, "edge_margin": 6},
        "donors": {"max_donors": 8, "max_distance_km": 800, "min_overlap_months": 24,
                   "min_precorr": 0.2, "precorr_window": 60},
        "split": {"test_station_frac": 0.15, "val_station_frac": 0.15, "seed": 7},
        "train": {"seq_pad": 6, "batch_size": 32},
    }


def iter_batches(ds, indices, bs, seq_pad, shuffle=True, rng=None):
    idx = list(indices)
    if shuffle:
        (rng or np.random).shuffle(idx)
    for i in range(0, len(idx), bs):
        yield collate_numpy([ds[j] for j in idx[i:i + bs]], seq_pad)


def masked_huber(z_hat, batch):
    import torch
    import torch.nn.functional as F
    z = batch["target_z"]; mask = batch["gap_mask"] * batch["target_valid"]
    h = F.huber_loss(z_hat, z, delta=1.0, reduction="none")
    return (h * mask).sum() / mask.sum().clamp(min=1.0)


def masked_gaussian_nll(z_hat, log_var, batch):
    """Heteroscedastic Gaussian negative log-likelihood in anomaly space (same form as MG-STGAI)."""
    import torch
    z = batch["target_z"]; mask = batch["gap_mask"] * batch["target_valid"]
    s = log_var.clamp(-6.0, 4.0)
    nll = 0.5 * (torch.exp(-s) * (z - z_hat) ** 2 + s)
    return (nll * mask).sum() / mask.sum().clamp(min=1.0)


def evaluate(model, ds, indices, cfg, device, collect=False):
    import torch
    model.eval()
    obs_by, pred_by = {}, {}
    records = []
    with torch.no_grad():
        for batch_np, meta in iter_batches(ds, indices, cfg["train"]["batch_size"],
                                           cfg["train"]["seq_pad"], shuffle=False):
            batch = to_torch(batch_np, device)
            out = model(batch)
            z_hat = out["z_hat"].cpu().numpy()
            has_lv = "log_var" in out
            log_var = out["log_var"].cpu().numpy() if has_lv else None
            for bi, m in enumerate(meta):
                L = m["length"]; tr = m["transformer"]
                fh = tr.inverse_transform(z_hat[bi, :L], m["gap_months"])
                if has_lv:                                     # native flow-space predictive std
                    sig_z = np.exp(0.5 * np.clip(log_var[bi, :L], -6.0, 4.0))
                    _hi = tr.inverse_transform(z_hat[bi, :L] + sig_z, m["gap_months"])
                    _lo = tr.inverse_transform(z_hat[bi, :L] - sig_z, m["gap_months"])
                    sig_flow = 0.5 * np.abs(_hi - _lo)
                truth = m["gap_truth_flow"]; ok = np.isfinite(truth)
                if ok.sum() < 2:
                    continue
                sid = m["station_id"]
                obs_by.setdefault(sid, []).append(truth[ok])
                pred_by.setdefault(sid, []).append(fh[ok])
                if collect:
                    dates = m.get("gap_dates") or [""] * L
                    for t in range(L):
                        if not np.isfinite(truth[t]):
                            continue
                        rec = {"station_id": sid, "date": dates[t],
                               "obs": float(truth[t]), "pred": float(fh[t]),
                               "stratum": m.get("stratum", ""),
                               "gap_id": "%s_%s" % (sid, dates[0] if dates else "")}
                        if has_lv:
                            rec["sigma"] = float(sig_flow[t])
                        records.append(rec)
    if not obs_by:
        return ({}, None, []) if collect else {}
    obs_by = {k: np.concatenate(v) for k, v in obs_by.items()}
    pred_by = {k: np.concatenate(v) for k, v in pred_by.items()}
    df, s2 = evaluate_by_station(obs_by, pred_by, peak_quantile=0.9)
    if collect:
        return s2, df, records
    return s2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, choices=["lstm", "brits", "saits", "grin"])
    ap.add_argument("--series_dir", required=True)
    ap.add_argument("--static", default=None)
    ap.add_argument("--start", default="1980-01-01")
    ap.add_argument("--end", default="2015-12-31")
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--hidden", type=int, default=64)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--use_donor", action="store_true")
    ap.add_argument("--uncertainty", action="store_true",
                    help="add native heteroscedastic Gaussian-NLL head and emit per-value sigma (flow space)")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--patience", type=int, default=10,
                    help="early-stopping patience on validation loss (epochs)")
    ap.add_argument("--no_early_stop", action="store_true", help="disable validation early stopping")
    ap.add_argument("--leak_mode", choices=["none", "mean", "var", "both"], default="none")
    ap.add_argument("--run_id", default=None,
                    help="isolated audit tag used for paired strict/leaky reruns")
    ap.add_argument("--out", default="results_full", help="checkpoint and training-curve directory")
    ap.add_argument("--folds", default=None, help="region-disjoint fold CSV from exp_spatial_split.py")
    ap.add_argument("--scheme", default="koppen_LOO", help="koppen_LOO or continent_LOO")
    ap.add_argument("--held_out", default=None, help="held-out group value (e.g. B, or Africa)")
    args = ap.parse_args()

    import torch
    from src.models.baselines_deep import get_model
    np.random.seed(args.seed); torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    torch.use_deterministic_algorithms(True, warn_only=True)
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.benchmark = False
    device = "cuda" if torch.cuda.is_available() else "cpu"
    use_donor = args.use_donor or args.model == "grin"
    run_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", args.run_id).strip("_") if args.run_id else None
    print(">> device=%s  model=%s  use_donor=%s  leak_mode=%s  seed=%d" %
          (device, args.model, use_donor, args.leak_mode, args.seed))

    cfg = make_cfg(args.smoke, args.leak_mode)
    if args.smoke:
        args.epochs = min(args.epochs, 6); args.limit = args.limit or 200

    flow = load_station_matrix(args.series_dir, args.start, args.end,
                               min_valid_months=60, min_days_available=20, limit=args.limit)
    flow = drop_gsim_twins(flow)
    static = (load_static(args.static) if (args.static and os.path.exists(args.static))
              else pd.DataFrame(index=flow.columns))
    train_s, val_s, test_s = split_stations(flow.columns, cfg["split"])
    if args.folds and args.held_out:                       # region-disjoint (leave-one-group-out)
        fd = pd.read_csv(args.folds)
        fd = fd[(fd["scheme"] == args.scheme) & (fd["held_out_group"].astype(str) == str(args.held_out))]
        present = set(flow.columns)
        test_s = set(fd[fd["role"] == "test"]["gsim_no"]) & present
        pool = [s for s in fd[fd["role"] == "train"]["gsim_no"] if s in present]
        _rng = np.random.default_rng(cfg["split"].get("seed", 7)); _rng.shuffle(pool)
        _nval = int(len(pool) * cfg["split"].get("val_station_frac", 0.15))
        val_s = set(pool[:_nval]); train_s = set(pool[_nval:])
        print("   [region-disjoint] scheme=%s held_out=%s" % (args.scheme, args.held_out))
    ds = GapImputationDataset(flow, static, cfg)
    tr = [i for i, g in enumerate(ds.gaps) if g.station_id in train_s]
    va = [i for i, g in enumerate(ds.gaps) if g.station_id in val_s]
    te = [i for i, g in enumerate(ds.gaps) if g.station_id in test_s]
    print("   samples train/val/test = %d/%d/%d" % (len(tr), len(va), len(te)))
    if not tr:
        print("   no training samples."); return

    model = get_model(args.model, hidden=args.hidden, use_donor=use_donor).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    rng = np.random.default_rng(args.seed)

    def batch_loss(out, batch):
        loss = masked_huber(out["z_hat"], batch)
        if "z_self_f" in out:   # brits bidirectional consistency
            bi = ((out["z_self_f"] - out["z_self_b"]) ** 2 * batch["gap_mask"]).sum() \
                 / batch["gap_mask"].sum().clamp(min=1.0)
            loss = loss + 0.3 * bi
        if args.uncertainty and "log_var" in out:   # native heteroscedastic head
            loss = loss + 0.5 * masked_gaussian_nll(out["z_hat"], out["log_var"], batch)
        return loss

    def val_loss():
        import torch
        if not va:
            return None
        model.eval(); vt = 0.0; vn = 0
        with torch.no_grad():
            for batch_np, _ in iter_batches(ds, va, cfg["train"]["batch_size"],
                                            cfg["train"]["seq_pad"], shuffle=False):
                batch = to_torch(batch_np, device)
                vt += float(batch_loss(model(batch), batch).detach()); vn += 1
        return vt / max(vn, 1)

    best_val = float("inf"); best_state = None; bad = 0; history = []
    for ep in range(1, args.epochs + 1):
        model.train(); t0 = time.time(); tot = 0.0; nb = 0
        for batch_np, _ in iter_batches(ds, tr, cfg["train"]["batch_size"],
                                        cfg["train"]["seq_pad"], shuffle=True, rng=rng):
            batch = to_torch(batch_np, device)
            loss = batch_loss(model(batch), batch)
            opt.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step(); tot += float(loss.detach()); nb += 1
        vloss = val_loss()
        history.append({"epoch": ep, "train_loss": tot / max(nb, 1),
                        "val_loss": vloss if vloss is not None else ""})
        if ep % max(1, args.epochs // 4) == 0 or ep == args.epochs:
            print("[ep %02d] train=%.4f val=%s %.1fs" % (
                ep, tot / max(nb, 1), ("%.4f" % vloss) if vloss is not None else "n/a",
                time.time() - t0))
        if (not args.no_early_stop) and (vloss is not None):
            if vloss < best_val - 1e-5:
                best_val = vloss; bad = 0
                best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            else:
                bad += 1
                if bad >= args.patience:
                    print("   early stop at ep %d (best val=%.4f)" % (ep, best_val)); break
    if best_state is not None:
        model.load_state_dict(best_state)
        print("   restored best-val checkpoint (val loss=%.4f)" % best_val)

    s, df_raw, records = evaluate(model, ds, te, cfg, device, collect=True)
    _root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    _unc = '_unc' if args.uncertainty else ''
    _rd = ('_rd_%s_%s' % (args.scheme.replace('_LOO', ''), args.held_out)) if (args.folds and args.held_out) else ''
    if run_id:
        output_tag = "leakage_%s_%s_%s" % (run_id, args.model, args.leak_mode)
    else:
        _lk = '' if args.leak_mode == 'none' else '_leak_%s' % args.leak_mode
        output_tag = '%s(%s)%s%s%s' % (args.model, 'donor' if use_donor else 'single', _unc, _rd, _lk)
    summary = dict(s, epochs=args.epochs, limit=(args.limit or 'all'), model=args.model,
                   use_donor=use_donor, uncertainty=args.uncertainty,
                   leak_mode=args.leak_mode, run_id=run_id or '', seed=args.seed,
                   early_stopping=('disabled' if args.no_early_stop else 'validation_loss'),
                   patience=args.patience, learning_rate=args.lr, hidden=args.hidden,
                   start=args.start, end=args.end, config=cfg,
                   n_prediction_rows=len(records), n_train_gaps=len(tr),
                   n_val_gaps=len(va), n_test_gaps=len(te))
    save_run_outputs(_root, output_tag, records, df_raw, summary)
    os.makedirs(args.out, exist_ok=True)
    curve = os.path.join(args.out, "train_curve_%s.csv" % output_tag)
    with open(curve, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["epoch", "train_loss", "val_loss"])
        w.writeheader(); w.writerows(history)
    checkpoint = os.path.join(args.out, "%s.pth" % output_tag)
    torch.save({"model": model.state_dict(), "model_name": args.model,
                "hidden": args.hidden, "use_donor": use_donor,
                "uncertainty": args.uncertainty, "leak_mode": args.leak_mode,
                "run_id": run_id, "seed": args.seed, "config": cfg,
                "summary": s}, checkpoint)
    print("[saved] curve -> %s" % curve)
    print("[saved] model -> %s" % checkpoint)
    if args.folds and args.held_out:
        append_result(os.path.join(_root, "results_region_disjoint.csv"),
                      {"model": args.model, "scheme": args.scheme, "held_out": args.held_out,
                       "NSE_median": s.get("NSE_median"), "n_stations": s.get("n_stations")})
    tagd = "+donor" if use_donor else "single"
    _root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    _csv = os.path.join(_root, "results_summary.csv")
    append_result(_csv, dict({"tag": output_tag, "split": "test",
                              "epochs": args.epochs, "limit": args.limit or "all"}, **s))
    print("[saved] %s" % _csv)
    print("\n[TEST] %s(%s)  NSE_med=%.3f KGE_med=%.3f alpha_med=%.3f peakNSE_med=%.3f peakNSE_pool=%.3f n=%d" % (
        args.model, tagd, s.get("NSE_median", float("nan")), s.get("KGE_median", float("nan")),
        s.get("alpha_median", float("nan")), s.get("peak_NSE_median", float("nan")),
        s.get("peak_NSE_pooled", float("nan")), s.get("n_stations", 0)))


if __name__ == "__main__":
    main()
