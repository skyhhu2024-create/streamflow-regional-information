# -*- coding: utf-8 -*-
"""
两阶段端到端训练（Stage1 结构恢复 + Stage2 振幅校正）。

损失 = Stage1(Huber + 高斯NLL + 双向一致性) + λ_kge · KGE分解损失(物理流量空间)
评估 = 反变换到物理流量后，对比"加/不加分位数映射"的逐站 NSE/KGE 与峰值段 NSE，
       直接量化第二阶段对削峰的改善。

  python scripts/train_full.py --series_dir <月序列目录> --static <静态表csv> [--smoke]
"""
from __future__ import annotations
import os, sys, argparse, time, re
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.data.gsim_io import load_station_matrix, load_static
from src.data.dedup_gsim import drop_gsim_twins
from src.data.dataset import GapImputationDataset, split_stations
from src.train.collate import collate_numpy, to_torch
from src.train.losses import stage1_loss, kge_decomposition_loss
from src.train.inverse import inverse_transform_torch
from src.postproc.quantile_map import StationQuantileMapper
from src.utils.metrics import evaluate_by_station, nse
from src.utils.results_log import append_result, save_run_outputs, save_process_series


def make_cfg(smoke, leak_mode="none"):
    return {
        "features": {"use_log1p": True, "deseasonalize": True,
                     "per_station_standardize": True, "leak_mode": leak_mode},
        "pseudo_gap": {"seed": 42, "gaps_per_station": 2 if smoke else 4,
                       "length_strata": [[1, 3], [4, 12], [13, 36]],
                       "min_context": 12, "edge_margin": 6},
        "donors": {"max_donors": 8, "max_distance_km": 800, "min_overlap_months": 24,
                   "min_precorr": 0.2, "precorr_window": 60},
        "split": {"test_station_frac": 0.15, "val_station_frac": 0.15, "seed": 7},
        "train": {"seq_pad": 6, "batch_size": 32},
    }


def iter_batches(ds, indices, batch_size, seq_pad, shuffle=True, rng=None):
    idx = list(indices)
    if shuffle:
        (rng or np.random).shuffle(idx)
    for i in range(0, len(idx), batch_size):
        samples = [ds[j] for j in idx[i:i + batch_size]]
        yield collate_numpy(samples, seq_pad)


def apply_ablation(batch_np, abl):
    """消融：直接在 numpy batch 上置零相应输入（donor / 双向后文）。"""
    if abl.get("no_donor"):
        for k in ["donor_gap_z", "donor_mask", "donor_ctx_z", "donor_ctx_mask",
                  "donor_weight", "donor_valid"]:
            batch_np[k][...] = 0.0
    if abl.get("no_bidir"):
        batch_np["ctx_post_z"][...] = 0.0
        batch_np["ctx_post_mask"][...] = 0.0
    return batch_np


def build_qmappers(ds, station_ids):
    """为每个站点拟合分位数映射（只用该站观测，无泄漏）。"""
    qm = {}
    for sid in station_ids:
        j = ds.station_ids.index(sid)
        mapper = StationQuantileMapper(by_month=True)
        mapper.fit(ds.flow[:, j], ds.months)
        qm[sid] = mapper
    return qm


def predict_and_eval(model, ds, indices, cfg, device, qmappers=None, abl=None, collect=False):
    import torch
    model.eval()
    abl = abl or {}
    obs_by, pred_by, mon_by = {}, {}, {}
    records = []
    pred_map = {}
    with torch.no_grad():
        for batch_np, meta in iter_batches(ds, indices, cfg["train"]["batch_size"],
                                           cfg["train"]["seq_pad"], shuffle=False):
            batch = to_torch(apply_ablation(batch_np, abl), device)
            out = model(batch)
            z_hat = out["z_hat"].cpu().numpy()
            log_var = out["log_var"].cpu().numpy()
            gate_g = out["g"].cpu().numpy()          # 记忆门 g(t)，机理图用
            sync_a = out["sync"].cpu().numpy()        # donor 同步强度
            for bi, m in enumerate(meta):
                L = m["length"]; tr = m["transformer"]
                flow_hat = tr.inverse_transform(z_hat[bi, :L], m["gap_months"])
                # 置信头 σ：z 空间取 σ_z，经真实(单调)反变换线性化到物理流量空间
                sig_z = np.exp(0.5 * log_var[bi, :L])
                _hi = tr.inverse_transform(z_hat[bi, :L] + sig_z, m["gap_months"])
                _lo = tr.inverse_transform(z_hat[bi, :L] - sig_z, m["gap_months"])
                sig_flow = 0.5 * np.abs(_hi - _lo)
                truth = m["gap_truth_flow"]; ok = np.isfinite(truth)
                if ok.sum() < 2:
                    continue
                sid = m["station_id"]
                obs_by.setdefault(sid, []).append(truth[ok])
                pred_by.setdefault(sid, []).append(flow_hat[ok])
                mon_by.setdefault(sid, []).append(m["gap_months"][ok])
                if collect:
                    dates = m.get("gap_dates") or [""] * L
                    gid = "%s:%d" % (sid, indices and 0)
                    for t in range(L):
                        if not np.isfinite(truth[t]):
                            continue
                        records.append({"station_id": sid, "date": dates[t],
                                        "obs": float(truth[t]), "pred": float(flow_hat[t]),
                                        "sigma": float(sig_flow[t]),
                                        "gate_g": float(gate_g[bi, t]),
                                        "sync": float(sync_a[bi, t]),
                                        "gap_pos": float(min(t + 1, L - t) / max(L, 1)),
                                        "stratum": m.get("stratum", ""),
                                        "gap_id": "%s_%s" % (sid, dates[0] if dates else "")})
                        pred_map[(sid, dates[t])] = float(flow_hat[t])
    if not obs_by:
        return ({}, {}, None, [], {}) if collect else ({}, {})
    cat = lambda d: {k: np.concatenate(v) for k, v in d.items()}
    obs_by = cat(obs_by); pred_by = cat(pred_by); mon_by = cat(mon_by)
    df_raw, s_raw = evaluate_by_station(obs_by, pred_by, peak_quantile=0.9)

    s_qm = {}
    if qmappers:
        pred_qm = {}
        for sid in pred_by:
            if sid in qmappers:
                pred_qm[sid] = qmappers[sid].transform(
                    pred_by[sid], mon_by[sid],
                    pred_ref=pred_by[sid], pred_ref_months=mon_by[sid])
            else:
                pred_qm[sid] = pred_by[sid]
        _, s_qm = evaluate_by_station(obs_by, pred_qm, peak_quantile=0.9)
    if collect:
        return s_raw, s_qm, df_raw, records, pred_map
    return s_raw, s_qm


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--series_dir", required=True)
    ap.add_argument("--static", default=None)
    ap.add_argument("--start", default="1980-01-01")
    ap.add_argument("--end", default="2015-12-31")
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--epochs", type=int, default=120)
    ap.add_argument("--patience", type=int, default=15, help="早停耐心(验证集NSE中位数)")
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--hidden", type=int, default=64)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--lambda_kge", type=float, default=0.5)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--out", default="results_full")
    ap.add_argument("--folds", default=None, help="region-disjoint fold CSV from exp_spatial_split.py")
    ap.add_argument("--scheme", default="koppen_LOO", help="koppen_LOO or continent_LOO")
    ap.add_argument("--held_out", default=None, help="held-out group value (e.g. B, or Africa)")
    ap.add_argument("--leak_mode", choices=["none", "mean", "var", "both"], default="none")
    ap.add_argument("--run_id", default=None,
                    help="isolated audit tag used for paired strict/leaky reruns")
    # 消融开关（论文 5.6.3）
    ap.add_argument("--no_donor", action="store_true", help="去掉 donor 通路")
    ap.add_argument("--no_bidir", action="store_true", help="去掉缺口后文(单向)")
    ap.add_argument("--no_stage2", action="store_true", help="去掉第二阶段尺度恢复头")
    ap.add_argument("--no_kge", action="store_true", help="去掉 KGE 分解损失")
    ap.add_argument("--no_qm", action="store_true", help="评估时去掉分位数映射")
    args = ap.parse_args()

    abl = {"no_donor": args.no_donor, "no_bidir": args.no_bidir}
    lambda_kge = 0.0 if (args.no_kge or args.no_stage2) else args.lambda_kge
    tag = ",".join([k for k in ["no_donor", "no_bidir", "no_stage2", "no_kge", "no_qm"]
                    if getattr(args, k)]) or "full"
    if args.leak_mode != "none":
        tag += ",leak_%s" % args.leak_mode
    run_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", args.run_id).strip("_") if args.run_id else None

    import torch
    from src.models.stage2 import TwoStageImputer
    np.random.seed(args.seed); torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    torch.use_deterministic_algorithms(True, warn_only=True)
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.benchmark = False
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f">> device={device}  ablation=[{tag}]  leak_mode={args.leak_mode}  seed={args.seed}  lambda_kge={lambda_kge}")

    cfg = make_cfg(args.smoke, args.leak_mode)
    if args.smoke:
        args.epochs = min(args.epochs, 6); args.limit = args.limit or 200

    print(">> 读取数据 / 组装 Dataset ...")
    flow = load_station_matrix(args.series_dir, args.start, args.end,
                               min_valid_months=60, min_days_available=20, limit=args.limit)
    flow = drop_gsim_twins(flow)
    static = (load_static(args.static) if (args.static and os.path.exists(args.static))
              else pd.DataFrame(index=flow.columns))
    train_s, val_s, test_s = split_stations(flow.columns, cfg["split"])
    if args.folds and args.held_out:
        fd = pd.read_csv(args.folds)
        fd = fd[(fd["scheme"] == args.scheme) & (fd["held_out_group"].astype(str) == str(args.held_out))]
        present = set(flow.columns)
        test_s = set(fd[fd["role"] == "test"]["gsim_no"]) & present
        pool = [s for s in fd[fd["role"] == "train"]["gsim_no"] if s in present]
        _rng = np.random.default_rng(cfg["split"].get("seed", 7)); _rng.shuffle(pool)
        _nval = int(len(pool) * cfg["split"].get("val_station_frac", 0.15))
        val_s = set(pool[:_nval]); train_s = set(pool[_nval:])
        print(f"   [region-disjoint] scheme={args.scheme} held_out={args.held_out}  test={len(test_s)} train={len(train_s)} val={len(val_s)}")
        tag = (tag + "," if tag else "") + "rd_%s_%s" % (args.scheme.replace("_LOO", ""), args.held_out)
    ds = GapImputationDataset(flow, static, cfg)
    tr_idx = [i for i, g in enumerate(ds.gaps) if g.station_id in train_s]
    va_idx = [i for i, g in enumerate(ds.gaps) if g.station_id in val_s]
    te_idx = [i for i, g in enumerate(ds.gaps) if g.station_id in test_s]
    print(f"   样本 train/val/test = {len(tr_idx)}/{len(va_idx)}/{len(te_idx)}")
    if len(tr_idx) == 0:
        print("   无训练样本。"); return

    print(">> 拟合分位数映射(每站，无泄漏) ...")
    qm_val = build_qmappers(ds, val_s)
    qm_test = build_qmappers(ds, test_s)

    model = TwoStageImputer(hidden=args.hidden, use_stage2=not args.no_stage2).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    rng = np.random.default_rng(args.seed)
    os.makedirs(args.out, exist_ok=True)

    import copy
    best_nse = -1e9; best_state = None; bad = 0; val_hist = []
    for ep in range(1, args.epochs + 1):
        model.train(); t0 = time.time(); agg = {}; nb = 0
        for batch_np, _ in iter_batches(ds, tr_idx, cfg["train"]["batch_size"],
                                        cfg["train"]["seq_pad"], shuffle=True, rng=rng):
            batch = to_torch(apply_ablation(batch_np, abl), device)
            out = model(batch)
            loss1, parts = stage1_loss(out, batch)
            flow_hat = inverse_transform_torch(out["z_hat"], batch["inv_sigma"],
                                               batch["inv_mu"], batch["inv_clim"],
                                               batch["_flags"])
            mask_flow = batch["gap_mask"] * batch["target_flow_valid"]
            lkge = kge_decomposition_loss(flow_hat, batch["target_flow"], mask_flow)
            loss = loss1 + lambda_kge * lkge
            parts["loss"] = float(loss.detach())
            opt.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step(); nb += 1
            for k, v in parts.items():
                agg[k] = agg.get(k, 0.0) + v
            agg["kge"] = agg.get("kge", 0.0) + float(lkge.detach())
        agg = {k: v / max(nb, 1) for k, v in agg.items()}
        # 每个 epoch 评估验证集（早停 + 选最优；val 不用 QM）
        s_val, _ = predict_and_eval(model, ds, va_idx, cfg, device, None, abl)
        vnse = s_val.get("NSE_median", float("nan"))
        val_hist.append({"epoch": ep, "train_loss": agg["loss"], "val_NSE_median": vnse,
                         "val_KGE_median": s_val.get("KGE_median", float("nan"))})
        improved = np.isfinite(vnse) and vnse > best_nse + 1e-4
        if improved:
            best_nse = vnse; best_state = copy.deepcopy(model.state_dict()); bad = 0
        else:
            bad += 1
        print("[ep %02d] loss=%.3f str=%.3f nll=%.3f kge=%.3f | val_NSE_med=%.3f best=%.3f bad=%d %.1fs" %
              (ep, agg["loss"], agg["str"], agg["nll"], agg.get("kge", 0.0), vnse, best_nse, bad, time.time() - t0))
        if bad >= args.patience:
            print("   >> early stop @ep%d (best val NSE_med=%.3f)" % (ep, best_nse)); break
    if best_state is not None:
        model.load_state_dict(best_state)
        print(">> loaded best-val model (NSE_med=%.3f)" % best_nse)
    # 保存训练/验证曲线（收敛证据，作图用）
    import csv as _csv
    os.makedirs(args.out, exist_ok=True)
    output_tag = ("leakage_%s_mgstgai_%s" % (run_id, args.leak_mode)
                  if run_id else "MG-STGAI[%s]" % tag)
    artifact_slug = re.sub(r"[^A-Za-z0-9_.-]+", "_", output_tag).strip("_")
    with open(os.path.join(args.out, "train_curve_%s.csv" % artifact_slug), "w",
              newline="", encoding="utf-8-sig") as _f:
        _w = _csv.DictWriter(_f, fieldnames=["epoch", "train_loss", "val_NSE_median", "val_KGE_median"])
        _w.writeheader(); _w.writerows(val_hist)

    print("\n>> test set (raw vs +quantile-mapping) ...")
    s_raw, s_qm, df_raw, records, pred_map = predict_and_eval(model, ds, te_idx, cfg, device,
                                   None if args.no_qm else qm_test, abl, collect=True)
    _root2 = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    summary = dict(s_raw, epochs=args.epochs, limit=(args.limit or "all"),
                   model="mgstgai", leak_mode=args.leak_mode, run_id=run_id or "",
                   seed=args.seed, early_stopping="validation_NSE_median",
                   patience=args.patience, learning_rate=args.lr, hidden=args.hidden,
                   lambda_kge=lambda_kge, start=args.start, end=args.end, config=cfg,
                   n_prediction_rows=len(records), n_train_gaps=len(tr_idx),
                   n_val_gaps=len(va_idx), n_test_gaps=len(te_idx))
    _out_dir = save_run_outputs(_root2, output_tag, records, df_raw, summary)
    # 逐站完整时间线（过程线/散点作图用）：全部观测月 + 缺口月预测
    test_sids = sorted({ds.gaps[i].station_id for i in te_idx})
    series_rows = []
    for sid in test_sids:
        j = ds.sid2idx[sid]
        for t in range(ds.T):
            d = ds.index[t].strftime("%Y-%m")
            obs = ds.flow[t, j]; pv = pred_map.get((sid, d))
            if not np.isfinite(obs) and pv is None:
                continue
            series_rows.append({"station_id": sid, "date": d,
                                "obs": (float(obs) if np.isfinite(obs) else ""),
                                "pred": (pv if pv is not None else ""),
                                "is_gap": (1 if pv is not None else 0)})
    save_process_series(_out_dir, series_rows)
    print("[saved] process series -> %s/test_series_long.csv.gz" % _out_dir)

    def show(label, s):
        print("   [%s] NSE_med=%.3f KGE_med=%.3f alpha_med=%.3f peakNSE_med=%.3f peakNSE_pool=%.3f" % (
            label, s.get("NSE_median", float("nan")), s.get("KGE_median", float("nan")),
            s.get("alpha_median", float("nan")), s.get("peak_NSE_median", float("nan")),
            s.get("peak_NSE_pooled", float("nan"))))
    show("raw ", s_raw)
    show("+QM ", s_qm)
    _root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    _csv = os.path.join(_root, "results_summary.csv")
    base = {"tag": output_tag, "epochs": args.epochs, "limit": args.limit or "all"}
    append_result(_csv, dict(base, split="test_raw", **s_raw))
    if s_qm:
        append_result(_csv, dict(base, split="test_qm", **s_qm))
    if args.folds and args.held_out:
        append_result(os.path.join(_root, "results_region_disjoint.csv"),
                      {"model": "MG-STGAI", "scheme": args.scheme, "held_out": args.held_out,
                       "NSE_median": s_raw.get("NSE_median"), "n_stations": s_raw.get("n_stations")})
    print("[saved] %s" % _csv)
    ckpt = os.path.join(args.out, "%s.pth" % artifact_slug)
    torch.save({"model": model.state_dict(), "hidden": args.hidden,
                "use_stage2": not args.no_stage2, "tag": tag,
                "output_tag": output_tag, "leak_mode": args.leak_mode,
                "run_id": run_id, "seed": args.seed, "config": cfg,
                "test_raw": s_raw, "test_qm": s_qm}, ckpt)
    print("[saved] model -> %s" % ckpt)
    print("[OK] done. ablation=[%s]" % tag)


if __name__ == "__main__":
    main()
