# -*- coding: utf-8 -*-
"""Audit and compare a versioned full Caravan daily rerun."""
from __future__ import annotations

import argparse
import json
import math
import os

import numpy as np
import pandas as pd

from exp_caravan_full_benchmark import dump_tag, method_specs, output_path, safe_run_id


ROOT = os.path.dirname(os.path.abspath(__file__))
COMBINATIONS = ("equal", "dist_w", "corr_w", "OLS")


def nse(obs, pred):
    obs = np.asarray(obs, float)
    pred = np.asarray(pred, float)
    mask = np.isfinite(obs) & np.isfinite(pred)
    obs, pred = obs[mask], pred[mask]
    if obs.size < 2:
        return np.nan
    denom = np.sum((obs - obs.mean()) ** 2)
    return np.nan if denom < 1e-12 else 1.0 - np.sum((obs - pred) ** 2) / denom


def corr_alpha(obs, pred):
    obs = np.asarray(obs, float)
    pred = np.asarray(pred, float)
    mask = np.isfinite(obs) & np.isfinite(pred)
    obs, pred = obs[mask], pred[mask]
    if obs.size < 3 or obs.std() < 1e-12 or pred.std() < 1e-12:
        return np.nan, np.nan
    return float(np.corrcoef(obs, pred)[0, 1]), float(pred.std() / obs.std())


def load_dump(run_id, slug):
    tag = dump_tag(run_id, slug)
    path = os.path.join(ROOT, "results", "raw", tag, "predictions_long.csv")
    if not os.path.exists(path):
        raise FileNotFoundError("missing daily dump: %s" % path)
    frame = pd.read_csv(path)
    required = {"station_id", "date", "obs", "pred"}
    if not required.issubset(frame.columns):
        raise ValueError("%s missing columns %s" % (tag, sorted(required - set(frame.columns))))
    frame = frame[["station_id", "date", "obs", "pred"]].copy()
    frame["date"] = pd.to_datetime(frame["date"], errors="raise").dt.strftime("%Y-%m-%d")
    dup = int(frame.duplicated(["station_id", "date"]).sum())
    if dup:
        raise ValueError("%s contains %d duplicate station-date keys" % (tag, dup))
    return frame


def per_station(frame):
    rows = []
    for station_id, group in frame.groupby("station_id", sort=False):
        obs = group["obs"].to_numpy(float)
        pred = group["pred"].to_numpy(float)
        r, alpha = corr_alpha(obs, pred)
        rows.append({
            "station_id": station_id,
            "NSE": nse(obs, pred),
            "r": r,
            "alpha": alpha,
            "n_obs": int(np.isfinite(obs).sum()),
        })
    return pd.DataFrame(rows).set_index("station_id")


def rankdata(values):
    return pd.Series(values).rank(method="average").to_numpy(float)


def signed_rank(diff):
    diff = np.asarray(diff, float)
    diff = diff[np.isfinite(diff) & (diff != 0)]
    if len(diff) < 10:
        return np.nan, np.nan
    ranks = rankdata(np.abs(diff))
    w_pos = float(ranks[diff > 0].sum())
    w_neg = float(ranks[diff < 0].sum())
    rank_biserial = (w_pos - w_neg) / max(w_pos + w_neg, 1e-12)
    n = len(diff)
    _, counts = np.unique(np.abs(diff), return_counts=True)
    tie = float(np.sum(counts ** 3 - counts))
    mean = n * (n + 1) / 4.0
    var = n * (n + 1) * (2 * n + 1) / 24.0 - tie / 48.0
    if var <= 0:
        return rank_biserial, np.nan
    z = (w_pos - mean) / math.sqrt(var)
    p = math.erfc(abs(z) / math.sqrt(2.0))
    return rank_biserial, p


def spatial_block_ci(diff, station_ids, meta, rng, n_boot):
    coords = meta.reindex(station_ids)
    lat = coords["latitude"].to_numpy(float)
    lon = coords["longitude"].to_numpy(float)
    cells = np.array([
        "%d_%d" % (math.floor(a / 5), math.floor(b / 5))
        if np.isfinite(a) and np.isfinite(b) else "NA"
        for a, b in zip(lat, lon)
    ])
    unique = np.unique(cells)
    groups = {cell: np.where(cells == cell)[0] for cell in unique}
    boot = np.empty(n_boot)
    for i in range(n_boot):
        chosen = rng.choice(unique, size=len(unique), replace=True)
        idx = np.concatenate([groups[cell] for cell in chosen])
        boot[i] = np.median(diff[idx])
    lo, hi = np.percentile(boot, [2.5, 97.5])
    return float(lo), float(hi), int(len(unique))


def old_scores(path):
    if not os.path.exists(path):
        return {}
    old = pd.read_csv(path)
    aliases = {"GRIN": "GRIN (+donor)"}
    return {
        aliases.get(str(row.method), str(row.method)): float(row.NSE_median)
        for row in old.itertuples()
    }


def compare_grid(run_id, old_grid):
    new_path = output_path("results_caravan_full_grid", run_id)
    if not os.path.exists(new_path):
        return None
    new = pd.read_csv(new_path)
    old = pd.read_csv(old_grid) if os.path.exists(old_grid) else pd.DataFrame()
    rows = []
    for row in new.itertuples(index=False):
        for combination in COMBINATIONS:
            new_value = float(getattr(row, combination))
            old_value = np.nan
            if len(old) and row.selection in set(old["selection"]):
                old_value = float(old.loc[old["selection"] == row.selection, combination].iloc[0])
            rows.append({
                "selection": row.selection,
                "combination": combination,
                "NSE_new": new_value,
                "NSE_old": old_value,
                "delta": new_value - old_value if np.isfinite(old_value) else np.nan,
                "role": "oracle" if row.selection == "oracle_ingap" else "diagnostic",
            })
    result = pd.DataFrame(rows)
    result.to_csv(output_path("results_caravan_daily_grid_change", run_id), index=False,
                  encoding="utf-8-sig", float_format="%.8f")
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run_id", required=True)
    ap.add_argument("--old_master", default=os.path.join(ROOT, "results_caravan_full_master.csv"))
    ap.add_argument("--old_grid", default=os.path.join(ROOT, "results_caravan_full_grid.csv"))
    ap.add_argument("--n_boot", type=int, default=2000)
    ap.add_argument("--min_stations", type=int, default=700)
    args = ap.parse_args()
    run_id = safe_run_id(args.run_id)
    specs = [spec for spec in method_specs() if spec.include_in_ranking]
    frames = {}
    metrics = {}
    print("[audit] loading %d ranked daily dumps for run_id=%s" % (len(specs), run_id))
    for spec in specs:
        frames[spec.name] = load_dump(run_id, spec.slug)
        metrics[spec.name] = per_station(frames[spec.name])
        print("  %-26s rows=%d stations=%d" %
              (spec.name, len(frames[spec.name]), len(metrics[spec.name])))

    reference_name = "DA-transfer (DAT)"
    reference = frames[reference_name].set_index(["station_id", "date"]).sort_index()
    ref_keys = reference.index
    structural = []
    for spec in specs:
        current = frames[spec.name].set_index(["station_id", "date"]).sort_index()
        if not current.index.equals(ref_keys):
            missing = len(ref_keys.difference(current.index))
            extra = len(current.index.difference(ref_keys))
            structural.append("%s key mismatch: missing=%d extra=%d" % (spec.name, missing, extra))
            continue
        obs_error = float(np.nanmax(np.abs(current["obs"].to_numpy(float) -
                                           reference["obs"].to_numpy(float))))
        if obs_error > 1e-10:
            structural.append("%s obs mismatch max_abs=%g" % (spec.name, obs_error))
    if structural:
        raise RuntimeError("daily dump structural audit failed:\n" + "\n".join(structural))

    old = old_scores(args.old_master)
    table_rows = []
    for spec in specs:
        station = metrics[spec.name]
        old_value = old.get(spec.name, np.nan)
        new_value = float(station["NSE"].median())
        table_rows.append({
            "method": spec.name,
            "NSE_new": new_value,
            "NSE_old": old_value,
            "delta": new_value - old_value if np.isfinite(old_value) else np.nan,
            "r_median": float(station["r"].median()),
            "alpha_median": float(station["alpha"].median()),
            "n_stations": int(station["NSE"].notna().sum()),
        })
    table = pd.DataFrame(table_rows).sort_values("NSE_new", ascending=False)
    table_out = output_path("results_caravan_daily_rerun_table", run_id)
    table.to_csv(table_out, index=False, encoding="utf-8-sig", float_format="%.8f")

    meta_path = output_path("results_caravan_daily_test_stations", run_id)
    meta = pd.read_csv(meta_path).set_index("station_id")
    rng = np.random.default_rng(0)
    paired_rows = []
    for ref_name in ("DA-transfer (DAT)", "Similarity reg"):
        ref = metrics[ref_name]["NSE"]
        for spec in specs:
            if spec.name == ref_name:
                continue
            joined = pd.concat({"method": metrics[spec.name]["NSE"], "ref": ref}, axis=1).dropna()
            diff = (joined["method"] - joined["ref"]).to_numpy(float)
            rb, p = signed_rank(diff)
            lo, hi, n_blocks = spatial_block_ci(
                diff, joined.index.to_numpy(), meta, rng, args.n_boot
            )
            paired_rows.append({
                "method": spec.name,
                "vs": ref_name,
                "n": int(len(diff)),
                "median_diff": float(np.median(diff)),
                "ci_lo": lo,
                "ci_hi": hi,
                "win_pct": float(100.0 * np.mean(diff > 0)),
                "rank_biserial": rb,
                "wilcoxon_p": p,
                "n_blocks": n_blocks,
            })
    paired = pd.DataFrame(paired_rows).sort_values(["vs", "median_diff"], ascending=[True, False])
    paired_out = output_path("results_caravan_daily_rerun_paired", run_id)
    paired.to_csv(paired_out, index=False, encoding="utf-8-sig", float_format="%.8f")
    grid_change = compare_grid(run_id, args.old_grid)

    sim = float(table.loc[table["method"] == "Similarity reg", "NSE_new"].iloc[0])
    dat = float(table.loc[table["method"] == "DA-transfer (DAT)", "NSE_new"].iloc[0])
    n_min = int(table["n_stations"].min())
    direction = "unchanged: Similarity reg > DAT" if sim > dat else "CHANGED: Similarity reg <= DAT"
    n_accept = n_min >= args.min_stations
    verdict = {
        "run_id": run_id,
        "structural_key_obs_audit": "PASS",
        "minimum_method_stations": n_min,
        "minimum_required_stations": args.min_stations,
        "station_count_acceptance": "PASS" if n_accept else "FAIL",
        "similarity_reg_NSE": sim,
        "DAT_NSE": dat,
        "daily_direction": direction,
        "monthly_manuscript_update_deferred": True,
        "table_csv": os.path.basename(table_out),
        "paired_csv": os.path.basename(paired_out),
        "grid_change_csv": (os.path.basename(output_path("results_caravan_daily_grid_change", run_id))
                            if grid_change is not None else None),
    }
    verdict_out = output_path("results_caravan_daily_verdict", run_id, "json")
    with open(verdict_out, "w", encoding="utf-8") as f:
        json.dump(verdict, f, ensure_ascii=False, indent=2)

    print("\n[table: new vs old]")
    print(table.to_string(index=False, float_format=lambda x: "%.4f" % x))
    print("\n[verdict] %s; n_min=%d (required >=%d)" %
          (direction, n_min, args.min_stations))
    print("[saved]", table_out)
    print("[saved]", paired_out)
    print("[saved]", verdict_out)
    if not n_accept:
        raise RuntimeError("daily station-count acceptance failed: %d < %d" %
                           (n_min, args.min_stations))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
