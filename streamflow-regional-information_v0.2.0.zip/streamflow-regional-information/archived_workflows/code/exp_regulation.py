# -*- coding: utf-8 -*-
"""exp_regulation.py — 审稿意见 7（人类活动/水库调控）分层分析，日尺度 Caravan。

协议与 exp_caravan_full_benchmark 完全一致：同一日尺度矩阵、同一 make_cfg 配置、
**修复后的** 伪缺口采样器、同一 donor 池 / 距平空间 / 逆变换。

训练无关与逐缺口拟合方法（DAT/similarity/RF/GBM）没有任何跨站训练参数，
因此可在**全部合格流域**上评估而不违反任何 hold-out 约束；
深度模型受 hold-out 约束，另在测试集上按 DOR 分层（见 README / SI）。

用法：
  python exp_regulation.py --methods idw,similarity_reg                 # 训练无关，全样本（CPU）
  python exp_regulation.py --methods rf_donor,gbm_donor --sample_per_band 60   # 树模型分层抽样
  python exp_regulation.py --methods rf_donor,gbm_donor                 # 树模型全样本（很慢）
  python exp_regulation.py --smoke                                      # 协议冒烟检查
可选：--spatial_cap 500  做 donor 候选池上限敏感性（复核报告问题 2）。

输出：
  results_regulation_station.csv                    逐站宽表（各方法 NSE/r/alpha + 天花板 r2 + 人类活动属性）
  results/raw/regulation_<method>/predictions_long.csv   逐缺口转储（--dump，默认开）
缓存：
  _cache_caravan_daily.npz   日尺度矩阵（首次构建约 10–15 分钟，之后秒级加载）
"""
from __future__ import annotations
import os, sys, glob, time, argparse, csv
import numpy as np, pandas as pd

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
from src.data.dataset import GapImputationDataset
from src.utils.metrics import evaluate_by_station
from src.baselines import classical as C

CACHE = os.path.join(ROOT, "_cache_caravan_daily.npz")
OUT_STATION = os.path.join(ROOT, "results_regulation_station.csv")

ATTR_HYDRO = ["dor_pc_pva", "hft_ix_s09", "ppd_pk_sav", "urb_pc_sse",
              "ire_pc_sse", "ari_ix_sav", "pre_mm_syr"]
ATTR_OTHER = ["gauge_lat", "gauge_lon", "area"]

DOR_BANDS = [(-0.5, 0.5, "none"), (0.5, 50, "10-50%"), (50, 150, "50-150%"),
             (150, 500, "150-500%"), (500, np.inf, ">500%")]


def build_matrix(limit_per_dataset=0, use_cache=True):
    """与 exp_caravan_full_benchmark.build_caravan_daily 相同的取数逻辑
    （同 csv、同 1990-2020 窗、同 >=1825 有效日过滤），但预分配数组、float32，
    以便在小内存机器上构建，并带 npz 缓存。"""
    if use_cache and not limit_per_dataset and os.path.exists(CACHE):
        z = np.load(CACHE, allow_pickle=True)
        dates = pd.to_datetime(z["dates"])
        flow = pd.DataFrame(z["flow"], index=dates, columns=list(z["sids"]))
        src = dict(zip(list(z["sids"]), list(z["src"])))
        print("[cache] loaded %s stations=%d" % (CACHE, flow.shape[1]))
        return flow, src
    base = os.path.join(ROOT, "Caravan", "Caravan", "Caravan")
    tsroot = os.path.join(base, "timeseries", "csv")
    dates = pd.date_range("1990-01-01", "2020-12-31", freq="D")
    pos = {d: i for i, d in enumerate(dates)}
    dsets = sorted(d for d in os.listdir(tsroot) if os.path.isdir(os.path.join(tsroot, d)))
    cols, arrs, src = [], [], {}
    t0 = time.time()
    for dn in dsets:
        files = sorted(glob.glob(os.path.join(tsroot, dn, "*.csv")))
        if limit_per_dataset:
            files = files[:limit_per_dataset]
        for f in files:
            sid = os.path.basename(f)[:-4]
            try:
                d = pd.read_csv(f, usecols=["date", "streamflow"])
            except Exception:
                continue
            v = np.full(len(dates), np.nan, dtype=np.float32)
            dt = pd.to_datetime(d["date"])
            ok = (dt >= dates[0]) & (dt <= dates[-1])
            ii = dt[ok].map(pos).values.astype(int)
            v[ii] = d["streamflow"][ok].values
            if np.isfinite(v).sum() >= 1825:
                cols.append(sid); arrs.append(v); src[sid] = dn
        print("  loaded %-12s total=%d (%.0fs)" % (dn, len(cols), time.time() - t0))
    flow = pd.DataFrame(np.column_stack(arrs) if arrs else np.zeros((len(dates), 0), np.float32),
                        index=dates, columns=cols)
    if not limit_per_dataset:
        np.savez(CACHE, flow=flow.values.astype(np.float32),
                 dates=np.array([str(d.date()) for d in dates]),
                 sids=np.array(cols), src=np.array([src[c] for c in cols]))
        print("[cache] wrote", CACHE)
    return flow, src


def dedup_stations(flow, station_src, verbose=True):
    """剔除 Caravan 跨/内子集重复测站（2026-07 复核发现，"必须修"第 2 项）。

    规则：两站为同一测站，若 (a) camels/hysets 同一 USGS 编号；或 (b) 坐标相距
    <300 m 且共同有效日 >=365 天上 log1p 流量相关 >0.95。每对保留有效日更多的一份。
    实测（1990–2020、>=1825 有效日样本）：451 对 camels-hysets 同编号孪生、
    16 对 hysets 内部近重复、1 对 lamah 内部近重复 → 剔除 459 站。
    影响：孪生目标站的 similarity NSE 被虚高到 ~0.99（donor 是"另一个自己"）。
    """
    base = os.path.join(ROOT, "Caravan", "Caravan", "Caravan", "attributes")
    coords = {}
    for dn in sorted(set(station_src.values())):
        o = os.path.join(base, dn, "attributes_other_%s.csv" % dn)
        if os.path.exists(o):
            ot = pd.read_csv(o).set_index("gauge_id")
            for s in ot.index:
                if s in station_src:
                    try:
                        coords[s] = (float(ot.at[s, "gauge_lat"]), float(ot.at[s, "gauge_lon"]))
                    except Exception:
                        pass
    sids = list(flow.columns)
    pos = {s: i for i, s in enumerate(sids)}
    pairs = set()
    # (a) camels/hysets 同编号
    cam = {s.split("_", 1)[1]: s for s in sids if s.startswith("camels_")}
    hyn = {s.split("_", 1)[1]: s for s in sids if s.startswith("hysets_")}
    for k in set(cam) & set(hyn):
        pairs.add(tuple(sorted((cam[k], hyn[k]))))
    # (b) 坐标 <300 m（网格哈希）
    from collections import defaultdict
    cell = defaultdict(list)
    for s in sids:
        if s in coords:
            la, lo = coords[s]
            cell[(round(la * 100), round(lo * 100))].append(s)
    for (ka, ko), grp in list(cell.items()):
        cand = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                cand += cell.get((ka + dx, ko + dy), [])
        for a in grp:
            for b in cand:
                if b <= a:
                    continue
                la, lo = coords[a]; lb, lob = coords[b]
                dla = (la - lb) * 111.0
                dlo = (lo - lob) * 111.0 * np.cos(np.radians(la))
                if dla * dla + dlo * dlo < 0.09:
                    pairs.add(tuple(sorted((a, b))))
    drop, kept_pairs = set(), []
    V = flow.values
    for a, b in sorted(pairs):
        xa, xb = V[:, pos[a]], V[:, pos[b]]
        m = np.isfinite(xa) & np.isfinite(xb)
        sameid = a.split("_", 1)[1] == b.split("_", 1)[1] and a.split("_")[0] != b.split("_")[0]
        r = np.corrcoef(np.log1p(xa[m]), np.log1p(xb[m]))[0, 1] if m.sum() >= 365 else np.nan
        if sameid or (np.isfinite(r) and r > 0.95):
            d = a if np.isfinite(xa).sum() < np.isfinite(xb).sum() else b
            drop.add(d)
            kept_pairs.append((a, b, round(float(r), 4) if np.isfinite(r) else "", d))
    if verbose:
        print("[dedup] duplicate pairs=%d -> dropping %d stations" % (len(kept_pairs), len(drop)))
    pd.DataFrame(kept_pairs, columns=["station_a", "station_b", "log_corr", "dropped"]).to_csv(
        os.path.join(ROOT, "caravan_duplicate_gauges.csv"), index=False)
    keep = [s for s in sids if s not in drop]
    return flow[keep], {s: station_src[s] for s in keep}


def load_attributes(station_src):
    base = os.path.join(ROOT, "Caravan", "Caravan", "Caravan", "attributes")
    rows = {}
    for dn in sorted(set(station_src.values())):
        h = os.path.join(base, dn, "attributes_hydroatlas_%s.csv" % dn)
        o = os.path.join(base, dn, "attributes_other_%s.csv" % dn)
        ha = pd.read_csv(h).set_index("gauge_id") if os.path.exists(h) else pd.DataFrame()
        ot = pd.read_csv(o).set_index("gauge_id") if os.path.exists(o) else pd.DataFrame()
        for sid, s in station_src.items():
            if s != dn:
                continue
            r = {"src": dn}
            for c in ATTR_HYDRO:
                r[c] = float(ha.at[sid, c]) if (len(ha) and sid in ha.index and c in ha.columns) else np.nan
            for c in ATTR_OTHER:
                r[c] = float(ot.at[sid, c]) if (len(ot) and sid in ot.index and c in ot.columns) else np.nan
            rows[sid] = r
    return pd.DataFrame.from_dict(rows, orient="index")


def make_cfg(smoke=False):
    """与 exp_caravan_full_benchmark.make_cfg 逐字一致（协议锁定）。"""
    return {"features": {"use_log1p": True, "deseasonalize": True, "per_station_standardize": True, "season_period": 366},
            "pseudo_gap": {"seed": 42, "gaps_per_station": 2 if smoke else 3,
                           "length_strata": [[7, 30], [31, 90], [91, 180]], "min_context": 365, "edge_margin": 30},
            "donors": {"max_donors": 8, "max_distance_km": 800, "min_overlap_months": 720, "min_precorr": 0.2, "precorr_window": 1800},
            "split": {"test_station_frac": 0.15, "val_station_frac": 0.15, "seed": 7},
            "classical": {"reg_window": 1825, "ar_window": 1825, "dtrr_window": 1825},
            "train": {"seq_pad": 14, "batch_size": 32}}


def dor_band(v):
    if not np.isfinite(v):
        return "unknown"
    for lo, hi, name in DOR_BANDS:
        if lo < v <= hi or (name == "none" and v == 0):
            return name
    return "unknown"


def pick_stations(attrs, sample_per_band, seed=0):
    """树模型抽样：每个非零 DOR 档 sample_per_band 站 + 未调控 3x（按 src 分层）。"""
    rng = np.random.default_rng(seed)
    bands = attrs["dor_pc_pva"].map(dor_band)
    keep = []
    for _, _, name in DOR_BANDS:
        pool = attrs.index[bands == name].tolist()
        n = sample_per_band * (3 if name == "none" else 1)
        if len(pool) > n:
            pool = list(rng.choice(pool, n, replace=False))
        keep.extend(pool)
    return set(keep)


def donor_ceiling_z(ds, gap):
    """DAT 的 z 空间 donor 合成 与 真实 z：用于逐站 donor 信息天花板 r^2。"""
    j = ds.sid2idx[gap.station_id]
    donors = ds._donors(gap)
    g0, g1 = gap.start, gap.end
    zt = ds.z[g0:g1 + 1, j]
    if not donors:
        return zt, np.full_like(zt, np.nan)
    idx = [ds.sid2idx[d["donor_id"]] for d in donors]
    w = np.array([d["weight"] for d in donors], float)
    Z = ds.z[g0:g1 + 1, idx]
    M = np.isfinite(Z)
    W = M * w[None, :]
    den = W.sum(1)
    zd = np.where(den > 0, np.nansum(np.nan_to_num(Z) * W, 1) / np.maximum(den, 1e-9), np.nan)
    return zt, zd


def dump_rows(tag, recs):
    d = os.path.join(ROOT, "results", "raw", "regulation_" + tag)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "predictions_long.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["station_id", "date", "obs", "pred"])
        w.writerows(recs)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--methods", default="idw,similarity_reg")
    ap.add_argument("--limit_per_dataset", type=int, default=0)
    ap.add_argument("--sample_per_band", type=int, default=0, help="树模型分层抽样；0=全样本")
    ap.add_argument("--spatial_cap", type=int, default=200)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--no_dump", action="store_true")
    ap.add_argument("--append", action="store_true", help="把新方法列并入已有宽表（默认覆盖重写）")
    args = ap.parse_args()
    t0 = time.time()

    flow, station_src = build_matrix(args.limit_per_dataset)
    flow, station_src = dedup_stations(flow, station_src)   # 必做：剔除跨子集孪生站
    attrs = load_attributes(station_src)
    static = pd.DataFrame({"latitude": attrs["gauge_lat"], "longitude": attrs["gauge_lon"]})

    if args.sample_per_band:
        keep = pick_stations(attrs, args.sample_per_band)
        flow = flow[[c for c in flow.columns if c in keep]]
        print("[sample] stratified subsample -> %d stations" % flow.shape[1])

    cfg = make_cfg(args.smoke)
    ds = GapImputationDataset(flow, static, cfg)
    ds.flow_df = None  # 省内存
    ds.donor_selector.spatial_cap = args.spatial_cap
    n_gap_st = len({g.station_id for g in ds.gaps})
    print("[build] stations=%d gaps=%d stations_with_gaps=%d (%.0fs)"
          % (flow.shape[1], len(ds.gaps), n_gap_st, time.time() - t0))

    # —— 天花板 r2（方法无关，只算一次）——
    zt_by, zd_by = {}, {}
    for g in ds.gaps:
        zt, zd = donor_ceiling_z(ds, g)
        ok = np.isfinite(zt) & np.isfinite(zd)
        if ok.sum() >= 2:
            zt_by.setdefault(g.station_id, []).append(zt[ok])
            zd_by.setdefault(g.station_id, []).append(zd[ok])
    ceil = {}
    for sid in zt_by:
        a = np.concatenate(zt_by[sid]); b = np.concatenate(zd_by[sid])
        if a.std() > 1e-9 and b.std() > 1e-9:
            ceil[sid] = float(np.corrcoef(a, b)[0, 1]) ** 2
    ndon = {}
    for g in ds.gaps:
        ndon.setdefault(g.station_id, []).append(len(ds._donors(g)))
    print("[ceiling] r2 computed for %d stations (%.0fs)" % (len(ceil), time.time() - t0))

    # —— 各方法 ——
    methods = [m.strip() for m in args.methods.split(",") if m.strip()]
    per_station = {}
    for mname in methods:
        fn = getattr(C, mname)
        ob, pb, recs = {}, {}, []
        for g in ds.gaps:
            try:
                pr = np.asarray(fn(ds, g))
            except Exception:
                continue
            j = ds.sid2idx[g.station_id]
            truth = ds.flow[g.start:g.end + 1, j]
            ok = np.isfinite(truth)
            if ok.sum() < 2:
                continue
            ob.setdefault(g.station_id, []).append(truth[ok])
            pb.setdefault(g.station_id, []).append(pr[ok])
            if not args.no_dump:
                dts = [d.strftime("%Y-%m-%d") for d in ds.index[g.start:g.end + 1]]
                for t in range(g.end - g.start + 1):
                    if np.isfinite(truth[t]):
                        recs.append([g.station_id, dts[t], float(truth[t]), float(pr[t])])
        ob = {k: np.concatenate(v) for k, v in ob.items()}
        pb = {k: np.concatenate(v) for k, v in pb.items()}
        df, summ = evaluate_by_station(ob, pb, peak_quantile=0.9)
        per_station[mname] = df.set_index("station_id")
        if not args.no_dump:
            dump_rows(mname, recs)
        print("[%s] NSE_med=%.3f n=%d (%.0fs)"
              % (mname, summ.get("NSE_median", float("nan")), summ.get("n_stations", 0), time.time() - t0))

    # —— 合并宽表 ——
    all_sids = sorted(set().union(*[set(d.index) for d in per_station.values()]))
    out = pd.DataFrame(index=all_sids)
    for mname, df in per_station.items():
        for c in ["NSE", "KGE", "r", "alpha", "beta", "peak_NSE"]:
            if c in df.columns:
                out["%s_%s" % (c, mname)] = df[c]
    out["r2_ceiling"] = pd.Series(ceil)
    out["n_donors_med"] = pd.Series({s: float(np.median(v)) for s, v in ndon.items()})
    out = out.join(attrs, how="left")
    out["dor_band"] = out["dor_pc_pva"].map(dor_band)
    mode = "a" if (args.append and os.path.exists(OUT_STATION)) else "w"
    if mode == "a":  # 补跑：新方法列合并进已有宽表
        old = pd.read_csv(OUT_STATION, index_col=0)
        newcols = [c for c in out.columns if c not in old.columns]
        out = old.join(out[newcols], how="outer")
    out.to_csv(OUT_STATION)
    print("[done] wrote %s rows=%d (%.0fs)" % (OUT_STATION, len(out), time.time() - t0))


if __name__ == "__main__":
    main()
