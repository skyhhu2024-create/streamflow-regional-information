"""Prefix-only, streamflow-only models for a matched context/support experiment.

No source matrix containing target gap truth is passed to prediction functions.
All array layouts are time-major in these small per-target routines.
"""
from __future__ import annotations

import numpy as np


def fit_transform(q: np.ndarray, months: np.ndarray, cutoff: int):
    """Fit on the prefix only; return transformed values and invertible params.

    All-station input shape is (time, station). Future values are transformed,
    never used in climatology/scale estimation. Callers isolate target truth.
    """
    q = np.asarray(q, dtype=float)
    x = np.log1p(np.maximum(q, 0))
    x[~np.isfinite(q)] = np.nan
    prefix_count = np.isfinite(x[:cutoff]).sum(0)
    prefix_mean = np.divide(np.nansum(x[:cutoff], axis=0), prefix_count,
                            out=np.full(q.shape[1], np.nan), where=prefix_count > 0)
    clim = np.zeros((12, q.shape[1]))
    counts = np.zeros_like(clim, dtype=int)
    for m in range(12):
        v = x[:cutoff][months[:cutoff] == m]
        counts[m] = np.isfinite(v).sum(0)
        clim[m] = np.divide(np.nansum(v, axis=0), counts[m],
                            out=np.full(q.shape[1], np.nan), where=counts[m] > 0)
        # Same pre-specified fallback as the existing StationTransformer.
        # An absent seasonal estimate is not mistaken for an absent raw flow.
        clim[m, counts[m] == 0] = prefix_mean[counts[m] == 0]
    anomaly = x - clim[months]
    good = np.isfinite(anomaly[:cutoff])
    n = good.sum(0)
    mu = np.divide(np.nansum(anomaly[:cutoff], axis=0), n,
                   out=np.zeros(q.shape[1]), where=n > 0)
    var = np.divide(np.nansum((anomaly[:cutoff] - mu) ** 2, axis=0), n,
                    out=np.zeros(q.shape[1]), where=n > 0)
    sd = np.sqrt(var)
    sd[(~np.isfinite(sd)) | (sd < 1e-6)] = 1.0
    return (anomaly - mu) / sd, clim, mu, sd, counts


def inverse(z, months, clim, mu, sd):
    return np.maximum(np.expm1(np.minimum(np.asarray(z) * sd + mu + clim[months], 50)), 0)


def rank_references(target_prefix, candidate_prefix, distances):
    """Qualify from last 60 calendar months, not compressed valid records."""
    t = np.asarray(target_prefix[-60:], float)
    d = np.asarray(candidate_prefix[-60:], float)
    mask = np.isfinite(d) & np.isfinite(t[:, None])
    n = mask.sum(0)
    tt = np.where(mask, t[:, None], 0.)
    dd = np.where(mask, d, 0.)
    tm = tt.sum(0) / np.maximum(n, 1)
    dm = dd.sum(0) / np.maximum(n, 1)
    tc = np.where(mask, t[:, None] - tm, 0.)
    dc = np.where(mask, d - dm, 0.)
    den = np.sqrt(np.sum(tc * tc, 0) * np.sum(dc * dc, 0))
    corr = np.divide(np.sum(tc * dc, 0), den, out=np.full(len(distances), np.nan), where=den > 1e-12)
    valid = (n >= 24) & np.isfinite(corr) & (corr >= .2)
    weights = corr * np.exp(-np.asarray(distances) / 800.)
    idx = np.flatnonzero(valid)
    order = np.argsort(-weights[idx], kind="stable")
    return idx[order], weights[idx[order]], corr[idx[order]], n[idx[order]]


def composite(z, weights, k=4):
    """Top k REPORTING donors from a prefix-fixed qualified rank, not fixed k."""
    if not len(weights):
        return np.full(len(z), np.nan), np.zeros(len(z), dtype=int)
    finite = np.isfinite(z)
    chosen = finite & (np.cumsum(finite, axis=1) <= k)
    w = chosen * np.asarray(weights)[None, :]
    den = w.sum(1)
    return np.divide(np.sum(np.nan_to_num(z) * w, axis=1), den,
                     out=np.full(len(z), np.nan), where=den > 0), chosen.sum(1)


def linear_fit(x, y, min_pairs=24):
    mask = np.isfinite(x) & np.isfinite(y)
    n = int(mask.sum())
    if n < min_pairs or np.var(x[mask]) < 1e-10:
        return None, n
    xx, yy = np.asarray(x)[mask], np.asarray(y)[mask]
    slope = float(np.mean((xx - xx.mean()) * (yy - yy.mean())) / np.var(xx))
    return (float(yy.mean() - slope * xx.mean()), slope), n


def fit_models(target_prefix, composite_prefix):
    z = np.asarray(target_prefix[-240:], float)
    d = np.asarray(composite_prefix[-240:], float)
    pair = np.isfinite(z[:-1]) & np.isfinite(z[1:])
    ar, ar_n = linear_fit(z[:-1], z[1:])
    if ar is None:
        c, phi = 0., 0.
        qvar = float(np.nanvar(z)) if np.isfinite(z).any() else 1.
    else:
        phi = float(np.clip(ar[1], -.98, .98))
        c = float(z[1:][pair].mean() - phi * z[:-1][pair].mean())
        qvar = float(np.mean((z[1:][pair] - c - phi * z[:-1][pair]) ** 2))
    obs, obs_n = linear_fit(z, d)
    om = np.isfinite(z) & np.isfinite(d)
    if obs is None:
        a, b, rvar = 0., 0., 1.
    else:
        a, b = obs
        rvar = float(np.mean((d[om] - a - b * z[om]) ** 2))
    reg, reg_n = linear_fit(np.asarray(composite_prefix)[-120:], np.asarray(target_prefix)[-120:])
    return dict(c=c, phi=phi, qvar=max(qvar, 1e-4), a=a, b=b, rvar=max(rvar, 1e-4),
                ar_pairs=ar_n, obs_pairs=obs_n, reg_pairs=reg_n,
                reg_intercept=reg[0] if reg else 0., reg_slope=reg[1] if reg else 1.,
                reg_fallback=reg is None)


def bridge(left, donor, params, right=None):
    """Scalar Kalman filtering / RTS smoothing; exact target boundary values.

    Retrospective smoothing may use other available reference months WITHIN
    the gap in either context. No reference data beyond the gap are supplied.
    Missing donor observations are skipped, never interpreted as zero flow.
    """
    donor = np.asarray(donor, float)
    L = len(donor)
    n = L + (right is not None)
    fm, fv, pm, pv = [np.empty(n) for _ in range(4)]
    mean, var = float(left), 0.
    c, phi, Q, a, b, R = [params[x] for x in ["c", "phi", "qvar", "a", "b", "rvar"]]
    for t in range(n):
        mean = c + phi * mean
        var = phi * phi * var + Q
        pm[t], pv[t] = mean, var
        if t < L and np.isfinite(donor[t]):
            gain = var * b / (b * b * var + R)
            mean += gain * (donor[t] - a - b * mean)
            var = max(var * (1. - gain * b), 0.)
        if t == L:
            mean, var = float(right), 0.
        fm[t], fv[t] = mean, var
    smooth = fm.copy()
    for t in range(n - 2, -1, -1):
        gain = fv[t] * phi / pv[t + 1]
        smooth[t] += gain * (smooth[t + 1] - pm[t + 1])
    return smooth[:L]


def predict_all(left, donor, params, right):
    """Return every pre-specified prediction from truth-free inputs."""
    donor = np.asarray(donor, float)
    L = len(donor)
    output = {}
    for support in ["observed", "late_outage", "all_outage"]:
        d = donor.copy()
        if support == "late_outage":
            d[L // 2:] = np.nan
        elif support == "all_outage":
            d[:] = np.nan
        dat = np.nan_to_num(d, nan=0.)
        reg = np.where(np.isfinite(d), params["reg_intercept"] + params["reg_slope"] * d, 0.)
        for context in ["internal", "extension"]:
            output[("DAT", context, support)] = dat.copy()
            output[("Composite_regression", context, support)] = reg.copy()
            output[("AR1_reference_bridge", context, support)] = bridge(
                left, d, params, right if context == "internal" else None)
    return output


def scores(truth, prediction, train_sd, baseline):
    """Station/gap metrics; caller guarantees identical finite truth sets."""
    o, p = np.asarray(truth, float), np.asarray(prediction, float)
    assert len(o) == len(p) and np.isfinite(o).all() and np.isfinite(p).all()
    err = p - o
    den = np.sum((o - o.mean()) ** 2)
    mse = float(np.mean(err ** 2))
    obs_sd, pred_sd = np.std(o), np.std(p)
    r = float(np.corrcoef(o, p)[0, 1]) if obs_sd > 1e-12 and pred_sd > 1e-12 else np.nan
    kge = 1 - np.sqrt((r - 1)**2 + (pred_sd / obs_sd - 1)**2 + (p.mean() / o.mean() - 1)**2) if obs_sd > 1e-12 and abs(o.mean()) > 1e-12 and np.isfinite(r) else np.nan
    bmse = np.mean((np.asarray(baseline) - o)**2)
    return dict(n_months=len(o), nse=float(1 - np.sum(err**2) / den) if den > 1e-12 else np.nan,
                kge=float(kge), rmse=float(np.sqrt(mse)), r=r,
                standardized_log_rmse=float(np.sqrt(np.mean(((np.log1p(p) - np.log1p(o)) / train_sd)**2))),
                skill_vs_seasonal=float(1 - mse / bmse) if bmse > 1e-12 else np.nan)
