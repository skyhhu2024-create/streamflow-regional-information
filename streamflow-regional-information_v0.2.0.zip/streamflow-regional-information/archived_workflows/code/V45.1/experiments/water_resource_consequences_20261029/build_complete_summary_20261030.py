from pathlib import Path
import hashlib
import json
import re
import pandas as pd

B = Path(__file__).resolve().parent
V = B.parent.parent
OUT = V / '水资源应用_全部工作与结果汇总_20261030.md'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
source_files = list((B/'analysis').glob('*.csv')) + [B/'水资源后果_全球核心结果_20261029.csv', B/'results/per_target_water_metrics.csv.gz']
before = {str(p):sha(p) for p in source_files}
core = pd.read_csv(B/'水资源后果_全球核心结果_20261029.csv')
c = pd.read_csv(B/'analysis/continuous_by_arm.csv')
b = pd.read_csv(B/'analysis/binary_proportions_by_arm.csv')
pc = pd.read_csv(B/'analysis/paired_continuous_effects.csv')
pb = pd.read_csv(B/'analysis/paired_binary_effects.csv')
ev = pd.read_csv(B/'analysis/event_counts_by_arm.csv')
arms = json.loads((B/'data/ARM_REGISTRY.json').read_text(encoding='utf-8'))['arm_names']
labels = {
 'ridge_Q_D0':'线性：保留区域参考', 'ridge_Q_D100':'线性：撤除100 km内参考',
 'ridge_Q_D300':'线性：撤除300 km内参考', 'ridge_Q_D800':'线性：撤除800 km内参考',
 'ridge_QP_D800':'线性：撤源后加实际降雨', 'ridge_QP_Gclim_D800':'线性：撤源后加降雨气候态',
 'corr_only_ridge_Q_D800':'线性：撤源后仅按历史相关排序', 'seasonal_baseline':'目标历史季节基线',
 'rbf_Q_D0':'核模型：保留区域参考', 'rbf_Q_D800':'核模型：撤除800 km内参考',
 'rbf_QP_D800':'核模型：撤源后加实际降雨'}
short = {arms[0]:'Q0',arms[1]:'Q100',arms[2]:'Q300',arms[3]:'Q800',arms[4]:'QP800',arms[5]:'QPc800',arms[6]:'Corr800',arms[7]:'季节基线',arms[8]:'KQ0',arms[9]:'KQ800',arms[10]:'KQP800'}
regions = {'Europe':'欧洲','Asia':'亚洲','Africa':'非洲','NorthAmerica':'北美','SouthAmerica':'南美','Oceania':'大洋洲','Other':'其他'}
parts=[]
def add(s): parts.append(s.strip()+'\n')
def table(headers, rows):
    add('| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+'\n'.join('| '+' | '.join(str(x) for x in row)+' |' for row in rows))
def one(df, **kw):
    d=df
    for k,v in kw.items(): d=d[d[k]==v]
    assert len(d)==1,(kw,len(d))
    return d.iloc[0]
def f(x,n=1): return f'{float(x):.{n}f}' if pd.notna(x) else '未计算'
def ci(row,field,mul=1,digits=3):
    return f"{f(row[field]*mul,digits)} [{f(row.ci025*mul,digits)}, {f(row.ci975*mul,digits)}]"
def lk(title,p):
    p=Path(p).resolve(); assert p.exists(),p
    return f'[{title}](<{p.as_posix()}>)'

add('''# 水资源应用：全部工作、计算方法与结果汇总

整理日期：2026年10月30日。对应 V45.1 最新正文及SI定稿。

本文汇总2026年10月29日开展的水资源用途评价，以及随后完成的绘图、入稿和图件合并。以数值修正后的最终数据为准。本次整理只读取已有结果，不重新训练模型、不重新生成预测、不改变阈值，也不修改论文。

**这轮工作的核心回答是：区域参考缺失造成的损失，不只体现在重构评分，还体现在偏枯月份识别、累计径流亏缺和整个缺口期的总水量估计。降雨能够部分补偿，但不同用途的收益明显不同。**

阅读顺序：第1—3节交代做了什么及如何计算；第4—7节给出结果和对照；第8—10节说明完整性、入稿位置及证据边界；第11节提供全部本地材料索引。表中展示全部11个方案和两档偏枯阈值；更细的逐站、逐洲、逐指标区间及状态明细均链接到完整原表。
''')
add('''## 1. 为什么补这项工作，实际完成了什么

原R3已经显示：即使全球参考仍然可用，撤除目标附近的区域径流记录后，重构表现仍会显著下降。这轮补充进一步检验这种损失是否影响实际的水量判断，并检验R4所增加的降雨信息能补偿到哪一步。

依次完成了以下工作：

1. 固定用途评价协议、阈值、容差、11个预测方案及16个配对对照，保留预期不利或不显著的结果。
2. 连接原始流量、目标身份、真实月历、冻结预测、参考支持和季节回退标记；核对其属于当前安全清理后的全球参考池版本。
3. 对固定8,083目标、11个方案、q20/q10两档阈值，生成177,826行逐目标结果。
4. 计算偏枯识别、累计亏缺、120个月总水量，以及前后时段均值变化四组指标；汇总包括9个连续指标、12个二值指标及事件/体积/异常状态描述。
5. 完成全球与各洲汇总、全16个预定配对、各项容差敏感性和空间区块不确定性。
6. 独立重算全部逐目标结果，复核全部统计表，并修正少数精确零阈值的浮点问题；修正前版本保留。
7. 先制作三面板点区间图，再按用户意见改成柱状图；用户确认后纳入正文，最后并入新版Fig. 3e–g。

这是一项**冻结预测的回溯用途评价**。新用途指标计算前固定了本轮方案，但此前已经看过原NSE等结果，因此不称为完全未接触过结果的新盲测或事前注册试验。
''')
add('''## 2. 队列、输入和11个方案

### 2.1 样本如何确定

- 原来源登记队列为8,898个满足H60/G120条件的目标；本轮使用其中8,083个降雨准入目标，其余815个不在本轮用途结果中。
- 每目标使用60个月（5年）可见历史，检验紧随其后的120个月（10年）前向缺口；起始年月依目标而异。
- 所有方案都在同一母队列上比较，没有按本轮重构精度再挑选站点。具体指标因负值、零分母或无事件等原因有不同有效数，见第8节。
- 采用当前主稿的全球候选池。D100、D300、D800表示压力试验中撤除相应距离以内的径流来源，**不表示把搜索范围限制在该距离以内**；远处合格来源仍可使用。
- 本轮主处理器是既有冻结的线性ridge，第二处理器是既有冻结的RBF核ridge，**不是重新运行旧版DAT全球补齐**。季节基线只用目标可见历史的原始流量历月均值。
- 降雨使用已有试验的当前月及前三个滞后月输入。降雨气候态对照在既有联合模型中替换缺口期降雨输入，不重新率定。

### 2.2 全部方案清单

以下短名仅用于本汇总的宽表。Q代表径流参考，P代表实际降雨，Pc代表降雨气候态，K代表核模型。
''')
table(['短名','方案','原始结果标识'],[(short[a],labels[a],f'`{a}`') for a in arms])
add('''## 3. 指标怎样计算

### 3.1 历史相对偏枯月：发生时间是否判断正确

对60个月可见历史流量Q作log(1+Q)变换，减去该历史中相应日历月均值μₘ，再用全部历史残差标准差s标准化。以历史标准距平的第20百分位c₂₀定义主阈值，第10百分位c₁₀作敏感性检验。原流量单位下的每月阈值为：

`Tₘ = max{exp(μₘ + s × cₚ) − 1, 0}`。

观测与所有预测共用这一历史阈值，严格满足Q<Tₘ才记为偏枯月。实际实现用数学等价的原残差分位数直接计算μₘ+s×cₚ，避免除乘往返误差。五年历史只是试验内的参照，不能将这里的偏枯月称为长期气候率定的干旱等级。

普通Heidke skill score（HSS）使用命中a、虚报b、漏报c、正确否定d：

`HSS = 2(ad − bc) / [(a+c)(c+d) + (a+b)(b+d)]`。

HSS越高表示识别越好，1为完美；本轮没有另设事后的HSS“达标线”。同时计算同一日历月内随机置换预测事件所对应的解析期望HSS，再逐站用普通HSS减去该期望。这个差值帮助检查收益是否仅来自季节事件频率，**不是另一种标准HSS，也不是信息的因果贡献量**。表中各列分别求中位数，所以差值列不一定等于两个中位数相减。

### 3.2 累计径流亏缺：低于阈值的量能否估准

与偏枯月识别使用相同Tₘ，按实际月天数积分：

`D = Σ max(Tₘ − Qₜ, 0) × daysₜ × 86,400`。

报告重构/观测亏缺比D̂/D、其绝对相对误差|D̂/D−1|，以及误差在25%和50%内的站点比例。比值1为准确，低于1是低估，高于1是高估；不能简单说越大越好。

另计算亏缺绝对误差除以“历史按天加权平均流量×缺口总秒数”，避免只用很小的真实亏缺作分母。真实亏缺为零时，比值及其容差无定义，另保留零亏缺、虚假亏缺和绝对量记录。这里的亏缺是低于水文阈值的径流体积，不是按供水需求计算的实际缺水损失。

### 3.3 总水量：整个十年区间的水量是否准确

`V = Σ Qₜ × daysₜ × 86,400`，报告(V̂−V)/V及其绝对值，并报告绝对误差≤10%、≤20%的比例。

该指标针对**整个120个月缺口的总水量**，不能写成年度水量误差中位数、每年水量准确率或趋势误差。不同测站可能属于嵌套流域，因此不将各站体积相加称为全球水量。

### 3.4 前后时段均值变化：方向是否判对

比较缺口120个月与历史60个月的按天加权平均流量。以±10%或±20%（含边界）定义持平，其余分为增加或减少。保存完整3×3观测—预测混淆表，再汇成四类：判断一致、真实变化却判持平、真实持平却判变化、增减方向相反。

这是两个时段均值的对比，**不是缺口内趋势斜率或显著性检验**。q20/q10不会改变总水量和均值变化结果，不能将其重复算作两批独立证据。

### 3.5 汇总、分母和区间

各站等权，连续量报告站点中位数与四分位数。配对效应先逐站相减再求中位数，不拿两个方案的中位数相减代替。比例同时保存有效目标分母与8,083注册目标分母；未评价目标属于未知，不当作已观察到的失败。

沿用2,000次5°空间区块自助抽样，覆盖274个有目标的格，seed=20261029。所有方案、指标和阈值共用抽样权重，同一格内站点共同抽取；不把每个月当成独立重复。95%区间为自助分布的2.5/97.5百分位。**5°格仅用于不确定性计算，没有改变用户要求的地图绘图模板。**

全球全部方案及16个配对都有区间；洲别主方案及撤源、加雨两个主要配对有区间。其余洲别对照按事先确定的范围保存点估计，未计算区间的地方不冒充已经检验。
''')
add('''## 4. 全球结果：全部11个方案

### 4.1 主阈值q20：时间和亏缺

HSS三列分别为站点中位数；亏缺误差列为逐站绝对相对误差的中位数，百分数为有效目标中的比例。
''')
def low_table(q):
    rows=[]
    for a in arms:
        r=one(core,arm=a,drought_percentile=q)
        rows.append([short[a],f(r.drought_hss_median,3),f(r.drought_hss_chance_median,3),f(r.drought_hss_excess_median,3),f(r.deficit_ratio_median,3),f(r.deficit_abs_ratio_error_median*100),f(r.deficit_within_25pct_pct_valid),f(r.deficit_within_50pct_pct_valid)])
    table(['方案','HSS','同历月机会HSS','超出机会值','亏缺比','亏缺绝对相对误差(%)','亏缺误差≤25%占比(%)','≤50%占比(%)'],rows)
low_table(20)
add('''主线性试验显示，撤源距离由0扩大到100、300、800 km时，HSS和亏缺容差达标比例持续下降。D800下加入实际降雨有补偿，但仍明显低于区域参考保留时的表现。

### 4.2 更严格阈值q10：完整敏感性
''')
low_table(10)
add('''更低的历史相对阈值下，区域参考撤除的损失仍然存在；加雨带来的偏枯识别和亏缺容差收益仍有限。不能用q20的较好表现代表更严格偏枯条件。

**两档阈值的不确定性不能混用：** q10下加雨使亏缺≤25%的比例净增0.713个百分点，95%区间为0.092至1.272，不含零；q20的对应增益为0.658个百分点，区间包含零。因此，“亏缺容差收益区间含零”仅适用于本文主阈值q20，不能推广到全部阈值。q10的增幅即使可检测，量级仍小。

表中的0.0%不一定是零站：q10下KQ0的亏缺≤25%为1/7,996；三个核模型方案的亏缺≤50%均为1/7,996，即0.012506%。完整精度与人数保存在原表。

### 4.3 总水量及归一化亏缺误差

总水量四列与偏枯阈值无关，仅列一次。有符号误差为负表示低估总水量。“归一亏缺误差”以历史均流水量为分母，与亏缺自身的相对误差不是同一指标。
''')
table(['方案','总水量有符号误差(%)','总水量绝对误差(%)','总水量误差≤10%占比(%)','≤20%占比(%)','q20归一亏缺误差(%)','q10归一亏缺误差(%)'],[
 [short[a],f((r:=one(core,arm=a,drought_percentile=20)).water_rel_error_median*100),f(r.water_abs_rel_error_median*100),f(r.water_within_10pct_pct_valid),f(r.water_within_20pct_pct_valid),f(r.deficit_abs_error_hmean_normalized_median*100,3),f(one(core,arm=a,drought_percentile=10).deficit_abs_error_hmean_normalized_median*100,3)] for a in arms])
add('''**原先设想的“平均水量仍基本准确，只是偏枯时序出错”不成立。** 区域参考撤除后，总水量绝对误差也明显增加。季节基线的总水量误差中位数15.4%甚至低于D800的17.9%，但其偏枯HSS为0、亏缺容差达标率为0，说明总量接近不能替代时间与亏缺的检验。

### 4.4 主要发现及其含义

1. **区域径流记录具有实际用途价值。** 主线性处理器的HSS由0.709降至0.140；累计亏缺误差≤25%的比例由44.3%降至11.9%；总水量误差由6.3%升至17.9%。全球远处仍有参考，不意味着区域变化可以被可靠替代。
2. **降雨提供部分补偿，不能概括为恢复了水资源用途可靠性。** HSS升至0.214，总水量误差降至16.0%；但亏缺容差达标仅升至12.6%。后者配对净增0.658个百分点，95%区间−0.033至1.295，包含零。
3. **实际同期降雨变化有贡献。** 实际降雨优于仅输入降雨气候态；q20配对HSS增益为0.061，95%区间0.040至0.085。此对照不能推断完整降雨—径流模型的潜力上限。
4. **用途之间存在差别。** D800下只按历史相关排序，亏缺比更接近1、亏缺容差比例更高，但HSS和总水量误差更差。累计量的部分改善不表示发生时机恢复正确，也不能把它说成所有用途上的统一优劣。
5. **处理方式仍影响用途结果。** 固定核ridge的偏枯和亏缺表现明显弱于本轮主线性处理器，加雨也没有复制主处理器的收益。q20下核ridge加雨后，亏缺≤25%达标率反而净降0.261个百分点（95%区间−0.447至−0.121），≤50%达标率净降0.645个百分点（−0.941至−0.402）。它没有为这些新用途调参，不能据此断言核方法普遍无效，也不能声称本文已识别所有算法共有的上限。部分核模型指标中位数及经验区间为零，不代表每个站点都相同，或总体作用精确为零。
''')
add('''## 5. 配对结果：全16个预定对照

以下均写“前者−后者”。HSS上升是改善；误差下降是改善；容差达标率上升是改善。中括号为95%空间区间。连续误差变化使用百分点，HSS使用自身分值。所有结果直接来自已完成的配对表，不是从上述四舍五入的中位数相减。
''')
contrasts=pc[['arm','reference']].drop_duplicates().itertuples(index=False,name=None)
contrasts=list(contrasts); assert len(contrasts)==16
for q in [20,10]:
    add(f'### 5.{1 if q==20 else 2} q{q}偏枯和亏缺的配对变化')
    rows=[]
    for a,ref in contrasts:
        rr=lambda df,m:one(df,arm=a,reference=ref,drought_percentile=q,region='Global',metric=m)
        rows.append([f'{short[a]} − {short[ref]}',ci(rr(pc,'drought_hss'),'paired_delta_median'),ci(rr(pc,'deficit_abs_ratio_error'),'paired_delta_median',100,2),ci(rr(pb,'deficit_within_25pct'),'net_pp_paired_valid',1,2)])
    table(['对照','配对HSS变化','配对亏缺绝对相对误差变化(百分点)','亏缺≤25%净变化(百分点)'],rows)
add('### 5.3 总水量的配对变化（与q阈值无关）')
table(['对照','配对总水量绝对误差变化(百分点)','总水量≤10%净变化(百分点)'],[
 [f'{short[a]} − {short[ref]}',ci(one(pc,arm=a,reference=ref,drought_percentile=20,region='Global',metric='water_abs_rel_error'),'paired_delta_median',100,2),ci(one(pb,arm=a,reference=ref,drought_percentile=20,region='Global',metric='water_within_10pct'),'net_pp_paired_valid',1,2)] for a,ref in contrasts])
add('''### 5.4 降雨让多少站新增达标，又让多少站失去达标

只报净收益会掩盖双向变化。下表是QP800相对Q800的配对人数；无效目标不参与配对，不按失败填入。
''')
rows=[]
for q in [20,10]:
    for m,title in [('deficit_within_25pct','亏缺≤25%'),('water_within_10pct','总水量≤10%')]:
        if q==10 and m.startswith('water'):continue
        r=one(pb,arm='ridge_QP_D800',reference='ridge_Q_D800',drought_percentile=q,region='Global',metric=m)
        rows.append([f'q{q} {title}',int(r.n_pairs),int(r.new_pass),int(r.lost_pass),int(r.both_pass),int(r.neither_pass),ci(r,'net_pp_paired_valid',1,2)])
table(['指标','配对数','新增达标','失去达标','共同达标','共同未达标','净变化(百分点)'],rows)
add('''## 6. 前后时段均值变化：全部方案和两档容差

下表使用有效目标分母。四类互斥且穷尽，四舍五入后行和可能不精确等于100%。季节基线几乎总判持平，因此“方向相反少”本身并不表示好表现，还要看漏报了多少真实变化。
''')
for band in [10,20]:
    add(f'### 6.{1 if band==10 else 2} ±{band}%视为持平')
    rows=[]
    for a in arms:
        vals=[one(b,arm=a,drought_percentile=20,region='Global',metric=f'change_{k}_{band}pct') for k in ['correct','false_stable','false_change','reversed']]
        rows.append([short[a],int(vals[0].n_valid),*[f(r.pct_valid) for r in vals]])
    table(['方案','有效n','判断一致(%)','真变化判持平(%)','真持平判变化(%)','增减方向相反(%)'],rows)
add('''区域参考保留时，±10%口径的判断一致率为76.7%；撤除800 km内参考后降为48.4%；加雨后升为51.2%。这支持水量判断也受区域信息影响，但不能把“前后均值增减方向”改写为趋势恢复。

## 7. 地区分布：哪里损失大，降雨补偿如何

本节只描述固定合格样本。北美占母队列的大多数，非洲97目标中93个在南非和纳米比亚，亚洲和非洲不是各自全洲的随机代表。洲际差异不能单独证明站网密度、气候或降雨质量的因果影响。本轮用途评价没有新增密度匹配归因；此前降雨—密度分析属于另一组试验。

### 7.1 q20偏枯月份识别
''')
keyarms=['ridge_Q_D0','ridge_Q_D800','ridge_QP_D800']
rows=[]
for region,zh in regions.items():
    r0=one(c,region=region,arm=keyarms[0],drought_percentile=20,metric='drought_hss')
    r=[one(c,region=region,arm=a,drought_percentile=20,metric='drought_hss') for a in keyarms]
    pr=one(pc,region=region,arm=keyarms[2],reference=keyarms[1],drought_percentile=20,metric='drought_hss')
    rows.append([zh,int(r0.n_registered),int(r0.n_valid),*[f(x['median'],3) for x in r],ci(pr,'paired_delta_median')])
table(['地区','注册n','HSS有效n','Q0 HSS','Q800 HSS','QP800 HSS','加雨配对HSS增益[95%区间]'],rows)
add('### 7.2 q20累计亏缺误差≤25%的达标比例')
rows=[]
for region,zh in regions.items():
    rr=[one(b,region=region,arm=a,drought_percentile=20,metric='deficit_within_25pct') for a in keyarms]
    pr=one(pb,region=region,arm=keyarms[2],reference=keyarms[1],drought_percentile=20,metric='deficit_within_25pct')
    rows.append([zh,int(rr[0].n_valid),*[f(r.pct_valid) for r in rr],ci(pr,'net_pp_paired_valid',1,2)])
table(['地区','有效n','Q0达标(%)','Q800达标(%)','QP800达标(%)','加雨净变化(百分点)[95%区间]'],rows)
add('### 7.3 十年总水量绝对误差')
rows=[]
for region,zh in regions.items():
    rr=[one(c,region=region,arm=a,drought_percentile=20,metric='water_abs_rel_error') for a in keyarms]
    pr=one(pc,region=region,arm=keyarms[2],reference=keyarms[1],drought_percentile=20,metric='water_abs_rel_error')
    rows.append([zh,int(rr[0].n_valid),*[f(r['median']*100) for r in rr],ci(pr,'paired_delta_median',100,2)])
table(['地区','有效n','Q0误差(%)','Q800误差(%)','QP800误差(%)','加雨配对误差变化(百分点)[95%区间]'],rows)
add('''不同用途的区域排序不必一致。描述“哪个地区受益最多”时必须同时说清指标、有效样本和对照，不能将HSS的提升直接等同于累计亏缺或水量收益。q20加雨HSS配对区间严格高于零的洲别为欧洲和北美，不能写成所有洲都获得同样明确的改善。本目录虽然保留了原风险标签，但没有完成风险分组的水资源效应汇总，不能将保存标签当成已开展分组分析。

## 8. 分母、异常情形和核查结果

### 8.1 为什么8,083目标会出现不同有效n
''')
rows=[]
for q in [20,10]:
    for m,title in [('drought_hss','偏枯HSS'),('deficit_ratio','真实亏缺为正的亏缺比'),('deficit_abs_error_hmean_normalized','历史水量归一亏缺误差'),('water_abs_rel_error','总水量相对误差')]:
        r=one(c,arm='ridge_Q_D0',drought_percentile=q,region='Global',metric=m)
        rows.append([f'q{q}',title,int(r.n_valid),int(r.n_unevaluated)])
table(['阈值','指标','有效数','未评价数'],rows)
add('''所有方案在上表各指标的有效分母一致。均值变化的有效数为8,069。

- 原始历史含负值5站，缺口真值含负值9站，两者重叠4站；没有人为截断或修饰成非负数据。
- 另有4站历史全零，不能估计历史异常阈值；1站缺口真值总水量为零，不能计算相对水量误差。
- 在阈值与观测合法的8,069站中，q20有9站无偏枯事件、1站所有月均为偏枯；q10分别为73站和1站。HSS在这些无二分类对比的情况下不评价。
- 无真实亏缺时不伪造亏缺比为1；无真实总水量时不伪造相对误差为0；仍保留能定义的绝对量和状态。
- 合法有限的季节回退预测可以评价用途，但保留原fit/support/fallback身份，不能把它称为获得充分参考支持。原输出未保存的状态保留未知值，不倒推填造。
- 不机械沿用原NSE不能评分的15站排除规则，新指标按自己的数学定义核算分母。

### 8.2 已完成的质量核查

| 层级 | 完成内容 | 结果 |
| --- | --- | --- |
| 输入身份 | 目标索引、真实年月、月天数、冻结历史变换、来源版本、预测身份 | 通过 |
| 合成指标测试 | 22项，含完美预测、季节机会值、零/全事件、闰年、零分母、负值、NaN、容差边界、四类穷尽性 | 通过 |
| 独立逐目标重算 | 177,826行；2,398个字段×方案×分位数组合核查，未调用生产指标函数 | 通过 |
| 独立汇总复核 | 149,452项检查，含单方案、配对、分母、混淆矩阵、状态和区间链接 | 通过 |
| 空间区间复算 | 350条区间，每条沿用2,000次抽样；包括330条核心和20条抽查 | 通过 |
| 计算阶段最终清单 | 104项来源、输出、哈希和完整性检查 | 通过 |
| 图件与文稿 | 三项主图数值、区间、分母及最新图号；正文23页、SI50页逐页检查 | 通过 |

### 8.3 修过什么问题，是否改变科学结果的定义

初版将历史残差除以标准差、取分位数，再乘回标准差时，6个数学上应为零的阈值变成约10⁻¹⁷的正数，使部分零流量月份被误判为严格低于阈值。q20涉及3站，q10涉及另外3站。

用80位高精度计算确认后，改用等价的原残差分位数直接反变换。科学分位数、严格小于规则、容差、模型和预测均未改变，也没有增加事后epsilon截断。全11方案、两阈值、16配对和同一空间抽样全部重算。旧代码、失败记录和修正前输出保留在archive中，本汇总只用修正后的最终结果。
''')
add('''## 9. 哪些已进入论文，哪些仍是完整本地补充结果

| 内容 | 当前呈现位置 | 状态 |
| --- | --- | --- |
| 区域撤源的偏枯识别、亏缺容差、总水量后果 | R3末段；Fig. 3e、f、g | 已纳入 |
| 加雨后的三项用途变化，以及q20、±25%亏缺容差下收益区间含零 | R4用途段；Fig. 3e–g及图注 | 已纳入 |
| 对区域记录连续性、降雨补偿范围的解释 | 引言衔接、Discussion | 已纳入 |
| 历史阈值、HSS、亏缺、水量积分、有效性和区间方法 | 正文Methods | 已纳入 |
| 原Fig. 3e–g的评分限制与季节缺失对照 | 最新SI Fig. S6a–c | 已移入SI；这些不是本轮水资源用途图 |
| q10、11方案全表、16配对、各洲用途表、均值变化及状态明细 | 本汇总及实验目录完整CSV | 已计算并本地保存，尚未全部写进当前SI DOCX |

图件版本轨迹：独立三面板点区间预览 → 用户确认的柱状预览 → 原独立主图Fig. 4 → 合并后Fig. 3e–g。原R4整图在插入独立用途图时曾编号Fig. 5，最终恢复为Fig. 4。当前引用以2026年10月30日最终正文和SI为准。

本次合并没有重新计算数据。Fig. 3a–d保持原图内容；底部三图采用已确认柱状图。原Fig. 3e–g的数据完整迁入S6，没有为了版面删除负收益或不确定结果。上述完整用途敏感性目前是本地可追溯材料，不能在文字中误称为已经存在于某个SI表号。

## 10. 这轮结果为论文增加了什么，边界在哪里

**增加的实质证据是：全球参考的名义可得性，与区域变化的实际可替代性之间的差距，能够传递到具体水资源判断。** 因此，持续、回收和共享区域径流记录的意义，不只是提高某一个重构分数，也包括保留偏枯发生时机、亏缺程度和总水量的信息。

降雨进一步说明外部信息的价值具有用途差别：它可以改善偏枯识别和总水量，但让累计亏缺重新落回指定容差的净收益很小。该结论支持本文的信息主线，而不是将论文转为发布一套对所有水文用途都可靠的数据产品。

需要明确保留以下边界：

1. 这是固定H60/G120、降雨准入队列的受控前向试验，不是全球所有GSIM自然缺口的用途准确率。
2. 区域撤源是压力试验，不等于现实站网已经撤站，也不是某个具体管理区域的损失估计。
3. 五年参照的偏枯阈值不是长期气候干旱等级；径流阈值亏缺不是实际供水缺口；没有计算库容、缺水经济损失或生态后果。
4. 十年总体水量和前后均值变化不能替代年度水量、趋势、洪峰、干旱历时或水库调度可靠性验证。
5. 只测试了既有冻结的处理器和降雨输入，不能解释为任何算法都无能为力，也没有排除更完整气象输入或专门用途模型的可能收益。
6. 非洲和亚洲样本有限且集中；本轮不能将洲际差异直接归因于监测密度，也不能把洲别数字推广到所有国家。

未开展的工作：新的流量重构训练、按用途调参、洪水极值验证、真实供需或库容模拟、全球实际干旱趋势重估、该用途结果的密度因果归因。这些均不能写成已经完成。
''')
add('## 11. 完整材料、原表与最新论文索引')
links=[
('本轮原始结果报告',B/'水资源后果_结果报告_20261029.md','最初计算完成时的报告；其中“尚未入稿”是当时状态，现状以本汇总第9节为准'),
('全部11方案×2阈值核心结果',B/'水资源后果_全球核心结果_20261029.csv','22行，含分母、四分位数、区间与容差'),
('逐目标完整结果',B/'results/per_target_water_metrics.csv.gz','177,826行；详细数值、有效性、原拟合/支持身份'),
('连续量完整汇总',B/'analysis/continuous_by_arm.csv','全球及各洲全部连续指标；中位数、四分位数与预定区间'),
('容差及方向类别比例',B/'analysis/binary_proportions_by_arm.csv','全部比例、已知达标人数、有效与注册两种分母'),
('连续量全配对',B/'analysis/paired_continuous_effects.csv','16对照×2阈值×全部地区与指标；逐站差值统计'),
('容差及方向类别全配对',B/'analysis/paired_binary_effects.csv','新增/失去/共同达标及净变化'),
('事件与混淆计数',B/'analysis/event_counts_by_arm.csv','命中、漏报、虚报、正确否定与事件数'),
('前后均值完整3×3混淆表',B/'analysis/period_mean_direction_confusion.csv','两档持平容差，所有方案和地区'),
('体积量描述',B/'analysis/volume_descriptors_by_arm.csv','各站体积的分布，未对嵌套流域求全球总和'),
('异常及有效状态',B/'analysis/state_counts_by_arm.csv','无事件、零分母、回退与未知状态；不可把跨方案累计数当独立站数'),
('空间抽样分位数',B/'analysis/bootstrap_quantiles.csv','全部已计算区间的抽样分位数'),
('用途计算协议',B/'PROTOCOL.md','问题、定义、阈值和边界'),
('统计汇总规范',B/'analysis_plan.md','全16对照、分母与区间规则'),
('指标字段说明',B/'METRICS_API.md','指标定义与有效条件'),
('来源与方案身份',B/'data/ARM_REGISTRY.json','全部方案及冻结来源切片'),
('目标元数据',B/'data/case_metadata.csv','原登记索引、国家和洲等；用途母队列是其中降雨准入目标'),
('零阈值修正记录',B/'NUMERICAL_FIX.md','修正缘由及旧版本归档位置'),
('独立指标核查报告',B/'audit/INDEPENDENT_METRICS_QA.md','全量逐目标独立复算'),
('独立汇总核查',B/'audit/INDEPENDENT_SUMMARY_QA.json','全部点估计与抽样区间核对'),
('计算阶段最终QA',B/'FINAL_QA.json','计算完成时的来源和输出哈希，非当前文稿状态'),
('柱状图原始源数据',B/'figures_water_20261029/bar_variant/source_data.csv','三指标×三条件、分母、95%区间'),
('柱状图配对源数据',B/'figures_water_20261029/bar_variant/paired_source_data.csv','图注引用的配对效应'),
('最新合并Fig. 3',V/'figure_consolidation_20261029/figures/Fig3_regional_substitution_water_consequences_20261029.pdf','水资源用途在e–g'),
('最新补充Fig. S6',V/'figure_consolidation_20261029/figures/FigS6_regional_and_seasonal_diagnostics_20261029.pdf','旧Fig. 3e–g的诊断及季节对照'),
('最新英文正文',V/'Observational_information_Main_Final_20261030.docx','23页最终清洁稿'),
('最新SI',V/'Observational_information_Supplementary_Final_20261030.docx','50页最终清洁稿'),
('合并与引用核查',V/'figure_consolidation_20261029/FINAL_QA.json','绑定最新文稿、图件和逐页检查')]
table(['材料','内容'],[(lk(title,p),desc) for title,p,desc in links])
add('''本汇总中的科学结果以实验目录最终CSV为依据；论文图号以最新定稿为依据。所有材料仅保存在本地，本次没有上传云端。
''')
text='\n'.join(parts)
OUT.write_text(text,encoding='utf-8-sig')
# Read-only source integrity and table coverage checks for the new summary.
assert before=={str(p):sha(p) for p in source_files}
assert len(core)==22 and len(arms)==11
assert all(a in text for a in arms)
assert len(contrasts)==16
assert not re.search(r'\b(?:nan|None)\b',text)
for p in re.findall(r'\]\(<([^>]+)>\)',text): assert Path(p).exists(),p
q={'status':'PASS','summary':str(OUT),'summary_sha256':sha(OUT),'characters':len(text),'lines':len(text.splitlines()),'source_files_unchanged':True,'n_arms':11,'n_percentiles':2,'n_contrasts':16,'n_regions':7,'source_hashes':before,'new_model_fits':0,'cloud_upload':False}
(B/'SUMMARY_20261030_QA.json').write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in q.items() if k!='source_hashes'},ensure_ascii=False))
