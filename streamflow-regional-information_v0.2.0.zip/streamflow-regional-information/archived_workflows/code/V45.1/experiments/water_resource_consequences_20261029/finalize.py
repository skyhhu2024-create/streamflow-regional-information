from pathlib import Path
import hashlib, json, csv
from datetime import datetime, timezone

R = Path(__file__).resolve().parent

def digest(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def read(p):
    return json.loads((R / p).read_text(encoding='utf-8'))

checks = []
def check(label, actual, expected):
    assert actual == expected, (label, actual, expected)
    checks.append(label)

table = R / 'results/per_target_water_metrics.csv.gz'
table_hash = digest(table)
score = read('results/PER_TARGET_COMPLETE.json')
stats = read('analysis/SUMMARY_QA.json')
metrics_audit = read('audit/INDEPENDENT_METRICS_QA.json')
stats_audit = read('audit/INDEPENDENT_SUMMARY_QA.json')
synthetic = read('METRICS_SYNTHETIC_QA.json')
check('score table hash', score['output_sha256'], table_hash)
check('score metric implementation', score['metrics_sha256'], digest(R / 'metrics.py'))
check('synthetic metric implementation', synthetic['metrics_sha256'], digest(R / 'metrics.py'))
check('synthetic tests', synthetic['success'], True)
check('score row count', score['n_rows'], 8083 * 11 * 2)
check('statistics status', stats['status'], 'PASS')
check('statistics table hash', stats['metric_table_sha256'], table_hash)
check('statistics schema hash', stats['schema_sha256'], digest(R / 'SCHEMA.json'))
check('metrics independent status', metrics_audit['status'], 'PASS')
check('metrics independent source', metrics_audit['inputs']['production_metrics_csv_sha256'], table_hash)
check('metrics independent receipt', metrics_audit['inputs']['production_receipt_sha256'], digest(R / 'results/PER_TARGET_COMPLETE.json'))
check('statistics independent status', stats_audit['status'], 'PASS')
check('statistics independent source', stats_audit['hashes']['per_target'], table_hash)
check('statistics independent receipt', stats_audit['hashes']['summary_receipt'], digest(R / 'analysis/SUMMARY_QA.json'))
for name, item in stats['outputs'].items():
    actual = digest(R / 'analysis' / name)
    check('statistical output ' + name, actual, item['sha256'])
    check('independent statistical output ' + name, actual, stats_audit['output_hashes'][name])
for name, item in read('data/DATA_COMPLETE.json')['files'].items():
    check('frozen input ' + name, digest(R / 'data' / name), item['sha256'])
for name, item in read('data/SOURCE_MANIFEST.json')['sources'].items():
    check('original source unchanged ' + name, digest(name), item['sha256'])

manuscripts = {
    'Observational_information_Main_Polished_20261029.docx': 'd9372987aa1942ceedaeaac6d9891f5a23dddc22a60f56e848d5bdc97eab1049',
    'Observational_information_Supplementary_Polished_20261029.docx': '42063d0412fca39fdcc99e53d15dccb3469eee351234112aeef5621dcfc8f791',
}
for name, expected in manuscripts.items():
    check('manuscript unchanged ' + name, digest(R.parent.parent / name), expected)
report = R / '水资源后果_结果报告_20261029.md'
keytable = R / '水资源后果_全球核心结果_20261029.csv'
with keytable.open(encoding='utf-8-sig', newline='') as f:
    rows = list(csv.DictReader(f))
check('core table rows', len(rows), 22)
check('core table arms', len({x['arm'] for x in rows}), 11)
check('core table percentiles', sorted({x['drought_percentile'] for x in rows}), ['10', '20'])
check('report size sufficient', len(report.read_text(encoding='utf-8')) > 5000, True)

files = ['PROTOCOL.md', 'analysis_plan.md', 'metrics.py', 'SCHEMA.json', 'METRICS_SYNTHETIC_QA.json',
         'run_metrics.py', 'summarize_water_results.py', 'write_report.py', 'finalize.py',
         'EVALUATION_FROZEN.json', 'ANALYSIS_PLAN_FROZEN.json', 'NUMERICAL_FIX.md',
         'results/PER_TARGET_COMPLETE.json', 'analysis/SUMMARY_QA.json',
         'audit/INDEPENDENT_METRICS_QA.json', 'audit/INDEPENDENT_SUMMARY_QA.json',
         '水资源后果_结果报告_20261029.md', '水资源后果_全球核心结果_20261029.csv']
out = {
    'status': 'PASS_FINAL_RESULTS_BOUND_AND_SOURCES_UNCHANGED',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'checks': checks,
    'n_checks': len(checks),
    'n_targets': 8083, 'n_arms': 11, 'n_rows': score['n_rows'],
    'original_sources_unchanged': True, 'manuscripts_unchanged': True,
    'cloud_upload': False, 'new_figures': False,
    'files': {p: digest(R / p) for p in files},
    'metric_table_sha256': table_hash,
    'interpretation': 'Retrospective evaluation of frozen predictions; metric thresholds fixed before computing these outcomes; primary and adverse sensitivity results retained.'
}
(R / 'FINAL_QA.json').write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')
print('FINAL_QA_PASS', len(checks))
