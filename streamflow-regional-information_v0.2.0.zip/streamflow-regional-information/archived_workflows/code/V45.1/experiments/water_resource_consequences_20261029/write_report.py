from pathlib import Path
import sys, json
R = Path(__file__).resolve().parent
CODE = next(p for p in R.parents if p.name == 'code')
sys.path.insert(0, str(CODE / 'V42/dependencies'))
import pandas as pd

A = R / 'analysis'
C = pd.read_csv(A / 'continuous_by_arm.csv')
B = pd.read_csv(A / 'binary_proportions_by_arm.csv')
PC = pd.read_csv(A / 'paired_continuous_effects.csv')
PB = pd.read_csv(A / 'paired_binary_effects.csv')
names = {
    'ridge_Q_D0':'区域参考保留', 'ridge_Q_D100':'撤除100 km内参考',
    'ridge_Q_D300':'撤除300 km内参考', 'ridge_Q_D800':'撤除800 km内参考',
    'ridge_QP_D800':'撤除800 km后加实际降雨',
    'ridge_QP_Gclim_D800':'撤除800 km后加降雨气候态',
    'corr_only_ridge_Q_D800':'撤除800 km后仅按历史相关排序',
    'seasonal_baseline':'目标历史季节基线',
    'rbf_Q_D0':'核ridge：区域参考保留', 'rbf_Q_D800':'核ridge：撤除800 km',
    'rbf_QP_D800':'核ridge：撤除800 km后加雨',
}


def get(df, arm, metric, q=20, reg='Global', ref=None):
    mask=(df.arm==arm)&(df.metric==metric)&(df.drought_percentile==q)&(df.region==reg)
    if ref is not None: mask &= df.reference==ref
    x=df[mask]
    assert len(x)==1, (arm,metric,q,reg,ref,len(x))
    return x.iloc[0]


def mdtable(headers, rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+
                     ['| '+' | '.join(map(str,row))+' |' for row in rows])


def point_table(arms, q=20):
    rows=[]
    for arm in arms:
        med=lambda m:get(C,arm,m,q)['median']
        pct=lambda m:get(B,arm,m,q)['pct_valid']
        rows.append([names[arm],f'{med("drought_hss"):.3f}',f'{med("drought_hss_excess"):.3f}',
                     f'{med("deficit_ratio"):.3f}',f'{pct("deficit_within_25pct"):.1f}%',
                     f'{100*med("water_abs_rel_error"):.1f}%',f'{pct("water_within_10pct"):.1f}%'])
    return mdtable(['条件','偏枯月份HSS','HSS减季节机会值','亏缺比中位数','亏缺误差≤25%','总水量绝对误差中位数','总水量误差≤10%'],rows)


def effect(arm, ref, metric, factor=1, binary=False, q=20):
    row=get(PB if binary else PC,arm,metric,q,ref=ref)
    value=row['net_pp_paired_valid' if binary else 'paired_delta_median']*factor
    return f'{value:+.3f} [{row.ci025*factor:+.3f}, {row.ci975*factor:+.3f}]'


mainarms=['ridge_Q_D0','ridge_Q_D100','ridge_Q_D300','ridge_Q_D800','ridge_QP_D800','seasonal_baseline']
key=[]
for q in (20,10):
    for arm in names:
        row={'arm':arm,'condition_zh':names[arm],'drought_percentile':q,'n_registered':8083}
        for metric in ['drought_hss','drought_hss_chance','drought_hss_excess','deficit_ratio',
                       'deficit_abs_ratio_error','deficit_abs_error_hmean_normalized','water_abs_rel_error','water_rel_error']:
            x=get(C,arm,metric,q)
            for v in ('n_valid','median','q25','q75','ci025','ci975'):row[metric+'_'+v]=x[v]
        for metric in ['deficit_within_25pct','deficit_within_50pct','water_within_10pct','water_within_20pct',
                       'change_correct_10pct','change_reversed_10pct','change_correct_20pct','change_reversed_20pct']:
            x=get(B,arm,metric,q)
            for v in ('n_valid','n_pass','pct_valid','pct_known_pass_registered','ci025','ci975'):row[metric+'_'+v]=x[v]
        key.append(row)
pd.DataFrame(key).to_csv(R/'水资源后果_全球核心结果_20261029.csv',index=False,encoding='utf-8-sig')

denrows=[]
for q in (20,10):
    for met,label in [('drought_hss','偏枯月份HSS'),('deficit_ratio','有真实亏缺的比值评价'),
                       ('deficit_abs_error_hmean_normalized','H期水量归一的亏缺绝对误差'),
                       ('water_abs_rel_error','缺口期水量相对误差')]:
        x=get(C,'ridge_Q_D0',met,q)
        denrows.append([q,label,int(x.n_valid),int(x.n_unevaluated)])
effects=[]
for label,met,factor,bb in [('偏枯月份HSS','drought_hss',1,False),
                           ('HSS减季节机会值','drought_hss_excess',1,False),
                           ('绝对亏缺相对误差（百分点）','deficit_abs_ratio_error',100,False),
                           ('亏缺误差≤25%的比例（百分点）','deficit_within_25pct',1,True),
                           ('总水量绝对相对误差（百分点）','water_abs_rel_error',100,False),
                           ('总水量误差≤10%的比例（百分点）','water_within_10pct',1,True)]:
    effects.append([label,effect('ridge_Q_D800','ridge_Q_D0',met,factor,bb),
                    effect('ridge_QP_D800','ridge_Q_D800',met,factor,bb)])
direction=[]
for arm in ['ridge_Q_D0','ridge_Q_D800','ridge_QP_D800','corr_only_ridge_Q_D800','seasonal_baseline']:
    vals=[get(B,arm,m)['pct_valid'] for m in ['change_correct_10pct','change_false_stable_10pct',
                                           'change_false_change_10pct','change_reversed_10pct']]
    direction.append([names[arm]]+[f'{v:.1f}%' for v in vals])
regionrows=[]
for reg,zh in [('Europe','欧洲'),('Asia','亚洲'),('Africa','非洲'),('NorthAmerica','北美'),
               ('SouthAmerica','南美'),('Oceania','大洋洲'),('Other','其他')]:
    x=get(C,'ridge_Q_D0','drought_hss',reg=reg)
    regionrows.append([zh,int(x.n_registered),int(x.n_valid)]+
                      [f'{get(C,a,"drought_hss",reg=reg)["median"]:.3f}' for a in ['ridge_Q_D0','ridge_Q_D800','ridge_QP_D800']]+
                      [f'{get(PC,"ridge_Q_D800","drought_hss",reg=reg,ref="ridge_Q_D0")["paired_delta_median"]:+.3f}'])

text=f'''# 区域参考撤除的水资源后果

2026年10月29日。本轮只计算冻结预测的用途结果；正文、SI、原预测和云端均未改动。

## 结果判断

这项补充有助于说明论文主线的实际含义：区域参考失去以后，剩余全球参考不仅重构评分下降，识别偏枯月份、估计其累计亏缺及缺口期总体水量也更困难。降雨可部分改善，改善程度因用途而异。

结果不支持预先设想的“平均水量仍准确、只有偏枯时序出错”。总体水量绝对误差同样显著增加。仅历史相关排序还显示用途之间的差别：累计亏缺量的部分指标优于联合排序，但时序识别和总体水量更差，不能把所有用途概括为同一种排名。

## 1 试验和指标

使用当前主稿安全清理后的全球参考池、固定8,083个降雨准入目标，每站60个月历史、其后120个月缺口，11个冻结预测臂。不重拟合、不调模型、不按结果选站。逐指标核算有效分母，全部预定阈值、容差和不利结果保留。

异常偏枯月是相对这五年可见历史的季节异常：原log1p季节变换、全部H残差标准差、H距平第20百分位；第10百分位作敏感性。这不是长期气候干旱等级。偏枯识别和累计亏缺采用同一个月变流量阈值；水量均乘实际月天数和秒数。

普通HSS越高表示识别更好（1为完美）；另报同历月条件机会值及其差值，防止把季节形状匹配当作跨年识别。该差值不是标准HSS，也不是信息量的因果分解。

亏缺比为重构累计亏缺/真实累计亏缺，1为准确，小于1表示低估。总体水量误差针对整个十年区间，不代表每一年准确，也不等同于趋势。

## 2 主结果

以下均为站点等权汇总。比例以对应指标有效站点为分母；全8,083母队列上的已知达标数和未评价数另列于CSV。

{point_table(mainarms)}

### 配对效应及95%空间区间

下表是逐站差值的中位数或配对比例变化，不能与上表两个中位数相减混用。沿用2,000次5°空间块重采样，全部臂共享同一组274格权重。

{mdtable(['指标','撤除800 km相对区域参考保留','撤除800 km后加雨相对仅径流'],effects)}

这使主要结论落到具体用途：区域参考对识别异常偏枯的时间及其程度均有价值；降雨补偿在月份识别上较清楚，而把累计亏缺估计带回±25%容差内的新增比例很小，区间包含零。不能将统计上可检测的连续改善都描述成足够满足某个用途。

## 3 降雨同期信息与其他选源方式

{point_table(['ridge_Q_D800','ridge_QP_D800','ridge_QP_Gclim_D800','corr_only_ridge_Q_D800'])}

实际降雨相对降雨气候态的配对HSS增益为 {effect('ridge_QP_D800','ridge_QP_Gclim_D800','drought_hss')}；这说明该对照中改善依赖缺口期降雨变化。气候态替换使用原已拟合联合模型，没有重新率定。

仅相关排序相对联合排序的HSS变化为 {effect('corr_only_ridge_Q_D800','ridge_Q_D800','drought_hss')}，总水量绝对误差变化为 {effect('corr_only_ridge_Q_D800','ridge_Q_D800','water_abs_rel_error',100)} 个百分点；但亏缺误差在±25%内的比例变化为 {effect('corr_only_ridge_Q_D800','ridge_Q_D800','deficit_within_25pct',binary=True)} 个百分点。累计亏缺接近真值，并不保证发生月份被准确识别。这里报告了对照事实，没有进一步认定其物理原因。

## 4 更严格偏枯阈值的敏感性

第10百分位代表更低的历史相对阈值，结果完整保留：

{point_table(['ridge_Q_D0','ridge_Q_D800','ridge_QP_D800','seasonal_baseline'],10)}

q10下撤源的配对HSS变化为 {effect('ridge_Q_D800','ridge_Q_D0','drought_hss',q=10)}，加雨变化为 {effect('ridge_QP_D800','ridge_Q_D800','drought_hss',q=10)}。亏缺±50%、总水量±20%和均值变化±20%的全部结果在同一套表中，未按结果筛选展示。

## 5 固定第二处理器

{point_table(['rbf_Q_D0','rbf_Q_D800','rbf_QP_D800'])}

第二处理器同样受到区域撤源影响，但对偏枯、亏缺和降雨补偿的表现与主处理器不同。因此，主试验支持所检验条件下区域信息的重要性，不给出所有算法共有的水资源用途上限；降雨的用途收益也不能脱离具体处理方式解释。核ridge是既有固定敏感性，未为这些新指标调整参数。

## 6 时段均值变化 补充结果

将缺口十年按天加权平均流量与前五年比较，±10%为持平；四类互斥穷尽。它是两个时段的均值比较，不是十年趋势方向或显著性检验。

{mdtable(['条件','一致','真变化判持平','真持平判变化','增减方向相反'],direction)}

完整3×3混淆表和±20%敏感性已保存。季节基线通常判持平，因此“方向反转少”不能单独当作好表现，还须看漏报变化。

## 7 地区范围

地区只描述原合格样本，不以洲际差异识别密度或气候机制。非洲97目标中的93个位于南非和纳米比亚；亚洲、非洲样本均不是全洲随机代表。

{mdtable(['地区','注册目标','q20 HSS有效数','区域参考保留HSS','800 km撤源HSS','撤源加雨HSS','撤源逐站HSS差中位数'],regionrows)}

各洲原始计数、全部点估计和主对照区间均在分析表中。未将受控队列的用途准确率外推到GSIM所有自然缺口或某个具体流域的实际管理损失。

## 8 有效分母

{mdtable(['H阈值百分位','指标','有效数','未评价数'],denrows)}

母队列中原始H含负值5站，G含负值9站；原样保留，未修饰负值。历史变换不可估、真值无偏枯/全偏枯、零真实亏缺和零真实水量分别编码。合法有限季节回退可评价用途，原fit/support和回退身份另存，未将其改称支持充分的重构。

## 9 对主线和入稿的建议

这套结果适合在R3时序损失段后用一个短段解释水资源含义，在R4加一句降雨能改善哪些判断。核心用途图可以集中于月份识别、亏缺和总体水量三个量，全部其他对照和阈值放SI，不必提前铺开三张Extended Data。

值得强调的是：参考可得性不能保证区域变化被替代，这一问题会影响偏枯识别和水量判断；补充降雨提供部分补偿，但其对时间和累计量的作用不完全相同。本文仍是一项观测信息作用研究，没有用这些测试发布一个已验证所有用途的全球重构产品。

不能写“平均水量基本不受影响”“降雨已经恢复干旱判断”“仅相关排序在所有用途上都更差”，也不能将五年参照下的事件称为经过长期气候率定的干旱等级。每一种说法都超出了本轮结果。

## 10 完整材料和核查

- `水资源后果_全球核心结果_20261029.csv`：全部11臂×两阈值的核心结果、有效分母、分位数和区间。
- `results/per_target_water_metrics.csv.gz`：177,826行逐目标、逐臂、逐阈值结果及原拟合/支持/回退标记。
- `analysis/continuous_by_arm.csv`、`binary_proportions_by_arm.csv`：完整单臂结果与双分母比例。
- `analysis/paired_continuous_effects.csv`、`paired_binary_effects.csv`：全部16个固定配对。
- `analysis/period_mean_direction_confusion.csv`、`state_counts_by_arm.csv`：方向混淆、异常/无定义情况。
- `PROTOCOL.md`、`analysis_plan.md`、`SCHEMA.json`：定义、对照及有效性。
- `data/SOURCE_MANIFEST.json`、`DATA_COMPLETE.json`：来源和冻结预测身份核对。
- `audit/`：独立指标与统计复核；`FINAL_QA.json`绑定最终交付哈希。

初次独立复核识别并修复了数学上零阈值的浮点除乘返还，涉及q20三例和q10三例。修复使用数学等价的残差原尺度分位数，没有改变百分位、容差、预测或科学假设；全量重新计算，修复前结果完整归档，详见 `NUMERICAL_FIX.md`。
'''
(R/'水资源后果_结果报告_20261029.md').write_text(text,encoding='utf-8')
print('REPORT_WRITTEN',len(text))
