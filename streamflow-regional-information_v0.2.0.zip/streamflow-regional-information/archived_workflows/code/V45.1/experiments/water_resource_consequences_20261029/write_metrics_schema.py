"""Export static API schema only; no empirical files accessed."""
from pathlib import Path
import json
import hashlib
import metrics

HERE=Path(__file__).resolve().parent
empty=metrics.empty_result(20)
types={k:('boolean' if isinstance(v,bool) else 'string' if isinstance(v,str) else 'integer' if isinstance(v,int) else 'number_or_nan') for k,v in empty.items()}
groups={
 'drought_hss_valid':['drought_hss','drought_hss_chance','drought_hss_excess'],
 'drought_observed_valid':['drought_observed_count','drought_observed_frequency','drought_observed_none','drought_observed_all'],
 'drought_predicted_valid':['drought_predicted_count','drought_predicted_frequency'],
 'drought_paired_valid':['drought_hits','drought_misses','drought_false_alarms','drought_correct_negatives','drought_frequency_error','drought_hss_expected_hits'],
 'deficit_paired_valid':['deficit_abs_error_m3','deficit_both_zero','deficit_false_positive','deficit_complete_miss'],
 'deficit_ratio_valid':['deficit_ratio','deficit_abs_ratio_error','deficit_within_25pct','deficit_within_50pct'],
 'deficit_normalized_error_valid':['deficit_signed_error_hmean_normalized','deficit_abs_error_hmean_normalized'],
 'water_paired_valid':['water_abs_error_m3','water_both_zero','water_false_positive'],
 'water_relative_error_valid':['water_rel_error','water_abs_rel_error','water_within_10pct','water_within_20pct'],
 'period_change_observed_valid':['period_mean_change_observed','change_observed_10pct','change_observed_20pct'],
 'period_change_prediction_valid':['period_mean_change_predicted','change_predicted_10pct','change_predicted_20pct'],
 'period_change_paired_valid':[f'change_{kind}_{tol}pct' for kind in ['category','correct','false_stable','false_change','reversed'] for tol in [10,20]],
}
schema={
 'version':metrics.VERSION,
 'public_api':'evaluate_case(hist_q, hist_dates, obs_q, pred_q, gap_dates, drought_percentile=20)',
 'input_lengths':{'hist_q':60,'hist_dates':60,'obs_q':120,'pred_q':120,'gap_dates':120},
 'flow_units':'m3/s',
 'volume_units':'m3',
 'dates':'ISO strings, datetime objects or numpy datetime64; consecutive calendar months, H/G adjacent',
 'percentile_values':[20,10],
 'flat_field_count':len(empty),
 'fields':types,
 'validity_groups':groups,
 'special_validity':{
   'drought_count_ratio':'drought_paired_valid and drought_observed_count > 0 and finite',
   'deficit_observed_m3':'drought_observed_valid and finite',
   'deficit_predicted_m3':'drought_predicted_valid and finite',
   'water_observed_volume_m3':'dates_valid and truth_input_valid and finite',
   'water_predicted_volume_m3':'dates_valid and prediction_input_valid and finite',
   'history_mean_flow':'dates_valid and history_input_valid and finite',
 },
 'category_values':['correct','false_stable','false_change','reversed','undefined'],
 'caller_preserves':['case_id','arm','continent','country','spatial_cell','actual_fit','support','fallback_identity'],
 'boundary_relative_tolerance':metrics.BOUNDARY_RTOL,
 'undefined_numeric':'NaN; never silently converted to zero, failure or success',
 'metric_scope':'H60-relative abnormal low months, matching deficit, whole-G volume and between-period mean change; not drought climatology/trend',
 'hashes':{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in ['metrics.py','test_metrics.py','PROTOCOL.md','METRICS_API.md']},
}
(HERE/'SCHEMA.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'field_count':len(empty),'metrics_sha256':schema['hashes']['metrics.py'],'schema_path':str(HERE/'SCHEMA.json')},ensure_ascii=False))
