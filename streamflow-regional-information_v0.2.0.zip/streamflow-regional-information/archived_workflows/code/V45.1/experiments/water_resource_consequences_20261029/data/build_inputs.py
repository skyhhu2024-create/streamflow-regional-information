"""Read-only frozen input assembly. No fits or new water-resource metrics."""
from pathlib import Path
from datetime import datetime, timezone
import os,sys,json,hashlib,warnings
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
CODE=next(p for p in HERE.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd
V45=CODE/'V45'
BASE=V45/'experiments/r4_full_source_gradient_20261026'
PRED=BASE/'predictions'
GLOBAL=V45/'experiments/r3_global_single_condition_20261022/global_data'
CORR=V45/'manuscripts/argument_revision_20261028/evidence/pure_correlation_predictions'
TRIAL=V45/'experiments/r4_observation_locations_20261025/trial_predictions/cases.csv'
PHYS=V45/'experiments/r4_global_siting_20261026/census/physical_identity_map.csv'
PREP=V45/'experiments/r4_global_information_20261025/prepared_inputs'
N,H,G=8898,60,120
DS=[0,100,300,800]
FLAG_NAMES=['actual_fit','requested_fit','requested_source','fallback','uses_P_H','uses_P_G_actual','uses_P_G_climatology']
ARMS=[('ridge_Q_D0',0,0,0),('ridge_Q_D100',1,0,0),('ridge_Q_D300',2,0,0),('ridge_Q_D800',3,0,0),
 ('ridge_QP_D800',3,0,1),('ridge_QP_Gclim_D800',3,0,2),('corr_only_ridge_Q_D800',None,None,None),
 ('seasonal_baseline',None,None,None),('rbf_Q_D0',0,1,0),('rbf_Q_D800',3,1,0),('rbf_QP_D800',3,1,1)]
sources={};outputs={};qa={}

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**23),b''):h.update(b)
 return h.hexdigest()

def reg(p,role):
 p=Path(p).resolve();key=str(p)
 if key not in sources:sources[key]={'sha256':sha(p),'bytes':p.stat().st_size,'role':role}
 return p

def arr(p,role='Frozen input array, opened read-only'):
 return np.load(reg(p,role),mmap_mode='r',allow_pickle=False)

def csv(p):return pd.read_csv(reg(p,'Frozen source table'),keep_default_na=False,na_values=[''],low_memory=False)

def loadjson(p):return json.loads(reg(p,'Frozen source receipt/definition').read_text(encoding='utf8'))

def savejson(p,obj):
 def clean(a):
  if isinstance(a,dict):return {str(k):clean(v) for k,v in a.items()}
  if isinstance(a,(list,tuple,np.ndarray)):return [clean(v) for v in a]
  if isinstance(a,np.generic):return clean(a.item())
  if isinstance(a,float) and not np.isfinite(a):return None
  return a
 Path(p).write_text(json.dumps(clean(obj),ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')

def savearray(name,value,description):
 p=HERE/(name+'.npy');np.save(p,value,allow_pickle=False)
 outputs[p.name]={'shape':list(value.shape),'dtype':str(value.dtype),'description':description,'sha256':sha(p)}

def equal(a,b):return bool(np.array_equal(np.asarray(a),np.asarray(b),equal_nan=True))

def check_receipt(path,folder,names):
 rec=loadjson(path)
 for name in names:
  p=reg(folder/name,'Original frozen array/table; hash checked against source receipt')
  assert sources[str(p)]['sha256']==rec['files'][name],f'Source freeze mismatch {p}'
 return rec

def rescore(y,p,b,fit,sup):
 sy=np.square(y-y.mean(1,keepdims=True)).sum(1)
 sy[np.all(y==y[:,:1],axis=1)]=0
 valid=np.isfinite(y).all(1)&(y>=0).all(1)&(sy>0)
 nse=1-np.divide(np.square(y-p).sum(1),sy,out=np.full(N,np.nan),where=sy>0)
 bn=1-np.divide(np.square(y-b).sum(1),sy,out=np.full(N,np.nan),where=sy>0)
 eligible=valid&np.isfinite(p).all(1)&(p>=0).all(1)&fit&sup.any(1)
 return nse,bn,valid,eligible,eligible&(nse>=.5)&(nse>bn)

def main():
 assert not (HERE/'DATA_COMPLETE.json').exists(),'Never overwrite frozen assembled inputs.'
 protocol=reg(HERE.parent/'PROTOCOL.md','Parent-fixed water-resource evaluation protocol; read only')
 full_names=['cases.csv','predictions.npy','support.npy','flags.npy','P_available.npy','gap_months.npy',
  'target_raw_calendar.npy','target_log_calendar.npy','target_anomaly_sd.npy','target_estimable.npy','target_risk.npy','training_mask.npy','selected_ids.npy','SCORING_INTERFACE.json']
 fullfreeze=check_receipt(PRED/'PREDICTIONS_FROZEN.json',PRED,full_names)
 corrfreeze=check_receipt(CORR/'PREDICTIONS_FROZEN.json',CORR,['predictions.npy','support.npy','actual_fit.npy','training_rows.npy','selected_ids.npy'])
 gc=loadjson(GLOBAL/'GLOBAL_INPUTS_FROZEN.json')
 for nm in ['QC20_Q.npy','dates.npy','station_ids.npy']:
  p=reg(GLOBAL/nm,'Original common GSIM QC20/month axis/identity array')
  assert sources[str(p)]['sha256']==gc['files']['global_data\\'+nm]
 cases=csv(PRED/'cases.csv');oldcases=csv(TRIAL);phys=csv(PHYS).sort_values('raw_index')
 assert len(cases)==N and np.array_equal(cases.row.to_numpy(),np.arange(N))
 ids=arr(GLOBAL/'station_ids.npy');Q=arr(GLOBAL/'QC20_Q.npy');dates=arr(GLOBAL/'dates.npy')
 assert Q.shape==(30959,432) and dates.shape==(432,) and np.issubdtype(dates.dtype,np.datetime64)
 assert dates[0]==np.datetime64('1980-01-01') and dates[-1]==np.datetime64('2015-12-01')
 monthaxis=dates.astype('datetime64[M]');assert equal(dates,monthaxis.astype('datetime64[D]'))
 assert np.all(np.diff(monthaxis.astype(int))==1)
 days=((monthaxis+1).astype('datetime64[D]')-monthaxis.astype('datetime64[D]')).astype(np.int16)
 assert days[np.flatnonzero(monthaxis==np.datetime64('2000-02','M'))[0]]==29
 assert days[np.flatnonzero(monthaxis==np.datetime64('1900-02','M'))[0]]==28 if (monthaxis==np.datetime64('1900-02','M')).any() else True
 raw=cases.raw_index.to_numpy(int)
 assert np.array_equal(ids[raw].astype(str),cases.station_id.astype(str).to_numpy())
 identity_columns=['row','case_id','station_id','raw_index','history_start','history_end','gap_start','gap_end','spatial_cell']
 for k in identity_columns:assert np.array_equal(cases[k].to_numpy(),oldcases[k].to_numpy()),'Pure-correlation case ordering mismatch: '+k
 cr=loadjson(CORR/'REGISTRATION.json')
 assert cr['inputs'][str(TRIAL.resolve())]==sources[str(TRIAL.resolve())]['sha256']
 assert len(phys)==30959 and np.array_equal(phys.raw_index.to_numpy(),np.arange(30959))
 assert np.array_equal(phys.station_id.astype(str).to_numpy(),ids.astype(str))
 hidx=cases.history_start.to_numpy(int)[:,None]+np.arange(H)
 gidx=cases.gap_start.to_numpy(int)[:,None]+np.arange(G)
 assert np.array_equal(hidx[:,-1]+1,cases.history_end.to_numpy(int))
 assert np.array_equal(gidx[:,-1]+1,cases.gap_end.to_numpy(int)) and np.array_equal(hidx[:,-1]+1,gidx[:,0])
 assert hidx.min()>=0 and gidx.max()<len(dates)
 assert equal(gidx,arr(PRED/'gap_months.npy'))
 h=np.asarray(Q[raw[:,None],hidx]);y=np.asarray(Q[raw[:,None],gidx]);hd=np.asarray(dates[hidx]);gd=np.asarray(dates[gidx])
 assert h.shape==(N,H) and y.shape==(N,G) and np.isfinite(h).all() and np.isfinite(y).all()
 pa=np.asarray(arr(PRED/'P_available.npy'),bool);assert pa.sum()==8083 and np.array_equal(pa,cases.P_available.to_numpy(bool))
 cal=np.asarray(arr(PRED/'target_raw_calendar.npy'));lcal=np.asarray(arr(PRED/'target_log_calendar.npy'));asd=np.asarray(arr(PRED/'target_anomaly_sd.npy'))
 baseline=np.take_along_axis(cal,gidx%12,axis=1)
 independently_calculated=np.stack([np.mean(h[i][hidx[i]%12==m]) for i in range(N) for m in range(12)]).reshape(N,12)
 assert np.allclose(independently_calculated,cal,rtol=1e-13,atol=1e-12,equal_nan=True)
 assert equal(cal,arr(PREP/'target_H_raw_calendar.npy'))
 hz=arr(PREP/'target_Hz.npy');assert hz.shape==(N,H)
 pp=arr(PRED/'predictions.npy');sup=arr(PRED/'support.npy');fl=arr(PRED/'flags.npy')
 cp=arr(CORR/'predictions.npy');cs=arr(CORR/'support.npy');cf=arr(CORR/'actual_fit.npy')
 assert pp.shape==sup.shape==(N,4,2,3,G) and fl.shape==(N,4,2,3,7)
 assert cp.shape==cs.shape==(N,4,G) and cf.shape==(N,4)
 assembled=np.full((N,len(ARMS),G),np.nan);support=np.full(assembled.shape,-1,np.int8)
 flags=np.full((N,len(ARMS),7),-1,np.int8);present=np.ones((N,len(ARMS)),bool)
 fallback=np.full(assembled.shape,-1,np.int8);registry=[];flagrows=[]
 for ai,(name,di,mi,ri) in enumerate(ARMS):
  entry={'axis_index':ai,'name':name,'source_row_order':'case_metadata.row; exact shared8898 index'}
  if di is not None:
   assembled[:,ai]=pp[:,di,mi,ri];support[:,ai]=sup[:,di,mi,ri].astype(np.int8);flags[:,ai]=fl[:,di,mi,ri].astype(np.int8)
   entry.update(source_prediction=str(PRED/'predictions.npy'),source_slice=['all',di,mi,ri,'all'],flag_origin='all7 original frozen flags',prediction_recomputed=False)
  elif name=='corr_only_ridge_Q_D800':
   assembled[:,ai]=cp[:,3];support[:,ai]=cs[:,3].astype(np.int8);flags[:,ai,0]=cf[:,3].astype(np.int8)
   entry.update(source_prediction=str(CORR/'predictions.npy'),source_slice=['all',3,'all'],flag_origin='actual_fit original; other6 flags not stored in source and remain−1',prediction_recomputed=False)
  else:
   assembled[:,ai]=baseline
   entry.update(source_prediction=str(PRED/'target_raw_calendar.npy'),source_slice='raw calendar indexed by verified G global month modulo12',flag_origin='all7 flags and reference support not applicable, remain−1',prediction_recomputed='no fit; exact frozen-calendar index only')
  if name!='seasonal_baseline':
   fallback[:,ai]=(support[:,ai]==0).astype(np.int8)
   mask=support[:,ai]==0
   assert equal(assembled[:,ai][mask],baseline[mask]),name+'unsupported values differ from original seasonal fallback'
  for fi,fn in enumerate(FLAG_NAMES):entry[fn+'_stored']=bool((flags[:,ai,fi]>=0).all())
  registry.append(entry)
  frame=cases[['row','case_id','station_id','raw_index']].copy();frame['arm']=name
  for fi,fn in enumerate(FLAG_NAMES):frame[fn]=flags[:,ai,fi]
  frame['prediction_present_in_source']=present[:,ai];frame['finite_prediction_months']=np.isfinite(assembled[:,ai]).sum(1)
  frame['original_supported_months']=np.where((support[:,ai]>=0).all(1),(support[:,ai]==1).sum(1),-1)
  frame['derived_seasonal_fallback_months']=np.where((fallback[:,ai]>=0).all(1),(fallback[:,ai]==1).sum(1),-1)
  flagrows.append(frame)
 assert equal(assembled[:,7],baseline)
 # Verify physical identity mapping against each stored selected source slot, including H.
 selected=arr(PRED/'selected_ids.npy');cselected=arr(CORR/'selected_ids.npy')
 aliasrecords=[]
 for i,e in cases.iterrows():
  prow=phys.iloc[int(e.raw_index)];aliasraw=np.asarray(json.loads(prow.all_same_station_exclusion_raw_indices),int)
  aliasids=json.loads(prow.all_same_station_exclusion_ids)
  assert np.array_equal(ids[aliasraw].astype(str),np.asarray(aliasids,str))
  assert int(e.raw_index) in aliasraw
  assert not np.isin(selected[i],aliasraw).any() and not np.isin(cselected[i],aliasraw).any()
  aliasrecords.append({'row':int(e.row),'case_id':e.case_id,'station_id':e.station_id,'raw_index':int(e.raw_index),
    'physical_group_raw_index':int(prow.physical_group_raw_index),'physical_group_id':prow.physical_group_id,
    'physical_component_size':int(prow.physical_component_size),'alias_raw_indices':json.dumps(aliasraw.tolist()),'alias_ids':json.dumps(aliasids)})
 pd.DataFrame(aliasrecords).to_csv(HERE/'case_physical_alias_mapping.csv',index=False)
 meta=cases.copy();meta['gsim_id']=meta.station_id;meta['primary_P8083']=pa
 meta['H_first_date']=hd[:,0].astype(str);meta['H_last_date']=hd[:,-1].astype(str)
 meta['G_first_date']=gd[:,0].astype(str);meta['G_last_date']=gd[:,-1].astype(str)
 meta['physical_group_raw_index']=phys.iloc[raw].physical_group_raw_index.to_numpy()
 meta['physical_group_id']=phys.iloc[raw].physical_group_id.to_numpy()
 meta.to_csv(HERE/'case_metadata.csv',index=False)
 pd.concat(flagrows,ignore_index=True).to_csv(HERE/'case_arm_flags.csv.gz',index=False,compression='gzip')
 values={
  'H_flow':(h,'Original QC20 monthly mean discharge in m3/s; untransformed. Negative original values are preserved, not repaired.'),
  'G_truth':(y,'Original QC20 withheld discharge, no alterations.'),
  'H_dates':(hd,'True month-start dates indexed from original dates.npy.'),'G_dates':(gd,'True month-start dates indexed from original dates.npy.'),
  'H_days':(days[hidx],'Actual Gregorian days in each H month.'),'G_days':(days[gidx],'Actual Gregorian days in each G month.'),
  'H_month_indices':(hidx.astype(np.int16),'Indices into source_dates.'),'G_month_indices':(gidx.astype(np.int16),'Indices into source_dates; exact original gap_months.'),
  'source_dates':(np.asarray(dates),'Original432-month axis, copied unchanged.'),'source_days':(days,'Month lengths derived from original month-start axis.'),
  'predictions':(assembled,'Raw m3/s, axes(case,arm,G_month); frozen values only, baseline uses frozen H raw calendar.'),
  'original_month_support':(support,'int8:1 supported transfer,0 original unsupported/fallback,−1 not applicable; baseline−1.'),
  'original_model_flags':(flags,'int8 axes(case,arm,flag); original0/1 values;−1 not stored or not applicable. See registry.'),
  'prediction_present':(present,'Serialized source arm present for each case, NOT a valid/finite/support flag.'),
  'derived_seasonal_fallback_month':(fallback,'For transfer arms only,1 iff original support==0, checked to equal baseline; baseline−1. Distinct from original requested-model fallback flag.'),
  'P_available':(pa,'Fixed source rain admission mask;8083true.'),
  'target_H_raw_calendar':(cal,'Original frozen arithmetic raw-flow calendar means.'),
  'target_H_log_calendar':(lcal,'Original frozen log1p-flow H calendar means.'),
  'target_H_anomaly_sd':(asd,'Original frozen H log-anomaly populationSD.'),
  'target_Hz':(np.asarray(hz),'Original frozen H standard log anomalies; no newly fit transform.'),
  'target_estimable':(np.asarray(arr(PRED/'target_estimable.npy')),'Original target transform estimability flag.'),
  'target_risk':(np.asarray(arr(PRED/'target_risk.npy')),'Original source/target geometry or identity warning; not silently excluded.'),
  'history_nonnegative':((h>=0).all(1),'Read-only H sign audit, not a new selection.'),
  'truth_nonnegative':((y>=0).all(1),'Read-only G sign audit, not a new selection.')}
 for name,(value,desc) in values.items():savearray(name,value,desc)
 savejson(HERE/'ARM_REGISTRY.json',{'axes':['case','arm','G_month'],'arm_names':[x[0] for x in ARMS],'flags':FLAG_NAMES,'sentinel':-1,'arms':registry})
 # Old-score identity QA only; no drought, volume, storage or change-direction metrics.
 originals=csv(BASE/'analysis/scores_long.csv.gz')
 corrscore=csv(CORR.parent/'pure_correlation_scores.csv.gz')
 oldrecords=[]
 for ai,(name,di,mi,ri) in enumerate(ARMS):
  if name=='seasonal_baseline':continue
  nse,bn,valid,eligible,success=rescore(y,assembled[:,ai],baseline,flags[:,ai,0]==1,support[:,ai]==1)
  if di is not None:
   ref=originals[(originals.D==DS[di])&(originals.method==['ridge','rbf_ridge'][mi])&(originals.arm==['Q','QP','QP_Gclim'][ri])].sort_values('row')
  else:
   ref=corrscore[corrscore.D==800].sort_values('row')
  assert len(ref)==N and np.array_equal(ref.row.to_numpy(int),np.arange(N))
  assert np.array_equal(ref.raw_index.to_numpy(int),raw)
  if 'station_id' in ref:
   assert np.array_equal(ref.station_id.astype(str).to_numpy(),cases.station_id.astype(str).to_numpy())
  else:
   # S17I score table stores row/raw_index rather than duplicated station names.
   assert np.array_equal(ids[ref.raw_index.to_numpy(int)].astype(str),cases.station_id.astype(str).to_numpy())
  assert np.allclose(nse,ref.NSE.to_numpy(float),rtol=1e-12,atol=1e-12,equal_nan=True),name+'NSE mismatch'
  success_col='old_NSE_pass' if 'old_NSE_pass' in ref else 'success'
  assert np.array_equal(success,ref[success_col].to_numpy(bool)),name+'success mismatch'
  assert np.array_equal(valid,ref.valid_truth.to_numpy(bool)),name+'truth-mask mismatch'
  oldrecords.append({'arm':name,'n_all':N,'n_primary':int(pa.sum()),'primary_valid_truth_n':int(valid[pa].sum()),
   'primary_success_n':int(success[pa].sum()),'primary_success_pct':float(100*success[pa].mean()),
   'all_success_n':int(success.sum()),'score_source':str(BASE/'analysis/scores_long.csv.gz') if di is not None else str(CORR.parent/'pure_correlation_scores.csv.gz'),
   'NSE_all_rows_match':True,'success_all_rows_exact_match':True,'truth_mask_exact_match':True})
 pd.DataFrame(oldrecords).to_csv(HERE/'old_NSE_identity_QA.csv',index=False)
 qa.update(n_all=N,n_primary=int(pa.sum()),all_arms_present=True,pure_correlation_case_identity_columns=identity_columns,
  pure_correlation_exact_shared8898_index=True,source_date_axis_verified=True,H_G_contiguous_and_monthly=True,days_from_real_dates=True,
  raw_calendar_independent_Hmean_max_abs_difference=float(np.nanmax(np.abs(independently_calculated-cal))),
  baseline_frozen120_values_exact=True,all_selected_source_slots_exclude_complete_target_aliases=True,
  primary_H_negative_cases=int((pa&~(h>=0).all(1)).sum()),primary_G_negative_cases=int((pa&~(y>=0).all(1)).sum()),
  old_scores=oldrecords,no_refitting=True,new_water_resource_metrics_calculated=False)
 savejson(HERE/'INPUT_QA.json',qa)
 savejson(HERE/'DATA_SCHEMA.json',{'case_axis':'8898 original rows; primary_P8083/P_available selects exactly8083 without reindexing source arrays',
  'flow_units':'m3/s; native GSIM MEAN after original QC20, not runoff depth, not integrated volume',
  'days':'Actual Gregorian month length, available for volume integration; builder does not calculate new water metrics',
  'country_parsing':'Use keep_default_na=False,na_values=[\"\"] to preserve Namibia NA.',
  'flag_warning':'Do not cast −1 sentinels to bool; compare original_model_flags[:,:,0]==1 for actual fit. Baseline is valid comparator but has no fitted-reference status.',
  'fallback_warning':'Whole-requested-model fallback flag and monthwise seasonal backfill are distinct and both preserved.',
  'arrays':outputs})
 savejson(HERE/'SOURCE_MANIFEST.json',{'script_sha256':sha(__file__),'sources':sources,'no_source_mutations':True})
 written={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in HERE.iterdir() if p.is_file() and p.name!='DATA_COMPLETE.json'}
 savejson(HERE/'DATA_COMPLETE.json',{'status':'PASS_FROZEN_INPUTS_READY','created_utc':datetime.now(timezone.utc).isoformat(),
  'n_all':N,'n_primary':8083,'n_arms':len(ARMS),'no_refitting':True,'no_new_water_metrics':True,'files':written})
 print('DATA_COMPLETE',len(written),'files',json.dumps(oldrecords,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
