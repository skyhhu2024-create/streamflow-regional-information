"""Frozen-prediction water-resource diagnostics; no fitting or empirical data access.

evaluate_case uses 60 history months followed by 120 gap months. Dates may be
ISO strings, datetime objects or numpy datetime64. All fields are scalar and
the output schema is stable, including when some metrics are undefined.

The five-year history is an experiment-specific reference, not a long-term
climate normal. The caller retains actual-fit, support and fallback metadata:
finite seasonal fallback predictions can be scored, but are not reclassified
as supported reconstructions by this module.
"""
from __future__ import annotations

import numpy as np

VERSION = '1.0.1'
HISTORY_MONTHS = 60
GAP_MONTHS = 120
SCALE_EPS = 1e-12
BOUNDARY_RTOL = 1e-12
SECONDS_PER_DAY = 86400.0
ALLOWED_DROUGHT_PERCENTILES = (20, 10)
NAN = float('nan')

BOOL_FIELDS = (
    'dates_valid', 'history_input_valid', 'truth_input_valid', 'prediction_input_valid',
    'event_definition_valid', 'drought_observed_valid', 'drought_predicted_valid',
    'drought_paired_valid', 'drought_hss_valid', 'deficit_paired_valid',
    'deficit_ratio_valid', 'deficit_normalized_error_valid', 'water_paired_valid',
    'water_relative_error_valid', 'period_change_observed_valid',
    'period_change_prediction_valid', 'period_change_paired_valid',
)
STATUS_FIELDS = (
    'dates_status', 'history_status', 'truth_status', 'prediction_status',
    'event_definition_status', 'drought_status', 'drought_hss_status',
    'deficit_status', 'deficit_ratio_status', 'deficit_normalized_error_status',
    'water_status', 'water_relative_error_status', 'period_change_status',
)
FLOAT_FIELDS = (
    'history_days', 'gap_days', 'history_mean_flow', 'history_mean_zero',
    'history_flow_constant', 'truth_flow_constant', 'prediction_flow_constant',
    'history_nonfinite_months', 'truth_nonfinite_months', 'prediction_nonfinite_months',
    'history_negative_months', 'truth_negative_months', 'prediction_negative_months',
    'gap_observed_mean_flow', 'gap_predicted_mean_flow',
    'history_log_residual_scale', 'history_anomaly_threshold',
    'threshold_flow_min', 'threshold_flow_max',
    'drought_observed_count', 'drought_predicted_count', 'drought_hits',
    'drought_misses', 'drought_false_alarms', 'drought_correct_negatives',
    'drought_count_ratio', 'drought_observed_frequency', 'drought_predicted_frequency',
    'drought_frequency_error', 'drought_observed_none', 'drought_observed_all',
    'drought_hss', 'drought_hss_chance', 'drought_hss_excess', 'drought_hss_expected_hits',
    'deficit_observed_m3', 'deficit_predicted_m3', 'deficit_ratio',
    'deficit_abs_ratio_error', 'deficit_abs_error_m3',
    'deficit_signed_error_hmean_normalized', 'deficit_abs_error_hmean_normalized',
    'deficit_within_25pct', 'deficit_within_50pct',
    'deficit_observed_zero', 'deficit_predicted_zero', 'deficit_both_zero',
    'deficit_false_positive', 'deficit_complete_miss',
    'water_observed_volume_m3', 'water_predicted_volume_m3',
    'water_rel_error', 'water_abs_rel_error', 'water_abs_error_m3',
    'water_within_10pct', 'water_within_20pct', 'water_observed_zero',
    'water_predicted_zero', 'water_both_zero', 'water_false_positive',
    'period_mean_change_observed', 'period_mean_change_predicted',
)
for _suffix in ('10pct', '20pct'):
    FLOAT_FIELDS += tuple(f'change_{key}_{_suffix}' for key in
                         ('observed', 'predicted', 'correct', 'false_stable', 'false_change', 'reversed'))


def empty_result(percentile):
    out = {k: False for k in BOOL_FIELDS}
    out.update({k: 'not_evaluated' for k in STATUS_FIELDS})
    out.update({k: NAN for k in FLOAT_FIELDS})
    out.update(metrics_version=VERSION, drought_percentile=int(percentile),
               history_expected_months=HISTORY_MONTHS, gap_expected_months=GAP_MONTHS,
               change_category_10pct='undefined', change_category_20pct='undefined')
    return out


def _flow_array(value, length):
    try:
        q = np.asarray(value, dtype=np.float64)
    except (TypeError, ValueError):
        return None, 'nonnumeric'
    if q.ndim != 1 or q.size != length:
        return None, 'wrong_shape'
    reasons = []
    if np.any(~np.isfinite(q)):
        reasons.append('nonfinite')
    if np.any(q < 0):
        reasons.append('negative')
    return q, '|'.join(reasons) if reasons else 'ok'


def _calendar(value, length):
    try:
        arr = np.asarray(value)
        if arr.ndim != 1 or arr.size != length:
            return None, None, None, 'wrong_shape'
        if arr.dtype.kind in 'biufc':
            return None, None, None, 'numeric_dates_not_allowed'
        dates = arr.astype('datetime64[D]')
        if np.isnat(dates).any():
            return None, None, None, 'nat'
        months = dates.astype('datetime64[M]')
        serial = months.astype(np.int64)
        if np.any(np.diff(serial) != 1):
            return None, None, None, 'nonconsecutive_months'
        days = ((months + np.timedelta64(1, 'M')).astype('datetime64[D]')
                - months.astype('datetime64[D]')).astype(float)
        return serial, serial % 12, days, 'ok'
    except (TypeError, ValueError, OverflowError):
        return None, None, None, 'invalid_dates'


def _finite_or_nan(x):
    return float(x) if np.isfinite(x) else NAN


def _mean_and_volume(q, days):
    # Normalize before multiplication for the mean; never clamp flow values.
    with np.errstate(over='ignore', invalid='ignore'):
        mean = np.sum(q * (days / days.sum()))
        volume = np.sum(q * days * SECONDS_PER_DAY)
    return _finite_or_nan(mean), _finite_or_nan(volume)


def within_tolerance(absolute_error, tolerance):
    """Inclusive boundary with fixed 1e-12 relative, zero absolute tolerance."""
    if not np.isfinite(absolute_error):
        return NAN
    return float(absolute_error < tolerance or
                 np.isclose(absolute_error, tolerance, rtol=BOUNDARY_RTOL, atol=0.0))


def period_change_class(relative_change, band):
    if not np.isfinite(relative_change):
        return NAN
    if within_tolerance(abs(relative_change), band):
        return 0.0
    return float(1 if relative_change > 0 else -1)


def direction_category(observed_class, predicted_class):
    if not np.isfinite(observed_class) or not np.isfinite(predicted_class):
        return 'undefined'
    if observed_class == predicted_class:
        return 'correct'
    if predicted_class == 0:
        return 'false_stable'
    if observed_class == 0:
        return 'false_change'
    return 'reversed'


def conditional_hss(observed_events, predicted_events, calendar_months):
    """Exact calendar-conditional expectation; no random permutations.

    Returns raw HSS, conditional expected HSS, excess HSS and expected hits.
    No observed binary contrast is explicitly non-evaluable for these scores.
    Counts/frequencies remain evaluable outside this function.
    """
    o = np.asarray(observed_events, dtype=bool)
    p = np.asarray(predicted_events, dtype=bool)
    m = np.asarray(calendar_months)
    if o.ndim != 1 or o.shape != p.shape or o.shape != m.shape or not o.size:
        raise ValueError('Event and month vectors must be nonempty and shape-aligned.')
    n = len(o)
    O = int(o.sum())
    P = int(p.sum())
    A = int(np.sum(o & p))
    EA = float(sum(float(o[m == k].sum()) * float(p[m == k].sum()) / np.sum(m == k)
                   for k in np.unique(m)))
    if O == 0 or O == n:
        return NAN, NAN, NAN, EA
    den = float(O * (n - P) + P * (n - O))
    raw = 2.0 * (n * A - O * P) / den
    chance = 2.0 * (n * EA - O * P) / den
    # Direct expression avoids cancellation between two separately calculated scores.
    excess = 2.0 * n * (A - EA) / den
    return float(raw), float(chance), float(excess), EA


def seasonal_threshold(hist_q, history_months, gap_months, percentile):
    """Match frozen log1p/H-calendar/pooled-residual transformation exactly."""
    x = np.log1p(hist_q)
    mu = np.array([np.mean(x[history_months == m]) for m in range(12)])
    residual = x - mu[history_months]
    scale = float(np.std(residual, ddof=0))
    if not np.isfinite(scale) or scale <= SCALE_EPS:
        return None, scale, NAN
    cutoff = float(np.percentile(residual / scale, percentile, method='linear'))
    # Mathematically scale*quantile(residual/scale) == quantile(residual).
    # Avoid a divide/multiply round trip: at exact zero-flow boundaries it can
    # leave a positive epsilon and incorrectly classify observed zeros as low.
    # Keep the standardized cutoff above for reporting; no epsilon cutoff or
    # change to the scientific percentile, strict comparison or physical floor.
    residual_cutoff = float(np.percentile(residual, percentile, method='linear'))
    threshold = np.maximum(np.expm1(mu[gap_months] + residual_cutoff), 0.0)
    return threshold, scale, cutoff


def evaluate_case(hist_q, hist_dates, obs_q, pred_q, gap_dates, drought_percentile=20):
    """Evaluate frozen H60/G120 predictions, retaining metric-specific undefined states.

    Declared percentile values are 20 (primary) and 10 (sensitivity). Flow units
    must be m^3/s; volumes are m^3. All dates are converted to calendar months;
    full adjacent H/G monthly windows are required. No real inputs are loaded
    and neither thresholds nor tolerances depend on gap-period outcomes.
    """
    if drought_percentile not in ALLOWED_DROUGHT_PERCENTILES:
        raise ValueError('Only predeclared drought percentiles 20 and 10 are allowed.')
    out = empty_result(drought_percentile)
    h, hs = _flow_array(hist_q, HISTORY_MONTHS)
    o, os = _flow_array(obs_q, GAP_MONTHS)
    p, ps = _flow_array(pred_q, GAP_MONTHS)
    out.update(history_status=hs, truth_status=os, prediction_status=ps,
               history_input_valid=hs == 'ok', truth_input_valid=os == 'ok',
               prediction_input_valid=ps == 'ok')
    for q, status, name in ((h, hs, 'history'), (o, os, 'truth'), (p, ps, 'prediction')):
        if q is not None:
            out[f'{name}_nonfinite_months'] = float(np.sum(~np.isfinite(q)))
            out[f'{name}_negative_months'] = float(np.sum(q < 0))
            if status == 'ok':
                out[f'{name}_flow_constant'] = float(np.all(q == q[0]))
    hd, hm, hw, hds = _calendar(hist_dates, HISTORY_MONTHS)
    gd, gm, gw, gds = _calendar(gap_dates, GAP_MONTHS)
    date_errors = [f'history:{hds}'] if hds != 'ok' else []
    if gds != 'ok':
        date_errors.append(f'gap:{gds}')
    if not date_errors and gd[0] != hd[-1] + 1:
        date_errors.append('history_gap_not_adjacent')
    if date_errors:
        out['dates_status'] = '|'.join(date_errors)
        for key in STATUS_FIELDS:
            if out[key] == 'not_evaluated':
                out[key] = 'invalid_dates'
        return out
    out.update(dates_valid=True, dates_status='ok', history_days=float(hw.sum()), gap_days=float(gw.sum()))

    # Water and mean-change diagnostics need no estimable anomaly variance.
    if hs == 'ok':
        out['history_mean_flow'] = _mean_and_volume(h, hw)[0]
        out['history_mean_zero'] = float(out['history_mean_flow'] == 0) if np.isfinite(out['history_mean_flow']) else NAN
    for q, status, prefix in ((o, os, 'observed'), (p, ps, 'predicted')):
        if status == 'ok':
            mean, volume = _mean_and_volume(q, gw)
            out[f'gap_{prefix}_mean_flow'] = mean
            out[f'water_{prefix}_volume_m3'] = volume
            out[f'water_{prefix}_zero'] = float(volume == 0) if np.isfinite(volume) else NAN
            if np.isfinite(mean) and out['history_mean_flow'] > 0:
                with np.errstate(over='ignore', invalid='ignore', divide='ignore'):
                    change = mean / out['history_mean_flow'] - 1.0
                if np.isfinite(change):
                    out[f'period_mean_change_{prefix}'] = float(change)
                    valid_key = 'period_change_observed_valid' if prefix == 'observed' else 'period_change_prediction_valid'
                    out[valid_key] = True
                    for band in (.10, .20):
                        out[f'change_{prefix}_{int(band*100)}pct'] = period_change_class(change, band)
    vo, vp = out['water_observed_volume_m3'], out['water_predicted_volume_m3']
    if np.isfinite(vo) and np.isfinite(vp):
        out.update(water_paired_valid=True, water_status='ok',
                   water_abs_error_m3=abs(vp - vo), water_both_zero=float(vo == 0 and vp == 0),
                   water_false_positive=float(vo == 0 and vp > 0))
        if vo > 0:
            with np.errstate(over='ignore', invalid='ignore'):
                rel = vp / vo - 1.0
            if np.isfinite(rel):
                out.update(water_relative_error_valid=True, water_relative_error_status='ok',
                           water_rel_error=float(rel), water_abs_rel_error=abs(float(rel)),
                           water_within_10pct=within_tolerance(abs(rel), .10),
                           water_within_20pct=within_tolerance(abs(rel), .20))
            else:
                out['water_relative_error_status'] = 'nonfinite_arithmetic'
        else:
            out['water_relative_error_status'] = 'zero_observed_volume'
    else:
        out['water_status'] = 'invalid_truth_or_prediction' if os != 'ok' or ps != 'ok' else 'nonfinite_arithmetic'
        out['water_relative_error_status'] = out['water_status']
    if out['period_change_observed_valid'] and out['period_change_prediction_valid']:
        out.update(period_change_paired_valid=True, period_change_status='ok')
        for suffix in ('10pct', '20pct'):
            cat = direction_category(out[f'change_observed_{suffix}'], out[f'change_predicted_{suffix}'])
            out[f'change_category_{suffix}'] = cat
            for kind in ('correct', 'false_stable', 'false_change', 'reversed'):
                out[f'change_{kind}_{suffix}'] = float(cat == kind)
    else:
        if hs != 'ok':
            out['period_change_status'] = 'invalid_history'
        elif not out['history_mean_flow'] > 0:
            out['period_change_status'] = 'nonpositive_or_undefined_history_mean'
        elif os != 'ok' or ps != 'ok':
            out['period_change_status'] = 'invalid_truth_or_prediction'
        else:
            out['period_change_status'] = 'nonfinite_arithmetic'

    # Abnormally low months and deficit share the exact same monthly threshold.
    if hs != 'ok':
        out['event_definition_status'] = 'invalid_history'
    else:
        threshold, scale, cutoff = seasonal_threshold(h, hm, gm, drought_percentile)
        out['history_log_residual_scale'] = scale
        out['history_anomaly_threshold'] = cutoff
        if threshold is None:
            out['event_definition_status'] = 'history_residual_scale_not_estimable'
        elif not np.all(np.isfinite(threshold)):
            out['event_definition_status'] = 'nonfinite_threshold'
        else:
            out.update(event_definition_valid=True, event_definition_status='ok',
                       threshold_flow_min=float(threshold.min()), threshold_flow_max=float(threshold.max()))
    if not out['event_definition_valid']:
        for key in ('drought_status', 'drought_hss_status', 'deficit_status',
                    'deficit_ratio_status', 'deficit_normalized_error_status'):
            out[key] = out['event_definition_status']
        return out
    events = {}
    for q, status, prefix in ((o, os, 'observed'), (p, ps, 'predicted')):
        if status == 'ok':
            ev = q < threshold  # Strict threshold; no pseudocount, no outcome-selected margin.
            events[prefix] = ev
            out[f'drought_{prefix}_valid'] = True
            out[f'drought_{prefix}_count'] = float(ev.sum())
            out[f'drought_{prefix}_frequency'] = float(ev.mean())
            with np.errstate(over='ignore', invalid='ignore'):
                deficit = np.sum(np.maximum(threshold - q, 0.0) * gw * SECONDS_PER_DAY)
            out[f'deficit_{prefix}_m3'] = _finite_or_nan(deficit)
            out[f'deficit_{prefix}_zero'] = float(deficit == 0) if np.isfinite(deficit) else NAN
    if 'observed' in events:
        O = int(events['observed'].sum())
        out.update(drought_observed_none=float(O == 0), drought_observed_all=float(O == GAP_MONTHS))
    if len(events) == 2:
        oe, pe = events['observed'], events['predicted']
        O, P = int(oe.sum()), int(pe.sum())
        raw, chance, excess, expected_hits = conditional_hss(oe, pe, gm)
        out.update(drought_paired_valid=True, drought_status='ok',
                   drought_hits=float(np.sum(oe & pe)), drought_misses=float(np.sum(oe & ~pe)),
                   drought_false_alarms=float(np.sum(~oe & pe)),
                   drought_correct_negatives=float(np.sum(~oe & ~pe)),
                   drought_count_ratio=float(P / O) if O else NAN,
                   drought_frequency_error=float((P - O) / GAP_MONTHS),
                   drought_hss=raw, drought_hss_chance=chance, drought_hss_excess=excess,
                   drought_hss_expected_hits=expected_hits)
        out['drought_hss_valid'] = bool(np.isfinite(raw))
        out['drought_hss_status'] = 'ok' if np.isfinite(raw) else 'no_observed_binary_contrast'
    else:
        out['drought_status'] = 'invalid_truth_or_prediction'
        out['drought_hss_status'] = out['drought_status']
    do, dp = out['deficit_observed_m3'], out['deficit_predicted_m3']
    if np.isfinite(do) and np.isfinite(dp):
        signed_diff = dp - do
        out.update(deficit_paired_valid=True, deficit_status='ok', deficit_abs_error_m3=abs(signed_diff),
                   deficit_both_zero=float(do == 0 and dp == 0), deficit_false_positive=float(do == 0 and dp > 0),
                   deficit_complete_miss=float(do > 0 and dp == 0))
        if do > 0:
            with np.errstate(over='ignore', invalid='ignore'):
                ratio = dp / do
            if np.isfinite(ratio):
                out.update(deficit_ratio_valid=True, deficit_ratio_status='ok', deficit_ratio=float(ratio),
                           deficit_abs_ratio_error=abs(float(ratio) - 1.0),
                           deficit_within_25pct=within_tolerance(abs(ratio - 1.0), .25),
                           deficit_within_50pct=within_tolerance(abs(ratio - 1.0), .50))
            else:
                out['deficit_ratio_status'] = 'nonfinite_arithmetic'
        else:
            out['deficit_ratio_status'] = 'zero_observed_deficit'
        normalizer = out['history_mean_flow'] * out['gap_days'] * SECONDS_PER_DAY
        if np.isfinite(normalizer) and normalizer > 0:
            norm_error = signed_diff / normalizer
            if np.isfinite(norm_error):
                out.update(deficit_normalized_error_valid=True, deficit_normalized_error_status='ok',
                           deficit_signed_error_hmean_normalized=float(norm_error),
                           deficit_abs_error_hmean_normalized=abs(float(norm_error)))
            else:
                out['deficit_normalized_error_status'] = 'nonfinite_arithmetic'
        else:
            out['deficit_normalized_error_status'] = 'nonpositive_or_undefined_history_normalizer'
    else:
        out['deficit_status'] = 'invalid_truth_or_prediction' if os != 'ok' or ps != 'ok' else 'nonfinite_arithmetic'
        out['deficit_ratio_status'] = out['deficit_status']
        out['deficit_normalized_error_status'] = out['deficit_status']
    return out
