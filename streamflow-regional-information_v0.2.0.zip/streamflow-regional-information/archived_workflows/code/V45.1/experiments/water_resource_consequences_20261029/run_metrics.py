"""Score the predeclared water-use outcomes without changing frozen predictions."""
from pathlib import Path
import os, sys, json, hashlib, time
from datetime import datetime, timezone
from concurrent.futures import ProcessPoolExecutor, as_completed
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
CODE = next(p for p in ROOT.parents if p.name == 'code')
sys.path.insert(0, str(CODE / 'V42/dependencies'))
import numpy as np
import pandas as pd
import metrics
DATA = ROOT / 'data'
OUT = ROOT / 'results'
CHUNKS = ROOT / 'case_chunks'
G = {}


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def savejson(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def init():
    for key in ('H_flow', 'G_truth', 'H_dates', 'G_dates', 'predictions',
                'original_model_flags', 'original_month_support', 'derived_seasonal_fallback_month',
                'prediction_present'):
        G[key] = np.load(DATA / f'{key}.npy', mmap_mode='r')
    G['registry'] = json.loads((DATA / 'ARM_REGISTRY.json').read_text(encoding='utf-8'))
    m = pd.read_csv(DATA / 'case_metadata.csv', keep_default_na=False, na_values=[''])
    assert np.array_equal(m.row.to_numpy(int), np.arange(8898))
    cols = [c for c in ('row', 'station_id', 'gsim_id', 'raw_index', 'continent', 'country',
                        'spatial_cell', 'latitude', 'longitude', 'primary_P8083',
                        'history_start', 'history_end', 'gap_start', 'gap_end',
                        'physical_group_id') if c in m]
    G['meta'] = m[cols].to_dict('records')


def worker(task):
    chunk_id, rows = task
    records = []
    names = G['registry']['arm_names']
    flagnames = G['registry']['flags']
    for row in rows:
        h = np.asarray(G['H_flow'][row], float)
        y = np.asarray(G['G_truth'][row], float)
        hd = np.asarray(G['H_dates'][row])
        gd = np.asarray(G['G_dates'][row])
        for ai, arm in enumerate(names):
            m = G['meta'][row].copy()
            m.update(arm=arm, arm_index=ai, primary_P8083=True,
                     original_prediction_present=bool(G['prediction_present'][row, ai]))
            for fi, name in enumerate(flagnames):
                m['original_' + name] = int(G['original_model_flags'][row, ai, fi])
            sup = G['original_month_support'][row, ai]
            fall = G['derived_seasonal_fallback_month'][row, ai]
            m['original_supported_months'] = int((sup == 1).sum()) if np.any(sup >= 0) else -1
            m['original_unsupported_months'] = int((sup == 0).sum()) if np.any(sup >= 0) else -1
            m['derived_seasonal_fallback_months'] = int((fall == 1).sum()) if np.any(fall >= 0) else -1
            m['is_seasonal_baseline'] = arm == 'seasonal_baseline'
            p = np.asarray(G['predictions'][row, ai], float)
            for percentile in (20, 10):
                result = metrics.evaluate_case(h, hd, y, p, gd, drought_percentile=percentile)
                records.append({**m, **result})
    frame = pd.DataFrame.from_records(records)
    assert len(frame) == len(rows) * 11 * 2
    path = CHUNKS / f'chunk_{chunk_id:04d}.csv.gz'
    frame.to_csv(path, index=False, compression='gzip')
    return {'chunk': chunk_id, 'first_row': int(rows[0]), 'last_row': int(rows[-1]),
            'targets': len(rows), 'metric_rows': len(frame), 'path': str(path.relative_to(ROOT)),
            'sha256': sha(path)}


def main():
    t0 = time.time()
    OUT.mkdir(exist_ok=True)
    CHUNKS.mkdir(exist_ok=True)
    receipt = json.loads((DATA / 'DATA_COMPLETE.json').read_text(encoding='utf-8'))
    assert receipt['status'] == 'PASS_FROZEN_INPUTS_READY'
    for name, item in receipt['files'].items():
        assert sha(DATA / name) == item['sha256'], ('changed data', name)
    qa = json.loads((ROOT / 'METRICS_SYNTHETIC_QA.json').read_text(encoding='utf-8'))
    assert qa['success'] and qa['failures'] == qa['errors'] == 0
    assert sha(ROOT / 'metrics.py') == qa['metrics_sha256']
    assert sha(ROOT / 'PROTOCOL.md') == qa['protocol_sha256']
    meta = pd.read_csv(DATA / 'case_metadata.csv', keep_default_na=False, na_values=[''])
    p = np.load(DATA / 'P_available.npy')
    assert p.dtype == bool and p.shape == (8898,) and int(p.sum()) == 8083
    rows = np.flatnonzero(p)
    assert np.array_equal(meta.row.to_numpy(int), np.arange(8898))
    assert np.array_equal(meta.primary_P8083.to_numpy(), p)
    freeze = dict(created_utc=datetime.now(timezone.utc).isoformat(),
                  status='FROZEN_BEFORE_NEW_WATER_METRICS',
                  n_registered=8083, n_parent=8898, n_arms=11, percentiles=[20, 10],
                  expected_metric_rows=8083 * 11 * 2,
                  protocol_sha256=sha(ROOT / 'PROTOCOL.md'),
                  metrics_sha256=sha(ROOT / 'metrics.py'),
                  driver_sha256=sha(__file__), input_receipt_sha256=sha(DATA / 'DATA_COMPLETE.json'),
                  analysis_plan_sha256=sha(ROOT / 'analysis_plan.md'),
                  raw_predictions_refit=False)
    savejson(ROOT / 'EVALUATION_FROZEN.json', freeze)
    tasks = [(i, rows[j:j+200].tolist()) for i, j in enumerate(range(0, len(rows), 200))]
    done = []
    with ProcessPoolExecutor(max_workers=4, initializer=init) as pool:
        jobs = [pool.submit(worker, task) for task in tasks]
        for fut in as_completed(jobs):
            item = fut.result()
            done.append(item)
            if len(done) % 5 == 0 or len(done) == len(tasks):
                print(f'WATER_METRICS {len(done)}/{len(tasks)} chunks; {time.time()-t0:.1f}s', flush=True)
    done.sort(key=lambda x: x['chunk'])
    # Reading the serialized chunks also tests numeric/string round-tripping.
    frames = [pd.read_csv(ROOT / x['path'], keep_default_na=False, na_values=['']) for x in done]
    data = pd.concat(frames, ignore_index=True).sort_values(['row', 'arm_index', 'drought_percentile'])
    assert len(data) == freeze['expected_metric_rows']
    assert not data.duplicated(['row', 'arm', 'drought_percentile']).any()
    assert data.groupby(['arm', 'drought_percentile']).size().eq(8083).all()
    assert data.dates_valid.all()
    assert data.groupby('row').station_id.nunique().eq(1).all()
    assert data.row.nunique() == 8083
    target = OUT / 'per_target_water_metrics.csv.gz'
    data.to_csv(target, index=False, compression='gzip')
    assert sha(ROOT / 'metrics.py') == freeze['metrics_sha256']
    assert sha(ROOT / 'PROTOCOL.md') == freeze['protocol_sha256']
    assert sha(__file__) == freeze['driver_sha256']
    savejson(OUT / 'PER_TARGET_COMPLETE.json', dict(status='PASS_ALL_PREDECLARED_ARMS_SCORED',
            created_utc=datetime.now(timezone.utc).isoformat(), n_targets=8083, n_rows=len(data),
            n_columns=len(data.columns), n_arms=11, elapsed_seconds=time.time()-t0,
            metrics_sha256=sha(ROOT / 'metrics.py'), freeze_sha256=sha(ROOT / 'EVALUATION_FROZEN.json'),
            output_sha256=sha(target), chunks=done, all_dates_valid=True,
            no_refit=True, original_predictions_unchanged=True))
    print('ALL_WATER_METRICS_COMPLETE', len(data), len(data.columns), f'{time.time()-t0:.1f}s', flush=True)


if __name__ == '__main__':
    main()
