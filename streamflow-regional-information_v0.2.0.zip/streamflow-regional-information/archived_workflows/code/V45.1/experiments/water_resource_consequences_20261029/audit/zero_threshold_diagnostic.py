"""Read-only floating-point diagnosis, no production metric import."""
from pathlib import Path
import sys,json
from decimal import Decimal, localcontext
ROOT=Path(__file__).resolve().parent.parent
CODE=next(p for p in ROOT.parents if p.name=='code');sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd
D=ROOT/'data'
def a(name):return np.load(D/(name+'.npy'))
h=a('H_flow');obs=a('G_truth');hm=a('H_dates').astype('datetime64[M]').astype(int)%12;gm=a('G_dates').astype('datetime64[M]').astype(int)%12
fmu=a('target_H_log_calendar');fsd=a('target_H_anomaly_sd')
meta=pd.read_csv(D/'case_metadata.csv',keep_default_na=False,na_values=[''])
out=[];diffs=[]
for row in np.flatnonzero(a('P_available')):
 if not np.isfinite(h[row]).all() or (h[row]<0).any():continue
 x=np.log1p(h[row]);mu=np.array([np.mean(x[hm[row]==m]) for m in range(12)])
 res=x-mu[hm[row]];sd=np.std(res)
 diffs.append({'row':int(row),'mu_max_abs':float(np.max(np.abs(mu-fmu[row]))),'sd_abs':float(abs(sd-fsd[row]))})
 if row not in [6145,7413,6542,6695,6728,7518]:continue
 q=20 if row in [6695,6728,7518] else 10
 with localcontext() as ctx:
  ctx.prec=80
  xd=[(Decimal.from_float(float(v))+1).ln() for v in h[row]]
  mud=[sum(xd[j] for j in range(60) if hm[row,j]==m)/5 for m in range(12)]
  rd=[xd[j]-mud[hm[row,j]] for j in range(60)]
  ordered=sorted(rd);position=Decimal(59)*q/100;lo=int(position);fraction=position-lo
  cutd=ordered[lo]+fraction*(ordered[lo+1]-ordered[lo])
  td=[max((mud[m]+cutd).exp()-1,Decimal(0)) for m in range(12)]
  cut=float(np.percentile(res/sd,q,method='linear'))
  native=np.maximum(np.expm1(mu+sd*cut),0)
  direct_cut=float(np.percentile(res,q,method='linear'))
  direct=np.maximum(np.expm1(mu+direct_cut),0)
  vmu=np.array([np.sum(np.where(hm[row]==m,x,0))/5 for m in range(12)])
  vr=x-vmu[hm[row]];vsd=np.sqrt(np.mean(vr**2));vcut=float(np.percentile(vr/vsd,q,method='linear'))
  vector=np.maximum(np.expm1(vmu+vsd*vcut),0)
  out.append({'row':int(row),'percentile':q,'station':meta.station_id.iloc[row],'H':h[row].tolist(),'G':obs[row].tolist(),'mu':mu.tolist(),'frozen_mu':fmu[row].tolist(),'mu_frozen_abs_max':float(np.max(abs(mu-fmu[row]))),'sd':float(sd),'frozen_sd':float(fsd[row]),'direct_cut':direct_cut,'native_scaled_cut':float(sd*cut),'decimal_cut':str(cutd),'decimal_log_threshold':[str(m+cutd) for m in mud],'decimal_threshold':[str(v) for v in td],'native_T':native.tolist(),'direct_T':direct.tolist(),'vector_T':vector.tolist(),'observed_counts':{'native':int((obs[row]<native[gm[row]]).sum()),'direct':int((obs[row]<direct[gm[row]]).sum()),'vector':int((obs[row]<vector[gm[row]]).sum()),'decimal':int(sum(Decimal.from_float(float(q))<td[m] for q,m in zip(obs[row],gm[row])))}})
pd.DataFrame(diffs).to_csv(ROOT/'audit/frozen_transform_comparison.csv',index=False)
result={'diagnoses':out,'n_compared':len(diffs),'maximum_mu_abs':max(x['mu_max_abs'] for x in diffs),'maximum_sd_abs':max(x['sd_abs'] for x in diffs),'mu_nonzero_count':sum(x['mu_max_abs']>0 for x in diffs),'sd_nonzero_count':sum(x['sd_abs']>0 for x in diffs)}
(ROOT/'audit/zero_threshold_diagnostic.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(result,indent=2))
