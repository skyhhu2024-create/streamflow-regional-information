from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parent.parent;CODE=next(p for p in ROOT.parents if p.name=='code');sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd
D=ROOT/'data'
def a(n):return np.load(D/(n+'.npy'),mmap_mode='r')
h=a('H_flow');o=a('G_truth');p=a('predictions');hm=a('H_dates').astype('datetime64[M]').astype(int)%12;gm=a('G_dates').astype('datetime64[M]').astype(int)%12
ix=np.flatnonzero(a('P_available'));names=json.loads((D/'ARM_REGISTRY.json').read_text())['arm_names']
details=[];summ=[];small_positive=[]
for q in [20,10]:
 for row in ix:
  hh=h[row]
  if not np.isfinite(hh).all() or (hh<0).any():continue
  x=np.log1p(hh);mu=np.array([x[hm[row]==m].mean() for m in range(12)]);res=x-mu[hm[row]];sd=res.std()
  if sd<=1e-12:continue
  t_old=np.maximum(np.expm1(mu[gm[row]]+sd*np.percentile(res/sd,q,method='linear')),0)
  t_new=np.maximum(np.expm1(mu[gm[row]]+np.percentile(res,q,method='linear')),0)
  tiny=(t_new>0)&(t_new<1e-12)
  if tiny.any():small_positive.append({'row':int(row),'percentile':q,'threshold_values':np.unique(t_new[tiny]).tolist(),'n_month_slots':int(tiny.sum()),'zero_truth_below_tiny_threshold':int(np.sum(tiny&(o[row]==0)))})
  for kind,aa in [('truth',o[row])]+[(n,p[row,j]) for j,n in enumerate(names)]:
   if not np.isfinite(aa).all() or (aa<0).any():continue
   old=aa<t_old;new=aa<t_new
   if np.any(old!=new):details.append({'row':int(row),'percentile':q,'series':kind,'old_count':int(old.sum()),'new_count':int(new.sum()),'month_slots':np.flatnonzero(old!=new).tolist(),'dates':[str(d) for d in a('G_dates')[row][old!=new]],'values':aa[old!=new].tolist(),'old_threshold':t_old[old!=new].tolist(),'new_threshold':t_new[old!=new].tolist()})
dd=pd.DataFrame(details)
(ROOT/'audit/direct_threshold_allcase_changes.json').write_text(json.dumps(details,indent=2),encoding='utf8')
(ROOT/'audit/direct_threshold_small_positive.json').write_text(json.dumps(small_positive,indent=2),encoding='utf8')
print(dd.to_string(index=False))
