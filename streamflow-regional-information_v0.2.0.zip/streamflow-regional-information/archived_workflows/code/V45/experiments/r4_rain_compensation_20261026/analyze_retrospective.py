"""Frozen-H conditions versus already-scored FULL G: retrospective diagnosis.

This module never constructs a new G prediction and never reads raw target G.
Registration binds this scorer and its plan before H conditions are connected
to previously disclosed G scores. Analyze requires the H-only score freeze.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import sys
from datetime import datetime, timezone

sys.dont_write_bytecode = True
for _thread_key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_thread_key] = '1'
ROOT = Path(__file__).resolve().parent
CODE = next(p for p in ROOT.parents if p.name == 'code')
sys.path.insert(0, str(CODE / 'V42/dependencies'))
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

EXP = ROOT.parent
BASE = EXP / 'r4_observation_locations_20261025'
GFILE = BASE / 'full_domain_rain_bridge/analysis_v2/scores_long.csv.gz'
OLD_IDS = BASE / 'trial_predictions/selected_ids.npy'
OLD_CASES = BASE / 'trial_predictions/cases.csv'
IDENTITY = EXP / 'r4_global_siting_20261026/census/physical_identity_map.csv'
PLAN = ROOT / 'RETROSPECTIVE_ANALYSIS_PLAN.json'
FREEZE = ROOT / 'RETROSPECTIVE_ANALYSIS_FROZEN.json'
HROOT = ROOT / 'history_analysis'
HFILE = HROOT / 'history_conditions.csv'
HFREEZE = HROOT / 'HISTORY_SCORES_FROZEN.json'
OUT = ROOT / 'retrospective_analysis'
METHODS = ('ridge', 'rbf_ridge')
RISK_IDS = ('GB_0000239', 'GB_0000240', 'GB_0000241', 'GB_0000242')
REPS = 2000
SEED = 20261026


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def clean(x):
    if isinstance(x, dict):
        return {str(k): clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple, np.ndarray)):
        return [clean(v) for v in x]
    if isinstance(x, np.generic):
        return clean(x.item())
    if isinstance(x, float) and not np.isfinite(x):
        return None
    return x


def write_json(path, value):
    Path(path).write_text(json.dumps(clean(value), indent=2, ensure_ascii=False,
                                   allow_nan=False) + '\n', encoding='utf-8')


def read_csv(path):
    # Namibia's country code NA must not silently become missing.
    return pd.read_csv(path, keep_default_na=False, low_memory=False)


def numeric(s):
    return pd.to_numeric(s, errors='coerce').to_numpy(float)


def boolean(s):
    a = s.astype(str).str.lower()
    assert a.isin(['true', 'false', '1', '0']).all(), (s.name, a.unique())
    return a.isin(['true', '1']).to_numpy()


def now():
    return datetime.now(timezone.utc).isoformat()


def register():
    assert not FREEZE.exists(), 'Preserve the frozen plan; use a versioned new plan for amendments.'
    assert not (OUT / 'ANALYSIS_COMPLETE.json').exists()
    plan = dict(
        status='POST_DISCLOSURE_RETROSPECTIVE_H_CONDITION_ANALYSIS',
        date='2026-10-26', N=8898, methods=list(METHODS),
        statement='The original H60/G120 G scores were previously examined. '
            'This is a frozen-H retrospective condition diagnosis, not a new blind test.',
        H='Two forward held-out intervals: first36 -> next12, first48 -> next12. '
            'Historical conditions supplied by separately frozen H-only production.',
        main_conditions=['Q_r_z', 'delta_r_z'],
        secondary_conditions=['E_Q', 'C_P'],
        G_outcomes=['QP minus Q raw monthly r', 'QP minus Q H-deseasonalized r',
                    'paired new/lost r>0.7 passes under original eligible definition'],
        G_source=str(GFILE), no_new_G_predictions=True, no_raw_G_read=True,
        main_groups='Each processor has H-only tertile cuts on Q_r_z and delta_r_z, '
            'using all H-condition-estimable, P-usable mothers. The same fixed cuts '
            'apply to every sensitivity. All nine cells and an H/P-unknown row retained.',
        unknown='Unknown if either H condition is not estimable, P not usable in both folds, '
            'or either primary H condition is nonfinite. Fallback zero is not P evidence.',
        cuts='NumPy linear quantiles 1/3 and2/3; ties use right-side insertion. '
            'Duplicate cuts and empty bins retained, not optimized using G.',
        fold_labels='Both delta_r_z>0; both<=0; mixed; unknown. No stability tuning.',
        sensitivities=['all8898', 'P_usable_both', 'P_usable_both_no_geometry_warning',
                       'exclude_pending_GB_exposure_union',
                       'P_usable_both_exclude_pending_GB_exposure_union'],
        risk='Union of targets with four pending British source IDs in old FULL H/G, '
            'new H risk_source_any, and pending target identity. Whole8898 remains the mother ledger.',
        identity='Old G FULL source domain is unchanged. Latest confirmed target aliases '
            'must be absent from chosen H and old FULL source IDs; otherwise fail rather than silently trim.',
        inference='Equal station point estimates. 2000 resamples of original spatial cells, '
            'same paired station outcomes inside a draw; mean delta-r and net-pass percentage-point CIs. '
            'Continuous Spearman is descriptive without IID p-values. No G-failure primary grouping.',
        sparse='Cells with n<30 or<10 spatial cells explicitly flagged descriptive_small_cell; '
            'continuous paired effects also flag n_paired<30 or<10 paired cells.',
        bootstrap_seed=SEED, bootstrap_replicates=REPS,
        metadata='Use old G continent/country/spatial_cell unchanged; preserve literal NA strings.',
        scope='No parameter search, model selection, G-based cutpoint tuning, new predictions, '
            'figures, manuscript edits, uploads, or automatic scientific direction changes.')
    write_json(PLAN, plan)
    sources = [Path(__file__), PLAN, GFILE, OLD_IDS, OLD_CASES, IDENTITY]
    write_json(FREEZE, dict(registered_at_utc=now(), status='SCORER_AND_PLAN_FROZEN_BEFORE_H_G_JOIN',
        H_scores_read=False, G_scores_newly_scored=False,
        files={str(p): sha(p) for p in sources}))
    print('RETROSPECTIVE_ANALYSIS_PLAN_FROZEN; analyze awaits HISTORY_SCORES_FROZEN.json', flush=True)


def check_freezes():
    assert FREEZE.exists(), 'Register scorer and plan before connecting H to G.'
    fr = json.loads(FREEZE.read_text(encoding='utf-8'))
    for p, h in fr['files'].items():
        assert sha(p) == h, f'Analysis frozen input changed: {p}'
    hf = json.loads(HFREEZE.read_text(encoding='utf-8'))
    assert hf['status'] == 'HISTORY_ONLY_SCORES_FROZEN'
    assert hf['original_target_G_read'] is False
    assert hf['rows'] == 17796
    assert hf['files']['history_conditions.csv'] == sha(HFILE)
    for name, digest in hf['files'].items():
        assert sha(HROOT / name) == digest, name
    pf = ROOT / 'history_predictions/PREDICTIONS_FROZEN.json'
    assert sha(pf) == hf['predictions_sha256']
    return fr, hf


def old_risks():
    cases = read_csv(OLD_CASES).sort_values('row').reset_index(drop=True)
    ident = read_csv(IDENTITY)
    selected = np.load(OLD_IDS, mmap_mode='r')[:, 1]
    assert len(cases) == 8898 and selected.shape == (8898, 180, 4)
    assert np.array_equal(numeric(cases.row), np.arange(8898))
    raw = numeric(ident.raw_index).astype(int)
    assert np.array_equal(raw, np.arange(len(ident)))
    risky = raw[ident.station_id.isin(RISK_IDS)]
    assert len(risky) == 4
    group = numeric(ident.physical_group_raw_index).astype(int)
    j = numeric(cases.raw_index).astype(int)
    same = ((group[np.maximum(selected, 0)] == group[j, None, None]) & (selected >= 0))
    assert not same.any(), 'Old FULL selected confirmed target aliases: review before retrospective association.'
    exposed = np.isin(selected, risky).any(axis=(1, 2))
    assert exposed.sum() == 21, 'Old pending source footprint changed; review frozen input.'
    return cases[['row', 'station_id']].assign(old_pending_GB_source_exposure=exposed)


def joined_data():
    h = read_csv(HFILE)
    assert len(h) == 17796
    keys = ['row', 'station_id', 'raw_index', 'method']
    required = keys + ['Q_r_z', 'delta_r_z', 'E_Q', 'C_P', 'fold0_delta_r_z',
        'fold1_delta_r_z', 'Q_condition_estimable', 'P_increment_estimable',
        'P_usable_both', 'geometry_warning', 'risk_source_any', 'risk_target']
    assert set(required).issubset(h.columns), sorted(set(required) - set(h.columns))
    assert not h.duplicated(keys).any()
    assert set(h.method) == set(METHODS)
    for k in ['row', 'raw_index']:
        h[k] = numeric(h[k]).astype(int)
    for k in ['Q_r_z', 'delta_r_z', 'E_Q', 'C_P', 'fold0_delta_r_z', 'fold1_delta_r_z']:
        h[k] = numeric(h[k])
    for k in ['Q_condition_estimable', 'P_increment_estimable', 'P_usable_both',
              'geometry_warning', 'risk_source_any', 'risk_target']:
        h[k] = boolean(h[k])
    h = h.merge(old_risks(), on=['row', 'station_id'], how='left', validate='many_to_one')
    assert h.old_pending_GB_source_exposure.notna().all()
    h['pending_GB_risk_union'] = h.old_pending_GB_source_exposure | h.risk_source_any | h.risk_target
    h['H_pair_known'] = (h.Q_condition_estimable & h.P_increment_estimable & h.P_usable_both
                         & np.isfinite(h.Q_r_z) & np.isfinite(h.delta_r_z))
    d0, d1 = h.fold0_delta_r_z.to_numpy(), h.fold1_delta_r_z.to_numpy()
    valid_fold = h.H_pair_known.to_numpy() & np.isfinite(d0) & np.isfinite(d1)
    labels = np.full(len(h), 'unknown', dtype=object)
    labels[valid_fold & (d0 > 0) & (d1 > 0)] = 'both_positive'
    labels[valid_fold & (d0 <= 0) & (d1 <= 0)] = 'both_nonpositive'
    labels[valid_fold & ~(((d0 > 0) & (d1 > 0)) | ((d0 <= 0) & (d1 <= 0)))] = 'mixed'
    h['H_fold_sign'] = labels
    # Preserve original G metadata without silently relabelling countries/continents.
    g = read_csv(GFILE)
    q = g[g.arm.eq('Q')].copy()
    qp = g[g.arm.eq('QP')].copy()
    for a in (q, qp):
        assert len(a) == 17796 and not a.duplicated(keys).any()
        for k in ['row', 'raw_index']:
            a[k] = numeric(a[k]).astype(int)
        for k in ['r', 'H_deseasonal_r']:
            a[k] = numeric(a[k])
        for k in ['eligible', 'r07_pass']:
            a[k] = boolean(a[k])
    meta = ['latitude', 'longitude', 'continent', 'country', 'spatial_cell', 'outer_fold',
            'history_start', 'history_end', 'gap_start', 'gap_end']
    value = ['r', 'H_deseasonal_r', 'eligible', 'r07_pass']
    q = q[keys + meta + value].rename(columns={v: 'G_Q_' + v for v in value})
    qp = qp[keys + value].rename(columns={v: 'G_QP_' + v for v in value})
    out = h.drop(columns=[k for k in meta if k in h.columns]).merge(q, on=keys, how='left', validate='one_to_one')
    out = out.merge(qp, on=keys, how='left', validate='one_to_one')
    assert len(out) == 17796 and out.G_Q_eligible.notna().all() and out.G_QP_eligible.notna().all()
    assert not out.spatial_cell.astype(str).eq('').any()
    for m in METHODS:
        x = out[out.method.eq(m)]
        assert len(x) == 8898 and set(x.row) == set(range(8898))
    out['G_pair_eligible'] = out.G_Q_eligible & out.G_QP_eligible
    out['G_delta_r_raw'] = out.G_QP_r - out.G_Q_r
    out['G_delta_r_deseasonal'] = out.G_QP_H_deseasonal_r - out.G_Q_H_deseasonal_r
    out['G_new_pass'] = out.G_QP_r07_pass & ~out.G_Q_r07_pass
    out['G_lost_pass'] = out.G_Q_r07_pass & ~out.G_QP_r07_pass
    out['G_net_pass'] = out.G_QP_r07_pass.astype(int) - out.G_Q_r07_pass.astype(int)
    return out


def quantile(a, q):
    return float(np.quantile(a, q, method='linear')) if len(a) else np.nan


def bootstrap_mean(v, code, draw):
    v = np.asarray(v, float)
    good = np.isfinite(v)
    if not good.any():
        return np.nan, np.nan
    k = draw.shape[1]
    num = np.bincount(code[good], weights=v[good], minlength=k)
    den = np.bincount(code[good], minlength=k)
    bn, bd = draw @ num, draw @ den
    x = np.divide(bn, bd, out=np.full(REPS, np.nan), where=bd > 0)
    x = x[np.isfinite(x)]
    return (quantile(x, .025), quantile(x, .975)) if len(x) else (np.nan, np.nan)


def describe(x, cols, draw, method, subset, grouping, group):
    n = len(x)
    nc = x.spatial_cell.nunique()
    record = dict(method=method, subset=subset, grouping=grouping, group=group,
        n=n, spatial_cells=nc, P_usable_n=int(x.P_usable_both.sum()),
        H_pair_known_n=int(x.H_pair_known.sum()), pending_GB_risk_n=int(x.pending_GB_risk_union.sum()),
        G_pair_eligible_n=int(x.G_pair_eligible.sum()),
        Q_pass=int(x.G_Q_r07_pass.sum()), QP_pass=int(x.G_QP_r07_pass.sum()),
        new_pass=int(x.G_new_pass.sum()), lost_pass=int(x.G_lost_pass.sum()),
        net_pass_pp=100 * x.G_net_pass.mean() if n else np.nan,
        Q_pass_pct=100 * x.G_Q_r07_pass.mean() if n else np.nan,
        QP_pass_pct=100 * x.G_QP_r07_pass.mean() if n else np.nan,
        cell_interpretation='descriptive_small_cell' if n < 30 or nc < 10 else 'adequate_descriptive_sample',
        evidence_status='retrospective_previously_disclosed_G')
    code = np.asarray([cols[s] for s in x.spatial_cell.astype(str)], int)
    lo, hi = bootstrap_mean(x.G_net_pass.to_numpy(float) * 100, code, draw)
    record.update(net_pass_pp_ci025=lo, net_pass_pp_ci975=hi)
    for metric in ['raw', 'deseasonal']:
        c = 'G_delta_r_' + metric
        good = x.G_pair_eligible.to_numpy() & np.isfinite(x[c].to_numpy(float))
        v = x.loc[good, c].to_numpy(float)
        l, u = bootstrap_mean(v, code[good], draw)
        record.update({f'{metric}_paired_n': len(v), f'{metric}_paired_cells': x.loc[good, 'spatial_cell'].nunique(),
            f'{metric}_mean_gain': np.mean(v) if len(v) else np.nan,
            f'{metric}_median_gain': np.median(v) if len(v) else np.nan,
            f'{metric}_mean_ci025': l, f'{metric}_mean_ci975': u,
            f'{metric}_positive_n': int((v > 0).sum()), f'{metric}_negative_n': int((v < 0).sum()),
            f'{metric}_small_paired_cell': len(v) < 30 or x.loc[good, 'spatial_cell'].nunique() < 10})
    for c in ['G_Q_r', 'G_QP_r', 'G_Q_H_deseasonal_r', 'G_QP_H_deseasonal_r']:
        v = x.loc[x.G_pair_eligible, c].to_numpy(float)
        v = v[np.isfinite(v)]
        record[c + '_paired_mean'] = float(np.mean(v)) if len(v) else np.nan
        record[c + '_paired_median'] = float(np.median(v)) if len(v) else np.nan
    for c in ['Q_r_z', 'delta_r_z', 'E_Q', 'C_P']:
        v = x[c].to_numpy(float)
        v = v[np.isfinite(v)]
        record[c + '_median'] = float(np.median(v)) if len(v) else np.nan
    return record


def analyze():
    fr, hf = check_freezes()
    assert not (OUT / 'ANALYSIS_COMPLETE.json').exists(), 'Preserve completed analysis; do not silently overwrite.'
    OUT.mkdir(exist_ok=True)
    df = joined_data()
    write_json(OUT / 'ANALYSIS_INPUTS_FROZEN.json', dict(started_at_utc=now(),
        analysis_plan_sha256=sha(PLAN), analysis_registration_sha256=sha(FREEZE),
        H_freeze_sha256=sha(HFREEZE), H_conditions_sha256=sha(HFILE),
        old_G_scores_sha256=sha(GFILE), new_G_predictions=False, raw_target_G_read=False,
        evidence_status='retrospective_previously_disclosed_G'))
    cuts, summaries, correlations = [], [], []
    df['H_Q_tertile'] = 'unknown'
    df['H_P_tertile'] = 'unknown'
    for method in METHODS:
        ix = df.method.eq(method)
        x = df.loc[ix].copy().sort_values('row')
        known = x.H_pair_known.to_numpy()
        for c, tag in [('Q_r_z', 'Q'), ('delta_r_z', 'P')]:
            vals = x.loc[known, c].to_numpy(float)
            a, b = quantile(vals, 1 / 3), quantile(vals, 2 / 3)
            labels = np.full(len(x), 'unknown', dtype=object)
            if len(vals):
                bins = np.searchsorted([a, b], vals, side='right')
                labels[known] = np.array(['low', 'middle', 'high'], object)[bins]
            x['H_' + tag + '_tertile'] = labels
            df.loc[x.index, 'H_' + tag + '_tertile'] = labels
            cuts.append(dict(method=method, condition=c, n_H_only=len(vals), q1=a, q2=b,
                             duplicate_cuts=bool(a == b), G_used_for_cuts=False))
        cells = sorted(x.spatial_cell.astype(str).unique())
        cols = {s: i for i, s in enumerate(cells)}
        rng = np.random.default_rng(SEED)
        draw = rng.multinomial(len(cells), np.ones(len(cells)) / len(cells), size=REPS).astype(float)
        masks = {
            'all8898': np.ones(len(x), bool),
            'P_usable_both': x.P_usable_both.to_numpy(),
            'P_usable_both_no_geometry_warning': (x.P_usable_both & ~x.geometry_warning).to_numpy(),
            'exclude_pending_GB_exposure_union': ~x.pending_GB_risk_union.to_numpy(),
            'P_usable_both_exclude_pending_GB_exposure_union': (x.P_usable_both & ~x.pending_GB_risk_union).to_numpy()}
        for subset, mask in masks.items():
            z = x.loc[mask]
            groups = [('overall', 'all', np.ones(len(z), bool)),
                      ('H_3x3', 'unknown_H_or_P', ~z.H_pair_known.to_numpy())]
            for q in ['low', 'middle', 'high']:
                for p in ['low', 'middle', 'high']:
                    groups.append(('H_3x3', f'Q_{q}__P_{p}',
                                   (z.H_Q_tertile.eq(q) & z.H_P_tertile.eq(p)).to_numpy()))
            for label in ['both_positive', 'both_nonpositive', 'mixed', 'unknown']:
                groups.append(('H_fold_sign', label, z.H_fold_sign.eq(label).to_numpy()))
            for grouping, group, take in groups:
                summaries.append(describe(z.loc[take], cols, draw, method, subset, grouping, group))
            for hc in ['Q_r_z', 'delta_r_z']:
                for gc in ['G_delta_r_raw', 'G_delta_r_deseasonal']:
                    ok = (z.H_pair_known & z.G_pair_eligible & np.isfinite(z[hc]) & np.isfinite(z[gc]))
                    v = z.loc[ok]
                    defined = len(v) >= 3 and v[hc].nunique() > 1 and v[gc].nunique() > 1
                    rho = float(spearmanr(v[hc], v[gc]).statistic) if defined else np.nan
                    correlations.append(dict(method=method, subset=subset, H_condition=hc, G_outcome=gc,
                        n=len(v), spatial_cells=v.spatial_cell.nunique(), Spearman_rho=rho,
                        small_sample=len(v) < 30 or v.spatial_cell.nunique() < 10,
                        inference='descriptive_no_IID_p_value', evidence_status='retrospective_previously_disclosed_G'))
        print('RETROSPECTIVE_SUMMARIES', method, 'complete', flush=True)
    df.to_csv(OUT / 'station_H_G_linked.csv.gz', index=False, compression='gzip')
    pd.DataFrame(cuts).to_csv(OUT / 'H_only_tertile_cutpoints.csv', index=False)
    pd.DataFrame(summaries).to_csv(OUT / 'condition_cells_and_sensitivities.csv', index=False)
    pd.DataFrame(correlations).to_csv(OUT / 'continuous_spearman.csv', index=False)
    risk_cols = ['row', 'station_id', 'method', 'old_pending_GB_source_exposure', 'risk_source_any',
                 'risk_target', 'pending_GB_risk_union']
    df[risk_cols].to_csv(OUT / 'pending_GB_exposure_union.csv', index=False)
    unknown_cols = ['row', 'station_id', 'method', 'Q_condition_estimable', 'P_increment_estimable',
        'P_usable_both', 'geometry_warning', 'H_pair_known', 'Q_r_z', 'delta_r_z']
    df[unknown_cols].to_csv(OUT / 'H_condition_eligibility_and_unknowns.csv', index=False)
    files = sorted(p for p in OUT.iterdir() if p.is_file())
    write_json(OUT / 'ANALYSIS_COMPLETE.json', dict(status='RETROSPECTIVE_H_CONDITION_ANALYSIS_COMPLETE',
        completed_at_utc=now(), station_method_rows=len(df), summary_rows=len(summaries),
        continuous_rows=len(correlations), methods=list(METHODS), bootstrap_replicates=REPS,
        new_G_predictions=False, raw_target_G_read=False, blind_validation_claim=False,
        files={p.name: sha(p) for p in files}))
    print('RETROSPECTIVE_CONDITION_ANALYSIS_COMPLETE; interpretation reserved for scientific review', flush=True)


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('step', choices=['register', 'analyze'])
    args = ap.parse_args()
    register() if args.step == 'register' else analyze()
