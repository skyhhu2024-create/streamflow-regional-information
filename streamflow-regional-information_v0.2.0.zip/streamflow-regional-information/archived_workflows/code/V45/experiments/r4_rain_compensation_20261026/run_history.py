"""Rebuild FULL-domain predictions in two rolling folds INSIDE each H60.

This file never loads target G values or prior G scores. Prediction building
accepts only a target's inner training observations. Source and precipitation
inputs can extend into the inner validation period, but never outside H60.
All source qualification, seasonal transforms, ranks and processors are refit
using the appropriate inner training months. Existing H60 composites are not
reused. This is a retrospective history diagnostic, not a new blind cohort.
"""
from pathlib import Path
import os
import sys
import json
import argparse
import importlib.util
import warnings
import time
from datetime import datetime, timezone
from concurrent.futures import ProcessPoolExecutor

for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CODE = next(p for p in HERE.parents if p.name == 'code')
sys.path.insert(0, str(CODE / 'V42/dependencies'))
PREV = HERE.parent / 'r4_global_information_20261025'
sys.path.insert(0, str(PREV / 'design_review'))
import numpy as np
import pandas as pd
import transfer_model as M

CORE = HERE.parent / 'r3_conditional_stress_20261024/source_outage/run_outage.py'
spec = importlib.util.spec_from_file_location('r4_history_core', CORE)
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)
OLD = C.OLD
CASES = CORE.parent / 'cases.csv'
RAIN = PREV / 'final_inputs/global8898_tp_197910_201512_ADMITTED.npz'
TWINS = CODE / 'gsim_near_duplicates_checked.csv'
PHYSICAL = HERE.parent / 'r4_global_siting_20261026/census/physical_identity_map.csv'
OUT = HERE / 'history_predictions'
N = 8898
METHODS = ('ridge', 'rbf_ridge')
ARMS = ('Q', 'QP', 'QP_Hclim')
FOLDS = ((36, 12), (48, 12))
RISK_IDS = ('GB_0000239', 'GB_0000240', 'GB_0000241', 'GB_0000242')
STATE = {}


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    C.js(path, value)


class HistorySourceWindow:
    """Array accessor used by the unchanged source-combination function.

    Only the 60 months of H are materialized; an absolute-date access outside
    that interval fails rather than silently making future source values
    available. Advanced indexing retains the same values as the old code.
    """
    def __init__(self, values, first_month):
        self.values = np.asarray(values, dtype=float)
        self.first = int(first_month)

    def __getitem__(self, indices):
        row, months = indices
        local = np.asarray(months, dtype=int) - self.first
        if not np.all((local >= 0) & (local < self.values.shape[1])):
            raise ValueError('Attempted source read outside the H-only window')
        return self.values[row, local]


def checked_aliases(meta):
    lookup = {str(s): i for i, s in enumerate(meta.station_id)}
    tw = pd.read_csv(TWINS, keep_default_na=False)
    tw = tw[tw.twin.astype(str).str.lower().eq('true')]
    adj = {}
    for e in tw.itertuples():
        if e.a in lookup and e.b in lookup:
            a, b = lookup[e.a], lookup[e.b]
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
    aliases = {}
    for root in adj:
        seen, todo = {root}, [root]
        while todo:
            for nxt in adj.get(todo.pop(), ()):
                if nxt not in seen:
                    seen.add(nxt)
                    todo.append(nxt)
        aliases[root] = seen
    return aliases


def init():
    warnings.filterwarnings('ignore', category=RuntimeWarning)
    STATE['cases'] = pd.read_csv(CASES, keep_default_na=False)
    assert len(STATE['cases']) == N
    assert np.array_equal(STATE['cases'].row.to_numpy(int), np.arange(N))
    STATE['Q'] = np.load(OLD / 'global_data/QC20_Q.npy', mmap_mode='r')
    STATE['raw'] = np.load(OLD / 'predictions/source_cache/source_raw_indices.npy')
    STATE['meta'] = pd.read_csv(OLD / 'design/all_station_roles.csv', keep_default_na=False)
    assert len(STATE['raw']) == 24734
    source = STATE['meta'].iloc[STATE['raw']]
    STATE['lat'] = pd.to_numeric(source.latitude, errors='coerce').to_numpy(float)
    STATE['lon'] = pd.to_numeric(source.longitude, errors='coerce').to_numpy(float)
    STATE['aliases'] = checked_aliases(STATE['meta'])
    physical = pd.read_csv(PHYSICAL, keep_default_na=False).sort_values('raw_index')
    assert np.array_equal(physical.raw_index.to_numpy(int), np.arange(len(STATE['meta'])))
    assert np.array_equal(physical.station_id.to_numpy(str), STATE['meta'].station_id.to_numpy(str))
    STATE['physical_group'] = physical.physical_group_raw_index.to_numpy(int)
    STATE['risk_raw'] = np.flatnonzero(STATE['meta'].station_id.isin(RISK_IDS))
    with np.load(RAIN, allow_pickle=False) as z:
        assert np.array_equal(z['station_ids'].astype(str), STATE['cases'].station_id.to_numpy(str))
        assert np.array_equal(z['raw_index'], STATE['cases'].raw_index.to_numpy(int))
        assert np.array_equal(z['calendar_index_1980'], np.arange(-3, 432))
        STATE['rain'] = z['precip_mm_month'].copy()
        STATE['rain_admitted'] = z['admission_mask'].astype(bool)
        STATE['rain_warning'] = z['geometry_warning_mask'].astype(bool)


def distances(lat, lon, source_lat, source_lon):
    a, b = np.deg2rad([lat, lon])
    c, d = np.deg2rad(source_lat), np.deg2rad(source_lon)
    hav = np.sin((c-a)/2)**2 + np.cos(a)*np.cos(c)*np.sin((d-b)/2)**2
    return 6371*2*np.arcsin(np.sqrt(np.clip(hav, 0, 1)))


def predict_fold(target_train, source_h60, source_raw, distance, excluded_raw,
                 history_start, training_length, raw_precipitation, rain_admitted):
    """Pure inner-fold prediction API: target validation truth is NOT accepted.

    raw_precipitation comprises the three antecedent months plus the inner
    training and 12 validation months. source_h60 contains source reports only
    inside the original H60. The held-out target cannot enter qualification.
    """
    ntrain = int(training_length)
    assert ntrain in (36, 48)
    train_months = np.arange(history_start, history_start+ntrain)
    validation_months = np.arange(history_start+ntrain, history_start+ntrain+12)
    target_train = np.asarray(target_train, float)
    assert target_train.shape == (ntrain,)
    assert source_h60.shape == (len(source_raw), 60)
    assert len(raw_precipitation) == ntrain+15
    assert not (np.asarray(source_raw).ndim != 1)
    tc, ts, tz = C.prep(target_train[None, :], train_months)
    tc, ts, tz = tc[0], float(ts[0]), tz[0]
    target_domain = bool(np.isfinite(target_train).all() and (target_train >= 0).all())
    estimable = bool(target_domain and np.isfinite(tc).all() and np.isfinite(ts))
    if not estimable:
        tz = np.full(ntrain, np.nan)
    raw_calendar = np.array([np.nanmean(target_train[train_months % 12 == m]) for m in range(12)])
    base = raw_calendar[validation_months % 12]
    cl, sd, zh = C.prep(source_h60[:, :ntrain], train_months)
    pairs, r = C.relation(zh, tz)
    same = np.isin(source_raw, list(excluded_raw))
    qualified = np.flatnonzero(np.isfinite(r) & (r > 0) & np.isfinite(sd) & ~same)
    order = C.ordering(np.asarray(source_raw), qualified, r, distance)
    source = {'raw': np.asarray(source_raw), 'Q': HistorySourceWindow(source_h60, history_start)}
    months = np.r_[train_months, validation_months]
    comp, counts, ids = C.combine(source, order, r, cl, sd, months)
    assert not np.isin(ids, list(excluded_raw)).any()
    training = np.isfinite(tz) & np.isfinite(comp[:ntrain])
    p = M.prepare_precipitation_lags(raw_precipitation, history_start_month=history_start,
                                   h_length=ntrain, g_length=12)
    hasp = bool(rain_admitted and p.available)
    qh, qv = comp[:ntrain, None], comp[ntrain:, None]
    predictions = np.full((2, 3, 12), np.nan)
    prediction_z = np.full_like(predictions, np.nan)
    model_z = np.full_like(predictions, np.nan)
    support = np.zeros((2, 3, 12), bool)
    flags = np.zeros((2, 3, 7), bool)
    reasons = []
    for mi, method in enumerate(METHODS):
        q, qr = M.fit_transfer(qh[training], tz[training], method=method, target_estimable=estimable)
        qp, pr = None, 'precipitation_not_admitted_or_incomplete'
        if hasp:
            qp, pr = M.fit_transfer(np.column_stack([qh, p.h])[training], tz[training],
                                    method=method, target_estimable=estimable)
        models = [q, qp if qp is not None else q, qp if qp is not None else q]
        val_features = [qv, np.column_stack([qv, p.g]) if qp is not None else qv,
                        np.column_stack([qv, p.g_climatology]) if qp is not None else qv]
        assert models[1] is models[2]
        for ai, model in enumerate(models):
            actual = model is not None
            requested = q is not None if ai == 0 else qp is not None
            usep = ai > 0 and qp is not None
            z = model.predict(val_features[ai]) if actual else np.full(12, np.nan)
            model_z[mi, ai] = z
            predictions[mi, ai], support[mi, ai] = C.transfer(z, tz, tc, ts, validation_months, base, actual)
            if estimable:
                prediction_z[mi, ai] = (np.log1p(predictions[mi, ai])-tc[validation_months % 12])/ts
            flags[mi, ai] = [actual, requested, True if ai == 0 else hasp,
                            not requested, usep, usep and ai == 1, usep and ai == 2]
        reasons.append(dict(method=method, Q=qr, QP=pr))
    if not hasp:
        np.testing.assert_allclose(predictions[:, 0], predictions[:, 1], atol=0, rtol=0, equal_nan=True)
        np.testing.assert_allclose(predictions[:, 0], predictions[:, 2], atol=0, rtol=0, equal_nan=True)
    # Per-fold arrays padded to H60 retain dates and train/validation meanings.
    all_ids = np.full((60, 4), -1, np.int32)
    all_ids[:ntrain+12] = ids
    all_counts = np.zeros(60, np.int8)
    all_counts[:ntrain+12] = counts
    all_comp = np.full(60, np.nan)
    all_comp[:ntrain+12] = comp
    all_train = np.zeros(60, bool)
    all_train[:ntrain] = training
    return dict(predictions=predictions, predictions_z=prediction_z, model_z=model_z,
                support=support, flags=flags, source_ids=all_ids, counts=all_counts,
                composite=all_comp, training_mask=all_train,
                target_log_calendar=tc, target_anomaly_sd=np.array(ts),
                target_raw_calendar=raw_calendar, validation_months=validation_months,
                meta=np.array([estimable, target_domain, training.sum(), len(qualified), hasp,
                               rain_admitted, p.available], float),
                reasons=np.array([json.dumps(x) for x in reasons], dtype=str))


def compute_case(i):
    """Build one case without reading its original target gap at all."""
    e = STATE['cases'].iloc[i]
    start, end, raw = int(e.history_start), int(e.history_end), int(e.raw_index)
    assert end-start == 60 and end == int(e.gap_start)
    target_h = np.asarray(STATE['Q'][raw, start:end], float)
    source_h = np.asarray(STATE['Q'][STATE['raw'], start:end], float)
    distance = distances(float(e.latitude), float(e.longitude), STATE['lat'], STATE['lon'])
    excluded = STATE['aliases'].get(raw, {raw})
    # The rainfall index zero corresponds to 1979-10 (relative month -3).
    results = []
    for length, validation_length in FOLDS:
        rawp = STATE['rain'][i, start:start+length+validation_length+3]
        results.append(predict_fold(target_h[:length], source_h, STATE['raw'], distance, excluded,
                                    start, length, rawp, bool(STATE['rain_admitted'][i])))
        selected = results[-1]['source_ids']
        used = selected[selected >= 0]
        assert not (STATE['physical_group'][used] == STATE['physical_group'][raw]).any(), (
            'Additional physical alias detected beyond old checked-twin exclusions', str(e.station_id))
    out = {key: np.stack([r[key] for r in results]) for key in results[0]}
    out['target_raw_index'] = np.array(raw, np.int32)
    out['history_start'] = np.array(start, np.int16)
    out['rain_geometry_warning'] = np.array(bool(STATE['rain_warning'][i]))
    out['risk_source_any'] = np.array([np.isin(r['source_ids'], STATE['risk_raw']).any() for r in results])
    out['risk_source_validation'] = np.array([np.isin(r['source_ids'][length:length+12], STATE['risk_raw']).any()
                                             for r, (length, _) in zip(results, FOLDS)])
    out['risk_target'] = np.array(str(e.station_id) in RISK_IDS)
    return out


def work(i):
    result = compute_case(i)
    p = OUT / 'case_cache' / f'{i:05d}.npz'
    tmp = p.with_suffix('.tmp.npz')
    np.savez_compressed(tmp, **result)
    os.replace(tmp, p)
    return i


def paths_to_freeze():
    return [Path(__file__), HERE / 'PROTOCOL.json', CASES, CORE,
            PREV / 'design_review/transfer_model.py',
            OLD / 'global_data/QC20_Q.npy', OLD / 'design/all_station_roles.csv',
            OLD / 'predictions/source_cache/source_raw_indices.npy', TWINS, PHYSICAL, RAIN]


def register():
    assert not (OUT / 'PREDICTIONS_FROZEN.json').exists()
    assert not (HERE / 'CODE_INPUTS_FROZEN.json').exists(), 'Do not silently overwrite registration'
    HERE.mkdir(exist_ok=True, parents=True)
    p = dict(registered_at_utc=datetime.now(timezone.utc).isoformat(), N=N, original_H=60,
             inner_folds=[dict(train=36, validation=12, heldout_positions=[36, 48]),
                          dict(train=48, validation=12, heldout_positions=[48, 60])],
             methods=list(METHODS), arms=list(ARMS),
             scope='All original8898 cases, history-only diagnostic. Previously revealed original G is not read here. No new blind-cohort claim.',
             source_domain='Same FULL baseline24734 GSIM QC candidates, no geographical or outer-fold source exclusion; remove self and entire checked-twin component. Four pending GB aliases are retained to preserve old FULL-domain comparability and flagged for later union-risk sensitivity.',
             physical_audit='Every selected source in each inner fold is checked against the newer complete physical identity map. A newly detected target alias aborts production rather than changing the source domain silently.',
             source_selection='Every inner fold refits log1p calendarmeans, anomalySD, >=12 common finite pairs, positive anomaly r, rank(-r)+rank(distance), rrank/rawID tie-break, monthly up-to4 positive-r-weighted references. No H60 composite reuse.',
             target_rule='Only inner training values estimate target seasonal transforms, domain/estimability, transfer and inverse guards. Validation target values cannot enter prediction API. Original target G is never requested.',
             precipitation='Original admitted ERA5-Land catchment monthly total mm/month; log1p current and lag1..3. Inner climate replacement uses inner-training calendar means and alters only inner-validation dates; preceding training lags remain actual.',
             processors='Fixed standardized ridge lambda.1 and fixed RBF lambda.1; original same-mask fit and inverse guards. No tuning or selection based on results.',
             fallback='P not admitted/incomplete or QP fit failed returns Q for both P arms; no actual Q fit returns inner raw-seasonal baseline. Preserve all cases, failures, unknowns, support and flags.',
             primary_history_conditions='Pooled24-month correlation between actual log-flow anomalies standardized using each inner training window and the Q prediction; corresponding QP-minus-Q correlation difference. Unchanged fixed processors reported separately. No information-class threshold chosen in this module.',
             auxiliary='Per-fold r and sign agreement; samefit actualP vs calendarP; raw-flow r; SSE skill difference (SSEQ-SSEQP)/SSTz; E_Q=1-SSEQ/sum(z_truth^2) and C_P=1-SSEQP/SSEQ using postguard standardized log predictions. E_Q seasonal reference is zero standardized anomaly, i.e. the inner-training log-calendar mean, not the raw-calendar fallback and not centered heldout SSTz. Near-zero denominator is unknown. These do not replace temporal correlation or equal information entropy.',
             flag_columns=['actual_fit', 'requested_fit', 'requested_source', 'fallback', 'uses_P_H', 'uses_P_validation_actual', 'uses_P_validation_climatology'],
             meta_columns=['target_estimable', 'target_nonnegative_complete', 'common_training_rows', 'qualified_sources', 'P_usable', 'P_admitted', 'P_required_period_complete'],
             scoring_gate='Freeze all inner-history predictions before score_history. score_history reads only held-out months lying inside original H60. No G scores or truth are loaded by any command.',
             excluded_scope='No manuscripts, SI, figures, cloud, new stations, topology, processor search or partial-cohort scientific claims.')
    write_json(HERE / 'PROTOCOL.json', p)
    write_json(HERE / 'CODE_INPUTS_FROZEN.json', dict(files={str(p): C.sha(p) for p in paths_to_freeze()},
                                                   target_G_read=False, old_G_scores_read=False))
    print('REGISTERED_HISTORY_ONLY_FULL_DOMAIN', flush=True)


def check_registration():
    reg = json.loads((HERE / 'CODE_INPUTS_FROZEN.json').read_text(encoding='utf8'))
    for path, expected in reg['files'].items():
        assert C.sha(path) == expected, path


def produce(workers):
    check_registration()
    assert not (OUT / 'PREDICTIONS_FROZEN.json').exists()
    (OUT / 'case_cache').mkdir(parents=True, exist_ok=True)
    jobs = [i for i in range(N) if not (OUT / 'case_cache' / f'{i:05d}.npz').exists()]
    st = time.time()
    with ProcessPoolExecutor(max_workers=workers, initializer=init) as pool:
        for count, i in enumerate(pool.map(work, jobs, chunksize=4), 1):
            if count % 250 == 0 or count == len(jobs):
                print(f'History predictions {count}/{len(jobs)}; row={i}; seconds={time.time()-st:.1f}', flush=True)
    print('ALL_HISTORY_CASES_PRESENT', flush=True)


def assemble():
    check_registration()
    assert not (OUT / 'PREDICTIONS_FROZEN.json').exists()
    with np.load(OUT / 'case_cache/00000.npz', allow_pickle=False) as z:
        shapes = {key: (z[key].shape, z[key].dtype) for key in z.files if key != 'reasons'}
    arrays = {key: np.lib.format.open_memmap(OUT / f'{key}.npy', mode='w+',
              dtype=dtype, shape=(N,)+shape) for key, (shape, dtype) in shapes.items()}
    audits = []
    cache_hashes = {}
    for i in range(N):
        path = OUT / 'case_cache' / f'{i:05d}.npz'
        cache_hashes[path.name] = C.sha(path)
        with np.load(path, allow_pickle=False) as z:
            for key in arrays:
                arrays[key][i] = z[key]
            for fi, (length, _) in enumerate(FOLDS):
                for mi, reason in enumerate(z['reasons'][fi]):
                    d = json.loads(str(reason))
                    audits.append(dict(row=i, fold=fi, training_months=length,
                        target_estimable=bool(z['meta'][fi, 0]), common_training_rows=int(z['meta'][fi, 2]),
                        qualified_sources=int(z['meta'][fi, 3]), P_usable=bool(z['meta'][fi, 4]),
                        P_admitted=bool(z['meta'][fi, 5]), geometry_warning=bool(z['rain_geometry_warning']),
                        risk_source_any=bool(z['risk_source_any'][fi]),
                        risk_source_validation=bool(z['risk_source_validation'][fi]),
                        risk_target=bool(z['risk_target']), **d))
    for a in arrays.values():
        a.flush()
    pd.DataFrame(audits).to_csv(OUT / 'fold_audit.csv', index=False, encoding='utf-8-sig')
    pd.read_csv(CASES, keep_default_na=False).to_csv(OUT / 'cases.csv', index=False, encoding='utf-8-sig')
    write_json(OUT / 'CASE_CACHE_HASHES.json', cache_hashes)
    paths = [OUT / f'{key}.npy' for key in arrays] + [OUT / 'fold_audit.csv', OUT / 'cases.csv', OUT / 'CASE_CACHE_HASHES.json']
    write_json(OUT / 'PREDICTIONS_FROZEN.json', dict(status='ALL_8898_HISTORY_ONLY_PREDICTIONS_FROZEN_BEFORE_SCORING',
        N=N, methods=list(METHODS), arms=list(ARMS), folds=[list(f) for f in FOLDS],
        target_G_read=False, original_G_score_read=False,
        registration_sha256=C.sha(HERE / 'CODE_INPUTS_FROZEN.json'),
        files={p.name: C.sha(p) for p in paths}))
    print('HISTORY_PREDICTIONS_FROZEN', flush=True)


def corr(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    if not (np.isfinite(x).all() and np.isfinite(y).all()) or len(x) < 3:
        return np.nan
    a, b = x-x.mean(), y-y.mean()
    den = np.sqrt(float(a@a)*float(b@b))
    return float(np.clip(a@b/den, -1, 1)) if den > 1e-24 else np.nan


def score_history():
    check_registration()
    f = json.loads((OUT / 'PREDICTIONS_FROZEN.json').read_text(encoding='utf8'))
    assert f['status'] == 'ALL_8898_HISTORY_ONLY_PREDICTIONS_FROZEN_BEFORE_SCORING'
    assert all(C.sha(OUT / path) == expected for path, expected in f['files'].items())
    assert not (HERE / 'history_analysis/HISTORY_SCORES_FROZEN.json').exists()
    cases = pd.read_csv(OUT / 'cases.csv', keep_default_na=False)
    q = np.load(OLD / 'global_data/QC20_Q.npy', mmap_mode='r')
    data = {key: np.load(OUT / f'{key}.npy', mmap_mode='r') for key in
            ['predictions', 'predictions_z', 'support', 'flags', 'meta', 'target_log_calendar',
             'target_anomaly_sd', 'risk_source_any', 'risk_source_validation', 'risk_target', 'rain_geometry_warning']}
    rows, foldrows = [], []
    for i, e in enumerate(cases.itertuples(index=False)):
        start, end = int(e.history_start), int(e.history_end)
        raw = int(e.raw_index)
        # Only two held-out windows INSIDE H; not a read of target G.
        y = np.stack([np.asarray(q[raw, start+length:start+length+12], float) for length, _ in FOLDS])
        assert start+FOLDS[-1][0]+12 == end
        valid_truth = bool(np.isfinite(y).all() and (y >= 0).all())
        zz = np.full_like(y, np.nan)
        for fi, (length, _) in enumerate(FOLDS):
            months = np.arange(start+length, start+length+12)
            if valid_truth and np.isfinite(data['target_anomaly_sd'][i, fi]):
                zz[fi] = (np.log1p(y[fi])-data['target_log_calendar'][i, fi, months % 12])/data['target_anomaly_sd'][i, fi]
        for mi, method in enumerate(METHODS):
            available = bool(data['meta'][i, :, 4].all())
            validq = bool(valid_truth and data['flags'][i, :, mi, 0, 0].all()
                          and data['support'][i, :, mi, 0].all() and np.isfinite(zz).all())
            validqp = bool(validq and available and data['flags'][i, :, mi, 1, 1].all()
                           and data['support'][i, :, mi, 1].all())
            identity = dict(row=i, station_id=e.station_id, raw_index=raw, method=method,
                            continent=e.continent, spatial_cell=e.spatial_cell, outer_fold=e.outer_fold,
                            history_start=start, history_end=end,
                            P_usable_both=available, Q_condition_estimable=validq,
                            P_increment_estimable=validqp, geometry_warning=bool(data['rain_geometry_warning'][i]),
                            risk_source_any=bool(data['risk_source_any'][i].any()),
                            risk_source_validation=bool(data['risk_source_validation'][i].any()),
                            risk_target=bool(data['risk_target'][i]))
            score = {}
            sst = float(np.sum((zz.ravel()-zz.mean())**2)) if np.isfinite(zz).all() else np.nan
            sses = []
            for ai, arm in enumerate(ARMS):
                predz = np.asarray(data['predictions_z'][i, :, mi, ai]).ravel()
                pred = np.asarray(data['predictions'][i, :, mi, ai]).ravel()
                isvalid = validq if ai == 0 else validqp
                score[f'{arm}_r_z_numeric'] = corr(zz.ravel(), predz)
                score[f'{arm}_r_raw_numeric'] = corr(y.ravel(), pred)
                score[f'{arm}_r_z'] = score[f'{arm}_r_z_numeric'] if isvalid else np.nan
                sse = float(np.sum((predz-zz.ravel())**2)) if np.isfinite(predz).all() and np.isfinite(zz).all() else np.nan
                sses.append(sse)
                score[f'{arm}_SSE_z'] = sse if isvalid else np.nan
                score[f'{arm}_skill_z'] = 1-sse/sst if isvalid and sst > 1e-24 else np.nan
            score['delta_r_z'] = score['QP_r_z']-score['Q_r_z']
            score['delta_r_actual_vs_clim_z'] = score['QP_r_z']-score['QP_Hclim_r_z']
            score['delta_skill_z'] = (sses[0]-sses[1])/sst if validqp and sst > 1e-24 else np.nan
            score['SST_z'] = sst
            sseseason = float(np.sum(zz**2)) if np.isfinite(zz).all() else np.nan
            # The 1e-12 relative guard avoids assigning ratios to numerically
            # negligible residual energy; raw denominators remain recorded.
            energy_guard = 1e-12*max(1., float(np.sum(zz**2))) if np.isfinite(zz).all() else np.nan
            score['SSE_season_z'] = sseseason
            score['E_Q'] = 1-sses[0]/sseseason if validq and sseseason > energy_guard else np.nan
            score['C_P'] = 1-sses[1]/sses[0] if validqp and sses[0] > energy_guard else np.nan
            fold_deltas = []
            for fi, (length, _) in enumerate(FOLDS):
                fq = bool(valid_truth and data['flags'][i, fi, mi, 0, 0] and data['support'][i, fi, mi, 0].all())
                fp = bool(fq and data['meta'][i, fi, 4] and data['flags'][i, fi, mi, 1, 1]
                          and data['support'][i, fi, mi, 1].all())
                fs = dict(row=i, station_id=e.station_id, method=method, fold=fi, training_months=length,
                          Q_estimable=fq, P_increment_estimable=fp)
                fsse = []
                for ai, arm in enumerate(ARMS):
                    isvalid = fq if ai == 0 else fp
                    zpred = np.asarray(data['predictions_z'][i, fi, mi, ai])
                    fs[f'{arm}_r_z'] = corr(zz[fi], zpred) if isvalid else np.nan
                    fs[f'{arm}_r_raw'] = corr(y[fi], data['predictions'][i, fi, mi, ai]) if isvalid else np.nan
                    fsse.append(float(np.sum((zpred-zz[fi])**2)))
                fs['delta_r_z'] = fs['QP_r_z']-fs['Q_r_z']
                fs['delta_r_actual_vs_clim_z'] = fs['QP_r_z']-fs['QP_Hclim_r_z']
                fsst = float(np.sum((zz[fi]-zz[fi].mean())**2))
                fs['delta_skill_z'] = (fsse[0]-fsse[1])/fsst if fp and fsst > 1e-24 else np.nan
                foldrows.append(fs)
                fold_deltas.append(fs['delta_r_z'])
            score['fold0_delta_r_z'], score['fold1_delta_r_z'] = fold_deltas
            score['both_fold_positive'] = bool(np.isfinite(fold_deltas).all() and min(fold_deltas) > 0)
            score['both_fold_negative'] = bool(np.isfinite(fold_deltas).all() and max(fold_deltas) < 0)
            rows.append(dict(**identity, **score))
    analysis = HERE / 'history_analysis'
    analysis.mkdir(exist_ok=True)
    outputs = [analysis / 'history_conditions.csv', analysis / 'history_fold_scores.csv']
    pd.DataFrame(rows).to_csv(outputs[0], index=False, encoding='utf-8-sig')
    pd.DataFrame(foldrows).to_csv(outputs[1], index=False, encoding='utf-8-sig')
    write_json(analysis / 'HISTORY_SCORES_FROZEN.json', dict(status='HISTORY_ONLY_SCORES_FROZEN',
        rows=len(rows), fold_rows=len(foldrows), original_target_G_read=False,
        predictions_sha256=C.sha(OUT / 'PREDICTIONS_FROZEN.json'),
        files={p.name: C.sha(p) for p in outputs}))
    print('HISTORY_SCORES_FROZEN', flush=True)


def synthetic():
    """Small synthetic guards only; no real-case production or scores."""
    rng = np.random.default_rng(20261026)
    nsource, first = 8, 17
    target = np.maximum(2+np.sin(np.arange(60)/3)+rng.normal(0, .2, 60), 0)
    source = np.maximum(target[None, :]+rng.normal(0, .2, (nsource, 60)), 0)
    source_raw = np.arange(8)
    distance = np.arange(8.)
    rainfall = np.maximum(rng.normal(10, 3, 63), 0)
    source[0] = target
    x = predict_fold(target[:36], source, source_raw, distance, {0}, first, 36, rainfall[:51], True)
    assert not (x['source_ids'] == 0).any()
    # Inputs dated AFTER this fold's validation must be inert.
    outside = source.copy()
    outside[:, 48:] = 1e12
    y = predict_fold(target[:36], outside, source_raw, distance, {0}, first, 36, rainfall[:51], True)
    for key in x:
        if key == 'reasons':
            assert np.array_equal(x[key], y[key])
        else:
            np.testing.assert_allclose(x[key], y[key], atol=0, rtol=0, equal_nan=True)
    # There is no argument through which held-out target truth can enter.
    import inspect
    assert 'target_validation' not in inspect.signature(predict_fold).parameters
    assert 'target_train' in inspect.signature(predict_fold).parameters
    denied = predict_fold(target[:36], source, source_raw, distance, {0}, first, 36, rainfall[:51], False)
    np.testing.assert_array_equal(denied['predictions'][:, 0], denied['predictions'][:, 1])
    np.testing.assert_array_equal(denied['predictions'][:, 0], denied['predictions'][:, 2])
    # H-dated antecedent rainfall lags are unchanged in the climate control.
    p = M.prepare_precipitation_lags(rainfall[:51], history_start_month=first, h_length=36, g_length=12)
    assert np.array_equal(p.g[0, 1:], p.g_climatology[0, 1:])
    try:
        HistorySourceWindow(source, first)[0, np.array([first-1])]
        raise AssertionError('Out-of-H access should fail')
    except ValueError:
        pass
    write_json(HERE / 'SYNTHETIC_QA.json', dict(status='PASS', checks=[
        'target_validation_not_accepted_by_prediction_API', 'self_source_excluded',
        'source_after_inner_validation_inert', 'denied_P_exact_Q_fallback',
        'climate_control_retains_H_dated_lags', 'source_accessor_rejects_outside_H'],
        real_data_produced=False))
    print('SYNTHETIC_QA_PASS', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('step', choices=['synthetic', 'register', 'produce', 'assemble', 'score_history'])
    parser.add_argument('--workers', type=int, default=8)
    args = parser.parse_args()
    if args.step == 'produce':
        produce(args.workers)
    else:
        globals()[args.step]()
