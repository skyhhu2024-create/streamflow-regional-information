from pathlib import Path
import sys,json,hashlib
HERE=Path(__file__).resolve().parent
CODE=next(p for p in HERE.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()

def main():
 out=HERE/'distance_v2';fr=json.loads((out/'DISTANCE_FROZEN.json').read_text(encoding='utf8'))
 assert all(sha(out/p)==v for p,v in fr['files'].items())
 c=pd.read_csv(HERE/'distance_cases.csv',keep_default_na=False).sort_values('output_row');meta=pd.read_csv(HERE/'distance_station_relation_metadata.csv').sort_values('output_row')
 h=pd.read_csv(HERE/'forward_station_history_calendar.csv.gz',keep_default_na=False);h=h[h.window.eq('all_visible')].set_index('station_id').reindex(c.station_id)
 state=np.load(out/'state.npy',mmap_mode='r');fields=np.load(out/'distance_and_r.npy',mmap_mode='r');counts=np.load(out/'counts.npy',mmap_mode='r')
 ri,mi=np.nonzero(state>0);assert len(ri)==2612522
 years=1980+mi//12;period=np.where(years<1990,'1980-1989',np.where(years<2000,'1990-1999',np.where(years<2010,'2000-2009','2010-2015')))
 d=pd.DataFrame({'target_row':ri,'month_index':mi,'continent':c.continent.to_numpy()[ri],'period':period,'all_visible_missing_calendar_band':h.missing_calendar_band.to_numpy()[ri],
                 'state':state[ri,mi],'nearest_raw_report_km':fields[ri,0,mi],'nearest_transformable_report_km':fields[ri,1,mi],
                 'RD4_weighted_km':fields[ri,2,mi],'RD4_weighted_r':fields[ri,3,mi],'raw_reporting_count':counts[ri,0,mi],'transformable_reporting_count':counts[ri,1,mi],'RD4_count':counts[ri,2,mi]})
 def summarize(z):
  n=len(z);raw=z.nearest_raw_report_km.notna();trans=z.nearest_transformable_report_km.notna()
  rr={'stations':int(z.target_row.nunique()),'forward_missing_months':n,'no_qualified_relation_months':int(z.state.eq(1).sum()),'no_synchronous_report_months':int(z.state.eq(2).sum()),'raw_report_not_transformable_months':int(z.state.eq(3).sum()),'transformable_support_months':int(z.state.eq(4).sum()),'raw_report_support_months':int(raw.sum())}
  for name in ['nearest_raw_report_km','nearest_transformable_report_km','RD4_weighted_km','RD4_weighted_r']:
   rr[name+'_median']=float(z[name].median()) if z[name].notna().any() else np.nan
  for radius in [100,300,800]:
   a=z.nearest_raw_report_km.gt(radius);b=z.nearest_transformable_report_km.gt(radius)
   rr[f'no_qualified_raw_report_within_{radius}_km_but_global_report_months']=int(a.sum())
   rr[f'no_transformable_report_within_{radius}_km_but_global_support_months']=int(b.sum())
   rr[f'raw_far_{radius}_pct_all_forward']=100*a.sum()/n
   rr[f'raw_far_{radius}_pct_supported']=100*a.sum()/raw.sum() if raw.any() else np.nan
   rr[f'RD4_weighted_distance_gt{radius}_months']=int(z.RD4_weighted_km.gt(radius).sum())
  rr['no_support_pct_all_forward']=100*z.state.lt(4).sum()/n
  return rr
 rows=[dict(scope='Global',region='Global',period='all',calendar_band='all',**summarize(d))]
 for keys,label in [(['continent'],'region'),(['period'],'period'),(['all_visible_missing_calendar_band'],'calendar'),(['continent','period','all_visible_missing_calendar_band'],'region_period_calendar')]:
  for names,z in d.groupby(keys,dropna=False,sort=True):
   if not isinstance(names,tuple):names=(names,)
   vals=dict(zip(keys,names));rows.append(dict(scope=label,region=vals.get('continent','Global'),period=vals.get('period','all'),calendar_band=vals.get('all_visible_missing_calendar_band','all'),**summarize(z)))
 pd.DataFrame(rows).to_csv(HERE/'distance_support_summary.csv',index=False)
 ss=[]
 for i,z in d.groupby('target_row',sort=True):
  rec=c.iloc[int(i)].to_dict();rec.update(summarize(z));rec.update(meta.iloc[int(i)].to_dict());ss.append(rec)
 pd.DataFrame(ss).to_csv(HERE/'distance_station_summary.csv.gz',index=False,compression='gzip')
 reason=[]
 for key,z in meta.groupby('relation_reason'):
  nums=(432-z.history_end_exclusive).sum();reason.append({'reason':key,'stations':len(z),'forward_missing_months':int(nums)})
 pd.DataFrame(reason).to_csv(HERE/'distance_relationship_reasons.csv',index=False)
 checks={'status':'COMPLETE','forward_missing_months':len(d),'targets':19418,'state_counts':{str(k):int(v) for k,v in d.state.value_counts().sort_index().items()},'summary_rows':len(rows),'outputs':{p.name:sha(p) for p in [HERE/'distance_support_summary.csv',HERE/'distance_station_summary.csv.gz',HERE/'distance_relationship_reasons.csv']}}
 (HERE/'DISTANCE_SUMMARY_COMPLETE.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf8')
 print(pd.DataFrame(rows).head(1).to_string(index=False));print(pd.DataFrame(reason).to_string(index=False))

if __name__=='__main__':main()
