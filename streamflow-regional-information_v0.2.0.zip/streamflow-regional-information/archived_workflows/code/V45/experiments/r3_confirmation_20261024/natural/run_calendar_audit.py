from pathlib import Path
import sys,json,hashlib,time
from datetime import datetime,timezone
HERE=Path(__file__).resolve().parent
CODE=next(p for p in HERE.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd
ARCH=CODE/'V42.2/experiments/r3_global_k4_20261014/outputs/R1_scope'
SOURCES=[ARCH/'archive_completion.npz',ARCH/'station_completion.csv',CODE/'recoverability/ids.npy',CODE/'recoverability/Z.mm']
CAL_BANDS=['0','1-2','3-5','6-11','12']
HIST_BANDS=['<12','12-23','24-59','60-119','>=120']
PERIODS=[('1980-1989',0,120),('1990-1999',120,240),('2000-2009',240,360),('2010-2015',360,432)]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def js(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
def band(k):return '0' if k==0 else '1-2' if k<=2 else '3-5' if k<=5 else '6-11' if k<=11 else '12'
def histband(n):return '<12' if n<12 else '12-23' if n<24 else '24-59' if n<60 else '60-119' if n<120 else '>=120'
def register():
 p=HERE/'NATURAL_PROTOCOL.json'
 assert not p.exists(),'Frozen protocol already exists'
 js(p,{'frozen_utc':datetime.now(timezone.utc).isoformat(),'scope':'Natural archive representation only; no reconstruction or outcomes. Main paper 24934 station domain, original 1980-2015 observed mask.',
       'denominators':{'all_stations':24934,'all_missing_station_months':4598259,'forward_stations':19418,'forward_missing_station_months':2612522},
       'history':'For each natural forward gap, all_visible uses all original observed months through last observation. H36 and H60 use last 36/60 CALENDAR months ending at last observation, clipped at 1980; not last N observed values. Original observed mask defines counts, signed observations retained in inventory and counted separately.',
       'calendar_bands':CAL_BANDS,'calendar_counts':'Each calendar month counts 0, 1 or >=2 observations; all 12 raw counts retained per station. Missing calendars count bins prespecified.',
       'history_length_bands':HIST_BANDS,'aggregation':'Equal station counts and missing forward station-month weights both reported. Region from frozen station_completion; missing-month decade is evaluation date, not end-of-observation decade. Whole natural archive task counts only descriptive.',
       'interpretation':'H36/H60 missing seasons may be imposed by limited window; all_visible distinguishes them from genuinely absent seasons in archive. No claims these calendar descriptions imply model failure or success; observed repetition is not sufficient to establish anomaly identifiability.',
       'distance':'Separate amendment and input-only computation required after checking global source flags; old new-U1/U2 trace is not full-domain evidence.',
       'sources':{str(p.relative_to(CODE)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in SOURCES},'script_sha256':sha(Path(__file__))})

def main():
 t0=time.time();pr=json.loads((HERE/'NATURAL_PROTOCOL.json').read_text(encoding='utf8'))
 assert sha(Path(__file__))==pr['script_sha256']
 assert all(sha(CODE/p)==v['sha256'] for p,v in pr['sources'].items())
 ar=np.load(ARCH/'archive_completion.npz',allow_pickle=True);ids=ar['station_id'].astype(str);obs=ar['observed'].astype(bool)
 st=pd.read_csv(ARCH/'station_completion.csv',keep_default_na=False);assert st.station_id.tolist()==ids.tolist()
 assert obs.shape==(24934,432) and int((~obs).sum())==4598259
 first=np.argmax(obs,1);last=431-np.argmax(obs[:,::-1],1);months=np.arange(432)
 task={'backward':(~obs)&(months[None,:]<first[:,None]),'forward':(~obs)&(months[None,:]>last[:,None]),'internal':(~obs)&(months[None,:]>=first[:,None])&(months[None,:]<=last[:,None])}
 assert sum(int(v.sum()) for v in task.values())==4598259
 types=[]
 for region,sel in [('Global',np.ones(len(ids),bool))]+[(str(c),st.continent.astype(str).eq(str(c)).to_numpy()) for c in sorted(st.continent.astype(str).unique())]:
  total=int((~obs[sel]).sum())
  for typ,m in task.items():types.append({'region':region,'type':typ,'archive_stations':int(sel.sum()),'stations_with_gap':int(m[sel].any(1).sum()),'missing_months':int(m[sel].sum()),'all_missing_months':total,'percent_of_all_missing':100*int(m[sel].sum())/total if total else np.nan})
 pd.DataFrame(types).to_csv(HERE/'full_missing_by_type_and_region.csv',index=False)
 rawids=np.load(CODE/'recoverability/ids.npy',allow_pickle=True).astype(str);ix={s:i for i,s in enumerate(rawids)}
 raw=np.memmap(CODE/'recoverability/Z.mm',dtype='float32',mode='r',shape=(len(rawids),432))
 rows=[]
 for j in np.flatnonzero(last<431):
  e=st.iloc[j];end=int(last[j])+1;gapn=432-end;alln=int(obs[j].sum());ridx=ix[ids[j]]
  for window,width in [('all_visible',432),('H36',36),('H60',60)]:
   start=0 if window=='all_visible' else max(0,end-width);ii=np.arange(start,end);vis=ii[obs[j,ii]];cc=np.bincount(vis%12,minlength=12)
   r={'station_id':ids[j],'raw_index':ridx,'continent':e.continent,'country':e.country,'latitude':e.latitude,'longitude':e.longitude,
      'window':window,'history_start_index':start,'history_end_exclusive':end,'history_span_months':end-start,'history_observed_months':int(cc.sum()),
      'all_visible_observed_months':alln,'all_visible_history_band':histband(alln),'history_observation_band':histband(int(cc.sum())),
      'first_observation_index':int(first[j]),'last_observation_index':int(last[j]),'forward_missing_months':gapn,
      'missing_calendars':int((cc==0).sum()),'missing_calendar_band':band(int((cc==0).sum())),'once_observed_calendars':int((cc==1).sum()),'repeated_calendars':int((cc>=2).sum()),
      'negative_history_observations':int((raw[ridx,vis]<0).sum())}
   for m in range(12):r[f'calendar_{m+1:02}_count']=int(cc[m])
   for name,a,b in PERIODS:r['gap_months_'+name]=max(0,b-max(end,a))
   rows.append(r)
 d=pd.DataFrame(rows);assert len(d)==19418*3
 d.to_csv(HERE/'forward_station_history_calendar.csv.gz',index=False,compression='gzip')
 assert all(d.groupby('window').forward_missing_months.sum()==2612522)
 allreg=[];alldec=[];repeats=[]
 for region,z in [('Global',d)]+[(str(c),d[d.continent.astype(str).eq(str(c))]) for c in sorted(d.continent.astype(str).unique())]:
  for window,q in z.groupby('window',sort=False):
   denm=int(q.forward_missing_months.sum());dens=len(q)
   for b in CAL_BANDS:
    sub=q[q.missing_calendar_band.eq(b)]
    allreg.append(dict(region=region,window=window,missing_calendar_band=b,stations=len(sub),station_denominator=dens,station_percent=100*len(sub)/dens if dens else np.nan,forward_missing_months=int(sub.forward_missing_months.sum()),month_denominator=denm,month_percent=100*sub.forward_missing_months.sum()/denm if denm else np.nan))
   for period,_,_ in PERIODS:
    col='gap_months_'+period;pm=int(q[col].sum());ps=int(q[col].gt(0).sum())
    for b in CAL_BANDS:
     sub=q[q.missing_calendar_band.eq(b)]
     alldec.append(dict(region=region,window=window,period=period,missing_calendar_band=b,stations=int(sub[col].gt(0).sum()),station_denominator=ps,forward_missing_months=int(sub[col].sum()),month_denominator=pm,month_percent=100*sub[col].sum()/pm if pm else np.nan))
   for m in range(12):
    cc=q[f'calendar_{m+1:02}_count']
    for label,sel in [('0',cc.eq(0)),('1',cc.eq(1)),('>=2',cc.ge(2))]:
     sub=q[sel];repeats.append(dict(region=region,window=window,calendar_month=m+1,observations=label,stations=len(sub),station_denominator=dens,station_percent=100*len(sub)/dens if dens else np.nan,forward_missing_months=int(sub.forward_missing_months.sum()),month_denominator=denm,month_percent=100*sub.forward_missing_months.sum()/denm if denm else np.nan))
 pd.DataFrame(allreg).to_csv(HERE/'calendar_structure_by_region.csv',index=False)
 pd.DataFrame(alldec).to_csv(HERE/'calendar_structure_by_decade.csv',index=False)
 pd.DataFrame(repeats).to_csv(HERE/'calendar_month_observation_frequency.csv',index=False)
 cross=d.groupby(['window','all_visible_history_band','missing_calendar_band'],dropna=False).agg(stations=('station_id','size'),forward_missing_months=('forward_missing_months','sum')).reset_index()
 cross.to_csv(HERE/'history_length_vs_season_coverage.csv',index=False)
 paired=d.pivot(index='station_id',columns='window',values='missing_calendars').join(d[d.window.eq('all_visible')].set_index('station_id')[['continent','forward_missing_months','all_visible_observed_months']])
 changes=[]
 for window in ['H36','H60']:
  for label,sel in [('missing_only_due_to_window',paired.all_visible.eq(0)&paired[window].gt(0)),('missing_in_archive_and_window',paired.all_visible.gt(0)),('complete_in_both',paired[window].eq(0))]:
   q=paired[sel];changes.append(dict(window=window,condition=label,stations=len(q),forward_missing_months=int(q.forward_missing_months.sum()),station_denominator=19418,month_denominator=2612522,month_percent=100*q.forward_missing_months.sum()/2612522))
 pd.DataFrame(changes).to_csv(HERE/'archive_vs_limited_window.csv',index=False)
 summaries=pd.DataFrame(allreg);summaries=summaries[summaries.region.eq('Global')]
 js(HERE/'CALENDAR_COMPLETE.json',{'status':'COMPLETE','stations':24934,'forward_stations':19418,'forward_missing_months':2612522,'history_rows':len(d),'seconds':time.time()-t0,'protocol_sha256':sha(HERE/'NATURAL_PROTOCOL.json'),'input_hashes_unchanged':all(sha(CODE/p)==v['sha256'] for p,v in pr['sources'].items())})
 print(summaries.to_string(index=False));print(pd.DataFrame(changes).to_string(index=False))

if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='register':register()
 else:main()
