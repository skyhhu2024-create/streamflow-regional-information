from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent
CODE=next(p for p in HERE.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np,pandas as pd
OLD=CODE/'V45/experiments/r3_global_single_condition_20261022'
m=np.load(OLD/'global_data/QC20_finite_mask.npy',mmap_mode='r')
roles=pd.read_csv(OLD/'design/all_station_roles.csv')
prev=pd.read_csv(OLD/'design/independent_target_cases.csv').set_index('raw_index')
cs=np.column_stack([np.zeros(len(m),dtype=int),np.cumsum(m,axis=1)])
anchors=np.arange(60,313)
complete=(cs[:,anchors+120]-cs[:,anchors-36])==156
twin=roles.twin_listed.astype(str).str.lower().eq('true').to_numpy()
rows=[]
for j in np.flatnonzero(complete.any(1)):
 a=anchors[complete[j]]
 oldstart=oldend=-1
 if j in prev.index:
  oldstart=int(prev.loc[j,'gap_start']);oldend=int(prev.loc[j,'gap_end'])
  a=a[(a+120<=oldstart)|(a>=oldend)]
 chosen=int(a[-1]) if len(a) else -1
 rows.append(dict(raw_index=int(j),station_id=roles.iloc[j].station_id,duplicate=bool(twin[j]),old_target=j in prev.index,old_gap_start=oldstart,old_gap_end=oldend,new_anchor=chosen,nonoverlap_candidates=len(a),continent=roles.iloc[j].continent))
df=pd.DataFrame(rows)
summary=dict(global_stations=len(m),H36_L120_qualified=len(df),duplicate_qualified=int(df.duplicate.sum()),nonduplicate_qualified=int((~df.duplicate).sum()),old_mothers_with_H36=int(df.old_target.sum()),old_mothers_nonoverlap=int((df.old_target&df.new_anchor.ge(0)&~df.duplicate).sum()),new_mothers_not_old=int((~df.old_target&~df.duplicate&df.new_anchor.ge(0)).sum()),final_all=int((~df.duplicate&df.new_anchor.ge(0)).sum()),final_continents=df.loc[~df.duplicate&df.new_anchor.ge(0),'continent'].value_counts().to_dict(),mask_only=True)
HERE.mkdir(parents=True,exist_ok=True)
df.to_csv(HERE/'mask_only_candidate_ledger.csv',index=False)
(HERE/'PREFLIGHT.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
