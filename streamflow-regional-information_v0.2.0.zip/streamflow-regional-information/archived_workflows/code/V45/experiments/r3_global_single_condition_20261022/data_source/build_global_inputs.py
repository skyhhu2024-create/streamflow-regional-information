"""All30959 native GSIM rows; raw/QC20 availability only, no target-role filter."""
from pathlib import Path
import os,sys,json,hashlib,time,re,warnings,argparse
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime,timezone
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
sys.dont_write_bytecode=True
import numpy as np
import pandas as pd
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;OUT=ROOT/'global_data'
CODE=next(p for p in HERE.parents if p.name=='code')
sys.path.insert(0,str(CODE))
from src.data.gsim_io import read_series
from src.data.dedup_gsim import load_twin_ids
SERIES=CODE/'GSIM_indices/GSIM_indices/TIMESERIES/monthly'
PRIOR=CODE/'boundary_validation_20260922/data/input_file_manifest.csv'
DATES=pd.date_range('1980-01-01','2015-12-01',freq='MS')
CUTOFF=np.arange(60,313,dtype=np.int16)

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()

def js(p,o):Path(p).write_text(json.dumps(o,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')

def get_inputs():
 prior=pd.read_csv(PRIOR);prior=prior[prior.role.eq('raw_monthly')].copy()
 files=sorted(SERIES.glob('*.mon'))
 assert len(files)==len(prior)==30959
 lookup=prior.set_index('path').to_dict('index')
 rows=[]
 for i,p in enumerate(files):
  rel=p.relative_to(CODE).as_posix();assert rel in lookup
  rows.append((i,str(p),lookup[rel]['sha256'],int(lookup[rel]['bytes'])))
 assert len({Path(p).stem for _,p,_,_ in rows})==30959
 return rows

def parse_station(entry):
 i,filename,expected_hash,expected_bytes=entry;p=Path(filename);before=p.stat()
 digest=sha(p)
 assert before.st_size==expected_bytes and digest==expected_hash,'Raw source differs from prior byte manifest: '+str(p)
 with warnings.catch_warnings(record=True) as caught:
  warnings.simplefilter('always')
  raw=read_series(str(p),min_days_available=0).reindex(DATES).to_numpy(dtype=np.float64)
  qc=read_series(str(p),min_days_available=20).reindex(DATES).to_numpy(dtype=np.float64)
 assert raw.shape==qc.shape==(432,)
 header={};column_present=False
 with p.open('r',encoding='utf8',errors='ignore') as f:
  for line in f:
   if line.startswith('#') and ':' in line:
    a=line.lstrip('#').split(':');header[a[0].strip()]=a[1].strip()
   s=line.strip().lower().replace('"','').replace('\t','')
   if s.startswith('date,'):
    column_present='n.available' in re.sub(r'[\s\"]','',line);break
 after=p.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
 sid=p.stem;hid=header.get('gsim.no','');assert not hid or hid==sid
 meta={'row_index':i,'station_id':sid,'source_file':p.relative_to(CODE).as_posix(),'source_bytes':before.st_size,'source_mtime_ns':before.st_mtime_ns,'source_sha256':digest,'matches_frozen_raw_manifest':True,'n_available_column_present':column_present,'parser_warning_count':len(caught),'header_country':header.get('country',''),'header_latitude':header.get('latitude',''),'header_longitude':header.get('longitude',''),'header_river':header.get('river',''),'header_station':header.get('station',''),'header_area':header.get('area','')}
 return i,raw,qc,meta

def complete_windows(mask):
 c=np.concatenate([np.zeros((len(mask),1),np.int16),np.cumsum(mask,axis=1,dtype=np.int16)],axis=1)
 h=(c[:,CUTOFF]-c[:,CUTOFF-60])==60
 g=(c[:,CUTOFF+120]-c[:,CUTOFF])==120
 return h,g,h&g

def signature(q):
 finite=np.isfinite(q);negative=finite&(q<0)
 n=finite.sum(1);minimum=np.min(np.where(finite,q,np.inf),axis=1);maximum=np.max(np.where(finite,q,-np.inf),axis=1)
 constant=(n>=2)&(minimum==maximum)
 return finite,negative,{'n_finite':n,'n_negative':negative.sum(1),'n_above100000':(finite&(q>100000)).sum(1),'constant_Q_defined':n>=2,'constant_Q':constant,'Q_min':np.where(n>0,minimum,np.nan),'Q_max':np.where(n>0,maximum,np.nan)}

def register(entries):
 inputs=[Path(__file__),CODE/'src/data/gsim_io.py',CODE/'src/data/dedup_gsim.py',PRIOR,CODE/'gsim_near_duplicates_checked.csv',CODE/'global_station_meta_kg.csv']
 path=HERE/'INPUT_PRODUCTION_REGISTERED.json'
 state={'status':'ALL30959_INPUT_ONLY_PARSE_RULES_REGISTERED_BEFORE_MAIN_PRODUCTION','created_utc':datetime.now(timezone.utc).isoformat(),'source_rows':30959,'dates':['1980-01-01','2015-12-01'],'matrix_shape_station_month':[30959,432],'dtype':'float64','authoritative_parser':'src.data.gsim_io.read_series called separately with min_days_available 0 and20','no_whole_archive_minimum_observation_gate':True,'no_old_target_test_or_reference_role_used':True,'negative_and_constant_only_marked':True,'no_value_clipping_or_scale_transform':True,'twin_ids_retained_and_only_marked':True,'all_cutoffs':list(map(int,CUTOFF)),'eligibility':'Each of60history and120gap months finite in same raw/QC20 mask; all253calendar cutoffs enumerated; no anchor selected','source_and_code_hashes':{str(p):sha(p) for p in inputs}}
 if path.exists():
  old=json.loads(path.read_text(encoding='utf8'));assert old['source_and_code_hashes']==state['source_and_code_hashes']
 else:js(path,state)
 return state

def run(workers):
 start=time.time();OUT.mkdir(parents=True,exist_ok=True)
 assert not (OUT/'GLOBAL_INPUTS_FROZEN.json').exists(),'Frozen output exists; no overwrite'
 assert not (OUT/'raw_Q.npy').exists() and not (OUT/'QC20_Q.npy').exists(),'Preserve partial outputs; do not silently restart'
 entries=get_inputs();reg=register(entries)
 raw=np.lib.format.open_memmap(OUT/'raw_Q.npy',mode='w+',dtype=np.float64,shape=(30959,432));qc=np.lib.format.open_memmap(OUT/'QC20_Q.npy',mode='w+',dtype=np.float64,shape=(30959,432))
 metadata=[]
 with ProcessPoolExecutor(max_workers=workers) as pool:
  for n,(i,a,b,m) in enumerate(pool.map(parse_station,entries,chunksize=32),1):
   raw[i]=a;qc[i]=b;metadata.append(m)
   if n%3000==0:print(f'Parsed {n}/30959; {time.time()-start:.1f}s',flush=True)
 raw.flush();qc.flush();meta=pd.DataFrame(metadata).sort_values('row_index').reset_index(drop=True)
 assert np.array_equal(meta.row_index.to_numpy(),np.arange(30959))
 ids=meta.station_id.astype(str).to_numpy(dtype=str)
 np.save(OUT/'station_ids.npy',ids,allow_pickle=False);np.save(OUT/'dates.npy',DATES.to_numpy(dtype='datetime64[D]'),allow_pickle=False)
 twins=load_twin_ids(str(CODE/'gsim_near_duplicates_checked.csv'))
 meta['twin_listed']=meta.station_id.isin(twins)
 geo=pd.read_csv(CODE/'global_station_meta_kg.csv').drop_duplicates('gsim.no').set_index('gsim.no').reindex(ids)
 for col in ['latitude','longitude','continent','country','climate_id','kg_major','kg_code']:
  if col in geo:meta[col]=geo[col].to_numpy()
 for col in ['latitude','longitude']:
  if col in meta:meta[col]=meta[col].fillna(pd.to_numeric(meta['header_'+col],errors='coerce'))
 masks={};windows={};summaries={};cutoff_rows=[]
 for name,q in [('raw',raw),('QC20',qc)]:
  finite,negative,stats=signature(q);np.save(OUT/f'{name}_finite_mask.npy',finite,allow_pickle=False);np.save(OUT/f'{name}_negative_mask.npy',negative,allow_pickle=False)
  for col,values in stats.items():meta[name+'_'+col]=values
  h,g,both=complete_windows(finite);windows[name+'_history_complete']=h;windows[name+'_gap_complete']=g;windows[name+'_joint_complete']=both
  meta[name+'_H060_complete_cutoff_count']=h.sum(1);meta[name+'_L120_complete_cutoff_count']=g.sum(1);meta[name+'_H060_L120_joint_cutoff_count']=both.sum(1)
  # These are marked sensitivities only; negative values remain available in main masks.
  _,_,nonnegative=complete_windows(finite&~negative)
  meta[name+'_joint_nonnegative_cutoff_count']=nonnegative.sum(1)
  summaries[name]={'all_station_rows':30959,'stations_any_finite':int(finite.any(1).sum()),'finite_months':int(finite.sum()),'stations_any_negative':int(negative.any(1).sum()),'negative_months':int(negative.sum()),'constant_Q_stations':int(stats['constant_Q'].sum()),'stations_with_any_complete_H60':int(h.any(1).sum()),'stations_with_any_complete_L120':int(g.any(1).sum()),'stations_with_any_joint_complete_window':int(both.any(1).sum()),'joint_station_cutoff_pairs':int(both.sum()),'joint_complete_twin_listed_stations':int((both.any(1)&meta.twin_listed.to_numpy()).sum()),'joint_complete_nonnegative_sensitivity_stations':int(nonnegative.any(1).sum()),'negative_not_used_as_main_eligibility_filter':True}
  for k,c in enumerate(CUTOFF):cutoff_rows.append({'domain':name,'cutoff_index':int(c),'gap_start':str(DATES[c].date()),'history_start':str(DATES[c-60].date()),'gap_end_inclusive':str(DATES[c+119].date()),'history_complete_stations':int(h[:,k].sum()),'gap_complete_stations':int(g[:,k].sum()),'joint_complete_stations':int(both[:,k].sum())})
 np.savez_compressed(OUT/'availability_H060_L120_forward.npz',cutoff_index=CUTOFF,**windows)
 meta['QC20_removed_finite_months']=(np.isfinite(raw)&~np.isfinite(qc)).sum(1)
 meta.to_csv(OUT/'station_metadata.csv',index=False,encoding='utf-8-sig')
 manifest_cols=['row_index','station_id','source_file','source_bytes','source_mtime_ns','source_sha256','matches_frozen_raw_manifest','n_available_column_present','parser_warning_count']
 meta[manifest_cols].to_csv(OUT/'source_file_manifest.csv',index=False,encoding='utf-8-sig')
 pd.DataFrame(cutoff_rows).to_csv(OUT/'availability_by_cutoff.csv',index=False,encoding='utf-8-sig')
 summary={'status':'ALL30959_AVAILABILITY_CENSUS_NO_ROLE_OR_ANCHOR_SELECTION','domains':summaries,'n_cutoffs':253,'source_file_hashes_all_match_previous_frozen_raw_manifest':bool(meta.matches_frozen_raw_manifest.all()),'n_available_column_missing_stations':int((~meta.n_available_column_present).sum()),'twin_listed_retained_rows':int(meta.twin_listed.sum()),'raw_inf_cells':int(np.isinf(raw).sum()),'QC20_inf_cells':int(np.isinf(qc).sum()),'raw_global_max':float(np.nanmax(raw)),'QC20_global_max':float(np.nanmax(qc)),'Q_above100000_retained':True,'source_normalization_or_model_fit_performed':False,'no_anchor_or_targets_sources_split_selected':True,'elapsed_seconds':time.time()-start}
 js(OUT/'AVAILABILITY_CENSUS.json',summary)
 schema={'arrays':{'raw_Q.npy':'float64[30959,432], original native MEAN values incl negative; no QC20/no minimum-month gate','QC20_Q.npy':'float64[30959,432], same IDs; native n.available>=20 when field exists','station_ids.npy':'Unicode[30959], sorted original .mon filename IDs; no implicit twins deletion','dates.npy':'datetime64[D][432], month starts','raw_finite_mask.npy':'bool[30959,432]','QC20_finite_mask.npy':'bool[30959,432]','raw_negative_mask.npy':'bool[30959,432]','QC20_negative_mask.npy':'bool[30959,432]'},'window_file':'availability_H060_L120_forward.npz','window_keys':{'cutoff_index':'int16[253],60..312','raw_history_complete':'bool[30959,253]','raw_gap_complete':'bool[30959,253]','raw_joint_complete':'bool[30959,253]','QC20_history_complete':'bool[30959,253]','QC20_gap_complete':'bool[30959,253]','QC20_joint_complete':'bool[30959,253]'},'metadata':'station_metadata.csv includes row_index, station_id, full source/header metadata, twin flags, raw/QC20 availability and constant/negative audit flags','scope':'Window presence only; no DAT sigma/truth variance or reference qualification filter, no performance screen, no fixed anchor/role split','old_QC_comparison':'QC20_Q matches native parser precision float64; cast to float32 before comparing old float32 benchmark cache'}
 js(OUT/'DATA_SCHEMA.json',schema)
 del raw,qc
 files={str(p.relative_to(ROOT)):sha(p) for p in sorted(OUT.iterdir()) if p.is_file()}
 assert all(sha(Path(p))==h for p,h in reg['source_and_code_hashes'].items())
 frozen={'status':'ALL30959_NATIVE_RAW_AND_QC20_INPUTS_AND_ALL253_FORWARD_WINDOWS_FROZEN_NO_ANCHOR_SELECTED','created_utc':datetime.now(timezone.utc).isoformat(),'n_stations':30959,'n_months':432,'n_cutoffs':253,'source_manifest_file':'global_data/source_file_manifest.csv','source_file_hashes_verified_all30959':True,'code_registration_sha256':sha(HERE/'INPUT_PRODUCTION_REGISTERED.json'),'files':files,'source_and_code_hashes':reg['source_and_code_hashes'],'summary':summary,'old_data_unchanged':True,'no_model_fit_no_score_no_target_role_selection':True}
 js(OUT/'GLOBAL_INPUTS_FROZEN.json',frozen)
 print(json.dumps({'status':frozen['status'],'freeze_sha256':sha(OUT/'GLOBAL_INPUTS_FROZEN.json'),'summary':summary},ensure_ascii=False),flush=True)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=12);args=ap.parse_args();run(args.workers)
