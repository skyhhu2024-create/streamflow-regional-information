from pathlib import Path
import sys,json,hashlib,warnings
ROOT=Path(__file__).resolve().parent
CODE=next(p for p in ROOT.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd
warnings.filterwarnings('ignore',category=RuntimeWarning)
OLD=CODE/'V42.3/experiments/grdc_tuopu_screen_20261015'
INV=CODE/'V45/experiments/r4_external_information_20261024/grdc_inventory'
GLOBAL=CODE/'V45/experiments/r3_global_single_condition_20261022'
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def longest(mask):
 idx=np.flatnonzero(mask)
 return int(max(map(len,np.split(idx,np.flatnonzero(np.diff(idx)>1)+1)))) if len(idx) else 0
def date(i):
 return f'{1980+i//12:04d}-{i%12+1:02d}' if i>=0 else ''
roles=pd.read_csv(GLOBAL/'design/all_station_roles.csv')
ids=roles.station_id.astype(str).to_numpy();lookup={s:i for i,s in enumerate(ids)}
raw=np.load(GLOBAL/'global_data/raw_Q.npy',mmap_mode='r')
qc=np.load(GLOBAL/'global_data/QC20_Q.npy',mmap_mode='r')
assert raw.shape==qc.shape==(len(ids),432)
cross=pd.read_csv(OLD/'station_identity_crosswalk.csv')
confirmed=cross[cross.identity_status.eq('confirmed')].drop_duplicates(['GSIM_id','GRDC_id']).copy()
assert not confirmed.GSIM_id.duplicated().any()
readiness=pd.read_csv(INV/'conservative_GRDC_source_role_readiness.csv').set_index('GSIM_id')
opp=pd.read_csv(OLD/'matched_station_opportunities.csv').set_index('GSIM_id')
mon=pd.read_csv(OLD/'monthly_valid_observations.csv.gz',parse_dates=['date'])
bad=pd.read_csv(OLD/'processed_native_GRDC_unit_review.csv')
mon=mon[mon.Flag.eq(100)&mon.Calculated.notna()&mon.Calculated.ge(0)&~mon.source_key.isin(bad.source_key)].copy()
assert (mon.groupby(['GRDC_id','date']).Calculated.nunique()<=1).all()
mon=mon.drop_duplicates(['GRDC_id','date']);mon['month']=(mon.date.dt.year-1980)*12+mon.date.dt.month-1
mon=mon[mon.month.between(0,431)]
precip=pd.read_csv(CODE/'V45/experiments/r4_global_information_20261025/final_inputs/global8898_precipitation_admission_ledger.csv').set_index('station_id')
twins=pd.read_csv(CODE/'gsim_near_duplicates_checked.csv');adj={}
for t in twins[twins.twin.astype(str).str.lower().eq('true')].itertuples():
 adj.setdefault(t.a,set()).add(t.b);adj.setdefault(t.b,set()).add(t.a)
rows=[];values=[];aliases=[]
for e in confirmed.sort_values('GSIM_id').itertuples():
 if e.GSIM_id not in lookup:continue
 sid=e.GSIM_id;i=lookup[sid];meta=roles.iloc[i]
 q=np.asarray(raw[i]);obs=np.flatnonzero(np.isfinite(q));anchor=int(obs[-1]+1) if len(obs) else -1
 tier='identity_only_not_old_overlap_compatible'
 if sid in readiness.index:tier='primary596_area_comparable' if bool(readiness.loc[sid,'area_comparable']) else 'secondary211_missing_area'
 v=np.full(432,np.nan);z=mon[mon.GRDC_id.eq(e.GRDC_id)];v[z.month.to_numpy(int)]=z.Calculated.to_numpy(float)
 h=np.arange(anchor-60,anchor) if anchor>=60 else np.arange(max(0,anchor-60),max(anchor,0))
 g=np.arange(anchor,min(anchor+120,432)) if anchor>=0 and anchor<432 else np.array([],int)
 gh=np.isfinite(v[g]);wholeG=anchor>=60 and anchor+120<=432
 hq=np.asarray(qc[i,h]);valid=np.isfinite(hq)&(hq>=0)
 counts=np.array([np.sum(valid&(h%12==m)) for m in range(12)])
 x=np.full(len(h),np.nan);x[valid]=np.log1p(hq[valid]);cl=np.array([np.nanmean(x[h%12==m]) for m in range(12)])
 sd=float(np.nanstd(x-cl[h%12])) if len(h) else np.nan
 estim=bool(len(h)==60 and valid.all() and np.isfinite(cl).all() and np.isfinite(sd) and sd>1e-12)
 comp={sid};todo=[sid]
 while todo:
  for n in adj.get(todo.pop(),()):
   if n not in comp:comp.add(n);todo.append(n)
 # Include all formally confirmed GSIM IDs tied to this GRDC physical ID.
 comp.update(confirmed.loc[confirmed.GRDC_id.eq(e.GRDC_id),'GSIM_id'])
 for a in sorted(comp):
  if a in lookup:aliases.append(dict(station_id=sid,excluded_station_id=a,excluded_raw_index=lookup[a],reason='target_itself' if a==sid else 'known_twin_component_or_confirmed_same_GRDC_ID'))
 rr=dict(station_id=sid,raw_index=i,GRDC_id=int(e.GRDC_id),identity_tier=tier,country=str(meta.country),continent=str(meta.continent),latitude=float(meta.latitude),longitude=float(meta.longitude),outer_fold=int(meta.outer_fold),spatial_cell=str(meta.spatial_cell),identifier_link=e.identifier_link,native_file=e.native_file,source_sha256=e.source_sha256,GSIM_first_month=date(int(obs[0])) if len(obs) else '',GSIM_last_month=date(anchor-1),anchor=anchor,history_start=anchor-60,history_end=anchor,gap_start=anchor,gap_end=anchor+120,complete_H60_G120_window=wholeG,raw_H_valid_months=int(np.isfinite(q[h]).sum()),QC20_H_nonnegative_months=int(valid.sum()),QC20_H_all60_nonnegative=bool(len(h)==60 and valid.all()),H_calendar_months_represented=int((counts>0).sum()),H_min_per_calendar_month=int(counts.min()),H_anomaly_sd=sd,target_estimable_fixed_rule=estim,GRDC_natural_forward_months=int(np.isfinite(v[anchor:]).sum()) if anchor>=0 else 0,GRDC_first120_valid_months=int(gh.sum()),GRDC_first120_longest_run=longest(gh),GRDC_first120_all_valid=bool(len(g)==120 and gh.all()),GRDC_first120_from_anchor_consecutive=int(next((j for j,t in enumerate(gh) if not t),len(gh))),in_global8898_precip_ledger=sid in precip.index,all435_precipitation_complete=False,precipitation_admitted=False,precipitation_geometry_warning=None,known_identity_exclusion_count=len(comp),has_any_natural_gap_truth=bool(np.any(np.isfinite(v)&~np.isfinite(q))))
 if sid in precip.index:
  p=precip.loc[sid];rr.update(all435_precipitation_complete=bool(p.all435_precipitation_complete),precipitation_admitted=bool(p.admission_mask),precipitation_geometry_warning=bool(p.geometry_warning))
 tm=g[gh]
 rr.update(GRDC_first120_first_truth=date(int(tm[0])) if len(tm) else '',GRDC_first120_last_truth=date(int(tm[-1])) if len(tm) else '',GRDC_first120_calendar_months_represented=int(len(np.unique(tm%12))),raw_H_all60_finite=bool(len(h)==60 and np.isfinite(q[h]).all()),raw_H_nonnegative_months=int(np.sum(np.isfinite(q[h])&(q[h]>=0))))
 rows.append(rr);values.append(v)
df=pd.DataFrame(rows);df.to_csv(ROOT/'all_confirmed_identity_forward_census.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(aliases).to_csv(ROOT/'target_same_identity_source_exclusions.csv',index=False,encoding='utf-8-sig')
np.savez_compressed(ROOT/'confirmed_GRDC_truth_values_NOT_INPUT.npz',station_ids=df.station_id.to_numpy(str),grdc_ids=df.GRDC_id.to_numpy(int),raw_indices=df.raw_index.to_numpy(int),Q_m3s=np.stack(values),month_index=np.arange(432))
out=[]
for tier in ['primary596_area_comparable','secondary211_missing_area','identity_only_not_old_overlap_compatible']:
 d=df[df.identity_tier.eq(tier)]
 for n in [120,60,36,24]:
  for metric in ['valid_months','longest_run','from_anchor_consecutive']:
   f=d[d.complete_H60_G120_window & (d['GRDC_first120_'+metric]>=n)]
   out.append(dict(tier=tier,required_GRDC_months=n,availability_metric=metric,targets=len(f),H60_complete_estimable=int(f.target_estimable_fixed_rule.sum()),precip_admitted=int(f.precipitation_admitted.sum()),H60_estimable_and_precip=int((f.target_estimable_fixed_rule&f.precipitation_admitted).sum()),countries=json.dumps(f.country.value_counts().to_dict()),continents=json.dumps(f.continent.value_counts().to_dict())))
summary=pd.DataFrame(out);summary.to_csv(ROOT/'forward_H60_G120_threshold_census.csv',index=False,encoding='utf-8-sig')
print(summary.to_string(index=False))
print('tier_counts',df.identity_tier.value_counts().to_dict())
case=df[df.identity_tier.eq('primary596_area_comparable')&df.complete_H60_G120_window&df.GRDC_first120_valid_months.ge(24)].copy()
exc=pd.DataFrame(aliases)
case['all_same_station_exclusion_raw_indices']=case.station_id.map(exc.groupby('station_id').excluded_raw_index.apply(lambda x:json.dumps(sorted(set(map(int,x))))))
case['all_same_station_exclusion_ids']=case.station_id.map(exc.groupby('station_id').excluded_station_id.apply(lambda x:json.dumps(sorted(set(x)))))
case['primary_exact_H60_G120_complete_truth']=case.target_estimable_fixed_rule & case.GRDC_first120_all_valid
case['supplementary_partial_G_truth']=~case.GRDC_first120_all_valid
case.insert(0,'row',np.arange(len(case)))
case.to_csv(ROOT/'cases.csv',index=False,encoding='utf-8-sig')
vmap={s:v for s,v in zip(df.station_id,values)}
truth=np.stack([vmap[e.station_id][e.gap_start:e.gap_end] for e in case.itertuples()])
months=np.stack([np.arange(e.gap_start,e.gap_end) for e in case.itertuples()])
np.savez_compressed(ROOT/'evaluation_truth.npz',station_ids=case.station_id.to_numpy(str),GRDC_ids=case.GRDC_id.to_numpy(int),raw_indices=case.raw_index.to_numpy(int),values=truth,mask=np.isfinite(truth),month_indices=months)
stages=[]
for tier in df.identity_tier.unique():
 d=df[df.identity_tier.eq(tier)]
 for label,mask in [
  ('all_identity_in_tier',np.ones(len(d),bool)),
  ('any_original_GSIM_missing_truth',d.has_any_natural_gap_truth),
  ('any_natural_forward_truth_1980_2015',d.GRDC_natural_forward_months.gt(0)),
  ('H60_and_G120_calendar_within_1980_2015',d.complete_H60_G120_window),
  ('H60_G120_and_any_G_truth',d.complete_H60_G120_window&d.GRDC_first120_valid_months.gt(0)),
  ('H60_G120_and_at_least24_G_truth',d.complete_H60_G120_window&d.GRDC_first120_valid_months.ge(24)),
  ('H60_G120_and_complete120_G_truth',d.complete_H60_G120_window&d.GRDC_first120_all_valid),
 ]:
  f=d.loc[mask]
  stages.append(dict(tier=tier,stage=label,targets=len(f),countries=json.dumps(f.country.value_counts().to_dict()),continents=json.dumps(f.continent.value_counts().to_dict())))
pd.DataFrame(stages).to_csv(ROOT/'sample_flow_by_identity_tier.csv',index=False,encoding='utf-8-sig')
files=[GLOBAL/'design/all_station_roles.csv',GLOBAL/'global_data/raw_Q.npy',GLOBAL/'global_data/QC20_Q.npy',OLD/'station_identity_crosswalk.csv',OLD/'monthly_valid_observations.csv.gz',OLD/'processed_native_GRDC_unit_review.csv',OLD/'matched_station_opportunities.csv',INV/'conservative_GRDC_source_role_readiness.csv',CODE/'gsim_near_duplicates_checked.csv',CODE/'V45/experiments/r4_global_information_20261025/final_inputs/global8898_precipitation_admission_ledger.csv']
manifest={'status':'CENSUS_ONLY_NO_PREDICTION_OR_SCORING','target_records':len(df),'primary_identity_tier':596,'secondary_missing_area_tier':211,'identity_only_not_old_overlap_compatible':270,'natural_forward_definition':'month strictly after last finite RAW GSIM value, never after a QC-only deletion','H':60,'G':120,'calendar_window_rule':'H and G completely within 1980-2015; anchor fixed to first actual forward-missing month','cohort_min_truth_months':24,'cohort_size':len(case),'exact_H60_G120_complete_truth_size':int(case.primary_exact_H60_G120_complete_truth.sum()),'target_estimable_cohort_size':int(case.target_estimable_fixed_rule.sum()),'precipitation_directly_reusable_cohort_size':int(case.precipitation_admitted.sum()),'GRDC_quality':'Calculated>=0, Flag100, known m3/s units; original-only and unresolved units excluded','truth_role':'Evaluation only; no GRDC values enter target H or source inputs','files':{str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in files},'native_case_files':{str(p):{'sha256':sha(p),'matches_prior':sha(p)==h} for p,h in zip(case.native_file,case.source_sha256)},'outputs':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in ROOT.glob('*') if p.is_file() and p.name!='CENSUS_COMPLETE.json'}}
assert all(v['matches_prior'] for v in manifest['native_case_files'].values())
(ROOT/'CENSUS_COMPLETE.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('cases',case.station_id.to_list(),'exact_primary',case.loc[case.primary_exact_H60_G120_complete_truth,'station_id'].to_list())
