from pathlib import Path
import sys,json,hashlib
R=Path(__file__).resolve().parent;C=next(p for p in R.parents if p.name=='code')
sys.path.insert(0,str(C/'V42/dependencies'))
import numpy as np
import pandas as pd
d=pd.read_csv(R/'all_confirmed_identity_forward_census.csv')
raw=np.load(C/'V45/experiments/r3_global_single_condition_20261022/global_data/raw_Q.npy',mmap_mode='r')
ids=pd.read_csv(C/'V45/experiments/r3_global_single_condition_20261022/design/all_station_roles.csv').station_id.astype(str).to_numpy();lookup={s:i for i,s in enumerate(ids)}
tw=pd.read_csv(C/'gsim_near_duplicates_checked.csv');adj={}
for e in tw[tw.twin.astype(str).str.lower().eq('true')].itertuples():
 adj.setdefault(e.a,set()).add(e.b);adj.setdefault(e.b,set()).add(e.a)
for _,g in d.groupby('GRDC_id'):
 nodes=list(g.station_id)
 for a in nodes:
  adj.setdefault(a,set()).update(nodes)
z=np.load(R/'confirmed_GRDC_truth_values_NOT_INPUT.npz',allow_pickle=False)
assert np.array_equal(z['station_ids'],d.station_id.to_numpy(str))
truth=np.isfinite(z['Q_m3s']);seenmask=np.zeros_like(truth);exclusions=[];out=[]
for j,e in enumerate(d.itertuples()):
 seen={e.station_id};todo=[e.station_id]
 while todo:
  for n in adj.get(todo.pop(),()):
   if n not in seen:seen.add(n);todo.append(n)
 ri=[lookup[s] for s in seen if s in lookup]
 for s in sorted(seen):
  if s in lookup:exclusions.append(dict(station_id=e.station_id,excluded_station_id=s,excluded_raw_index=lookup[s],reason='target_itself' if s==e.station_id else 'complete_known_twin_and_confirmed_same_GRDC_component'))
 seenmask[j]=np.isfinite(raw[ri]).any(axis=0)
 g=np.arange(max(0,e.anchor),min(e.anchor+120,432)) if e.anchor>=0 else np.array([],int)
 physical=truth[j,g]&~seenmask[j,g]
 out.append(dict(station_id=e.station_id,GRDC_id=e.GRDC_id,identity_tier=e.identity_tier,anchor=e.anchor,gap_end=min(e.anchor+120,432),G_calendar_months=len(g),GRDC_target_entry_missing_truth_months=int(truth[j,g].sum()),same_identity_raw_observed_G_months=int(seenmask[j,g].sum()),GRDC_truth_already_in_other_GSIM_identity_months=int(np.sum(truth[j,g]&seenmask[j,g])),GRDC_physical_all_GSIM_identities_missing_truth_months=int(physical.sum()),physical_missing_truth_calendar_months=int(len(np.unique(g[physical]%12))),all_same_station_exclusion_raw_indices=json.dumps(sorted(ri)),all_same_station_exclusion_ids=json.dumps(sorted(seen))))
p=pd.DataFrame(out);p.to_csv(R/'physical_identity_gap_audit.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(exclusions).to_csv(R/'complete_physical_identity_source_exclusions.csv',index=False,encoding='utf-8-sig')
np.savez_compressed(R/'physical_identity_observation_masks.npz',station_ids=d.station_id.to_numpy(str),raw_indices=d.raw_index.to_numpy(int),month_indices=np.arange(432),same_identity_GSIM_observed_mask=seenmask,GRDC_physical_missing_truth_mask=truth&~seenmask)
c=pd.read_csv(R/'cases.csv').station_id
t=pd.read_csv(R/'truncated_calendar_candidates_NOT_REGISTERED.csv').station_id
for label,s in [('full120_cohort5',c),('truncated_candidate141',t)]:
 f=p[p.station_id.isin(s)]
 print(label, 'n',len(f),'truthmonths',int(f.GRDC_target_entry_missing_truth_months.sum()),'physicaltruthmonths',int(f.GRDC_physical_all_GSIM_identities_missing_truth_months.sum()),'>=24',int(f.GRDC_physical_all_GSIM_identities_missing_truth_months.ge(24).sum()),'>=120',int(f.GRDC_physical_all_GSIM_identities_missing_truth_months.ge(120).sum()))
 print(f[f.station_id.isin(c)].to_string(index=False))
