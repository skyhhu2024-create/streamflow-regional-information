"""Score only after frozen predictions pass independent input/leakage QA."""
from pathlib import Path
import sys,json,hashlib,argparse,warnings
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
CODE=next(p for p in ROOT.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd
warnings.filterwarnings('ignore',category=RuntimeWarning)
METHODS=['ridge','rbf_ridge'];ARMS=['Q','QP','QP_Gclim'];MASKS=['physical_gap','entry_gap'];THRESHOLDS=[.6,.7,.8]
OUT=ROOT/'analysis_v2';B=2000;SEED=20261026
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for x in iter(lambda:f.read(4*1024*1024),b''):h.update(x)
 return h.hexdigest()
def clean(x):
 if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
 if isinstance(x,(list,tuple,np.ndarray)):return [clean(v) for v in x]
 if isinstance(x,np.generic):return clean(x.item())
 if isinstance(x,float) and not np.isfinite(x):return None
 return x
def js(p,x):Path(p).write_text(json.dumps(clean(x),ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
def register():
 plan=dict(status='PRE_SCORING_FIXED_PLAN',N=141,methods=METHODS,arms=ARMS,masks=MASKS,thresholds=THRESHOLDS,
  primary='raw monthly Pearson r>.7, >=24 fixed truth months, defined r, actual fit and >=1 reference-supported scored month; mother denominator141 retained',
  masks_definition='Physical-gap mask excludes every known same-identity GSIM observation. Entry-gap mask is separate sensitivity. Never drop a month because a particular prediction is bad or absent; any nonfinite output on fixed mask invalidates that case/method/arm.',
  failure_status='Keep short truth, constant truth or prediction, undefined correlation, nonfinite or negative truth/prediction, unestimable model, and no supported truth months separately; no threshold pass for these cases. Constant means exact equality/zero SST; no extra low-flow SD threshold is introduced in scoring.',
  numeric_pass='Report r threshold without fit/support gate separately; seasonal baseline uses numeric pass only and is never labelled reconstruction with reference support.',
  metrics='r; alpha=population SD(pred)/population SD(truth); delta=(mean(pred)-mean(truth))/population SD(truth); NSE; correlation after subtracting the same target-H raw calendar mean from truth and prediction. No clipping/replacing extreme scores. Also report supported truth-month fraction, threshold passes also passed by seasonal baseline, and paired r gain versus seasonal baseline; none changes primary admission.',
  continuous_pairs='Only jointly eligible cases and finite paired metric; retain all141 for binary pass accounting. Report paired valid n. alpha and delta gains mean reductions in abs(alpha-1) and abs(delta).',
  contrasts=['QP minus Q','QP minus QP_Gclim'],
  strata='all141, fixed H-estimable, P admitted, P actually used from H-fit flags, geometry clean/warning/unknown, fixed G length bins, exact120 entry/physical groups, continents and countries; no outcome-based strata',
  bootstrap=dict(replicates=B,seed=SEED,unit='frozen target 5degree spatial_cell',draw='resample all unique cells with replacement, carry all targets in each sampled cell; reuse identical draw weights for contrasts/strata',CI='percentile 2.5/97.5 for paired mean changes and percentage-point pass changes',minimum_reported_CI_targets=10,minimum_reported_CI_spatial_cells=5,small_groups='point estimates and denominator only; no stable-hotspot claim',multiple_comparisons='exploratory strata, no multiplicity-adjusted discovery claim'),
  global_scope='These are real-gap local matched GRDC cases of different forward lengths, not a population estimate or a matched performance comparison with the8898 H60/G120 experiment. Exact complete120 physical-gap truth group is empty.',
  gate='audit/PRE_SCORING_QA.json passed=true and hashes of prediction freeze/code inputs/cases/truth must match; prediction files and code-input hashes verified before truth values are loaded')
 js(HERE/'SCORING_PLAN.json',plan)
 paths=[Path(__file__),HERE/'SCORING_PLAN.json',ROOT/'census/registered_cases.csv',ROOT/'census/registered_evaluation_truth.npz',ROOT/'census/REGISTERED_CENSUS_COMPLETE.json']
 js(HERE/'SCORING_CODE_FROZEN.json',dict(files={str(p):sha(p) for p in paths},no_prediction_scores_read=True))
 print('SCORING_PLAN_AND_CODE_REGISTERED_NO_SCORES_READ',flush=True)

def correlation(a,b):
 if len(a)<2 or not np.isfinite(a).all() or not np.isfinite(b).all():return np.nan
 if np.all(a==a[0]) or np.all(b==b[0]):return np.nan
 ac=a-a.mean();bc=b-b.mean();den=float(np.sqrt((ac@ac)*(bc@bc)))
 return float(np.clip(ac@bc/den,-1,1)) if den>0 else np.nan

def score(y,p,mask,support,fit,months,rawcal,baseline=False):
 n=int(mask.sum());yy=np.asarray(y[mask],float);pp=np.asarray(p[mask],float)
 sup=int(np.sum(np.asarray(support,bool)[mask]));reasons=[]
 if n<24:reasons.append('less_than24_truth_months')
 truthfinite=bool(np.isfinite(yy).all());predfinite=bool(np.isfinite(pp).all())
 truthnonnegative=bool(np.all(yy>=0));prednonnegative=bool(np.all(pp>=0))
 if not truthfinite:reasons.append('nonfinite_truth_on_registered_mask')
 if not predfinite:reasons.append('nonfinite_prediction_on_fixed_truth_mask')
 if truthfinite and not truthnonnegative:reasons.append('negative_truth')
 if predfinite and not prednonnegative:reasons.append('negative_prediction')
 sd=float(np.std(yy)) if n and truthfinite else np.nan
 if n and truthfinite and np.all(yy==yy[0]):sd=0.
 if not np.isfinite(sd) or sd==0:reasons.append('constant_or_absent_truth')
 if n>=2 and predfinite and np.all(pp==pp[0]):reasons.append('constant_prediction')
 vals=dict(r=np.nan,alpha=np.nan,delta=np.nan,NSE=np.nan,H_deseasonal_r=np.nan)
 if n>=2 and truthfinite and predfinite and truthnonnegative and prednonnegative and sd>0:
  vals['r']=correlation(yy,pp);psd=0. if np.all(pp==pp[0]) else float(np.std(pp));vals['alpha']=psd/sd;vals['delta']=float((pp.mean()-yy.mean())/sd)
  vals['NSE']=float(1-np.sum((pp-yy)**2)/np.sum((yy-yy.mean())**2))
  bg=rawcal[np.asarray(months)[mask]%12]
  vals['H_deseasonal_r']=correlation(yy-bg,pp-bg)
 if not np.isfinite(vals['r']):reasons.append('undefined_r')
 numeric=bool(n>=24 and truthfinite and predfinite and truthnonnegative and prednonnegative and sd>0 and np.isfinite(vals['r']))
 if not baseline:
  if not fit:reasons.append('no_actual_fit')
  if sup==0:reasons.append('no_supported_truth_months')
 eligible=numeric if baseline else bool(numeric and fit and sup>0)
 return dict(truth_months=n,support_truth_months=sup,support_truth_fraction=sup/n if n else np.nan,actual_fit=bool(fit),all_fixed_mask_predictions_finite=predfinite,truth_nonnegative=truthnonnegative,prediction_nonnegative=prednonnegative,numeric_eligible=numeric,eligible=eligible,status='eligible' if eligible else ';'.join(reasons),**vals,
  **{f'pass_{str(t).replace(".","")}':bool(eligible and vals['r']>t) for t in THRESHOLDS},
  **{f'numeric_pass_{str(t).replace(".","")}':bool(numeric and vals['r']>t) for t in THRESHOLDS})

def gate():
 sc=json.loads((HERE/'SCORING_CODE_FROZEN.json').read_text(encoding='utf8'))
 assert all(sha(p)==h for p,h in sc['files'].items()),'scoring code/registered truth or cases changed'
 qa=json.loads((ROOT/'audit/PRE_SCORING_QA.json').read_text(encoding='utf8'));assert qa['passed'] is True
 checks={'prediction_freeze_sha256':ROOT/'predictions/PREDICTIONS_FROZEN.json','code_inputs_freeze_sha256':ROOT/'CODE_INPUTS_FROZEN.json','registered_cases_sha256':ROOT/'census/registered_cases.csv','evaluation_truth_sha256':ROOT/'census/registered_evaluation_truth.npz'}
 assert all(qa[k]==sha(p) for k,p in checks.items()),'QA bindings stale'
 pf=json.loads((ROOT/'predictions/PREDICTIONS_FROZEN.json').read_text(encoding='utf8'))
 assert all(sha(ROOT/'predictions'/p)==h for p,h in pf['files'].items()),'prediction file changed'
 cf=json.loads((ROOT/'CODE_INPUTS_FROZEN.json').read_text(encoding='utf8'))
 assert all(sha(p)==h for p,h in cf['files'].items()),'production input/code changed'
 return qa

def summarize(a,group,method,arm,mask,sel,cases):
 f=a.loc[sel];n=len(f);v=dict(group=group,method=method,arm=arm,mask=mask,n=n,spatial_cells=int(cases.loc[sel,'spatial_cell'].nunique()),eligible=int(f.eligible.sum()),numeric_eligible=int(f.numeric_eligible.sum()))
 for t in THRESHOLDS:
  s=str(t).replace('.','');v[f'pass_{s}']=int(f[f'pass_{s}'].sum());v[f'pass_{s}_percent']=100*v[f'pass_{s}']/n if n else np.nan
  v[f'numeric_pass_{s}']=int(f[f'numeric_pass_{s}'].sum())
  v[f'pass_{s}_also_seasonal_baseline']=int((f[f'pass_{s}']&f[f'seasonal_numeric_pass_{s}']).sum())
 for col in ['r','alpha','delta','NSE','H_deseasonal_r']:
  x=f.loc[f.eligible,col].to_numpy(float);x=x[np.isfinite(x)]
  v[col+'_valid_n']=len(x);v[col+'_median']=float(np.median(x)) if len(x) else np.nan;v[col+'_mean']=float(np.mean(x)) if len(x) else np.nan
 gain=f.loc[f.eligible,'r_gain_vs_seasonal_baseline'].to_numpy(float);gain=gain[np.isfinite(gain)]
 v['r_gain_vs_seasonal_baseline_valid_n']=len(gain);v['r_gain_vs_seasonal_baseline_median']=float(np.median(gain)) if len(gain) else np.nan
 v['supported_truth_months']=int(f.support_truth_months.sum());v['truth_months']=int(f.truth_months.sum())
 return v

def run():
 qa=gate();assert not (OUT/'ANALYSIS_COMPLETE.json').exists(),'preserve completed analysis; new version required'
 OUT.mkdir(exist_ok=True)
 c=pd.read_csv(ROOT/'census/registered_cases.csv');assert len(c)==141
 tr=np.load(ROOT/'census/registered_evaluation_truth.npz',allow_pickle=False)
 assert np.array_equal(c.station_id.to_numpy(str),tr['station_ids'].astype(str))
 adm=pd.read_csv(ROOT/'inputs_precip/admission.csv').set_index('station_id')
 assert set(c.station_id)==set(adm.index)
 masks={'physical_gap':tr['true_physical_gap_mask']&tr['mask'],'entry_gap':tr['mask']}
 rows=[];metadata=[]
 for i,e in enumerate(c.itertuples()):
  z=np.load(ROOT/'predictions/cases'/f'{i:04d}.npz',allow_pickle=False);L=int(e.L)
  assert np.array_equal(z['gap_months'],tr['month_indices'][i,:L])
  assert np.all(tr['month_indices'][i,L:]==-1)
  assert np.array_equal(np.isfinite(z['predictions'][:,:,L:]),np.zeros((2,3,120-L),bool))
  a=adm.loc[e.station_id]
  warning=a.get('geometry_warning',None)
  geo='unknown' if pd.isna(warning) else ('warning' if str(warning).lower()=='true' or warning==1 else 'clean')
  metadata.append(dict(row=i,station_id=e.station_id,p_available=bool(z['p_available']),geometry_group=geo,Q_source_count=int(z['source_qualified_count']),target_estimable=bool(z['target_estimable']),**{f'{m}_P_actually_used':bool(z['flags'][mi,1,4]) for mi,m in enumerate(METHODS)}))
  for maskname,maskarr in masks.items():
   mask=maskarr[i];y=tr['values'][i];months=tr['month_indices'][i];rawcal=z['target_H_raw_calendar']
   for mi,m in enumerate(METHODS):
    for ai,arm in enumerate(ARMS):
     rec=score(y,z['predictions'][mi,ai],mask,z['support'][mi,ai],bool(z['flags'][mi,ai,0]),months,rawcal)
     rows.append(dict(row=i,station_id=e.station_id,method=m,arm=arm,mask=maskname,**rec))
   base=np.full(120,np.nan);base[:L]=z['baseline']
   rec=score(y,base,mask,np.zeros(120,bool),False,months,rawcal,baseline=True)
   rows.append(dict(row=i,station_id=e.station_id,method='seasonal',arm='baseline',mask=maskname,**rec))
  z.close()
 scores=pd.DataFrame(rows);meta=pd.DataFrame(metadata);scores=scores.merge(c[['row','country','continent','spatial_cell','L','target_estimable_fixed_rule']],on='row',validate='many_to_one')
 bs=scores[scores.method.eq('seasonal')][['row','mask','r']+[f'numeric_pass_{str(t).replace(".","")}' for t in THRESHOLDS]].copy()
 bs=bs.rename(columns={'r':'seasonal_baseline_r',**{f'numeric_pass_{str(t).replace(".","")}':f'seasonal_numeric_pass_{str(t).replace(".","")}' for t in THRESHOLDS}})
 scores=scores.merge(bs,on=['row','mask'],validate='many_to_one');scores['r_gain_vs_seasonal_baseline']=scores.r-scores.seasonal_baseline_r
 scores.to_csv(OUT/'scores_long.csv.gz',index=False,compression='gzip');meta.to_csv(OUT/'input_and_fit_strata.csv',index=False)
 cells,cell_index=np.unique(c.spatial_cell.to_numpy(str),return_inverse=True);rng=np.random.default_rng(SEED)
 draws=rng.integers(0,len(cells),size=(B,len(cells)));cw=np.stack([np.bincount(x,minlength=len(cells)) for x in draws]);weights=cw[:,cell_index]
 np.savez_compressed(OUT/'bootstrap_spatial_cell_draws.npz',cells=cells,cell_index=cell_index,cell_draws=draws,station_weights=weights,seed=np.array(SEED))
 fixed={'all141':np.ones(len(c),bool),'H60_estimable':c.target_estimable_fixed_rule.to_numpy(bool),'P_admitted':meta.p_available.to_numpy(bool),'P_not_admitted':~meta.p_available.to_numpy(bool),'full120_calendar':c.L.eq(120).to_numpy(),'exact120_entry_truth':c.exact_H60_G120_entry_complete_truth.to_numpy(bool),'exact120_physical_truth':c.exact_H60_G120_physical_complete_truth.to_numpy(bool)}
 for name,lo,hi in [('G24_35',24,35),('G36_59',36,59),('G60_119',60,119)]:fixed[name]=c.L.between(lo,hi).to_numpy()
 for g in ['clean','warning','unknown']:fixed['geometry_'+g]=meta.geometry_group.eq(g).to_numpy()
 for col in ['continent','country']:
  labels=c[col].fillna('Unknown').astype(str)
  for name in sorted(labels.unique()):fixed[col+':'+name]=labels.eq(name).to_numpy()
 summaries=[];pairs=[];boot=[];denoms=[]
 def ci(values,sel):
  keep=sel&np.isfinite(values);n=int(keep.sum());nc=int(len(np.unique(cell_index[keep])))
  if n<10 or nc<5:return np.nan,np.nan,0,n,nc
  ww=weights[:,keep];den=ww.sum(1);good=den>0
  est=(ww[good]@values[keep])/den[good]
  lo,hi=np.percentile(est,[2.5,97.5]);return float(lo),float(hi),int(good.sum()),n,nc
 for m in METHODS+['seasonal']:
  groups=dict(fixed)
  if m!='seasonal':groups['P_actually_used']=meta[f'{m}_P_actually_used'].to_numpy(bool);groups['P_not_actually_used']=~groups['P_actually_used']
  for name,sel in groups.items():denoms.append(dict(method=m,group=name,n=int(sel.sum()),spatial_cells=int(len(np.unique(cell_index[sel])))))
  for maskname in MASKS:
   byarm={a:scores[(scores.method==m)&(scores.arm==a)&(scores['mask']==maskname)].set_index('row').reindex(range(len(c))) for a in (ARMS if m!='seasonal' else ['baseline'])}
   for arm,f in byarm.items():
    for name,sel in groups.items():summaries.append(summarize(f,name,m,arm,maskname,sel,c))
   if m=='seasonal':continue
   for ref in ['Q','QP_Gclim']:
    new=byarm['QP'];old=byarm[ref];both=old.eligible.to_numpy(bool)&new.eligible.to_numpy(bool)
    rec=pd.DataFrame({'row':c.row,'station_id':c.station_id,'method':m,'mask':maskname,'contrast':'QP_minus_'+ref,'both_eligible':both})
    changes={'r_gain':new.r.to_numpy()-old.r.to_numpy(),'NSE_gain':new.NSE.to_numpy()-old.NSE.to_numpy(),'H_deseasonal_r_gain':new.H_deseasonal_r.to_numpy()-old.H_deseasonal_r.to_numpy(),'alpha_error_reduction':np.abs(old.alpha.to_numpy()-1)-np.abs(new.alpha.to_numpy()-1),'delta_error_reduction':np.abs(old.delta.to_numpy())-np.abs(new.delta.to_numpy())}
    for metric,v in changes.items():
     v=np.where(both,v,np.nan);rec[metric]=v
     for name,sel in groups.items():
      lo,hi,bn,n,nc=ci(v,sel);vsel=v[sel];finite=vsel[np.isfinite(vsel)]
      boot.append(dict(method=m,mask=maskname,contrast='QP_minus_'+ref,group=name,metric=metric,point=float(np.mean(finite)) if len(finite) else np.nan,ci_low=lo,ci_high=hi,valid_pairs=n,spatial_cells=nc,valid_bootstrap=bn,threshold=np.nan,new_pass=np.nan,lost_pass=np.nan,denominator=int(sel.sum())))
    for threshold in THRESHOLDS:
     suffix=str(threshold).replace('.','');op=old[f'pass_{suffix}'].to_numpy(bool);npas=new[f'pass_{suffix}'].to_numpy(bool);v=(npas.astype(int)-op.astype(int))*100.
     rec['new_pass_'+suffix]=npas&~op;rec['lost_pass_'+suffix]=op&~npas;rec['pass_change_pp_'+suffix]=v
     for name,sel in groups.items():
      lo,hi,bn,n,nc=ci(v,sel);ng=int(np.sum(npas[sel]&~op[sel]));nl=int(np.sum(op[sel]&~npas[sel]));den=int(sel.sum())
      assert abs((ng-nl)*100/den-np.mean(v[sel]))<1e-12 if den else True
      boot.append(dict(method=m,mask=maskname,contrast='QP_minus_'+ref,group=name,metric='pass_rate_change_pp',point=100*(ng-nl)/den if den else np.nan,ci_low=lo,ci_high=hi,valid_pairs=n,spatial_cells=nc,valid_bootstrap=bn,threshold=threshold,new_pass=ng,lost_pass=nl,denominator=den))
    pairs.append(rec)
 pd.DataFrame(summaries).to_csv(OUT/'summary_by_predefined_stratum.csv',index=False)
 pd.concat(pairs,ignore_index=True).to_csv(OUT/'paired_station_changes.csv.gz',index=False,compression='gzip')
 pd.DataFrame(boot).to_csv(OUT/'paired_bootstrap.csv',index=False)
 pd.DataFrame(denoms).to_csv(OUT/'stratum_denominators.csv',index=False)
 scores.groupby(['mask','method','arm','status'],dropna=False).size().rename('n').reset_index().to_csv(OUT/'failure_status_counts.csv',index=False)
 outputs=[p for p in OUT.glob('*') if p.is_file() and p.name!='ANALYSIS_COMPLETE.json']
 js(OUT/'ANALYSIS_COMPLETE.json',dict(status='ALL_REGISTERED_REAL_FORWARD_SCORES_COMPLETE',N=len(c),score_rows=len(scores),pre_score_QA_sha256=sha(ROOT/'audit/PRE_SCORING_QA.json'),scoring_code_freeze_sha256=sha(HERE/'SCORING_CODE_FROZEN.json'),truth_masks=['physical_gap_primary','entry_gap_sensitivity'],exact_H60_G120_complete_physical_truth_cases=0,files={p.name:sha(p) for p in outputs},no_outcome_filtering=True,no_new_model_or_tuning=True))
 print('REAL_FORWARD_SCORING_COMPLETE',len(scores),'rows',flush=True)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('step',choices=['register','run']);args=ap.parse_args();globals()[args.step]()
