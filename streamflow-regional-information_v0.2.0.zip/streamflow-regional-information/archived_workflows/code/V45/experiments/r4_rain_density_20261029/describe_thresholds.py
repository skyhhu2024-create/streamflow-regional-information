"""Prespecified descriptive threshold-distance and country concentration checks.

These use scored target outcomes for explanation only; they do not select inputs,
fit weights, estimate causal effects, or produce a prospective admission rule.
"""
from pathlib import Path
import sys,json
R=Path(__file__).resolve().parent
C=next(p for p in R.parents if p.name=='code')
sys.path.insert(0,str(C/'V42/dependencies'))
import numpy as np,pandas as pd
d=pd.read_csv(R/'data/paired_rainfall_density_cases.csv.gz',keep_default_na=False,na_values=[''])
d=d[(d.method=='ridge')&(d.D==800)&d.P_available].copy()
w=pd.read_csv(R/'adjustment/target_overlap_weights.csv.gz')
def wm(v,w):
    ok=np.isfinite(v)&np.isfinite(w)&(w>0);v=np.asarray(v)[ok];w=np.asarray(w)[ok]
    o=np.argsort(v);v=v[o];cw=np.cumsum(w[o]);h=cw[-1]*.5
    lo=np.searchsorted(cw,h,side='left');hi=np.searchsorted(cw,h,side='right')
    return (v[lo]+v[min(hi,len(v)-1)])/2
rows=[];countries=[]
for (comparator,stage),ww in w.groupby(['comparator','stage']):
    j=d.merge(ww[['station_id','weight']],on='station_id',validate='one_to_one')
    for region,g in j.groupby('continent'):
        valid=g.paired_valid_NSE
        a=g.loc[valid].copy();wt=a.weight.to_numpy();total=wt.sum()
        threshold=np.maximum(.5,a.Q_seasonal_NSE.to_numpy())
        distance=threshold-a.Q_NSE.to_numpy()
        rows.append(dict(comparator=comparator,stage=stage,region=region,n=len(g),finite_n=len(a),weighted_Q_NSE_median=wm(a.Q_NSE,wt),weighted_QP_NSE_median=wm(a.QP_NSE,wt),weighted_threshold_distance_median=wm(distance,wt),weighted_baseline_failure_fraction=np.average(~a.Q_old_NSE_pass,weights=wt),weighted_Q_NSE_negative_fraction=np.average(a.Q_NSE<0,weights=wt),weighted_Q_NSE_within0p1_below_threshold=np.average((distance>0)&(distance<=.1),weights=wt),weighted_Q_NSE_within0p25_below_threshold=np.average((distance>0)&(distance<=.25),weights=wt)))
        ct=g.groupby('country').agg(n=('station_id','size'),weight_sum=('weight','sum')).reset_index();ct['weight_share']=ct.weight_sum/ct.weight_sum.sum();ct['comparator']=comparator;ct['stage']=stage;ct['region']=region;countries.append(ct)
pd.DataFrame(rows).to_csv(R/'primary/threshold_distance_descriptive.csv',index=False)
pd.concat(countries).to_csv(R/'primary/adjusted_country_weight_composition.csv',index=False)

# All countries, no selection based on benefit; point sensitivity to national concentration.
out=[]
for region,g in d.groupby('continent'):
    for country in sorted(g.country.unique()):
        a=g[g.country!=country]
        if not len(a):continue
        b=a[a.paired_valid_NSE];c=a[a.paired_valid_r]
        out.append(dict(region=region,omitted_country=country,removed_n=len(g)-len(a),remaining_n=len(a),delta_NSE_median=b.delta_NSE.median(),delta_r_median=c.delta_r.median(),NSE_success_net_pp=100*a.delta_success_NSE.mean()))
pd.DataFrame(out).to_csv(R/'primary/leave_one_country_out_point_sensitivity.csv',index=False)
print(pd.DataFrame(rows).query("comparator=='Asia' and stage in ['raw','synchronous_reference_climate']").to_string(index=False))
