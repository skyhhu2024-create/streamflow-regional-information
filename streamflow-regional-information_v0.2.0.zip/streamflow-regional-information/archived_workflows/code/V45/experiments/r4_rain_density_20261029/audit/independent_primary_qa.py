"""Independent read-only verification of the parent's fixed primary analysis."""
from pathlib import Path
import ast
import hashlib
import json
import sys
import warnings

HERE = Path(__file__).resolve().parents[1]
CODE = next(p for p in HERE.parents if p.name == 'code')
sys.path.insert(0, str(CODE / 'V42/dependencies'))
import numpy as np
import pandas as pd
from scipy.stats import spearmanr


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return pd.read_csv(path, keep_default_na=False, na_values=[''])


def same(a, b, name, atol=1e-11):
    np.testing.assert_allclose(a, b, rtol=1e-11, atol=atol, equal_nan=True, err_msg=name)


source = HERE / 'analyze_primary.py'
primary = HERE / 'primary'
assert (primary / 'PRIMARY_QA.json').exists()
input_file = HERE / 'data/paired_rainfall_density_cases.csv.gz'
qafile = json.loads((primary / 'PRIMARY_QA.json').read_text())
assert qafile['input_sha256'] == sha(input_file)
full = read(input_file)
assert len(full) == 71184
d = full[full.primary_P8083].copy()
assert d.groupby(['D', 'method']).size().eq(8083).all()
assert d.groupby(['D', 'method']).row.nunique().eq(8083).all()
assert not d.duplicated(['row', 'D', 'method']).any()
d.loc[~np.isfinite(d.official_estimated_area_km2) | (d.official_estimated_area_km2 <= 0), 'official_estimated_area_km2'] = np.nan

# Membership/criterion checks use original frozen score flags without replacing
# real finite fallback outcomes by either missing data or false precision success.
for arm in ('Q', 'QP'):
    expected = d[arm + '_eligible'] & (d[arm + '_NSE'] >= .5) & (d[arm + '_NSE'] > d[arm + '_seasonal_NSE'])
    assert expected.equals(d[arm + '_old_NSE_pass'])
assert np.array_equal(d.delta_success_NSE, d.QP_old_NSE_pass.astype(int) - d.Q_old_NSE_pass.astype(int))
assert d.loc[(d.D == 800) & d.method.eq('ridge') & d.continent.eq('Africa')].country.eq('NA').sum() == 16

boot = np.load(primary / 'bootstrap_draws.npz')
cells = boot['spatial_cells']
draws = boot['draws']
assert draws.shape == (2000, 274)
assert np.all(draws.sum(1) == 274)
assert np.array_equal(np.sort(d.spatial_cell.unique()), cells)
replay = np.random.default_rng(20261029).multinomial(274, np.repeat(1 / 274, 274), size=2000)
assert np.array_equal(replay, draws)
index = {v: i for i, v in enumerate(cells)}
d['cell_index'] = d.spatial_cell.map(index)

# Load only the three estimator function definitions, not the parent's top-level
# analysis or data reads, then compare with literal integer replication.
tree = ast.parse(source.read_text(encoding='utf-8'))
functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in ('medboot', 'meanboot', 'corrboot')]
namespace = {'np': np, 'cells': cells}
exec(compile(ast.Module(body=functions, type_ignores=[]), str(source), 'exec'), namespace)
rng = np.random.default_rng(74851)
synthetic_checks = 0
for size in (3, 5, 19, 31):
    x = rng.integers(0, 6, size=size).astype(float)
    y = rng.integers(-2, 7, size=size).astype(float)
    ix = rng.integers(0, 8, size=size)
    small = rng.multinomial(8, np.full(8, 1 / 8), size=100)
    testdraws = np.zeros((100, 274), dtype=int)
    testdraws[:, :8] = small
    namespace['draws'] = testdraws
    gotmed = namespace['medboot'](y, ix)
    gotmean = namespace['meanboot'](y, ix)
    gotcorr = namespace['corrboot'](x, y, ix)
    for k, row in enumerate(testdraws):
        xx = np.repeat(x, row[ix])
        yy = np.repeat(y, row[ix])
        med = np.median(yy) if len(yy) else np.nan
        mean = np.mean(yy) if len(yy) else np.nan
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            corr = spearmanr(xx, yy).statistic if len(xx) >= 2 else np.nan
        same(gotmed[k], med, 'weighted median literal replicate')
        same(gotmean[k], mean, 'weighted mean literal replicate')
        same(gotcorr[k], corr, 'weighted Spearman literal replicate')
        synthetic_checks += 3
namespace['draws'] = draws

summary = read(primary / 'region_distance_paired_effects.csv')
regions_checked = 0
fallback_pairs_retained = {}
for row in summary.itertuples():
    z = d[(d.D == row.D) & d.method.eq(row.method)]
    if row.group != 'Global':
        z = z[z.continent.eq(row.group)]
    assert len(z) == row.n_registered
    if row.metric in ('NSE', 'r'):
        metric = row.metric
        valid = z.Q_valid_truth & z.QP_valid_truth & np.isfinite(z['Q_' + metric]) & np.isfinite(z['QP_' + metric])
        w = z[valid]
        value = w['QP_' + metric] - w['Q_' + metric]
        assert len(w) == row.n_pairs
        same(np.median(value), row.delta_median, 'median of individual changes')
        same(w['Q_' + metric].median(), row.Q_median, 'Q median')
        same(w['QP_' + metric].median(), row.QP_median, 'QP median')
        assert (value > 1e-12).sum() == row.improved
        assert (value < -1e-12).sum() == row.worsened
        if row.group == 'Global':
            fallback_pairs_retained[f'{row.method}_D{row.D}_{metric}'] = int((~w.Q_eligible | ~w.QP_eligible).sum())
    else:
        assert row.metric == 'NSE_success_pp'
        same(100 * z.Q_old_NSE_pass.mean(), row.Q_median, 'original Q success')
        same(100 * z.QP_old_NSE_pass.mean(), row.QP_median, 'original QP success')
        same(100 * z.delta_success_NSE.mean(), row.delta_median, 'net success denominator')
        assert z.new_success_NSE.sum() == row.new_success
        assert z.lost_success_NSE.sum() == row.lost_success
    regions_checked += 1

# Reproduce a prespecified broad sample of bootstrap CIs for global and the three
# relevant continents. Every group uses the same saved block resampling matrix.
ci_checks = 0
for row in summary[(summary.method == 'ridge') & (summary.D.isin([0, 800])) & summary.group.isin(['Global', 'Europe', 'Asia', 'Africa'])].itertuples():
    z = d[(d.D == row.D) & d.method.eq(row.method)]
    if row.group != 'Global':
        z = z[z.continent.eq(row.group)]
    if row.metric == 'NSE_success_pp':
        estimates = 100 * namespace['meanboot'](z.delta_success_NSE.to_numpy(), z.cell_index.to_numpy(int))
    else:
        ok = z.Q_valid_truth & z.QP_valid_truth & np.isfinite(z['Q_' + row.metric]) & np.isfinite(z['QP_' + row.metric])
        z = z[ok]
        estimates = namespace['medboot'](z['delta_' + row.metric].to_numpy(), z.cell_index.to_numpy(int))
    same(np.nanquantile(estimates, [.025, .975]), [row.ci025, row.ci975], 'reported CI replay')
    ci_checks += 1

# Reproduce outcome-independent quartile membership and correlation estimates.
extra = HERE / 'exposures/exposure_summary.csv'
if extra.exists():
    ex = read(extra).rename(columns={'within800_mean': 'reporters_near800_mean',
        'annulus800_1500_mean': 'reporters_ring800_1500_mean', 'beyond800_mean': 'reporters_far800_mean'})
    d = d.merge(ex.drop(columns=[c for c in ex if c != 'row' and c in d]), on='row', validate='many_to_one')
base = d[(d.D == 800) & d.method.eq('ridge')].copy()
cuts = json.loads((primary / 'D800_quartile_cutpoints.json').read_text())
quart = read(primary / 'D800_quartile_effects.csv')
composition = read(primary / 'D800_quartile_region_composition.csv')
quartile_checks = 0
for cut in cuts:
    f = cut['feature']
    v = pd.to_numeric(base[f], errors='coerce')
    finite = np.isfinite(v)
    expected = np.unique(np.quantile(v[finite], [.25, .5, .75]))
    same(expected, cut['cutpoints'], f + ' exposure-only quartiles')
    assert finite.sum() == cut['n_finite']
    labels = np.where(finite, np.searchsorted(expected, v, side='left') + 1, 0)
    for b in np.unique(labels):
        z = base[labels == b]
        group = f'Q{b}' if b else 'Unknown'
        rows = quart[quart.feature.eq(f) & quart.group.eq(group)]
        assert rows.n_registered.eq(len(z)).all()
        c = composition[(composition.feature == f) & (composition.bin == b)]
        assert c.n.sum() == len(z)
        assert dict(zip(c.region, c.n)) == z.continent.value_counts().to_dict()
        for rr in rows.itertuples():
            if rr.metric == 'NSE_success_pp':
                same(100 * z.delta_success_NSE.mean(), rr.delta_median, 'quartile success')
            else:
                ok = z.Q_valid_truth & z.QP_valid_truth & np.isfinite(z['Q_' + rr.metric]) & np.isfinite(z['QP_' + rr.metric])
                zz = z[ok]
                same(np.median(zz['delta_' + rr.metric]), rr.delta_median, 'quartile paired median')
            quartile_checks += 1
corr = read(primary / 'D800_feature_spearman.csv')
for rr in corr.itertuples():
    z = base if rr.region == 'Global' else base[base.continent.eq(rr.region)]
    ok = z.Q_valid_truth & z.QP_valid_truth & np.isfinite(z['Q_' + rr.metric]) & np.isfinite(z['QP_' + rr.metric]) & np.isfinite(z[rr.feature])
    z = z[ok]
    assert len(z) == rr.n
    same(spearmanr(z[rr.feature], z['delta_' + rr.metric]).statistic, rr.spearman, 'independent Spearman point')

inter = read(primary / 'within_target_rainfall_interaction.csv')
for rr in inter.itertuples():
    a = d[(d.D == rr.D) & d.method.eq(rr.method)].set_index('row')
    b = d[(d.D == 0) & d.method.eq(rr.method)].set_index('row').loc[a.index]
    if rr.region != 'Global':
        a = a[a.continent.eq(rr.region)]; b = b.loc[a.index]
    assert len(a) == rr.n_registered
    if rr.metric == 'NSE_success_pp':
        value = 100 * (a.delta_success_NSE - b.delta_success_NSE).mean()
    else:
        m = rr.metric
        ok = a.Q_valid_truth & a.QP_valid_truth & b.Q_valid_truth & b.QP_valid_truth
        for arm in ('Q', 'QP'):
            ok &= np.isfinite(a[arm + '_' + m]) & np.isfinite(b[arm + '_' + m])
        v = a['delta_' + m] - b['delta_' + m]
        ok &= np.isfinite(v)
        assert ok.sum() == rr.n_pairs
        value = np.median(v[ok])
    same(value, rr.paired_interaction_median, 'same-case difference of rainfall gains')

result = dict(status='PASS', analysis_script_sha256=sha(source), input_sha256=sha(input_file),
    parent_QA_sha256=sha(primary / 'PRIMARY_QA.json'), fixed_cases=8083,
    fixed_spatial_blocks=274, bootstrap_replicates=2000,
    checks=dict(success_flag_algebra='PASS', mother_denominator='PASS',
        literal_NA_country_preserved='PASS', weighted_synthetic_replications=synthetic_checks,
        region_distance_summary_rows=regions_checked, bootstrap_interval_replays=ci_checks,
        quartile_result_rows=quartile_checks, correlation_point_estimates=len(corr),
        paired_interaction_rows=len(inter), all_estimates_tolerance='1e-11',
        quartiles_use_inputs_only='PASS', all_scores_and_fallback_continuous_pairs_retained='PASS'),
    noneligible_finite_valid_truth_pairs_retained=fallback_pairs_retained,
    interpretation_caveats=[
        'Historical qualification counts measure potential-source richness, not raw geographic density or simultaneous reporting.',
        'Selected G input descriptors use source availability during G; their r values remain H qualification correlations.',
        'Reported continuous delta_median is median(QP-Q); the difference of arm medians need not match.',
        'NSE_success_pp rows use Q_median/QP_median field names for percentages and delta_median for net percentage-point change; interpret by metric label.',
        'Retrospective conditional associations do not identify a causal density effect or extrapolate African/Asian samples to entire continents.'
    ],
    output_hashes={p.name: sha(p) for p in primary.glob('*.csv')})
(HERE / 'audit/INDEPENDENT_PRIMARY_QA.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'status': 'PASS', 'summary_rows': regions_checked, 'synthetic_checks': synthetic_checks,
                  'quartile_rows': quartile_checks, 'correlations': len(corr), 'interactions': len(inter)}))
