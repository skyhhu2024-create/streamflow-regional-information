"""Independent joins, aggregates, weights, intervals and threshold-description QA."""
from pathlib import Path
import os,sys,json,hashlib,importlib.util
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
CODE=next(p for p in Path(__file__).resolve().parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np,pandas as pd
from scipy.special import expit
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;ADJ=ROOT/'adjustment'
BASE=ROOT.parent/'r4_full_source_gradient_20261026'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p,**kw):return pd.read_csv(p,keep_default_na=False,na_values=[''],float_precision='round_trip',**kw)
def close(a,b,tol=2e-10):return bool(np.allclose(a,b,rtol=tol,atol=tol,equal_nan=True))
def wm(x,w):
 x=np.asarray(x,dtype=float);w=np.asarray(w,dtype=float);ok=np.isfinite(x)&np.isfinite(w)&(w>0)
 if not ok.any():return np.nan
 x=x[ok];w=w[ok];order=np.argsort(x,kind='stable');x=x[order];w=w[order]/np.max(w)
 c=np.cumsum(w);h=c[-1]/2;k=min(int(np.searchsorted(c,h)),len(x)-1)
 return float((x[k]+x[k+1])/2)if k+1<len(x)and np.isclose(c[k],h,rtol=1e-13,atol=0)else float(x[k])
def tr(x,kind):
 x=pd.to_numeric(x,errors='coerce').to_numpy(float,copy=True);x[~np.isfinite(x)]=np.nan
 if kind=='log':x[x<=0]=np.nan;return np.log(x)
 if kind=='log1p':x[x<0]=np.nan;return np.log1p(x)
 return x
cfg=json.loads((ADJ/'config.json').read_text(encoding='utf8'))
assert cfg['logistic_C']==1.0 and cfg['bootstrap_replicates']==1000 and cfg['seed']==20261029
data=read(ROOT/'data/paired_rainfall_density_cases.csv.gz')
d=data[(data.D==800)&(data.method=='ridge')&data.primary_P8083].copy()
assert len(d)==d.station_id.nunique()==8083
exp=read(ROOT/'exposures/exposure_summary.csv')
d=d.merge(exp[['row','station_id','raw_index','within800_mean','beyond800_mean']],on=['row','station_id','raw_index'],how='left',validate='1:1')
assert d[['within800_mean','beyond800_mean']].notna().all().all()
src=read(BASE/'analysis/scores_long.csv.gz',usecols=['row','D','method','arm','NSE','r','valid_truth','old_NSE_pass','r07_pass','seasonal_NSE'])
src=src[(src.D==800)&(src.method=='ridge')&src.row.isin(d.row)]
checks={};raw_stats={}
dd=d.set_index('row')
for arm in ['Q','QP']:
 z=src[src.arm==arm].set_index('row').loc[dd.index]
 for field in ['NSE','r','seasonal_NSE','valid_truth','old_NSE_pass','r07_pass']:
  assert close(dd[arm+'_'+field],z[field]),(arm,field)
for metric in ['NSE','r']:
 assert close(d['delta_'+metric],d['QP_'+metric]-d['Q_'+metric])
 valid=d.Q_valid_truth&d.QP_valid_truth&np.isfinite(d['Q_'+metric])&np.isfinite(d['QP_'+metric])
 assert np.array_equal(valid,d['paired_valid_'+metric])
for met,col in [('NSE','old_NSE_pass'),('r07','r07_pass')]:
 assert np.array_equal(d['delta_success_'+met],d['QP_'+col].astype(int)-d['Q_'+col].astype(int))
checks['raw_source_values_and_flags_exact_with_float_tolerance']=True
checks['fixed8083_identity_and_exposure_join']=True
checks['metric_validity_is_truth_finite_pair_including_fallback']=True
checks['success_denominator_keeps_all_fixed_targets']=True
for region in ['Europe','Asia','Africa']:
 a=d[d.continent==region];v=a[a.paired_valid_NSE];r=a[a.paired_valid_r]
 raw_stats[region]=dict(n=len(a),NSE_finite=len(v),r_finite=len(r),median_delta_NSE=float(np.median(v.delta_NSE)),median_delta_r=float(np.median(r.delta_r)),new_NSE=int((a.delta_success_NSE==1).sum()),lost_NSE=int((a.delta_success_NSE==-1).sum()),net_NSE_pp=float(a.delta_success_NSE.mean()*100))
weights=read(ADJ/'target_overlap_weights.csv.gz');effects=read(ADJ/'effect_estimates.csv');boot=read(ADJ/'bootstrap_draw_results.csv.gz')
balance_table=read(ADJ/'covariate_balance.csv')
assert len(effects)==96 and len(boot)==8000
assert not weights.duplicated(['station_id','comparator','stage']).any()
max_pointdiff=0.;max_weightdiff=0.;max_prop_diff=0.;gradientchecks=[];scalechecks=[];warning_summary={}
stages=cfg['stages']
for comp in ['Asia','Africa']:
 z=d[d.continent.isin(['Europe',comp])].sort_values('station_id').reset_index(drop=True)
 y=(z.continent=='Europe').to_numpy(float);pars=json.loads((ADJ/f'fit_parameters_{comp}.json').read_text(encoding='utf8'))
 diag=json.loads((ADJ/f'diagnostics_{comp}.json').read_text(encoding='utf8'))
 assert not diag['failures']
 warning_summary[comp]={}
 for stage in stages:
  ww=weights[(weights.comparator==comp)&(weights.stage==stage)].set_index('station_id').loc[z.station_id]
  assert np.array_equal(ww.continent,z.continent) and np.array_equal(ww.spatial_cell,z.spatial_cell)
  w=ww.weight.to_numpy(float);p=ww.propensity_Europe.to_numpy(float)
  if stage=='raw':assert np.array_equal(w,np.ones(len(z)))
  else:
   spec=dict(cfg['reference_numeric'])
   if stage in ['reference_climate','synchronous_reference_climate']:spec.update(cfg['additional_numeric'])
   if stage=='synchronous_reference_climate':
    for a,b in cfg['synchronous_count_replacement'].items():spec[b]=spec.pop(a)
   assert not any(k.startswith(('delta_','Q_','QP_'))for k in spec)
   pa=pars[stage];coeff=pa['coefficients'];cols=[]
   for name in list(coeff)[1:]:
    if '='in name:
     field,level=name.split('=',1);s=z[field].fillna('Missing').astype(str).replace({'nan':'Missing','':'Missing'});v=(s==level).to_numpy(float)
    elif name.endswith('__missing'):
     field=name[:-9];v=(~np.isfinite(tr(z[field],spec[field]))).astype(float)
    else:
     v=tr(z[name],spec[name]);med=np.median(v[np.isfinite(v)])if np.isfinite(v).any()else 0.
     assert close(med,pa['preprocessing']['imputation'][name]['imputation'])
     v=np.where(np.isfinite(v),v,med)
    cols.append(v)
   raw=np.column_stack(cols);mu=raw.mean(0);sd=raw.std(0);sd[sd<1e-12]=1
   assert close(mu,pa['preprocessing']['means'])and close(sd,pa['preprocessing']['scales'])
   X=(raw-mu)/sd;coef=np.array(list(coeff.values()));A=np.column_stack([np.ones(len(z)),X]);pred=expit(A@coef)
   max_prop_diff=max(max_prop_diff,float(np.max(np.abs(pred-p))))
   want=np.where(y==1,1-p,p);max_weightdiff=max(max_weightdiff,float(np.max(np.abs(w-want))))
   grad=A.T@(pred-y);grad[1:]+=coef[1:]/cfg['logistic_C']
   assert np.max(np.abs(grad))<.002
   for column,name in enumerate(list(coeff)[1:]):
    xx=raw[:,column];eu=xx[y==1];co=xx[y==0];scale=np.sqrt((eu.var(ddof=1)+co.var(ddof=1))/2)
    rawdiff=eu.mean()-co.mean();weightdiff=np.average(eu,weights=w[y==1])-np.average(co,weights=w[y==0])
    b=balance_table[(balance_table.comparator==comp)&(balance_table.stage==stage)&(balance_table.covariate==name)].iloc[0]
    assert close(b.raw_SMD,rawdiff/scale if scale>1e-12 else 0.)
    assert close(b.adjusted_SMD,weightdiff/scale if scale>1e-12 else 0.)
   gradientchecks.append(dict(comparator=comp,stage=stage,max_gradient=float(np.max(np.abs(grad)))))
  got={}
  for metric in ['delta_NSE','delta_r','delta_success_NSE','delta_success_r07']:
   x=z[metric].to_numpy(float,copy=True)
   if metric in cfg['continuous_fields']:x[~z[cfg['continuous_fields'][metric]].to_numpy(bool)]=np.nan
   for region,mask in [('Europe',y==1),(comp,y==0)]:
    good=mask&np.isfinite(x)&(w>0)
    val=wm(x[good],w[good])if metric in cfg['continuous_fields']else np.average(x[good],weights=w[good])
    got[(metric,region)]=val
    if metric in cfg['continuous_fields']:
     for scale in [1e-15,1e-6,1e6,1e100]:scalechecks.append(close(wm(x[good],w[good]*scale),val))
   got[(metric,'difference')]=got[(metric,'Europe')]-got[(metric,comp)]
  for (metric,region),val in got.items():
   er=effects[(effects.comparator==comp)&(effects.stage==stage)&(effects.metric==metric)&(effects.region==region)].iloc[0]
   max_pointdiff=max(max_pointdiff,float(abs(er.estimate-val)))
   bb=boot[(boot.comparator==comp)&(boot.stage==stage)];assert bb.replicate.nunique()==1000 and set(bb.replicate)==set(range(1000))
   column=metric+'__'+('Comparator'if region==comp else region)
   vv=bb[column].dropna().to_numpy();assert len(vv)==er.successful_bootstraps==1000
   assert close(np.quantile(vv,[.025,.975]),[er.ci_low,er.ci_high])
  stage_diag=diag['stages'][stage]
  warning_summary[comp][stage]={'warnings':stage_diag['warnings'],'max_abs_adjusted_SMD':stage_diag['max_abs_adjusted_SMD'],'regional_ESS':{k:v['ESS']for k,v in stage_diag['regions'].items()},'regional_cell_ESS':{k:v['cell_weight_ESS']for k,v in stage_diag['regions'].items()},'common_interval':[float(t)for t in stage_diag['central_common_interval']]}
  if stage_diag['max_abs_adjusted_SMD']>.1:assert any('Residual' in s for s in stage_diag['warnings'])
  for reg,rd in stage_diag['regions'].items():
   mask=(y==1)if reg=='Europe'else(y==0);rw=w[mask];ee=rw.sum()**2/np.dot(rw,rw)
   assert close(ee,rd['ESS'])
   if ee<50:assert any(reg+' ESS' in s for s in stage_diag['warnings'])
assert max_pointdiff<2e-10 and max_prop_diff<2e-10 and max_weightdiff<2e-10
checks.update(overlap_weights_formula_and_saved_coefficient_reconstruction=True,all_96_point_estimates_recomputed=True,all_96_intervals_recomputed_from1000_draws=True,all_models_L2_C1_unpenalized_intercept_fit_continent_not_reconstruction_outcomes=True,all_adjusted_covariate_SMDs_recomputed=True,finite_admissibility_and_full_binary_denominators=True,diagnostic_ESS_and_imbalance_warnings_present=True,independent_weighted_median_scale_invariance=all(scalechecks))
# Independently reconstruct the post-hoc threshold table from the same frozen scores.
tt=read(ROOT/'primary/threshold_distance_descriptive.csv');threshold_maxdiff=0.
for er in tt.itertuples():
 ww=weights[(weights.comparator==er.comparator)&(weights.stage==er.stage)]
 z=d[d.continent==er.region].merge(ww[['station_id','weight']],on='station_id',validate='1:1');a=z[z.paired_valid_NSE]
 assert len(z)==er.n and len(a)==er.finite_n
 w=a.weight.to_numpy();qn=a.Q_NSE.to_numpy();pn=a.QP_NSE.to_numpy();distance=np.maximum(.5,a.Q_seasonal_NSE)-qn
 vals={'weighted_Q_NSE_median':wm(qn,w),'weighted_QP_NSE_median':wm(pn,w),'weighted_threshold_distance_median':wm(distance,w),'weighted_baseline_failure_fraction':np.average(~a.Q_old_NSE_pass,weights=w),'weighted_Q_NSE_negative_fraction':np.average(qn<0,weights=w),'weighted_Q_NSE_within0p1_below_threshold':np.average((distance>0)&(distance<=.1),weights=w),'weighted_Q_NSE_within0p25_below_threshold':np.average((distance>0)&(distance<=.25),weights=w)}
 for k,v in vals.items():threshold_maxdiff=max(threshold_maxdiff,abs(v-getattr(er,k)))
assert threshold_maxdiff<2e-10
checks['all_threshold_descriptive_rows_recomputed']=True
# Import routines without executing main and replay prespecified bootstrap draws.
spec=importlib.util.spec_from_file_location('adjustment_audited',ADJ/'run_adjustment.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
production_scale_tests=[]
for factor in [1.,1e-15,1e-6,1e6,1e100]:production_scale_tests.append({'factor':factor,'value':mod.weighted_median(np.array([0.,10.,100.]),np.array([.6,.2,.2])*factor)})
checks['production_weighted_median_scale_invariance']=all(v['value']==0 for v in production_scale_tests)
replayed=[]
for ci,comp in enumerate(['Asia','Africa']):
 z=d[d.continent.isin(['Europe',comp])].sort_values('station_id').reset_index(drop=True);y=(z.continent=='Europe').to_numpy(float)
 cells,cid=np.unique(z.spatial_cell.astype(str),return_inverse=True);draws=np.random.default_rng(cfg['seed']+ci).multinomial(len(cells),np.full(len(cells),1/len(cells)),size=1000)
 for bi in [0,17,999]:
  freq=draws[bi][cid].astype(float)
  for stage in stages:
   if stage=='raw':w=freq
   else:
    X,_,_,_=mod.Covariates(z,stage).matrix(freq);p,_,_=mod.fit_logistic(X,y,freq);w=freq*np.where(y==1,1-p,p)
   values=mod.summarize(y,w,mod.effect_metrics(z));rr=boot[(boot.comparator==comp)&(boot.stage==stage)&(boot.replicate==bi)].iloc[0]
   for k,v in values.items():assert close(v,rr[k]),(comp,stage,bi,k,v,rr[k])
   replayed.append(dict(comparator=comp,stage=stage,replicate=bi,all12effects_exact_with_tolerance=True))
checks['24_sample_bootstrap_fits_preprocessing_and_shared_cells_reproduced']=True
warnings=['All adjusted comparisons are descriptive overlap-population associations, not causal effects or a proof that station density explains continental differences.','Europe-Africa adjusted climate overlap is inadequate; Europe-Asia overlap targets only a limited comparable subset.','Threshold-distance summaries use evaluated target scores and cannot be used as an advance source-selection rule. Distance to max(0.5,seasonal NSE) is an NSE-score barrier, not the separate actual-support gate.']
if not checks['production_weighted_median_scale_invariance']:warnings.append('Production weighted-median exact-half test has absolute-tolerance scale sensitivity; correction requested. Current recorded point estimates match independent scale-invariant recomputation.')
files=[ROOT/'data/paired_rainfall_density_cases.csv.gz',ROOT/'exposures/exposure_summary.csv',ADJ/'run_adjustment.py',ADJ/'config.json',ADJ/'target_overlap_weights.csv.gz',ADJ/'effect_estimates.csv',ADJ/'bootstrap_draw_results.csv.gz',ROOT/'describe_thresholds.py',ROOT/'primary/threshold_distance_descriptive.csv']
out={'status':'PASS'if all(checks.values())else'REVIEW','checks':checks,'files':{str(p):sha(p)for p in files},'raw_region_scores':raw_stats,'max_point_estimate_difference':max_pointdiff,'max_propensity_difference':max_prop_diff,'max_weight_difference':max_weightdiff,'max_threshold_summary_difference':threshold_maxdiff,'gradient_checks':gradientchecks,'production_scale_tests':production_scale_tests,'bootstrap_replays':replayed,'overlap_warning_summary':warning_summary,'interpretive_notes':warnings}
(HERE/'INDEPENDENT_ADJUSTMENT_QA.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in out.items()if k not in ['files','bootstrap_replays','overlap_warning_summary']},ensure_ascii=False,indent=2))
