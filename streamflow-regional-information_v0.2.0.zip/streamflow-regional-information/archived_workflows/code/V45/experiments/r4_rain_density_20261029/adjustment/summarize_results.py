from pathlib import Path
import sys,json,hashlib
HERE=Path(__file__).resolve().parent
CODE=next(p for p in HERE.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=pd.read_csv(HERE.parent/'data/paired_rainfall_density_cases.csv.gz',keep_default_na=False,na_values=[''],low_memory=False)
d=d[(d.D==800)&(d.method=='ridge')&d.primary_P8083].copy()
s=pd.read_csv(HERE/'effect_estimates.csv')
w=pd.read_csv(HERE/'target_overlap_weights.csv.gz')
assert (HERE/'effect_estimates_before_NA_read_fix.csv').read_bytes()==(HERE/'effect_estimates.csv').read_bytes()
stage_names={'raw':'原始','reference':'参考条件','reference_climate':'参考条件＋气候/面积','synchronous_reference_climate':'实际同期报告＋气候/面积'}
metric_names={'delta_NSE':'ΔNSE中位数','delta_r':'Δr中位数','delta_success_NSE':'严格成功净增（百分点）','delta_success_r07':'r>0.7净增（百分点）'}
concentration=[]
for comp in ['Asia','Africa']:
 for st in stage_names:
  z=w[(w.comparator==comp)&(w.stage==st)].merge(d[['station_id','country','kg_major']],on='station_id',validate='many_to_one')
  for reg in ['Europe',comp]:
   q=z[z.continent==reg].copy();q['weight_fraction']=q.weight/q.weight.sum()
   for col in ['country','kg_major','spatial_cell']:
    g=q.groupby(col,dropna=False).weight_fraction.sum().sort_values(ascending=False)
    for lev,frac in g.items():concentration.append({'comparator':comp,'stage':st,'region':reg,'dimension':col,'level':lev,'weight_fraction':frac})
pd.DataFrame(concentration).to_csv(HERE/'weight_concentration.csv',index=False)
missing=[]
config=json.loads((HERE/'config.json').read_text())
for reg in ['Europe','Asia','Africa']:
 z=d[d.continent==reg]
 for k,t in (config['reference_numeric']|config['additional_numeric']).items():
  v=pd.to_numeric(z[k],errors='coerce').to_numpy(float);bad=~np.isfinite(v)
  if t=='log':bad|=v<=0
  elif t=='log1p':bad|=v<0
  missing.append({'region':reg,'covariate':k,'n':len(z),'missing_or_invalid':int(bad.sum())})
pd.DataFrame(missing).to_csv(HERE/'covariate_missingness.csv',index=False)
qa=[]
for comp in ['Asia','Africa']:
 for reg in ['Europe',comp]:
  z=d[d.continent==reg]
  for metric in metric_names:
   if metric in config['continuous_fields']:
    a=z.loc[z[config['continuous_fields'][metric]],metric].to_numpy(float);v=np.median(a[np.isfinite(a)])
   else:v=z[metric].mean()
   found=s[(s.comparator==comp)&(s.stage=='raw')&(s.region==reg)&(s.metric==metric)].estimate.iloc[0]
   assert abs(v-found)<1e-12
   qa.append({'comparator':comp,'region':reg,'metric':metric,'raw_recompute':float(v),'difference':float(v-found)})
assert len(w)==(1258+302)*4+(1258+97)*4
assert w.groupby(['comparator','stage','station_id']).size().max()==1
assert (w.weight>0).all() and (w.weight<=1).all()
diagnostics={c:json.loads((HERE/f'diagnostics_{c}.json').read_text()) for c in ['Asia','Africa']}
assert all(len(q['failures'])==0 for q in diagnostics.values())
receipt={'status':'PASS','tests':{'NA_metadata_read_fix_leaves_effects_byte_identical':True,'raw_effects_recomputed':qa,
 'all_fixed_pair_targets_retained_in_every_stage':True,'all_overlap_weights_positive_and_bounded':True,'zero_bootstrap_fit_failures':True},
 'data_sha256':sha(HERE.parent/'data/paired_rainfall_density_cases.csv.gz'),'effects_sha256':sha(HERE/'effect_estimates.csv'),
 'weights_sha256':sha(HERE/'target_overlap_weights.csv.gz'),'script_sha256':sha(HERE/'run_adjustment.py')}
(HERE/'INTERNAL_QA.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')

lines=['# 降雨收益的洲际条件比较：完整结果',
'',
'这次分析回答的是：欧洲与亚洲、非洲的加雨收益差异，在参考信息与水文气候条件较接近的目标之间是否仍然存在。它不是密度的因果实验，也不是新的降雨重构模型。',
'',
'**主要结果：欧洲—亚洲的连续精度增益差异随条件调整收缩，但完整调整仅覆盖一个很窄的可比目标总体；欧洲—非洲缺乏充分共同条件，不能据此给出可靠的全洲调整结论。不能把“差异收缩”写成密度或气候解释了多少比例的收益。**',
'',
'## 样本与事先方案',
'',
'保留固定 P8083 母队列，D800、ridge、H60/G120、源资格及原成功定义均不变。欧洲1,258站、亚洲302站、非洲97站全部进入各自比较，没有按收益或拟合成功挑子样本。ΔNSE的有限配对分别为1,258/302/97；Δr为1,258/302/96。合法回退保留。严格成功净增的分母保持全部目标；严格成功指原冻结的 NSE≥0.5、优于季节基线且有实际拟合及参考贡献，r>0.7另列，二者不混用。',
'',
'在读取逐站收益前冻结三种比较，随后仍在读取收益前加入第四种同期报告计数核查。两次配置和脚本均保留。第一种等权；第二种调整历史合格来源丰富程度、实际选中距离、H相关和训练长度；第三种再加官方估计面积、宽气候类及H期降雨均值/CV/季节性；第四种把历史合格计数换成G120中全部同期合法合格源的月均报告数。800 km内报告数是撤源前背景，D800下内圈实际输入为零。',
'',
'逻辑回归只拟合洲别、不使用目标收益或基线精度。L2、C=1，重叠权重为欧洲1−p、比较地区p；数值缺失中位数填补并设指示，气候one-hot。两洲共享唯一5°格网抽样池，1,000次重采样均重做预处理和权重拟合；全部拟合成功。95%区间为区块bootstrap百分位区间。',
'',
'## 欧洲减比较地区的收益差异',
'',
'以下ΔNSE/Δr均为“逐站加雨收益的地区中位数”之差；成功率为地区净增率之差。原始与调整结果对应的目标权重不同，因此不是可直接相减的机制贡献分解。',
'']
for comp in ['Asia','Africa']:
 lines += ['### 欧洲—'+('亚洲' if comp=='Asia' else '非洲'),'','| 条件 | 指标 | 欧洲减比较地区 | 95%区间 |','|---|---|---:|---:|']
 for st in stage_names:
  for met in metric_names:
   row=s[(s.comparator==comp)&(s.stage==st)&(s.metric==met)&(s.region=='difference')].iloc[0]
   scale=100 if met.startswith('delta_success') else 1
   digits=2 if scale==100 else 4
   lines.append(f"| {stage_names[st]} | {metric_names[met]} | {row.estimate*scale:.{digits}f} | [{row.ci_low*scale:.{digits}f}, {row.ci_high*scale:.{digits}f}] |")
 lines += ['']
lines += ['## 共同支撑与代表性决定哪些结果可以解释','','| 比较 | 调整 | 最大绝对SMD | 欧洲ESS / 比较地区ESS | 共享中心范围覆盖比例：欧洲 / 比较地区 |','|---|---|---:|---:|---:|']
for comp in ['Asia','Africa']:
 for st in ['reference','reference_climate','synchronous_reference_climate']:
  q=diagnostics[comp]['stages'][st];e=q['regions']['Europe'];c=q['regions']['Comparator']
  lines.append(f"| 欧洲—{comp} | {stage_names[st]} | {q['max_abs_adjusted_SMD']:.3f} | {e['ESS']:.1f} / {c['ESS']:.1f} | {100*e['unweighted_fraction_in_central_common_interval']:.1f}% / {100*c['unweighted_fraction_in_central_common_interval']:.1f}% |")
lines += ['',
'欧洲—亚洲参考条件模型把最大SMD降至0.032，但共享中心范围仅含15.7%的欧洲原样本。加入气候/面积后，协变量均值平衡尚可（最大SMD0.090；实际同期版0.083），同时权重集中：亚洲有效站数约74–76、空间格网权重ESS仅约4。实际同期版中，亚洲约86.1%的权重来自日本、13.3%来自俄罗斯，印度约0.6%；两洲权重约74%集中于宽气候D类。这不是整个亚洲与整个欧洲的等条件比较。',
'',
'欧洲—非洲完整调整的ESS降至约24/22，最大SMD仍0.46–0.52，且两组1%–99%倾向得分区间无交集。非洲原样本仅16个5°格网，97站中77站南非、16站纳米比亚。完整调整后，非洲约99.96%的权重落在南非，欧洲大部分权重落在西班牙。该调整没有构造出足够平衡的全洲比较，不能用仍为正的区间声称气候和信息条件相同后欧洲仍有优势。',
'',
'## 可据此写什么',
'',
'1. 原始样本中欧洲加雨收益更大，这是直接描述性结果；本轮重现欧洲逐站ΔNSE中位数0.1470，亚洲0.0202，非洲0.0062。',
'2. 欧洲—亚洲的连续收益差距对参考条件、气候与面积的样本构成敏感。条件权重下ΔNSE差距缩小，提示原始洲际对比包含显著的条件构成差异；不能因此认定“欧洲的高密度导致降雨更有效”。',
'3. 即使欧洲—亚洲的ΔNSE中位数差异在完整调整后接近零，严格成功净增差异仍约10个百分点。这是不同统计量，涉及是否跨越固定阈值；本轮没有以基线精度调整，也不能把该差异解释为纯粹的信息转移机制。',
'4. 非洲完整条件比较的识别基础不足，比一个看似显著的调整系数更值得披露。该样本无法支持对整个非洲的条件推断。',
'',
'## 建议放置',
'',
'先作为SI的条件核查。正文如需一句，应聚焦“洲际收益差异不能脱离参考条件和样本覆盖解释”，同时交代亚洲/非洲可比样本有限。不要声称通过本分析已证明站网密度的因果机制、消除了地域差异或估计出整个大陆在相同条件下的反事实收益。',
'',
'## 留存文件',
'',
'- `effect_estimates.csv`：所有地区、所有统计量、全部四种条件及区间。',
'- `bootstrap_draw_results.csv.gz`：全部1,000次空间重采样结果，含所有null/负向结果。',
'- `target_overlap_weights.csv.gz`：每个比较/条件的全部目标权重和倾向分数。',
'- `covariate_balance.csv`、`covariate_missingness.csv`、`weight_concentration.csv`：平衡、缺失及国别/气候/格网权重分布。',
'- `diagnostics_Asia.json`、`diagnostics_Africa.json`：共享范围、ESS、格网数及所有预设警示。',
'- `PRE_FIT_FREEZE_v1.json`、`PRE_FIT_FREEZE_v2.json`、`config.json`、`INPUT_RECEIPT.json`、`RUN_RECEIPT.json`、`INTERNAL_QA.json`：方案、输入及实现审计。',
'',
'本轮未修改正文、SI或论文图件。']
(HERE/'洲际降雨收益_条件比较结果.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
print('REPORT_AND_INTERNAL_QA_WRITTEN')
