"""Frozen retrospective Europe/Asia/Africa rainfall-gain overlap comparison."""
from pathlib import Path
import os, sys, json, hashlib, time, argparse
from datetime import datetime, timezone
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
HERE=Path(__file__).resolve().parent
CODE=next(p for p in HERE.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd
from scipy.special import expit
from scipy.optimize import minimize

DATA=HERE.parent/'data/paired_rainfall_density_cases.csv.gz'
EXPOSURE=HERE.parent/'exposures/exposure_summary.csv'
CONFIG={
 'created_utc':datetime.now(timezone.utc).isoformat(),
 'scope':{'primary_P8083':True,'D':800,'method':'ridge','comparators':['Asia','Africa']},
 'seed':20261029,'bootstrap_replicates':1000,'logistic_C':1.0,
 'continuous_fields':{'delta_NSE':'paired_valid_NSE','delta_r':'paired_valid_r'},
 'binary_fields':['delta_success_NSE','delta_success_r07'],
 'reference_numeric':{
  'eligible_near800':'log1p','eligible_remaining800':'log1p',
  'selected_G_distance_median_km':'log',
  'selected_H_historical_r_mean':'identity','train_months':'identity'},
 'additional_numeric':{'official_estimated_area_km2':'log',
  'p_H_mean_mm_per_month':'log1p','p_H_cv':'identity','p_H_seasonality_cv':'identity'},
 'additional_categorical':['kg_major'],
 'synchronous_count_replacement':{'eligible_near800':'within800_mean','eligible_remaining800':'beyond800_mean'},
 'stages':['raw','reference','reference_climate','synchronous_reference_climate'],
 'missing':'Weighted-median numeric imputation and explicit missing indicators; categorical Missing level.',
 'bootstrap':'Pooled unique original spatial_cell blocks, common multinomial draw across regions and models; preprocessing and logistic fit refitted every draw.',
 'weighted_median':'Inverse weighted CDF; exactly half total weight gives midpoint of adjacent values. Uniform weights reproduce numpy median.',
 'balance':'SMD numerator is current weighted difference; denominator fixed unweighted pooled within-region SD of transformed/imputed original covariate.',
 'fit_objective':'sum(sample_weight*(logaddexp(0,eta)-y*eta)) + sum(beta^2)/(2*C); intercept unpenalized',
 'flags':{'abs_SMD':0.1,'ESS':50,'contributing_cells':20,'central_overlap_fraction':0.5},
}

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for a in iter(lambda:f.read(2**20),b''):h.update(a)
 return h.hexdigest()

def save(p,x):
 def clean(a):
  if isinstance(a,dict):return {str(k):clean(v) for k,v in a.items()}
  if isinstance(a,(list,tuple,np.ndarray)):return [clean(v) for v in a]
  if isinstance(a,np.generic):return clean(a.item())
  if isinstance(a,float) and not np.isfinite(a):return None
  return a
 Path(p).write_text(json.dumps(clean(x),indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf8')

def boolean(s):
 if pd.api.types.is_bool_dtype(s):return s.fillna(False).to_numpy(bool)
 return s.astype(str).str.lower().isin(['true','1','1.0']).to_numpy()

def weighted_median(x,w):
 ok=np.isfinite(x)&np.isfinite(w)&(w>0)
 if not ok.any():return np.nan
 a=np.asarray(x)[ok];v=np.asarray(w)[ok];o=np.argsort(a,kind='stable');a=a[o];v=v[o]
 c=np.cumsum(v);half=c[-1]/2;k=min(np.searchsorted(c,half),len(c)-1)
 if k+1<len(c) and np.isclose(c[k],half,rtol=1e-13,atol=0):return float((a[k]+a[k+1])/2)
 return float(a[k])

def transform(x,t):
 x=pd.to_numeric(x,errors='coerce').to_numpy(dtype=float,copy=True)
 x[~np.isfinite(x)]=np.nan
 if t=='log':x[x<=0]=np.nan;return np.log(x)
 if t=='log1p':x[x<0]=np.nan;return np.log1p(x)
 return x

class Covariates:
 def __init__(self,d,stage):
  spec=dict(CONFIG['reference_numeric'])
  cats=[]
  if stage in ['reference_climate','synchronous_reference_climate']:spec.update(CONFIG['additional_numeric']);cats=CONFIG['additional_categorical']
  if stage=='synchronous_reference_climate':
   for old,new in CONFIG['synchronous_count_replacement'].items():spec[new]=spec.pop(old)
  self.numeric={k:transform(d[k],v) for k,v in spec.items()}
  self.cat={k:d[k].fillna('Missing').astype(str).replace({'nan':'Missing','':'Missing'}).to_numpy() for k in cats}
  self.levels={k:sorted(set(x)) for k,x in self.cat.items()}
 def matrix(self,freq):
  cols=[];names=[];params={}
  for k,x in self.numeric.items():
   valid=np.isfinite(x)&(freq>0)
   med=weighted_median(x[valid],freq[valid]) if valid.any() else 0.
   a=np.where(np.isfinite(x),x,med)
   cols.extend([a,(~np.isfinite(x)).astype(float)])
   names.extend([k,k+'__missing']);params[k]={'imputation':med}
  for k,x in self.cat.items():
   for lev in self.levels[k]:cols.append((x==lev).astype(float));names.append(k+'='+lev)
  raw=np.column_stack(cols)
  mu=np.average(raw,axis=0,weights=freq)
  sd=np.sqrt(np.average((raw-mu)**2,axis=0,weights=freq));sd[sd<1e-12]=1
  return (raw-mu)/sd,raw,names,{'imputation':params,'means':mu,'scales':sd}

def fit_logistic(X,y,freq):
 n,p=X.shape;A=np.column_stack([np.ones(n),X]);C=CONFIG['logistic_C']
 def fg(b):
  eta=A@b;pr=expit(eta)
  f=np.dot(freq,np.logaddexp(0,eta)-y*eta)+np.dot(b[1:],b[1:])/(2*C)
  g=A.T@(freq*(pr-y));g[1:]+=b[1:]/C
  return f,g
 b=np.zeros(p+1);prev=np.average(y,weights=freq)
 if not 0<prev<1:raise ValueError('bootstrap has only one region')
 b[0]=np.log(prev/(1-prev))
 z=minimize(fg,b,jac=True,method='L-BFGS-B',options={'maxiter':500,'ftol':1e-12,'gtol':1e-7})
 grad=float(np.max(np.abs(fg(z.x)[1])))
 if (not z.success) or grad>0.002:raise RuntimeError(f'logistic convergence: {z.message}; maxgrad={grad}')
 return expit(A@z.x),z.x,{'iterations':int(z.nit),'max_gradient':grad,'objective':float(z.fun)}

def effect_metrics(d):
 out={}
 for k,flag in CONFIG['continuous_fields'].items():
  x=pd.to_numeric(d[k],errors='coerce').to_numpy(dtype=float,copy=True);x[~boolean(d[flag])]=np.nan;out[k]=x
 for k in CONFIG['binary_fields']:
  x=pd.to_numeric(d[k],errors='coerce').to_numpy(float)
  assert np.isfinite(x).all() and set(x)<=set([-1,0,1]),(k,'frozen binary data invalid')
  out[k]=x
 return out

def summarize(y,w,effects):
 a={}
 for metric,x in effects.items():
  for region,mask in [('Europe',y==1),('Comparator',y==0)]:
   ok=mask&np.isfinite(x)&(w>0)
   a[metric+'__'+region]=(weighted_median(x[ok],w[ok]) if metric in CONFIG['continuous_fields'] else float(np.average(x[ok],weights=w[ok]))) if ok.any() else np.nan
  a[metric+'__difference']=a[metric+'__Europe']-a[metric+'__Comparator']
 return a

def ess(w):
 return float(w.sum()**2/np.dot(w,w)) if np.dot(w,w)>0 else 0.

def diagnostics(d,y,w,prop,raw,names,effects,cellid):
 balance=[]
 for j,name in enumerate(names):
  x=raw[:,j];e=x[y==1];c=x[y==0]
  sd=np.sqrt((np.var(e,ddof=1)+np.var(c,ddof=1))/2)
  before=float(e.mean()-c.mean());after=float(np.average(e,weights=w[y==1])-np.average(c,weights=w[y==0]))
  balance.append({'covariate':name,'raw_mean_Europe':e.mean(),'raw_mean_comparator':c.mean(),
   'adjusted_mean_Europe':np.average(e,weights=w[y==1]),'adjusted_mean_comparator':np.average(c,weights=w[y==0]),
   'raw_SMD':before/sd if sd>1e-12 else 0.,'adjusted_SMD':after/sd if sd>1e-12 else 0.})
 q={reg:np.quantile(prop[mask],[0,.01,.05,.25,.5,.75,.95,.99,1]).tolist() for reg,mask in [('Europe',y==1),('Comparator',y==0)]}
 lo=max(q['Europe'][1],q['Comparator'][1]);hi=min(q['Europe'][-2],q['Comparator'][-2])
 report={'propensity_quantiles_0_1_5_25_50_75_95_99_100':q,'central_common_interval':[lo,hi],
  'max_abs_raw_SMD':max((abs(v['raw_SMD']) for v in balance),default=0),
  'max_abs_adjusted_SMD':max((abs(v['adjusted_SMD']) for v in balance),default=0),'regions':{},'warnings':[]}
 if report['max_abs_adjusted_SMD']>0.1:report['warnings'].append('Residual covariate imbalance exceeds |SMD|=0.1.')
 for reg,mask in [('Europe',y==1),('Comparator',y==0)]:
  cw=np.bincount(cellid[mask],weights=w[mask]);rr={'n':int(mask.sum()),'weight_sum':w[mask].sum(),'ESS':ess(w[mask]),
   'contributing_spatial_cells':int(np.count_nonzero(cw)),'cell_weight_ESS':ess(cw),
   'unweighted_fraction_in_central_common_interval':float(np.mean((prop[mask]>=lo)&(prop[mask]<=hi))) if hi>=lo else 0.,
   'metrics':{}}
  for met,x in effects.items():
   valid=mask&np.isfinite(x);rr['metrics'][met]={'finite_n':int(valid.sum()),'missing_n':int((mask&~np.isfinite(x)).sum()),
    'valid_weight_fraction':float(w[valid].sum()/w[mask].sum()),'ESS':ess(w[valid])}
  report['regions'][reg]=rr
  if rr['ESS']<50:report['warnings'].append(reg+' ESS < 50.')
  if rr['contributing_spatial_cells']<20:report['warnings'].append(reg+' has fewer than 20 contributing cells.')
  if rr['unweighted_fraction_in_central_common_interval']<.5:report['warnings'].append(reg+' central common-support coverage < 50%.')
 return balance,report

def synthetic_checks():
 rng=np.random.default_rng(52);x=rng.normal(size=200);w=np.ones(200)
 assert weighted_median(x,w)==np.median(x)
 assert weighted_median(np.array([1.,2.,3.]),np.array([1.,1.,2.]))==2.5
 for scale in [1e-15,1.,1e15]:
  assert weighted_median(np.array([0.,10.,100.]),np.array([.6,.2,.2])*scale)==0.
  assert weighted_median(np.array([1.,2.,3.]),np.array([1.,1.,2.])*scale)==2.5
 X=rng.normal(size=(400,3));y=(rng.uniform(size=400)<expit(.3+X[:,0])).astype(float)
 p,b,z=fit_logistic(X,y,np.ones(400));assert b[1]>0 and z['max_gradient']<.002
 # Multiplicity weights must be equivalent to explicitly repeating sampled rows.
 f=rng.integers(0,4,size=400);pp,bb,zz=fit_logistic(X,y,f)
 ix=np.repeat(np.arange(400),f);pp2,bb2,zz2=fit_logistic(X[ix],y[ix],np.ones(len(ix)))
 assert np.max(np.abs(bb-bb2))<1e-5
 return {'weighted_median_uniform':'PASS','weighted_median_exact_half':'PASS','weighted_median_weight_scale_invariance':'PASS','logistic_signal':'PASS','logistic_cluster_multiplicity':'PASS'}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--freeze',action='store_true');ap.add_argument('--amend-freeze',action='store_true');ap.add_argument('--replicates',type=int,default=1000);args=ap.parse_args()
 if args.amend_freeze:
  assert (HERE/'PRE_FIT_FREEZE_v1.json').exists() and not (HERE/'PRE_FIT_FREEZE_v2.json').exists()
  save(HERE/'config.json',CONFIG)
  receipt={'created_utc':datetime.now(timezone.utc).isoformat(),'config_sha256':sha(HERE/'config.json'),'protocol_sha256':sha(HERE/'PROTOCOL.md'),'script_sha256':sha(__file__),'synthetic_checks':synthetic_checks(),'outcomes_read':False,'amendment':'Add independently computed all-qualified synchronous reporter counts, retaining original 3 models.'}
  save(HERE/'PRE_FIT_FREEZE_v2.json',receipt);save(HERE/'PRE_FIT_FREEZE.json',receipt)
  print('PRE_FIT_FREEZE_V2',flush=True);return
 if args.freeze:
  assert not (HERE/'config.json').exists();save(HERE/'config.json',CONFIG)
  save(HERE/'PRE_FIT_FREEZE.json',{'created_utc':datetime.now(timezone.utc).isoformat(),'config_sha256':sha(HERE/'config.json'),'protocol_sha256':sha(HERE/'PROTOCOL.md'),'script_sha256':sha(__file__),'synthetic_checks':synthetic_checks(),'outcomes_read':False})
  print('PRE_FIT_FREEZE',flush=True);return
 frozen=json.loads((HERE/'config.json').read_text(encoding='utf8'))
 # Timestamps are metadata only; operational configuration must match frozen values.
 for k in CONFIG:
  if k!='created_utc':assert CONFIG[k]==frozen[k],k
 assert args.replicates==CONFIG['bootstrap_replicates']
 start=time.time();d=pd.read_csv(DATA,low_memory=False,keep_default_na=False,na_values=[''])
 d=d[(d.D==800)&(d.method=='ridge')&boolean(d.primary_P8083)].copy()
 assert len(d)==8083 and d.station_id.nunique()==8083
 assert 'spatial_cell' in d and d.spatial_cell.notna().all()
 assert (EXPOSURE.parent/'EXPOSURES_COMPLETE.json').exists() and (EXPOSURE.parent/'INDEPENDENT_DIRECT_COUNT_QA.json').exists()
 exposure=pd.read_csv(EXPOSURE,keep_default_na=False,na_values=[''])
 keys=['row','station_id','raw_index'];cols=list(CONFIG['synchronous_count_replacement'].values())
 d=d.merge(exposure[keys+cols],on=keys,how='left',validate='one_to_one')
 assert d[cols].notna().all().all()
 save(HERE/'INPUT_RECEIPT.json',{'dataset':str(DATA),'sha256':sha(DATA),'exposure_path':str(EXPOSURE),'exposure_sha256':sha(EXPOSURE),'rows_primary':len(d),'continent_counts':d.continent.value_counts().to_dict(),'script_sha256':sha(__file__),'config_sha256':sha(HERE/'config.json'),'synthetic_checks':synthetic_checks()})
 allsummary=[];allbalance=[];allboot=[];allweights=[];alldiag={};allparams={}
 for ci,comp in enumerate(CONFIG['scope']['comparators']):
  z=d[d.continent.isin(['Europe',comp])].copy().sort_values('station_id').reset_index(drop=True)
  y=(z.continent=='Europe').to_numpy(float);effects=effect_metrics(z)
  cells,cellid=np.unique(z.spatial_cell.astype(str),return_inverse=True);nc=len(cells)
  assert np.any(y==1) and np.any(y==0)
  rng=np.random.default_rng(CONFIG['seed']+ci)
  draws=rng.multinomial(nc,np.full(nc,1/nc),size=args.replicates)
  outboot={};covs={};orig={};diagn={};params={}
  basecov=Covariates(z,'reference_climate');_,base_raw,base_names,_=basecov.matrix(np.ones(len(z)))
  for stage in CONFIG['stages']:
   if stage=='raw':p=np.full(len(z),y.mean());w=np.ones(len(z));raw=base_raw;names=base_names
   else:
    covs[stage]=Covariates(z,stage);X,raw,names,prep=covs[stage].matrix(np.ones(len(z)))
    p,coef,fit=fit_logistic(X,y,np.ones(len(z)));w=np.where(y==1,1-p,p);params[stage]={'fit':fit,'coefficients':dict(zip(['intercept']+names,coef)),'preprocessing':prep}
   orig[stage]=summarize(y,w,effects)
   bal,diag=diagnostics(z,y,w,p,raw,names,effects,cellid);diagn[stage]=diag
   for b in bal:b.update(comparator=comp,stage=stage);allbalance.append(b)
   wt=z[['station_id','continent','spatial_cell']].copy();wt['comparator']=comp;wt['stage']=stage;wt['propensity_Europe']=p;wt['weight']=w;allweights.append(wt)
   outboot[stage]=[]
  failures=[]
  for bi,draw in enumerate(draws):
   freq=draw[cellid].astype(float)
   for stage in CONFIG['stages']:
    try:
     if stage=='raw':w=freq
     else:
      X,_,_,_=covs[stage].matrix(freq);p,_,fit=fit_logistic(X,y,freq);w=freq*np.where(y==1,1-p,p)
     row=summarize(y,w,effects);row.update(comparator=comp,stage=stage,replicate=bi);outboot[stage].append(row)
    except Exception as e:failures.append({'comparator':comp,'stage':stage,'replicate':bi,'error':str(e)})
   if (bi+1)%100==0:print(f'{comp}: {bi+1}/{args.replicates}, elapsed {time.time()-start:.1f}s; failures {len(failures)}',flush=True)
  for stage in orig:
   bb=pd.DataFrame(outboot[stage]);allboot.extend(outboot[stage])
   for key,val in orig[stage].items():
    metric,region=key.split('__');xx=bb[key].dropna().to_numpy()
    row={'comparator':comp,'stage':stage,'metric':metric,'region':comp if region=='Comparator' else region,'estimate':val,
      'ci_low':np.quantile(xx,.025) if len(xx) else np.nan,'ci_high':np.quantile(xx,.975) if len(xx) else np.nan,'successful_bootstraps':len(xx),'requested_bootstraps':args.replicates}
    allsummary.append(row)
  alldiag[comp]={'n_unique_spatial_cells':nc,'stages':diagn,'failures':failures};allparams[comp]=params
  save(HERE/f'diagnostics_{comp}.json',alldiag[comp]);save(HERE/f'fit_parameters_{comp}.json',params)
  pd.DataFrame(allsummary).to_csv(HERE/'effect_estimates.csv',index=False)
  pd.DataFrame(allboot).to_csv(HERE/'bootstrap_draw_results.csv.gz',index=False,compression='gzip')
  pd.DataFrame(allbalance).to_csv(HERE/'covariate_balance.csv',index=False)
  pd.concat(allweights,ignore_index=True).to_csv(HERE/'target_overlap_weights.csv.gz',index=False,compression='gzip')
  print('COMPLETED',comp,flush=True)
 save(HERE/'RUN_RECEIPT.json',{'status':'COMPLETE','created_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.time()-start,'bootstrap_replicates':args.replicates,'data_sha256':sha(DATA),'config_sha256':sha(HERE/'config.json'),'script_sha256':sha(__file__),'outputs':{p.name:sha(p) for p in HERE.iterdir() if p.suffix in ['.csv','.gz','.json'] and p.name!='RUN_RECEIPT.json'}})

if __name__=='__main__':main()
