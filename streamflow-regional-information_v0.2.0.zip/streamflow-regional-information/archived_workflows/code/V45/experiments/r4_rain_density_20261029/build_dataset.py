"""Build an outcome-preserving, paired dataset from the frozen R4 experiment.

No model fits, outcome aggregation, threshold search, or prediction modification.
Every source array is opened read-only. H denotes the original 60-month history;
G denotes the following 120-month target gap. G source descriptors use lawful
source reports only, never the target's withheld observations.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys
import warnings

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CODE = next(p for p in HERE.parents if p.name == 'code')
sys.path.insert(0, str(CODE / 'V42/dependencies'))
import numpy as np
import pandas as pd

ROOT = CODE / 'V45/experiments'
BASE = ROOT / 'r4_full_source_gradient_20261026'
PRED = BASE / 'predictions'
PREP = ROOT / 'r4_global_information_20261025/prepared_inputs'
FINALP = ROOT / 'r4_global_information_20261025/final_inputs'
META = ROOT / 'r4_global_siting_20261026/census/metadata_enrichment_v3/global_station_metadata.csv'
OUT = HERE / 'data'
DS = (0, 100, 300, 800)
METHODS = ('ridge', 'rbf_ridge')
N = 8898
SOURCES = {}
DEFINITIONS = {}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def register(path, role):
    path = Path(path)
    if str(path) not in SOURCES:
        SOURCES[str(path)] = {'sha256': sha(path), 'bytes': path.stat().st_size, 'role': role}
    return path


def load_array(name):
    path = register(PRED / (name + '.npy'), 'Frozen prediction-side input/flag array; read-only')
    return np.load(path, mmap_mode='r')


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, np.ndarray)):
        return [clean(v) for v in value]
    if isinstance(value, np.generic):
        return clean(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def save_json(path, value):
    Path(path).write_text(json.dumps(clean(value), ensure_ascii=False, indent=2,
                                   allow_nan=False) + '\n', encoding='utf-8')


def csv(path, **kwargs):
    register(path, 'Frozen source table')
    return pd.read_csv(path, keep_default_na=False, low_memory=False, **kwargs)


def define(column, description, source, units=None, timing=None):
    DEFINITIONS[column] = dict(description=description, source=source)
    if units is not None:
        DEFINITIONS[column]['units'] = units
    if timing is not None:
        DEFINITIONS[column]['timing'] = timing


def correlation(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    valid = np.isfinite(x) & np.isfinite(y)
    count = valid.sum(1)
    xx, yy = np.where(valid, x, 0), np.where(valid, y, 0)
    den = np.maximum(count, 1)
    dx = np.where(valid, x - xx.sum(1)[:, None] / den[:, None], 0)
    dy = np.where(valid, y - yy.sum(1)[:, None] / den[:, None], 0)
    scale = np.sqrt((dx * dx).sum(1) * (dy * dy).sum(1))
    return np.divide((dx * dy).sum(1), scale, out=np.full(len(x), np.nan),
                     where=(count >= 3) & (scale > 1e-24))


def source_features(cases):
    eligible = load_array('eligible_source_counts')
    counts = load_array('counts')
    distance = load_array('selected_distance')
    historical_r = load_array('selected_r')
    ids = load_array('selected_ids')
    training = load_array('training_mask')
    assert eligible.shape == (N, 4)
    assert counts.shape == (N, 4, 180)
    assert distance.shape == historical_r.shape == ids.shape == (N, 4, 180, 4)
    assert training.shape == (N, 4, 60)
    assert np.all(eligible >= 0) and np.all(np.diff(eligible, axis=1) <= 0)
    assert np.all((counts >= 0) & (counts <= 4))
    assert np.all(np.diff(counts.astype(int), axis=1) <= 0)
    frames = []
    for di, D in enumerate(DS):
        record = {'row': np.arange(N), 'D': np.full(N, D),
                  'eligible_current': np.asarray(eligible[:, di]),
                  'train_months': training[:, di].sum(1)}
        for j, level in enumerate(DS):
            record[f'eligible_N_D{level}'] = np.asarray(eligible[:, j])
        record.update(eligible_near100=eligible[:, 0] - eligible[:, 1],
                      eligible_ring100_300=eligible[:, 1] - eligible[:, 2],
                      eligible_ring300_800=eligible[:, 2] - eligible[:, 3],
                      eligible_near800=eligible[:, 0] - eligible[:, 3],
                      eligible_remaining800=np.asarray(eligible[:, 3]))
        for period, sl in (('H', slice(0, 60)), ('G', slice(60, 180))):
            cc = np.asarray(counts[:, di, sl])
            dd = np.asarray(distance[:, di, sl])
            rr = np.asarray(historical_r[:, di, sl])
            ii = np.asarray(ids[:, di, sl])
            active = ii >= 0
            assert np.array_equal(active.sum(2), cc)
            assert np.isfinite(dd[active]).all() and np.isfinite(rr[active]).all()
            assert np.all((rr[active] > 0) & (rr[active] <= 1))
            if D:
                assert np.all(dd[active] > D)
            dd = np.where(active, dd, np.nan)
            rr = np.where(active, rr, np.nan)
            weights = np.where(active, rr, 0)
            denom = weights.sum(2)
            weighted_distance = np.divide(np.nansum(dd * weights, 2), denom,
                out=np.full(denom.shape, np.nan), where=denom > 0)
            weighted_r = np.divide(np.nansum(rr * weights, 2), denom,
                out=np.full(denom.shape, np.nan), where=denom > 0)
            with warnings.catch_warnings():
                warnings.simplefilter('ignore', RuntimeWarning)
                for statistic, func in (('mean', np.nanmean), ('median', np.nanmedian)):
                    record[f'selected_{period}_distance_{statistic}_km'] = func(dd, axis=(1, 2))
                    record[f'selected_{period}_historical_r_{statistic}'] = func(rr, axis=(1, 2))
                    record[f'selected_{period}_distance_weighted_{statistic}_km'] = func(weighted_distance, axis=1)
                    record[f'selected_{period}_historical_r_weighted_{statistic}'] = func(weighted_r, axis=1)
                record[f'selected_{period}_fraction_slots_over800'] = np.divide(
                    np.sum(active & (dd > 800), axis=(1, 2)), active.sum(axis=(1, 2)),
                    out=np.full(N, np.nan), where=active.sum(axis=(1, 2)) > 0)
            record[f'selected_{period}_unique_sources'] = np.array([
                len(np.unique(row[row >= 0])) for row in ii], dtype=int)
            record[f'K4_{period}_count_mean'] = cc.mean(1)
            record[f'K4_{period}_count_median'] = np.median(cc, axis=1)
            record[f'K4_{period}_count_min'] = cc.min(1)
            record[f'K4_{period}_count_max'] = cc.max(1)
            record[f'K4_{period}_count_q25'] = np.quantile(cc, .25, axis=1)
            record[f'K4_{period}_count_q75'] = np.quantile(cc, .75, axis=1)
            record[f'K4_{period}_reporting_months'] = (cc > 0).sum(1)
            for k in range(5):
                record[f'K4_{period}_fraction_count{k}'] = (cc == k).mean(1)
        assert np.array_equal(record['train_months'], record['K4_H_reporting_months'])
        frames.append(pd.DataFrame(record))
    result = pd.concat(frames, ignore_index=True)
    for name in result:
        if name.startswith('eligible_'):
            define(name, 'Number of H-qualified sources after the stated distance withdrawal, or disjoint circle counts by subtraction. H qualification: >=12 paired anomaly observations, positive H correlation, valid H transform and physical-target identity exclusion. D0 removes no source even if colocated. Not total geographic gauges or synchronous reporter density.', 'eligible_source_counts.npy; src/engine.py', 'sources', 'H-only eligibility and static distance')
        elif name.startswith('K4_'):
            define(name, 'Monthly selected input count summary, including zero-input months. Up to 4 per month; H=60, G=120. Not all available sources.', 'counts.npy', 'count or fraction', 'H or lawful source G reporting, as field prefix')
        elif name.startswith('selected_'):
            define(name, 'Selected source summary for H or G slots. Unweighted mean/median pools all valid selected slots; weighted summaries first use positive H correlation weights within each month, then equal-weight monthly mean/median across reporting months. All historical_r fields contain H qualification r, including G selections; none measures target-G agreement. unique_sources counts distinct selected physical raw rows in the stated interval. No-input descriptors remain NaN.', 'selected_ids.npy; selected_distance.npy; selected_r.npy; run_outage.py combine()', 'km, correlation, count or fraction as suffix', 'H qualification; H or lawful source G availability')
    define('train_months', 'Shared finite H target/composite rows used in both Q and QP fits at the same D; original training mask.', 'training_mask.npy', 'months', 'H-only')
    define('D', 'Withdraw sources at distance <=D km; 0 denotes no withdrawal, not withdrawal of colocated sources.', 'SCORING_INTERFACE.json', 'km')
    return result


def static_features(cases):
    metadata = csv(META)
    assert not metadata.raw_index.duplicated().any()
    source_cols = ['raw_index', 'station_id', 'continent_display', 'country_display',
        'kg_major', 'kg_code', 'climate_id', 'official_area_km2',
        'official_estimated_area_km2', 'official_area_source', 'official_catchment_quality',
        'official_area_band', 'area_km2', 'area_band', 'header_river', 'header_station',
        'header_country_original', 'official_country_code', 'country_display_note',
        'continent_display_note', 'physical_group_id', 'physical_component_size']
    shared = cases[['row', 'case_id', 'raw_index', 'station_id', 'latitude', 'longitude',
                    'spatial_cell', 'outer_fold', 'history_start', 'history_end',
                    'gap_start', 'gap_end', 'H', 'L']].copy()
    meta = metadata[source_cols].rename(columns={'station_id': 'metadata_station_id',
        'continent_display': 'continent', 'country_display': 'country',
        'area_km2': 'legacy_header_area_numeric', 'area_band': 'legacy_header_area_band'})
    shared = shared.merge(meta, on='raw_index', how='left', validate='one_to_one')
    assert shared.metadata_station_id.eq(shared.station_id).all()
    shared = shared.drop(columns='metadata_station_id')
    shared['frozen_score_continent'] = cases.continent.to_numpy()
    shared['frozen_score_country'] = cases.country.to_numpy()
    shared['continent_changed_from_frozen_score'] = shared.continent.ne(shared.frozen_score_continent)
    shared['country_changed_from_frozen_score'] = shared.country.ne(shared.frozen_score_country)
    for field in ['official_area_km2', 'official_estimated_area_km2', 'legacy_header_area_numeric', 'climate_id']:
        shared[field] = pd.to_numeric(shared[field], errors='coerce')
    available = np.asarray(load_array('P_available'), bool)
    assert available.sum() == 8083
    shared['P_available'] = available
    shared['primary_P8083'] = available
    shared['target_risk'] = np.asarray(load_array('target_risk'), bool)
    for array_name in ['nearest_full_G_median_distance', 'nearest_far800_fraction_all_G',
                       'nearest_no_report_fraction', 'nearest_reported_month_count']:
        shared['D0_' + array_name] = np.asarray(load_array(array_name))
    ppath = register(PREP / 'PRECIPITATION_H_ONLY_INPUTS.npz', 'Frozen H-only transformed precipitation input')
    with np.load(ppath) as pp:
        ph = pp['p_h']
        assert ph.shape == (N, 60, 4)
        assert np.array_equal(pp['p_available'], available)
        shared['P_availability_reason'] = pp['p_reason']
        shared['P_geometry_admitted'] = pp['geometry_admitted']
    with np.load(register(FINALP / 'global8898_tp_197910_201512_ADMITTED.npz', 'Admitted precipitation units, source, and geometry flags; no G precipitation values used')) as rawp:
        assert np.array_equal(rawp['station_ids'], shared.station_id.to_numpy())
        assert np.array_equal(rawp['admission_mask'], available)
        units, product = str(rawp['units'].item()), str(rawp['source_product'].item())
        assert units == 'mm/month', units
        for field in ('geometry_warning_mask', 'agency_area_warning_mask', 'reach_scope_warning_mask',
                      'geometry_clean_mask', 'input_complete_mask'):
            shared['P_' + field] = rawp[field]
    # p_h is log1p(raw monthly catchment precipitation), not standardized anomalies.
    # Only contemporaneous lag0 H values are used for climatic summaries.
    raw_h = np.expm1(ph[:, :, 0])
    complete = np.isfinite(raw_h).all(1) & (raw_h >= 0).all(1)
    raw_h[~complete] = np.nan
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', RuntimeWarning)
        mean = np.mean(raw_h, axis=1)
        std = np.std(raw_h, axis=1, ddof=0)
        hmonths = shared.history_start.to_numpy(int)[:, None] + np.arange(60)[None, :]
        seasonal = np.stack([np.nanmean(np.where(hmonths % 12 == month, raw_h, np.nan), axis=1)
                             for month in range(12)], axis=1)
        seasonal_std = np.std(seasonal, axis=1, ddof=0)
        shared['p_H_mean_mm_per_month'] = mean
        shared['p_H_sd_mm_per_month'] = std
        shared['p_H_cv'] = np.divide(std, mean, out=np.full(N, np.nan), where=mean > 0)
        shared['p_H_seasonality_cv'] = np.divide(seasonal_std, mean,
                                                  out=np.full(N, np.nan), where=mean > 0)
        shared['p_H_seasonal_range_mm_per_month'] = np.max(seasonal, 1) - np.min(seasonal, 1)
        shared['p_H_lag1_r'] = correlation(raw_h[:, 1:], raw_h[:, :-1])
        shared['p_H_complete60'] = complete
    assert complete[available].all()
    for name in shared:
        if name not in DEFINITIONS:
            if name.startswith('p_H_'):
                define(name, 'H-only precipitation descriptor; invert lag0 log1p P with expm1. CV uses population SD/mean. seasonality_cv uses SD of 12 original-H arithmetic calendar-month means divided by their mean. Complete60 is required; no future target truth or G rainfall contributes. Lag1 r uses H months 2..60 versus 1..59.', 'PRECIPITATION_H_ONLY_INPUTS.npz p_h; transfer_model.py prepare_precipitation_lags()', 'mm/month, ratio, r or bool as suffix', 'H60 only')
            elif name in ('official_area_km2', 'official_estimated_area_km2'):
                define(name, 'Original reported official area or separately estimated official area, respectively. No coalescing or fallback between the two; estimated area is the designated main adjustment covariate.', str(META), 'km2', 'static metadata')
            elif name.startswith('legacy_header_area'):
                define(name, 'Legacy header numeric area/band; retained for provenance only. Original units/compatibility are not uniformly established. Do not use as standardized km2 adjustment.', str(META), 'not standardized')
            else:
                define(name, 'Exact canonical metadata join or frozen case/availability field. continent/country are latest display labels; original frozen score labels retained separately. P flags from admitted input and availability arrays.', str(META) + '; predictions/cases.csv; indicated prediction/prepared input arrays')
    return shared, {'rainfall_units': units, 'rainfall_product': product,
                   'continental_label_changes': int(shared.continent_changed_from_frozen_score.sum()),
                   'country_label_changes': int(shared.country_changed_from_frozen_score.sum())}


def paired_scores(cases):
    scores = csv(BASE / 'analysis/scores_long.csv.gz')
    identifiers = ['row', 'station_id', 'raw_index', 'latitude', 'longitude', 'continent',
                   'country', 'spatial_cell', 'outer_fold', 'history_start', 'history_end',
                   'gap_start', 'gap_end', 'P_available', 'target_risk', 'D', 'method', 'arm']
    outcome_columns = [c for c in scores if c not in identifiers]
    bool_columns = ['valid_truth', 'finite_prediction', 'nonnegative_prediction',
        'actual_model_estimable', 'eligible', 'undefined_r', 'undefined_H_deseasonal_r',
        'old_NSE_pass', 'NSE_below_minus100', 'r06_pass', 'numeric_r06', 'r07_pass',
        'numeric_r07', 'r08_pass', 'numeric_r08', 'full120_supported']
    for col in outcome_columns:
        if col in bool_columns:
            assert scores[col].dtype == bool, (col, str(scores[col].dtype))
        else:
            scores[col] = pd.to_numeric(scores[col], errors='coerce')
    assert len(scores) == N * 4 * 2 * 3
    key = ['row', 'D', 'method']
    frames = []
    for arm in ('Q', 'QP'):
        z = scores.loc[scores.arm.eq(arm), key + outcome_columns].copy()
        assert not z.duplicated(key).any()
        z = z.rename(columns={c: arm + '_' + c for c in outcome_columns})
        frames.append(z)
        for name in outcome_columns:
            define(arm + '_' + name, 'Unmodified original frozen metric/flag for ' + arm + '. eligible is valid truth, finite nonnegative prediction, actual fit and >0 supported G months; it is not success. old_NSE_pass additionally requires NSE>=0.5 and NSE>seasonal NSE. r07_pass additionally requires raw r>0.7; no NSE gate. H_deseasonal_r subtracts the H-derived target raw seasonal mean from target and prediction over G. All120 G months are scored, including fallback portions.', 'analysis/scores_long.csv.gz; trial_score_core.py metrics()', timing='G evaluation from frozen scores')
    result = frames[0].merge(frames[1], on=key, validate='one_to_one')
    result['paired_valid_truth'] = result.Q_valid_truth & result.QP_valid_truth
    result['paired_eligible'] = result.Q_eligible & result.QP_eligible
    for metric in ('NSE', 'r', 'H_deseasonal_r', 'alpha', 'delta', 'S',
                   'absolute_alpha_error', 'absolute_delta_error'):
        result['delta_' + metric] = result['QP_' + metric] - result['Q_' + metric]
        result['paired_valid_' + metric] = result.paired_valid_truth & np.isfinite(result['Q_' + metric]) & np.isfinite(result['QP_' + metric])
        define('delta_' + metric, 'QP minus Q, directly from original metrics; no clipping and no eligibility mask applied. Positive error-component changes are worse, unlike NSE/r increases.', 'paired frozen scores')
        define('paired_valid_' + metric, 'Both arms valid_truth and finite metric. This permits legal fallback and does NOT require actual fit or support. Use explicit masks rather than dropping rows.', 'paired frozen scores')
    for label, col in (('NSE', 'old_NSE_pass'), ('r07', 'r07_pass')):
        q, qp = result['Q_' + col], result['QP_' + col]
        result['delta_success_' + label] = qp.astype(np.int8) - q.astype(np.int8)
        result['new_success_' + label] = qp & ~q
        result['lost_success_' + label] = q & ~qp
        result['both_success_' + label] = q & qp
        for prefix in ('delta', 'new', 'lost', 'both'):
            define(prefix + '_success_' + label, 'Paired success transition from Q to QP using original ' + col + '. Delta is -1/0/+1; mean times100 is net percentage-point change. Full fixed mother denominator, not eligible-only denominator.', 'paired frozen scores')
    flags = load_array('flags')
    names = ('actual_fit', 'requested_fit', 'requested_source', 'fallback', 'uses_P_H',
             'uses_P_G_actual', 'uses_P_G_climatology')
    ri = result.row.to_numpy(int)
    di = result.D.map({d: i for i, d in enumerate(DS)}).to_numpy(int)
    mi = result.method.map({m: i for i, m in enumerate(METHODS)}).to_numpy(int)
    for ai, arm in enumerate(('Q', 'QP')):
        for fi, name in enumerate(names):
            result[arm + '_flag_' + name] = flags[ri, di, mi, ai, fi]
            define(arm + '_flag_' + name, 'Exact production flag; actual_fit may be Q fallback when requested QP unavailable. requested_fit/source distinguishes intended arm. No recomputation.', 'flags.npy; SCORING_INTERFACE.json')
        assert np.array_equal(result[arm + '_flag_actual_fit'], result[arm + '_actual_model_estimable'])
    for name in ('paired_valid_truth', 'paired_eligible'):
        define(name, 'Both original arm flags true. paired_valid_truth does not require fit/support; paired_eligible does.', 'paired frozen scores')
    return result


def write_csv(frame, name):
    path = OUT / name
    frame.to_csv(path, index=False, compression={'method': 'gzip', 'compresslevel': 6, 'mtime': 0})
    return dict(path=str(path), rows=len(frame), columns=len(frame.columns), sha256=sha(path), bytes=path.stat().st_size)


def main():
    OUT.mkdir(exist_ok=True)
    cases = csv(PRED / 'cases.csv')
    assert len(cases) == N and np.array_equal(cases.row, np.arange(N))
    assert cases.station_id.is_unique and cases.raw_index.is_unique
    assert (cases.history_end - cases.history_start).eq(60).all()
    assert (cases.gap_end - cases.gap_start).eq(120).all()
    assert cases.history_end.eq(cases.gap_start).all()
    print('Building static and H-only precipitation features', flush=True)
    static, provenance = static_features(cases)
    print('Building selected-reference H/G features', flush=True)
    inputs = source_features(cases)
    print('Pairing unchanged frozen Q and QP scores', flush=True)
    result = paired_scores(cases).merge(inputs, on=['row', 'D'], how='left', validate='many_to_one')
    result = result.merge(static, on='row', how='left', validate='many_to_one')
    result = result.sort_values(['D', 'method', 'row']).reset_index(drop=True)
    assert len(result) == N * 4 * 2 and not result.duplicated(['row', 'D', 'method']).any()
    group_n = result.groupby(['D', 'method']).agg(n=('row', 'size'), p=('primary_P8083', 'sum'))
    assert group_n.n.eq(N).all() and group_n.p.eq(8083).all()
    assert not result.station_id.isna().any()
    assert set(result.continent.unique()) <= {'Africa', 'Asia', 'Europe', 'NorthAmerica', 'Oceania', 'SouthAmerica', 'Other', 'UNK'}
    unavailable = ~result.primary_P8083
    for metric in ('NSE', 'r', 'H_deseasonal_r'):
        np.testing.assert_allclose(result.loc[unavailable, 'Q_' + metric],
                                   result.loc[unavailable, 'QP_' + metric], rtol=0, atol=0, equal_nan=True)
    for name in result:
        if name not in DEFINITIONS:
            define(name, 'Frozen case key or original method label; no redefinition.', 'predictions/cases.csv; SCORING_INTERFACE.json')
    print('Writing complete unfiltered paired dataset', flush=True)
    outputs = [write_csv(result, 'paired_rainfall_density_cases.csv.gz'),
               write_csv(inputs, 'case_distance_input_descriptors.csv.gz'),
               write_csv(static, 'case_static_metadata_and_H_rainfall.csv.gz')]
    coverage = dict(status='PASS', cases=N, P_primary=8083, P_unavailable=815,
        paired_rows=len(result), distance_levels=DS, methods=METHODS,
        all_case_rows_retained=True, all_nan_and_extreme_scores_retained=True,
        no_prediction_refit=True, no_outcome_aggregation=True,
        feature_availability_by_continent=static.groupby('continent', dropna=False).agg(
            n_all=('row', 'size'), n_P=('primary_P8083', 'sum')).reset_index().to_dict('records'),
        P_primary_missing_adjustment_fields={col: int(static.loc[static.primary_P8083, col].isna().sum())
            for col in ['official_area_km2', 'official_estimated_area_km2',
                        'p_H_mean_mm_per_month', 'p_H_cv', 'p_H_seasonality_cv']},
        P_primary_area_validity={col: dict(
            positive=int((static.loc[static.primary_P8083, col] > 0).sum()),
            nonpositive=int((static.loc[static.primary_P8083, col] <= 0).sum()),
            missing=int(static.loc[static.primary_P8083, col].isna().sum()),
            policy='Preserve original numeric values in table; positive finite area required for log-area adjustment. No reported/estimated fallback.')
            for col in ['official_area_km2', 'official_estimated_area_km2']},
        feature_missing_by_D=[dict(D=int(D), field=col,
            missing_P_primary=int(result.loc[(result.D == D) & result.method.eq('ridge') & result.primary_P8083, col].isna().sum()))
            for D in DS for col in ['selected_G_distance_median_km',
                'selected_H_historical_r_mean', 'selected_G_historical_r_weighted_mean']],
        invariants=['eligible counts nonincreasing with D', 'selected count <=4 and nonincreasing with D',
            'selected source slots exactly equal stored counts', 'selected H r positive <=1',
            'selected distances strictly >D for D>0', 'shared training count equals H selected reporting months',
            'P-unavailable QP metrics exactly equal Q including NaN', 'metadata raw index and station identity exact'],
        provenance=provenance)
    save_json(OUT / 'COVERAGE.json', coverage)
    for p, role in [(BASE / 'src/engine.py', 'Production interpretation only, not executed'),
        (ROOT / 'r3_conditional_stress_20261024/source_outage/run_outage.py', 'Source qualification/weight definitions only, not executed'),
        (ROOT / 'r4_global_information_20261025/design_review/transfer_model.py', 'P lag transform definition only, not executed'),
        (ROOT / 'r4_observation_locations_20261025/input_audit/trial_score_core.py', 'Frozen score definitions only, not executed'),
        (PRED / 'SCORING_INTERFACE.json', 'Production array axes and denominator definitions'),
        (PREP / 'PRECIPITATION_PREPARED.json', 'Precipitation input provenance'),
        (FINALP / 'PRECIPITATION_READY.json', 'Precipitation admission provenance'),
        (HERE / 'PROTOCOL.md', 'Retrospective analysis protocol owned by parent')]:
        register(p, role)
    save_json(OUT / 'FIELD_DEFINITIONS.json', dict(columns=list(result), definitions=DEFINITIONS,
        key=['row', 'D', 'method'], continuous_primary_mask='primary_P8083 AND paired_valid_<metric>; legal fallback included',
        success_denominator='all fixed primary_P8083, or all8898 explicitly secondary',
        manuscript_success='old_NSE_pass: eligible AND NSE>=0.5 AND NSE>target seasonal NSE',
        r07_success='r07_pass: eligible AND valid nonnegative output AND r>0.7; separate secondary criterion',
        count_caveat='eligible counts are H-qualified pool richness, not simultaneous reporting density; K4 count is selected input count only',
        time_caveat='G-selected descriptors may use lawful contemporaneous source availability but never target-G truth; not exclusively H-only prospective covariates',
        region_caveat='Sample-continent descriptions are not global population estimates'))
    # Read back every exported arm outcome/flag, not just selected favorable cases.
    readback = pd.read_csv(OUT / 'paired_rainfall_density_cases.csv.gz',
                          keep_default_na=False, low_memory=False, float_precision='round_trip')
    checked = []
    for col in result:
        if col.startswith(('Q_', 'QP_', 'delta_', 'new_success_', 'lost_success_',
                           'both_success_', 'paired_valid_', 'paired_eligible')):
            if result[col].dtype == bool:
                assert np.array_equal(readback[col].to_numpy(), result[col].to_numpy()), col
            else:
                decoded = np.array([np.nan if value == '' else float(value)
                                    for value in readback[col]], dtype=float)
                np.testing.assert_allclose(decoded,
                    result[col], rtol=0, atol=0, equal_nan=True, err_msg=col)
            checked.append(col)
    assert readback.station_id.equals(result.station_id)
    assert readback.continent.equals(result.continent)
    assert readback.country.equals(result.country)
    save_json(OUT / 'READBACK_QA.json', dict(status='PASS', rows=len(readback),
        dataset_sha256=sha(OUT / 'paired_rainfall_density_cases.csv.gz'),
        exact_round_trip_metric_and_flag_columns=checked,
        canonical_station_country_continent_exact=True,
        no_outcome_group_aggregation=True))
    save_json(OUT / 'DATA_MANIFEST.json', dict(created_utc=datetime.now(timezone.utc).isoformat(),
        build_script={'path': str(Path(__file__)), 'sha256': sha(__file__)},
        source_files=SOURCES, outputs=outputs,
        verification_files={p.name: sha(p) for p in (OUT / 'FIELD_DEFINITIONS.json', OUT / 'COVERAGE.json', OUT / 'READBACK_QA.json')},
        prediction_refit=False, source_arrays_opened_readonly=True,
        outcomes_previously_viewed=True, new_blind_validation=False,
        purpose='Complete frozen-arm paired data for retrospective rainfall-gain/reference-conditions investigation. No favorable outcome selection or analysis in this script.'))
    print(json.dumps({'status': 'PASS', 'paired_rows': len(result), 'primary_cases': 8083,
                      'outputs': outputs, 'coverage': str(OUT / 'COVERAGE.json')}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
