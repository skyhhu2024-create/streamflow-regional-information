"""Input-only source abundance; frozen original qualifications, no target G reads."""
from pathlib import Path
import os,sys,json,hashlib,time,argparse,warnings
from datetime import datetime,timezone
from collections import OrderedDict
from concurrent.futures import ProcessPoolExecutor,as_completed
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
CODE=next(p for p in HERE.parents if p.name=='code')
EX=CODE/'V45/experiments';BASE=EX/'r4_full_source_gradient_20261026';PRED=BASE/'predictions'
sys.path.insert(0,str(BASE/'src'))
import engine as E
import numpy as np
import pandas as pd
OLD=EX/'r3_global_single_condition_20261022';PREP=EX/'r4_global_information_20261025/prepared_inputs'
PHYS=EX/'r4_global_siting_20261026/census/physical_identity_map.csv'
N=8898;H=60;G=120
BANDS=['within800','annulus800_1500','beyond800','global']
S={}

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def inputs():return [PRED/'cases.csv',PRED/'eligible_source_counts.npy',PRED/'counts.npy',PRED/'P_available.npy',PRED/'nearest_qualified_reporter_distance_G.npy',OLD/'global_data/QC20_Q.npy',OLD/'predictions/source_cache/source_raw_indices.npy',OLD/'design/all_station_roles.csv',PHYS,BASE/'design_review/recommended_source_exclusions.csv',PREP/'target_Hz.npy',BASE/'src/engine.py',E.CORE_PATH]
def register():
 p=HERE/'EXPOSURE_PLAN_FROZEN.json'
 assert not p.exists(),'Preserve existing frozen exposure plan'
 save(p,dict(created_utc=datetime.now(timezone.utc).isoformat(),purpose='Quantify accessible synchronous reference-source abundance, not terrestrial station density',N=N,H=H,G=G,bands=BANDS,boundaries={'within800':'distance<=800 km','annulus800_1500':'800<distance<=1500 km','beyond800':'distance>800 km','global':'no distance restriction'},selection='All original H-qualified sources, not K4. Original 24714 safety-cleaned source domain; remove complete target physical identity before every G read.',qualification='Reuse original Fortran-layout H-only source prep and C.relation against frozen target_Hz. >=12 common finite anomaly months, positive r, valid anomaly SD. EXACT comparison to frozen D0/100/300/800 eligible counts for every target.',monthly_reports='Qualified source raw G finite and nonnegative, H-derived calendar mean finite for that G month. Read only other legal physical sites. All monthly counts kept; zeros are explicit.',summaries=['mean','median','min','fraction_zero','fraction_at_least4'],workers_max=6,numpy_threads=1,source_H_cache='At most four original H anchors per worker; group batches by identical history start/end',outcome_policy='No scores or target G truth loaded; no refitting, rescoring or response-guided grouping. 1500-km boundary fixed before exposure computation and any new outcome association.',validation='Every target eligible-count equality; min(global/beyond800,4) equals frozen D0/D800 selected counts at every G month; global zeros equal original no-reporter months. Separate direct-month loops at first target in each continent, minimum/maximum H start and fixed-seed 16 targets.',script_sha256=sha(Path(__file__)),input_sha256={str(p):sha(p)for p in inputs()}))
 print('EXPOSURE_PLAN_FROZEN',flush=True)
def init():
 warnings.filterwarnings('ignore',category=RuntimeWarning)
 S['cases']=pd.read_csv(PRED/'cases.csv',keep_default_na=False)
 assert len(S['cases'])==N and np.array_equal(S['cases'].row,np.arange(N))
 S['Q']=np.load(OLD/'global_data/QC20_Q.npy',mmap_mode='r')
 raw=np.load(OLD/'predictions/source_cache/source_raw_indices.npy')
 excluded=pd.read_csv(BASE/'design_review/recommended_source_exclusions.csv',keep_default_na=False).raw_index.to_numpy(int)
 S['raw']=raw[~np.isin(raw,excluded)];assert len(S['raw'])==24714
 S['excluded']=set(excluded.tolist())
 meta=pd.read_csv(OLD/'design/all_station_roles.csv',keep_default_na=False)
 S['lat']=meta.iloc[S['raw']].latitude.to_numpy(float);S['lon']=meta.iloc[S['raw']].longitude.to_numpy(float)
 phy=pd.read_csv(PHYS,keep_default_na=False).sort_values('raw_index')
 assert np.array_equal(phy.raw_index,np.arange(len(meta)))
 assert np.array_equal(phy.station_id,meta.station_id)
 S['physical']=phy.physical_group_raw_index.to_numpy(int)
 S['target_Hz']=np.load(PREP/'target_Hz.npy',mmap_mode='r')
 S['eligible_frozen']=np.load(PRED/'eligible_source_counts.npy',mmap_mode='r')
 S['selected_counts']=np.load(PRED/'counts.npy',mmap_mode='r')
 S['nearest']=np.load(PRED/'nearest_qualified_reporter_distance_G.npy',mmap_mode='r')
 S['cache']=OrderedDict()
def history(h):
 key=(int(h[0]),int(h[-1])+1)
 if key not in S['cache']:
  vals=np.asfortranarray(S['Q'][S['raw'][:,None],h[None,:]],dtype=float)
  S['cache'][key]=E.C.prep(vals,h)
  if len(S['cache'])>4:S['cache'].popitem(last=False)
 else:S['cache'].move_to_end(key)
 return S['cache'][key]
def qualify(i):
 e=S['cases'].iloc[i];h=np.arange(int(e.history_start),int(e.history_end));g=np.arange(int(e.gap_start),int(e.gap_end))
 assert len(h)==H and len(g)==G and h[-1]+1==g[0]
 cl,sd,z=history(h);_,r=E.C.relation(z,np.asarray(S['target_Hz'][i]))
 own=set(np.flatnonzero(S['physical']==S['physical'][int(e.raw_index)]).tolist())
 q=np.flatnonzero(np.isfinite(r)&(r>0)&np.isfinite(sd)&~np.isin(S['raw'],list(own)))
 dist=E.distances(e.latitude,e.longitude,S['lat'],S['lon'])
 elig=np.array([len(q),np.sum(dist[q]>100),np.sum(dist[q]>300),np.sum(dist[q]>800)],np.int32)
 assert np.array_equal(elig,S['eligible_frozen'][i]),('eligible mismatch',int(i),elig.tolist(),S['eligible_frozen'][i].tolist())
 assert not(set(S['raw'][q])&(own|S['excluded']))
 return e,g,q,dist,cl,elig,own
def guarded_g(raw,g,own):
 assert not(set(map(int,raw))&(own|S['excluded']))
 assert len(g)==120
 return np.asarray(S['Q'][raw[:,None],g[None,:]],dtype=float)
def compute(i):
 e,g,q,dist,cl,elig,own=qualify(i)
 counts=np.zeros((4,G),np.int32)
 for start in range(0,len(q),4096):
  jj=q[start:start+4096];raw=S['raw'][jj]
  val=guarded_g(raw,g,own)
  valid=np.isfinite(val)&(val>=0)&np.isfinite(cl[jj[:,None],(g%12)[None,:]])
  dd=dist[jj];masks=[dd<=800,(dd>800)&(dd<=1500),dd>800,np.ones(len(jj),bool)]
  for k,mask in enumerate(masks):counts[k]+=valid[mask].sum(axis=0,dtype=np.int32)
 assert np.array_equal(counts[0]+counts[2],counts[3])
 assert np.all(counts[1]<=counts[2])
 assert np.array_equal(np.minimum(counts[3],4),S['selected_counts'][i,0,H:])
 assert np.array_equal(np.minimum(counts[2],4),S['selected_counts'][i,3,H:])
 assert np.array_equal(counts[3]==0,~np.isfinite(S['nearest'][i]))
 assert np.max(counts)<65536
 return counts.astype(np.uint16),elig
def batch(indices):
 monthly=[];eligible=[]
 for i in indices:
  a,b=compute(int(i));monthly.append(a);eligible.append(b)
 return np.asarray(indices,np.int32),np.stack(monthly),np.stack(eligible)
def produce(workers):
 assert 1<=workers<=6
 plan=json.loads((HERE/'EXPOSURE_PLAN_FROZEN.json').read_text(encoding='utf8'))
 assert plan['script_sha256']==sha(Path(__file__))
 assert all(sha(Path(p))==h for p,h in plan['input_sha256'].items())
 assert not (HERE/'EXPOSURES_COMPLETE.json').exists()
 cases=pd.read_csv(PRED/'cases.csv',keep_default_na=False)
 tasks=[]
 for _,df in cases.groupby(['history_start','history_end'],sort=True):
  ix=df.row.to_numpy(int)
  tasks.extend([ix[j:j+64].tolist()for j in range(0,len(ix),64)])
 monthly=np.lib.format.open_memmap(HERE/'monthly_counts.npy',mode='w+',dtype=np.uint16,shape=(N,4,G))
 eligible=np.lib.format.open_memmap(HERE/'eligible_counts_recomputed.npy',mode='w+',dtype=np.int32,shape=(N,4))
 seen=np.zeros(N,bool);st=time.monotonic();done=0
 with ProcessPoolExecutor(max_workers=workers,initializer=init)as pool:
  pending=[pool.submit(batch,task)for task in tasks]
  for f in as_completed(pending):
   ix,a,b=f.result();assert not seen[ix].any();monthly[ix]=a;eligible[ix]=b;seen[ix]=True;done+=len(ix)
   if done%256<64 or done==N:print(f'EXPOSURES {done}/{N}; seconds={time.monotonic()-st:.1f}',flush=True)
 assert seen.all();monthly.flush();eligible.flush()
 columns=cases[['row','station_id','raw_index','continent','country','spatial_cell','P_available','history_start','history_end','gap_start','gap_end']].copy()
 for k,name in enumerate(BANDS):
  v=monthly[:,k,:]
  columns[name+'_mean']=v.mean(1);columns[name+'_median']=np.median(v,axis=1);columns[name+'_min']=v.min(1)
  columns[name+'_fraction_zero']=(v==0).mean(1);columns[name+'_fraction_at_least4']=(v>=4).mean(1)
 for k,d in enumerate([0,100,300,800]):columns[f'eligible_N_D{d}']=eligible[:,k]
 columns.to_csv(HERE/'exposure_summary.csv',index=False)
 save(HERE/'EXPOSURES_COMPLETE.json',dict(status='ALL_8898_EXPOSURES_COMPLETE_AWAITING_INDEPENDENT_VALIDATION',N=N,bands=BANDS,monthly_shape=[N,4,G],monthly_dtype='uint16',history_anchors=int(cases.history_start.nunique()),seconds=time.monotonic()-st,all_eligible_four_distances_exact=True,all_D0_D800_selected_caps_exact=True,all_zero_reporter_patterns_exact=True,no_target_G_reads=True,no_outcomes_loaded=True,no_refits=True,plan_sha256=sha(HERE/'EXPOSURE_PLAN_FROZEN.json'),outputs={p.name:sha(p)for p in [HERE/'monthly_counts.npy',HERE/'eligible_counts_recomputed.npy',HERE/'exposure_summary.csv']}))
 print('EXPOSURES_COMPLETE',flush=True)
def validate():
 init();monthly=np.load(HERE/'monthly_counts.npy',mmap_mode='r');cases=S['cases']
 sample=set(cases.groupby('continent',sort=True).row.first().astype(int))
 sample|={int(cases.loc[cases.history_start.idxmin(),'row']),int(cases.loc[cases.history_start.idxmax(),'row'])}
 sample|=set(np.random.default_rng(20261029).choice(N,16,replace=False).tolist())
 checks=[]
 for i in sorted(sample):
  e,g,q,dist,cl,elig,own=qualify(i);raw=S['raw'][q]
  independent=np.zeros((4,G),np.int32)
  assert not(set(map(int,raw))&(own|S['excluded']))
  # Independently loop across months and bands, never production chunks.
  for ti,month in enumerate(g):
   values=np.asarray(S['Q'][raw,int(month)],dtype=float)
   valid=np.isfinite(values)&(values>=0)&np.isfinite(cl[q,int(month)%12])
   d=dist[q]
   independent[:,ti]=[np.count_nonzero(valid&(d<=800)),np.count_nonzero(valid&(d>800)&(d<=1500)),np.count_nonzero(valid&(d>800)),np.count_nonzero(valid)]
  assert np.array_equal(independent,monthly[i]),('independent loop mismatch',i)
  checks.append(dict(row=i,station_id=e.station_id,continent=e.continent,months=120,bands=4,exact=True))
 save(HERE/'INDEPENDENT_DIRECT_COUNT_QA.json',dict(status='PASS',sample_rule='First target per continent, minimum/maximum H start, fixed-seed16 without replacement; no outcome-based selection',seed=20261029,sample_n=len(checks),integer_cells_checked=len(checks)*4*120,checks=checks,script_sha256=sha(Path(__file__)),plan_sha256=sha(HERE/'EXPOSURE_PLAN_FROZEN.json'),monthly_sha256=sha(HERE/'monthly_counts.npy'),target_G_never_read=True))
 print(json.dumps(dict(status='PASS',sample_n=len(checks),integer_cells_checked=len(checks)*480)),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('command',choices=['register','produce','validate']);p.add_argument('--workers',type=int,default=6);a=p.parse_args()
 if a.command=='register':register()
 elif a.command=='produce':produce(a.workers)
 else:validate()
