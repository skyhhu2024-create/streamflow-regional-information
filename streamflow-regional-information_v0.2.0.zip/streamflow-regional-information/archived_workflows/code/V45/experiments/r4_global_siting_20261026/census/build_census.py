"""All-GSIM mask-only forward cohort census; no outcomes or site-selection skill."""
from pathlib import Path
import sys, json, hashlib, time
from datetime import datetime, timezone
HERE=Path(__file__).resolve().parent
CODE=next(p for p in HERE.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd
OLD=CODE/'V45/experiments/r3_global_single_condition_20261022'
ARCH=CODE/'V42.2/experiments/r3_global_k4_20261014/outputs/R1_scope'
TW=CODE/'gsim_near_duplicates_checked.csv'
GR=CODE/'V45/experiments/r4_external_information_20261024/grdc_inventory/confirmed_identity_roles.csv'
LENGTHS=[24,36,60,120]
PENDING=['GB_0000239','GB_0000240','GB_0000241','GB_0000242']

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()

def js(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')

def main():
    t0=time.time();HERE.mkdir(exist_ok=True,parents=True)
    assert not (HERE/'CENSUS_COMPLETE.json').exists(),'Frozen census exists; preserve outputs'
    src=[OLD/'global_data/raw_Q.npy',OLD/'global_data/QC20_Q.npy',OLD/'global_data/station_ids.npy',OLD/'global_data/station_metadata.csv',OLD/'design/independent_target_cases.csv',ARCH/'archive_completion.npz',ARCH/'station_completion.csv',TW,GR]
    js(HERE/'CENSUS_PROTOCOL.json',dict(created_utc=datetime.now(timezone.utc).isoformat(),H=60,G=LENGTHS,
        scope='All30959 GSIM native archive rows, 1980-01 through2015-12; no target performance or outcome-based station screening.',
        rule='For each raw station ID, choose latest complete H60 immediately followed by G24/36/60/120 in calendar months, separately under raw and QC20 finite masks. Keep constant and negative-value windows for downstream estimability reporting, never filter by score or variance.',
        identity='Undirected connected components of all checked twin=True edges plus confirmed same-GRDC-ID edges. Per G and mask choose one eligible ID per physical component: non-twin_listed preferred, then latest anchor, then lexicographic ID. No cross-ID value stitching. All eligible and excluded records retained.',
        pending_aliases='Four British pending identities excluded from future source pools, retained and flagged in target census.',
        old_comparison='Old8898 H60/G120 cases retained separately with their original hash-selected anchor. NewG120 uses latest anchor and fuller identity components; it is not a reproduction or overwrite of old cases.',
        representation='Report raw catalogue, raw/QC observed, paper24934, natural19418 forward, old8898 and new cohorts by continent/country/5-degree cell/Koppen major+code/record length/natural gap length/catchment area. Counts and coverage are descriptive, not sampling representativeness guarantees.',
        source_files={str(p.relative_to(CODE)):sha(p) for p in src},script_sha256=sha(__file__)))
    m=pd.read_csv(OLD/'global_data/station_metadata.csv',keep_default_na=False,low_memory=False)
    ids=np.load(OLD/'global_data/station_ids.npy',allow_pickle=False).astype(str)
    assert np.array_equal(m.station_id.to_numpy(str),ids) and len(ids)==30959
    n=len(ids);lookup={s:i for i,s in enumerate(ids)};parent=np.arange(n)
    def root(i):
        while parent[i]!=i:
            parent[i]=parent[parent[i]];i=parent[i]
        return i
    def union(a,b):
        a,b=root(a),root(b)
        if a!=b:parent[max(a,b)]=min(a,b)
    edges=[];tw=pd.read_csv(TW,keep_default_na=False)
    for e in tw[tw.twin.astype(str).str.lower().eq('true')].itertuples():
        if e.a in lookup and e.b in lookup:
            union(lookup[e.a],lookup[e.b]);edges.append(dict(a=e.a,b=e.b,evidence='checked_twin'))
    gr=pd.read_csv(GR,keep_default_na=False,dtype=str)
    for gid,z in gr.groupby('GRDC_id'):
        ss=sorted(set(s for s in z.GSIM_id if s in lookup))
        for s in ss[1:]:
            union(lookup[ss[0]],lookup[s]);edges.append(dict(a=ss[0],b=s,evidence='confirmed_GRDC_'+gid))
    canonical=np.array([root(i) for i in range(n)],dtype=np.int32)
    m['raw_index']=np.arange(n);m['physical_group_raw_index']=canonical;m['physical_group_id']=ids[canonical]
    components={int(k):np.flatnonzero(canonical==k).tolist() for k in np.unique(canonical)}
    m['physical_component_size']=[len(components[int(k)]) for k in canonical]
    m['source_pending_alias_excluded']=m.station_id.isin(PENDING)
    m['all_same_station_exclusion_raw_indices']=[json.dumps(components[int(k)]) for k in canonical]
    m['all_same_station_exclusion_ids']=[json.dumps(ids[components[int(k)]].tolist()) for k in canonical]
    idcols=['raw_index','station_id','physical_group_raw_index','physical_group_id','physical_component_size','twin_listed','source_pending_alias_excluded','all_same_station_exclusion_raw_indices','all_same_station_exclusion_ids']
    m[idcols].to_csv(HERE/'physical_identity_map.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(edges).to_csv(HERE/'physical_identity_edges.csv',index=False,encoding='utf-8-sig')
    offsets=np.r_[0,np.cumsum([len(components[int(k)]) for k in canonical])]
    members=np.concatenate([np.asarray(components[int(k)],np.int32) for k in canonical])
    np.savez_compressed(HERE/'physical_identity_arrays.npz',station_ids=ids,physical_group_raw_index=canonical,alias_offsets=offsets,alias_raw_indices=members,pending_source_excluded=m.source_pending_alias_excluded.to_numpy(bool))
    lat=pd.to_numeric(m.latitude,errors='coerce').to_numpy();lon=pd.to_numeric(m.longitude,errors='coerce').to_numpy()
    valid=np.isfinite(lat)&np.isfinite(lon)&(np.abs(lat)<=90)&(np.abs(lon)<=180)
    m['valid_coordinates']=valid
    m['spatial_cell']=[f'{int(np.floor(a/5))}:{int(np.floor(b/5))}' if ok else 'Unknown' for a,b,ok in zip(lat,lon,valid)]
    for col in ['continent','country','kg_major','kg_code']:m[col]=m[col].astype(str).replace('','Unknown')
    m['record_length_band']=pd.cut(pd.to_numeric(m.raw_n_finite),[-1,23,59,119,239,999],labels=['<24','24-59','60-119','120-239','>=240']).astype(str)
    area=pd.to_numeric(m.header_area,errors='coerce');m['area_km2']=area
    m['area_band']=pd.cut(area,[0,100,1000,10000,100000,np.inf],labels=['0-100','100-1000','1000-10000','10000-100000','>100000'],include_lowest=False).astype(str).replace('nan','Unknown_or_nonpositive')
    ar=np.load(ARCH/'archive_completion.npz',allow_pickle=True);aid=ar['station_id'].astype(str);obs=ar['observed'].astype(bool)
    assert len(aid)==24934 and int((~obs).sum())==4598259
    last=431-np.argmax(obs[:,::-1],axis=1);natural={s:432-int(j)-1 for s,j in zip(aid,last)}
    m['in_R1_scope']=m.station_id.isin(aid);m['natural_forward_gap_months']=m.station_id.map(natural).fillna(0).astype(int)
    m['has_natural_forward_gap']=m.in_R1_scope&m.natural_forward_gap_months.gt(0)
    m['natural_forward_gap_band']=pd.cut(m.natural_forward_gap_months,[-1,0,23,59,119,239,999],labels=['none','1-23','24-59','60-119','120-239','>=240']).astype(str)
    assert int(m.has_natural_forward_gap.sum())==19418 and int(m.natural_forward_gap_months.sum())==2612522
    old=pd.read_csv(OLD/'design/independent_target_cases.csv',keep_default_na=False,low_memory=False);oldids=set(old.station_id)
    m['in_old8898']=m.station_id.isin(oldids)
    old.to_csv(HERE/'old8898_original_cases_UNCHANGED.csv',index=False,encoding='utf-8-sig')
    keep=['raw_index','station_id','physical_group_raw_index','physical_group_id','physical_component_size','twin_listed','source_pending_alias_excluded','all_same_station_exclusion_raw_indices','all_same_station_exclusion_ids','latitude','longitude','continent','country','kg_major','kg_code','climate_id','spatial_cell','valid_coordinates','header_river','header_station','area_km2','area_band','raw_n_finite','QC20_n_finite','raw_n_negative','QC20_n_negative','record_length_band','in_R1_scope','natural_forward_gap_months','natural_forward_gap_band','has_natural_forward_gap','in_old8898']
    meta=m[keep].copy();meta.to_csv(HERE/'global_station_metadata.csv',index=False,encoding='utf-8-sig')
    flags={};allfunnel=[];groups={}
    groups['raw_catalogue30959']=np.ones(n,bool);groups['paper24934']=m.in_R1_scope.to_numpy();groups['natural_forward19418']=m.has_natural_forward_gap.to_numpy();groups['old8898']=m.in_old8898.to_numpy()
    for maskname in ['raw','QC20']:
        q=np.load(OLD/f'global_data/{maskname}_Q.npy',mmap_mode='r');mask=np.isfinite(q)
        groups[maskname+'_any_observation']=mask.any(1)
        c=np.pad(np.cumsum(mask,axis=1,dtype=np.int16),((0,0),(1,0)))
        for length in LENGTHS:
            aa=np.arange(60,433-length,dtype=np.int16)
            joint=(c[:,aa+length]-c[:,aa-60])==(60+length)
            count=joint.sum(1);qual=count>0
            anchor=np.where(qual,aa[len(aa)-1-np.argmax(joint[:,::-1],axis=1)],-1)
            led=meta.copy();led['mask']=maskname;led['H']=60;led['G']=length;led['L']=length;led['task']='forward';led['legal_anchor_count']=count;led['anchor']=anchor
            led['history_start']=np.where(qual,anchor-60,-1);led['history_end']=anchor;led['gap_start']=anchor;led['gap_end']=np.where(qual,anchor+length,-1)
            led['complete_window']=qual;led['selected_physical_representative']=False
            candidates=led[qual].copy();candidates['is_listed_twin']=candidates.twin_listed.astype(str).str.lower().eq('true')
            chosen=candidates.sort_values(['physical_group_id','is_listed_twin','anchor','station_id'],ascending=[True,True,False,True]).drop_duplicates('physical_group_id').index
            selected=np.zeros(n,bool);selected[chosen]=True;led.loc[chosen,'selected_physical_representative']=True
            representative=led.loc[chosen].set_index('physical_group_id').station_id.to_dict();led['selected_identity_station_id']=led.physical_group_id.map(representative).fillna('')
            led['screening_state']=np.where(~qual,'no_complete_H60_G_window',np.where(selected,'selected','qualified_same_physical_identity_duplicate'))
            led['case_id']=[hashlib.sha256(f'GLOBAL_SITING_20261026|{maskname}|{s}|H60|G{length}|{a}'.encode()).hexdigest()[:28] if ok else '' for s,a,ok in zip(ids,anchor,qual)]
            led['H_start_year_month']=[str(pd.Period('1980-01',freq='M')+int(a)-60) if ok else '' for a,ok in zip(anchor,qual)]
            led['G_start_year_month']=[str(pd.Period('1980-01',freq='M')+int(a)) if ok else '' for a,ok in zip(anchor,qual)]
            led['G_last_year_month']=[str(pd.Period('1980-01',freq='M')+int(a)+length-1) if ok else '' for a,ok in zip(anchor,qual)]
            led.to_csv(HERE/f'ledger_{maskname}_G{length}.csv.gz',index=False,compression='gzip')
            cases=led.loc[chosen].sort_values('raw_index').copy()
            cases.to_csv(HERE/f'cases_{maskname}_G{length}.csv',index=False,encoding='utf-8-sig')
            if maskname=='QC20':cases.to_csv(HERE/f'cases_G{length}.csv',index=False,encoding='utf-8-sig')
            flag=f'{maskname}_G{length}';flags[flag]=dict(qualified_raw_IDs=int(qual.sum()),unique_physical_targets=int(selected.sum()),excluded_qualified_aliases=int((qual&~selected).sum()),spatial_cells=int(cases.loc[cases.valid_coordinates,'spatial_cell'].nunique()),countries=int(cases.country.nunique()),continents=cases.continent.value_counts().to_dict(),climates=cases.kg_major.value_counts().to_dict())
            groups[flag]=selected
            allfunnel.extend([dict(mask=maskname,G=length,step='catalogue',n=n),dict(mask=maskname,G=length,step='any_finite',n=int(mask.any(1).sum())),dict(mask=maskname,G=length,step='complete_H60_G_rawIDs',n=int(qual.sum())),dict(mask=maskname,G=length,step='physical_unique',n=int(selected.sum())),dict(mask=maskname,G=length,step='selected_without_coordinates',n=int((selected&~valid).sum()))])
            print(json.dumps({flag:flags[flag]},ensure_ascii=False),flush=True)
    pd.DataFrame(allfunnel).to_csv(HERE/'selection_funnel.csv',index=False,encoding='utf-8-sig')
    rows=[];dimensions=['continent','country','kg_major','kg_code','spatial_cell','record_length_band','natural_forward_gap_band','area_band']
    for dim in dimensions:
        for level,z in m.groupby(dim,dropna=False,sort=True):
            ix=z.index.to_numpy();row=dict(dimension=dim,level=str(level))
            for name,sel in groups.items():
                k=int(sel[ix].sum());row[name+'_n']=k;row[name+'_share_pct']=100*k/int(sel.sum()) if sel.sum() else None
            rows.append(row)
    rep=pd.DataFrame(rows);rep.to_csv(HERE/'representativeness_by_all_dimensions.csv',index=False,encoding='utf-8-sig')
    # Cross-classification keeps small and absent climate-region combinations visible.
    cross=[]
    for (cont,clim),z in m.groupby(['continent','kg_major'],sort=True):
        r=dict(continent=cont,kg_major=clim)
        for name,sel in groups.items():r[name+'_n']=int(sel[z.index.to_numpy()].sum())
        r['natural_forward_missing_months']=int(z.natural_forward_gap_months.sum());cross.append(r)
    pd.DataFrame(cross).to_csv(HERE/'continent_climate_coverage.csv',index=False,encoding='utf-8-sig')
    absent=[]
    for G in LENGTHS:
        for dim in ['continent','country','kg_major','kg_code','spatial_cell']:
            zz=rep[(rep.dimension==dim)&(rep.natural_forward19418_n>0)&(rep[f'QC20_G{G}_n']==0)]
            for e in zz.itertuples():absent.append(dict(G=G,dimension=dim,level=e.level,natural_forward_targets=e.natural_forward19418_n,paper_stations=e.paper24934_n))
    pd.DataFrame(absent).to_csv(HERE/'natural_demand_strata_without_validation_targets.csv',index=False,encoding='utf-8-sig')
    comparison=[]
    for length in LENGTHS:
        new=pd.read_csv(HERE/f'cases_G{length}.csv',keep_default_na=False);oldmerge=old[['station_id','anchor']].rename(columns={'anchor':'old_anchor'})
        j=new.merge(oldmerge,on='station_id',how='left')
        comparison.append(dict(G=length,new_targets=len(new),same_ID_as_old8898=int(j.old_anchor.notna().sum()),not_in_old8898=int(j.old_anchor.isna().sum()),same_anchor_as_old8898=int((pd.to_numeric(j.anchor)==pd.to_numeric(j.old_anchor)).sum())))
    pd.DataFrame(comparison).to_csv(HERE/'new_cohorts_vs_old8898.csv',index=False,encoding='utf-8-sig')
    info=dict(status='GLOBAL_MASK_ONLY_CENSUS_COMPLETE',all_raw_IDs=n,physical_components=len(components),multi_ID_physical_components=sum(len(x)>1 for x in components.values()),cohorts=flags,seconds=time.time()-t0,notes=['Availability selection alone is not a claim of global statistical representativeness.','Unrepresented regions and short/incomplete histories retained in denominator tables.','No new target G scores, algorithms, source selection, figures or manuscript/cloud changes.'])
    js(HERE/'CENSUS_COMPLETE.json',info)
    js(HERE/'CENSUS_FILES_FROZEN.json',dict(files={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!='CENSUS_FILES_FROZEN.json'}))
    print('COMPLETE',time.time()-t0,flush=True)

if __name__=='__main__':main()
