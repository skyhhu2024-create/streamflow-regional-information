"""Evaluation after prediction and independent QA gates. Never selects sites."""
from pathlib import Path
import os,sys,json,argparse,hashlib
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1];CODE=next(p for p in ROOT.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np,pandas as pd
from run_trial import NETWORKS,METHODS,INPUTS,sha,js,C,D

def register():
    plan=dict(date='2026-10-26',primary='raw monthly r>0.7 AND actual fit AND support on at least one scored month; fixed mother denominator',secondary=['r>.6','r>.8','raw r','target-H-calendar-deseasonal r','NSE','alpha','delta','target seasonal numeric r pass'],
      uncertainty='Paired bootstrap over 5degree spatial cells represented in each fixed reported subset; draw same number of cells with replacement2000 times. Mean station-weighted paired effect. Report CI only if>=5 represented cells.',
      bootstrap_seed='First8hex sha256 of 20261026|cohort|comma-joined global spatial-cell codes of the subset; code order lexicographic. Record actual seed per row.',
      denominator='mother_n and paired_evaluable_n separately. New/lost counts always refer to the reported mother mask; continuous metrics restrict to paired evaluable finite cases.',
      interpretations='Separate target-by-target one-location interventions. Per-region, P availability and different-location subsets are predeclared; no choosing favorable model/rule/threshold. Balanced weights descriptive, not extrapolated population shares.')
    js(ROOT/'SCORING_PLAN.json',plan)
    js(ROOT/'SCORING_CODE_FROZEN.json',dict(files={str(p):sha(p) for p in [Path(__file__),ROOT/'SCORING_PLAN.json']},new_G_scores_read=False))
    print('SCORING_REGISTERED',flush=True)

def metric(p,y):
    n=y.shape[1];ym=y.mean(1);pm=p.mean(1);yc=y-ym[:,None];pc=p-pm[:,None]
    sy=(yc*yc).sum(1);sp=(pc*pc).sum(1)
    sy[np.all(y==y[:,0,None],1)]=0;sp[np.all(p==p[:,0,None],1)]=0
    ok=np.isfinite(y).all(1)&(y>=0).all(1)&np.isfinite(p).all(1)&(sy>0)
    r=np.divide((yc*pc).sum(1),np.sqrt(sy*sp),out=np.full(len(y),np.nan),where=ok&(sp>0))
    r=np.clip(r,-1,1);ns=1-np.divide(((p-y)**2).sum(1),sy,out=np.full(len(y),np.nan),where=ok)
    alpha=np.divide(np.sqrt(sp/n),np.sqrt(sy/n),out=np.full(len(y),np.nan),where=ok)
    delta=np.divide(pm-ym,np.sqrt(sy/n),out=np.full(len(y),np.nan),where=ok)
    return dict(r=r,NSE=ns,alpha=alpha,delta=delta,valid_truth=np.isfinite(y).all(1)&(y>=0).all(1)&(sy>0))

def correlation(p,y):
    pc=p-p.mean(1)[:,None];yc=y-y.mean(1)[:,None];a=(pc*pc).sum(1);b=(yc*yc).sum(1)
    a[np.all(p==p[:,0,None],1)]=0;b[np.all(y==y[:,0,None],1)]=0
    return np.clip(np.divide((pc*yc).sum(1),np.sqrt(a*b),out=np.full(len(y),np.nan),where=np.isfinite(p).all(1)&np.isfinite(y).all(1)&(a>0)&(b>0)),-1,1)

def score(cohort):
    for p,h in json.loads((ROOT/'SCORING_CODE_FROZEN.json').read_text(encoding='utf8'))['files'].items():assert sha(p)==h,p
    out=ROOT/'analysis'/cohort;out.mkdir(parents=True,exist_ok=True)
    pred=ROOT/'predictions'/cohort;freeze=json.loads((pred/'PREDICTIONS_FROZEN.json').read_text(encoding='utf8'))
    qa=json.loads((ROOT/'audit'/('PREDICTIONS_'+cohort+'_INDEPENDENT_QA.json')).read_text(encoding='utf8'))
    assert qa['passed'] and qa['prediction_freeze_sha256']==sha(pred/'PREDICTIONS_FROZEN.json')
    for p,h in freeze['files'].items():assert sha(p)==h,p
    cases=pd.read_csv(D/(cohort+'_cases.csv'),keep_default_na=False);n=len(cases);L=int(cases.L.iloc[0])
    Q=np.load(C.OLD/'global_data/QC20_Q.npy',mmap_mode='r')
    y=np.stack([Q[int(e.raw_index),int(e.gap_start):int(e.gap_end)] for e in cases.itertuples()])
    P=np.load(pred/'predictions.npy',mmap_mode='r');S=np.load(pred/'support.npy',mmap_mode='r');F=np.load(pred/'fit.npy');U=np.load(pred/'uses_P.npy');IM=np.load(pred/'input_meta.npy')
    base=np.load(pred/'seasonal_baseline.npy');cal=np.load(pred/'target_raw_calendar.npy')
    season=np.stack([cal[i,np.arange(int(e.gap_start),int(e.gap_end))%12] for i,e in enumerate(cases.itertuples())])
    b=metric(base,y);bframe=cases[['row','station_id','physical_group_id','continent','country','kg_major','spatial_cell','latitude','longitude']].copy()
    for k,v in b.items():bframe[k]=v
    bframe['numeric_pass07']=np.isfinite(bframe.r)&bframe.r.gt(.7);bframe.to_csv(out/'seasonal_baseline.csv',index=False,encoding='utf-8-sig')
    frames=[]
    for ni,network in enumerate(NETWORKS):
        for mi,method in enumerate(METHODS):
            for ci,inp in enumerate(INPUTS):
                pp=np.asarray(P[:,ni,mi,ci]);met=metric(pp,y)
                df=cases[['row','station_id','physical_group_id','continent','country','kg_major','spatial_cell','latitude','longitude','pending_alias_target']].copy()
                df['cohort']=cohort;df['network']=network;df['method']=method;df['inputs']=inp;df['L']=L
                for k,v in met.items():df[k]=v
                df['anomaly_r']=correlation(pp-season,y-season)
                df['support_months']=S[:,ni,mi,ci].sum(1);df['fit_estimable']=F[:,ni,mi,ci];df['uses_P']=U[:,ni,mi,ci];df['P_available']=IM[:,1].astype(bool)
                df['evaluable']=met['valid_truth']&np.isfinite(met['r'])&np.isfinite(pp).all(1)&F[:,ni,mi,ci]&(df.support_months.to_numpy()>0)
                for cut in (.6,.7,.8):df[f'pass{int(cut*10):02d}']=df.evaluable&df.r.gt(cut)
                df['seasonal_r']=b['r'];df['seasonal_numeric_pass07']=np.isfinite(b['r'])&(b['r']>.7)
                frames.append(df)
    allscore=pd.concat(frames,ignore_index=True);allscore.to_csv(out/'scores_long.csv.gz',index=False)
    js(out/'SCORES_FROZEN.json',dict(rows=len(allscore),N=n,L=L,files={str(p):sha(p) for p in [out/'scores_long.csv.gz',out/'seasonal_baseline.csv']},prediction_freeze_sha256=sha(pred/'PREDICTIONS_FROZEN.json'),score_code_sha256=sha(Path(__file__))))
    print('SCORED',cohort,len(allscore),flush=True)

def summaries(cohort):
    out=ROOT/'analysis'/cohort;df=pd.read_csv(out/'scores_long.csv.gz',keep_default_na=False,na_values=[''])
    # Preserve Namibia country code rather than the default pandas NA token.
    choices=pd.read_csv(D/(cohort+'_static_choices.csv'),keep_default_na=False)
    cases=pd.read_csv(D/(cohort+'_cases.csv'),keep_default_na=False);N=len(cases)
    groups={(n,m,i):g.sort_values('row').reset_index(drop=True) for (n,m,i),g in df.groupby(['network','method','inputs'],sort=False)}
    ref=groups[('REDUCED','ridge','QP')]
    continents=cases.continent.to_numpy(str);climates=cases.kg_major.to_numpy(str)
    chosen=choices[choices.rule.eq('CLIMATE_NEAREST')].sort_values('row')
    masks=[('all','all',np.ones(N,bool))]+[('continent',x,continents==x) for x in np.unique(continents)]+[('climate',x,climates==x) for x in np.unique(climates)]
    masks += [('input','P_available',ref.P_available.to_numpy(bool)),('input','P_unavailable',~ref.P_available.to_numpy(bool)),('selection','different_static_locations',~chosen.same_two_rules.to_numpy(bool)),('selection','climate_nonfallback',~chosen.fallback_to_nearest.to_numpy(bool))]
    ci=np.load(ROOT/'predictions'/cohort/'candidate_info.npy')
    records=[]
    for key,g in groups.items():
        network,method,inp=key
        for dim,label,mask in masks:
            v=g[mask];ok=v.evaluable.to_numpy(bool);ev=v[ok]
            records.append(dict(network=network,method=method,inputs=inp,dimension=dim,stratum=label,n=len(v),spatial_cells=int(v.spatial_cell.nunique()),evaluable=int(ok.sum()),passed=int(v.pass07.sum()),pass_pct=100*float(v.pass07.mean()) if len(v) else np.nan,pass06_pct=100*float(v.pass06.mean()) if len(v) else np.nan,pass08_pct=100*float(v.pass08.mean()) if len(v) else np.nan,seasonal_numeric_pass_pct=100*float(v.seasonal_numeric_pass07.mean()) if len(v) else np.nan,median_r=ev.r.median(),median_anomaly_r=ev.anomaly_r.median(),median_NSE=ev.NSE.median(),median_abs_alpha_error=(ev.alpha-1).abs().median(),median_abs_delta_error=ev.delta.abs().median(),P_used=int(v.uses_P.sum())))
    pd.DataFrame(records).to_csv(out/'summary_by_stratum.csv',index=False)
    # Equal represented continents/cells are descriptive alternative weightings,
    # not claims that unsampled populations become represented by reweighting.
    balance=[]
    six=['Africa','Asia','Europe','NorthAmerica','Oceania','SouthAmerica']
    for key,g in groups.items():
        for how,col in [('equal_represented_continents','continent'),('equal_sampled_spatial_cells','spatial_cell')]:
            t=g[g.continent.isin(six)] if col=='continent' else g
            means=t.groupby(col).pass07.mean()
            balance.append(dict(network=key[0],method=key[1],inputs=key[2],weighting=how,units=len(means),pass_pct=100*means.mean()))
    pd.DataFrame(balance).to_csv(out/'descriptive_balanced_weightings.csv',index=False)
    # Cluster-resampled paired contrasts; globally unobserved regions remain unestimated.
    cells,code=np.unique(cases.spatial_cell.to_numpy(str),return_inverse=True);K=len(cells)
    bootcache={}
    pairs=[]
    for m in METHODS:
        for inp in INPUTS:
            pairs.append((('REDUCED',m,inp),('FULL',m,inp),'source_withholding'))
            for n in NETWORKS[2:]:pairs.append(((n,m,inp),('REDUCED',m,inp),'one_location_addition'))
        for n in NETWORKS:pairs.append(((n,m,'QP'),(n,m,'Q'),'rain_added'))
        for h in [24,36,60]:pairs.append(((f'CLIMATE_NEAREST_{h}',m,'QP'),(f'NEAREST_{h}',m,'QP'),'static_rule_comparison'))
        for rule in ['NEAREST','CLIMATE_NEAREST']:
            for h0,h1 in [(24,36),(36,60)]:pairs.append(((f'{rule}_{h1}',m,'QP'),(f'{rule}_{h0}',m,'QP'),'longer_common_history'))
    paired=[]
    basemasks=[m for m in masks if m[0] in ['all','continent','selection','input']]
    for aa,bb,kind in pairs:
        a,b=groups[aa],groups[bb]
        pairmasks=list(basemasks)
        if aa[0] not in ['FULL','REDUCED']:
            rule=0 if aa[0].startswith('NEAREST') else 1;li=[24,36,60].index(int(aa[0].split('_')[-1]));cc=ci[:,rule,li]
            avail=(cc[:,2]>=24)&(cc[:,3]>=2)&(cc[:,8]==int(cases.L.iloc[0]))
            pairmasks+=[('candidate','sufficient_H_and_full_G_reports',avail)]
        for dim,label,mask in pairmasks:
            new=int(np.sum(mask&a.pass07.to_numpy(bool)&~b.pass07.to_numpy(bool)));lost=int(np.sum(mask&~a.pass07.to_numpy(bool)&b.pass07.to_numpy(bool)))
            for metricname in ['pass07','r','anomaly_r']:
                v=a[metricname].to_numpy(float)-b[metricname].to_numpy(float);good=mask&np.isfinite(v)
                if metricname!='pass07':good&=a.evaluable.to_numpy(bool)&b.evaluable.to_numpy(bool)
                num=np.bincount(code[good],weights=v[good],minlength=K);den=np.bincount(code[good],minlength=K)
                represented=tuple(np.flatnonzero(den).tolist());bseed=int(hashlib.sha256(('20261026|'+cohort+'|'+','.join(map(str,represented))).encode()).hexdigest()[:8],16)
                if represented:
                    if represented not in bootcache:bootcache[represented]=np.random.default_rng(bseed).multinomial(len(represented),np.full(len(represented),1/len(represented)),size=2000)
                    draw=bootcache[represented];ix=np.array(represented,int);bd=draw@den[ix];bn=draw@num[ix]
                    sample=np.divide(bn,bd,out=np.full(2000,np.nan),where=bd>0)
                else:sample=np.full(2000,np.nan)
                factor=100 if metricname=='pass07' else 1
                finite=sample[np.isfinite(sample)];unitcount=int(np.sum(den>0));reportci=len(finite)>0 and unitcount>=5
                paired.append(dict(network=aa[0],reference=bb[0],method=aa[1],inputs=aa[2],reference_inputs=bb[2],contrast=kind,dimension=dim,stratum=label,metric=metricname,n=int(good.sum()),mother_n=int(mask.sum()),paired_evaluable_n=int((mask&a.evaluable.to_numpy(bool)&b.evaluable.to_numpy(bool)).sum()),spatial_cells=unitcount,bootstrap_seed=bseed,mean_gain=factor*np.mean(v[good]) if good.any() else np.nan,median_gain=factor*np.median(v[good]) if good.any() else np.nan,ci025=factor*np.quantile(finite,.025) if reportci else np.nan,ci975=factor*np.quantile(finite,.975) if reportci else np.nan,positive_pct=100*np.mean(v[good]>0) if good.any() else np.nan,negative_pct=100*np.mean(v[good]<0) if good.any() else np.nan,new_success=new,lost_success=lost,new_lost_denominator='mother_n',CI_status='cluster_interval' if reportci else 'too_few_cells_descriptive_only'))
    pd.DataFrame(paired).to_csv(out/'paired_spatial_bootstrap.csv',index=False)
    deliver_positions(cohort,groups,choices,ci)
    files=[out/'summary_by_stratum.csv',out/'descriptive_balanced_weightings.csv',out/'paired_spatial_bootstrap.csv',out/'all_target_candidate_duration_results.csv.gz',out/'candidate_location_summary.csv']
    js(out/'ANALYSIS_COMPLETE.json',dict(cohort=cohort,N=N,spatial_cells=K,bootstrap_replicates=2000,files={str(p):sha(p) for p in files},scores_frozen_sha256=sha(out/'SCORES_FROZEN.json')))
    print('ANALYSED',cohort,flush=True)

def deliver_positions(cohort,groups,choices,ci):
    out=ROOT/'analysis'/cohort;frames=[]
    for ri,rule in enumerate(['NEAREST','CLIMATE_NEAREST']):
        choice=choices[choices.rule.eq(rule)].sort_values('row').reset_index(drop=True)
        for li,h in enumerate([24,36,60]):
            network=f'{rule}_{h}';a=groups[(network,'ridge','QP')];b=groups[('REDUCED','ridge','QP')];f=groups[('FULL','ridge','QP')]
            nonlinear=groups[(network,'rbf_ridge','QP')];nonbase=groups[('REDUCED','rbf_ridge','QP')]
            z=choice.copy();z['cohort']=cohort;z['target_continent']=a.continent;z['target_country']=a.country;z['target_latitude']=a.latitude;z['target_longitude']=a.longitude;z['common_history_months']=h
            for name,v in [('baseline_r',b.r),('with_candidate_r',a.r),('full_archive_r',f.r),('paired_r_gain',a.r-b.r),('baseline_pass',b.pass07),('with_candidate_pass',a.pass07),('new_pass',a.pass07&~b.pass07),('lost_pass',~a.pass07&b.pass07),('target_evaluable',a.evaluable),('baseline_anomaly_r',b.anomaly_r),('with_candidate_anomaly_r',a.anomaly_r),('RBF_paired_r_gain',nonlinear.r-nonbase.r),('RBF_new_pass',nonlinear.pass07&~nonbase.pass07),('RBF_lost_pass',~nonlinear.pass07&nonbase.pass07),('P_available',a.P_available)]:z[name]=v.to_numpy()
            cols={2:'paired_common_months',3:'min_per_calendar_month',4:'candidate_historical_r',5:'candidate_qualified',6:'selected_H_slots',7:'selected_G_slots',8:'candidate_G_report_months',10:'qualification_status'}
            for j,col in cols.items():z[col]=ci[:,ri,li,j]
            z['candidate_data_evaluable']=(ci[:,ri,li,2]>=24)&(ci[:,ri,li,3]>=2)&(ci[:,ri,li,8]==int(a.L.iloc[0]))
            z['evidence']='retrospective_one_location_trial_at_existing_physical_site'
            z['operating_status']='not_verified_currently'
            z['interpretation']='Separate target-specific intervention; not additive joint-network effect or evidence for unmeasured river reach.'
            frames.append(z)
    allp=pd.concat(frames,ignore_index=True);allp.to_csv(out/'all_target_candidate_duration_results.csv.gz',index=False)
    agg=allp.groupby(['rule','candidate_id','latitude','longitude','candidate_river','candidate_continent','common_history_months'],dropna=False).agg(target_pairs=('target_id','size'),target_countries=('target_country','nunique'),target_continents=('target_continent','nunique'),qualified_pairs=('candidate_qualified','sum'),used_G_pairs=('selected_G_slots',lambda x:int((x>0).sum())),new_pass_pairs=('new_pass','sum'),lost_pass_pairs=('lost_pass','sum'),positive_r_pairs=('paired_r_gain',lambda x:int((x>0).sum())),negative_r_pairs=('paired_r_gain',lambda x:int((x<0).sum())),median_r_gain=('paired_r_gain','median')).reset_index()
    agg.to_csv(out/'candidate_location_summary.csv',index=False,encoding='utf-8-sig')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('step',choices=['register','score','summaries']);ap.add_argument('--cohort',choices=['long120','short24']);a=ap.parse_args()
    register() if a.step=='register' else globals()[a.step](a.cohort)
