
# Release adapter: filesystem location only; scientific operations are unchanged.
def _release_path(kind, relative):
    import os as _release_os
    from pathlib import Path as _ReleasePath
    code_root = next(p for p in _ReleasePath(__file__).resolve().parents if p.name == "code")
    root = code_root if kind == "code" else _ReleasePath(_release_os.environ.get("STREAMFLOW_DATA_ROOT", str(code_root.parent / "inputs")))
    return str(root / relative)

from pathlib import Path
import sys, json, hashlib, math, time
ROOT=Path(__file__).resolve().parents[1]
CODE=next(p for p in ROOT.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def read(path): return pd.read_csv(path,keep_default_na=False,low_memory=False)
def num(x): return pd.to_numeric(x,errors='coerce').to_numpy(float)

def main():
    start=time.time();D=ROOT/'design_v3';O=ROOT/'audit'
    freeze=json.loads((D/'STATIC_CHOICES_FROZEN.json').read_text(encoding='utf8'))
    for kind in ['inputs','outputs']:
        for p,h in freeze[kind].items(): assert digest(p)==h,(kind,p)
    old=ROOT.parent/'r3_global_single_condition_20261022'
    m=read(old/'design/all_station_roles.csv');ids=m.station_id.to_numpy(str)
    index={s:i for i,s in enumerate(ids)}
    adjacency={}
    def edge(a,b):
        if a in index and b in index:
            x,y=index[a],index[b];adjacency.setdefault(x,set()).add(y);adjacency.setdefault(y,set()).add(x)
    twins=read(CODE/'gsim_near_duplicates_checked.csv')
    for e in twins.itertuples():
        if str(e.twin).lower()=='true': edge(e.a,e.b)
    gr=read(ROOT.parent/'r4_external_information_20261024/grdc_inventory/confirmed_identity_roles.csv')
    for gid,z in gr.groupby('GRDC_id'):
        assert str(gid).strip() not in ('','nan','None')
        a=sorted(set(z.GSIM_id)&set(index))
        for b in a[1:]: edge(a[0],b)
    canonical=np.arange(len(ids));members={}
    for root in range(len(ids)):
        if root in members:continue
        found={root};front=[root]
        while front:
            for v in adjacency.get(front.pop(),()):
                if v not in found: found.add(v);front.append(v)
        group=sorted(found)
        for j in group: canonical[j]=group[0];members[j]=group
    ident=read(ROOT/'census/physical_identity_map.csv')
    np.testing.assert_array_equal(canonical,ident.physical_group_raw_index.to_numpy(int))
    for e in ident.itertuples():
        assert json.loads(e.all_same_station_exclusion_raw_indices)==members[e.raw_index]
        assert json.loads(e.all_same_station_exclusion_ids)==ids[members[e.raw_index]].tolist()
    raw=np.load(old/'predictions/source_cache/source_raw_indices.npy')
    risk={'GB_0000239','GB_0000240','GB_0000241','GB_0000242'}
    raw=np.array([x for x in raw if ids[x] not in risk])
    inv=read(D/'source_inventory.csv');phys=read(D/'physical_source_inventory.csv');cand=read(D/'candidate_locations.csv')
    np.testing.assert_array_equal(raw,inv.raw_index.to_numpy(int))
    expected_reps=np.array([min(raw[canonical[raw]==c]) for c in np.unique(canonical[raw])])
    np.testing.assert_array_equal(np.sort(expected_reps),np.sort(phys.raw_index.to_numpy(int)))
    official=read(ROOT/'census/metadata_enrichment_v3/global_station_metadata.csv')
    assert np.array_equal(ids,official.station_id.to_numpy(str))
    for table in [inv,phys,cand]:
        ix=table.raw_index.to_numpy(int)
        np.testing.assert_array_equal(table.continent.to_numpy(str),official.continent_display.to_numpy(str)[ix])
        np.testing.assert_array_equal(table.country.to_numpy(str),official.country_display.to_numpy(str)[ix])
        np.testing.assert_array_equal(table.stratum.to_numpy(str), (table.continent+'|'+table.kg_major).to_numpy(str)) if 'stratum' in table else None
    expected_hidden=[]
    for stratum,z in phys.groupby('stratum'):
        rr=z.raw_index.to_numpy(int)
        expected=[hashlib.sha256(('global_siting_20261026|'+ids[canonical[x]]).encode()).hexdigest() for x in rr]
        assert expected==z.hash.tolist()
        perm=np.lexsort((ids[canonical[rr]],np.array(expected)))
        chosen=rr[perm[:math.floor(len(rr)/5)]]
        expected_hidden.extend(chosen.tolist())
    np.testing.assert_array_equal(np.sort(expected_hidden),np.sort(cand.raw_index.to_numpy(int)))
    hidden=set(canonical[np.array(expected_hidden)])
    is_hidden=np.array([x in hidden for x in canonical[raw]])
    np.testing.assert_array_equal(is_hidden,inv.withheld.to_numpy(bool))
    net=np.load(D/'network_roles.npz')
    np.testing.assert_array_equal(net['full_raw'],raw)
    np.testing.assert_array_equal(net['withheld_raw'],raw[is_hidden])
    np.testing.assert_array_equal(net['retained_raw'],raw[~is_hidden])
    assert not (set(canonical[net['withheld_raw']])&set(canonical[net['retained_raw']]))
    cat=Path(_release_path('data', '3-GSIM_indices/GSIM_metadata/GSIM_metadata/GSIM_catalog/GSIM_catchment_characteristics.csv'))
    area=read(cat).set_index('gsim.no')['area.meta']
    expected_area=pd.to_numeric(cand.station_id.map(area),errors='coerce').to_numpy(float)
    ca=num(cand.official_area_km2);np.testing.assert_allclose(ca,expected_area,equal_nan=True,rtol=0,atol=0)
    lat=num(cand.latitude);lon=num(cand.longitude);radlat=np.deg2rad(lat);radlon=np.deg2rad(lon)
    cr=cand.raw_index.to_numpy(int);cp=canonical[cr]
    valid=np.isfinite(lat)&np.isfinite(lon)&(abs(lat)<=90)&(abs(lon)<=180)
    np.testing.assert_array_equal(valid,cand.valid_coordinates.to_numpy(bool))
    totals={};max_distance_error=0.0
    for name in ['long120','short24']:
        cases=read(D/f'{name}_cases.csv');choices=read(D/f'{name}_static_choices.csv')
        assert len(choices)==2*len(cases)
        assert not choices.selection_used_candidate_runoff.to_numpy(bool).any()
        expected_case_area=pd.to_numeric(cases.station_id.map(area),errors='coerce').to_numpy(float)
        np.testing.assert_allclose(num(cases.official_area_km2),expected_case_area,equal_nan=True,rtol=0,atol=0)
        expected_case_kg=m.iloc[cases.raw_index.to_numpy(int)].kg_major.to_numpy(str)
        expected_case_kg=np.where(np.isin(expected_case_kg,list('ABCDE')),expected_case_kg,'Unknown')
        np.testing.assert_array_equal(cases.kg_major.to_numpy(str),expected_case_kg)
        for e in cases.itertuples():
            la,lo=np.deg2rad([float(e.latitude),float(e.longitude)])
            hv=np.sin((radlat-la)/2)**2+np.cos(radlat)*np.cos(la)*np.sin((radlon-lo)/2)**2
            hv=np.clip(hv,0,1);distance=12742*np.arctan2(np.sqrt(hv),np.sqrt(1-hv))
            good=valid&(cp!=canonical[e.raw_index])&np.isfinite(distance)
            q=np.flatnonzero(good);near=q[np.lexsort((cr[q],distance[q]))[0]] if len(q) else -1
            aa=expected_case_area[e.row];kg=expected_case_kg[e.row]
            matching=good&(kg in list('ABCDE'))&(cand.kg_major.to_numpy(str)==kg)
            q=np.flatnonzero(matching);clim=q[np.lexsort((cr[q],distance[q]))[0]] if len(q) else near
            for rule,j in [('NEAREST',near),('CLIMATE_NEAREST',clim)]:
                rec=choices.iloc[2*e.row+(rule=='CLIMATE_NEAREST')]
                assert rec.rule==rule and int(rec.row)==int(e.row) and rec.target_id==e.station_id
                assert int(rec.candidate_row)==j,(name,e.station_id,rule)
                assert int(rec.candidate_raw_index)==int(cr[j])
                assert rec.candidate_id==ids[cr[j]]
                assert cp[j]!=canonical[e.raw_index]
                assert int(rec.climate_matching_candidates)==int(matching.sum())
                assert bool(rec.fallback_to_nearest)==(rule=='CLIMATE_NEAREST' and not len(q))
                assert bool(rec.same_two_rules)==(near==clim)
                max_distance_error=max(max_distance_error,abs(float(rec.distance_km)-distance[j]))
        totals[name]={'targets':len(cases),'location_choices':len(choices),'same_location_two_rules':int(choices[choices.rule.eq('NEAREST')].same_two_rules.sum()),'climate_fallbacks':int(choices.fallback_to_nearest.sum()),'unique_candidate_locations':int(choices.candidate_id.nunique()),'countries':cases.country.nunique(),'climate_groups':cases.kg_major.value_counts().to_dict()}
    assert max_distance_error<1e-7,max_distance_error
    report={'passed':True,'scope':'All physical identities, network removal and all static choices independently reconstructed without runoff data','raw_archive_entries':len(ids),'source_entries':len(raw),'physical_sources':len(phys),'withheld_physical_locations':len(cand),'withheld_source_entries':int(is_hidden.sum()),'cohorts':totals,'max_haversine_distance_difference_km':max_distance_error,'official_area_description_verified':True,'area_used_for_selection':False,'candidate_runoff_opened':False,'all_frozen_hashes_verified':True,'static_freeze_sha256':digest(D/'STATIC_CHOICES_FROZEN.json'),'audit_script_sha256':digest(__file__),'seconds':time.time()-start}
    (O/'STATIC_CHOICES_V3_INDEPENDENT_QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
