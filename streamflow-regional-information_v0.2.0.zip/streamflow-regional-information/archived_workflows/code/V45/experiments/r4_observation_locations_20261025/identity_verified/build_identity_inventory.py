"""Strict catalogue-level distinctness review of all 926 unresolved native IDs.

No target prediction, target G score or reconstruction quality is read. Flow
overlap is used solely to exclude likely duplicate identities, never to admit
sources because they produce better predictions. All rules are registered
before running the full review. New here means outside the frozen GSIM catalogue,
not newly constructed in the physical world.
"""

# Release adapter: filesystem location only; scientific operations are unchanged.
def _release_path(kind, relative):
    import os as _release_os
    from pathlib import Path as _ReleasePath
    code_root = next(p for p in _ReleasePath(__file__).resolve().parents if p.name == "code")
    root = code_root if kind == "code" else _ReleasePath(_release_os.environ.get("STREAMFLOW_DATA_ROOT", str(code_root.parent / "inputs")))
    return str(root / relative)

from pathlib import Path
from collections import defaultdict
from datetime import datetime, timezone
from io import StringIO
import hashlib, json, re, sys, unicodedata
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent
CODE=next(p for p in ROOT.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from difflib import SequenceMatcher

OLD=CODE/'V42.3/experiments/grdc_tuopu_screen_20261015'
LOCAL=CODE/'V45/experiments/r4_external_information_20261024/location_audit_20261025'
OFFICIAL=CODE/'V42.3/experiments/u2_external_audit_20261015/raw_public/grdc_caravan_v06'
CAT=Path(_release_path('data', '3-GSIM_indices/GSIM_metadata/GSIM_metadata/GSIM_catalog/GSIM_metadata.csv'))
R3=CODE/'V45/experiments/r3_global_single_condition_20261022'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def canon(x):
    s=str(x).strip()
    if s.upper() in ('','NA','NAN','NONE','NULL','-999','0'):return ''
    s=''.join(c for c in unicodedata.normalize('NFKD',s) if not unicodedata.combining(c))
    return re.sub('[^A-Z0-9]','',s.upper())

def name(x):
    return canon(re.sub(r'\([^)]*\)','',str(x)))

def identifier(x):
    s=re.sub(r'\.0$','',str(x).strip())
    c=canon(s)
    return str(int(c)) if c.isdigit() else c

def number(x):
    try:return float(x)
    except (ValueError,TypeError):return np.nan

def xyz(lat,lon):
    a=np.deg2rad(lat);b=np.deg2rad(lon)
    return np.column_stack([np.cos(a)*np.cos(b),np.cos(a)*np.sin(b),np.sin(a)])

def distance(a,b,c,d):
    p=xyz(np.array([a]),np.array([b]))[0];q=xyz(np.array([c]),np.array([d]))[0]
    return float(12742*np.arcsin(min(1.,np.linalg.norm(p-q)/2)))

def run_lengths(mask):
    d=np.diff(np.r_[False,mask,False].astype(np.int8))
    return list(zip(np.flatnonzero(d==1),np.flatnonzero(d==-1)))

def parse_native(p):
    # Native GRDC DOS-ASCII files use Latin-1, including the superscript 3.
    text=Path(p).read_bytes().decode('latin-1')
    lines=text.splitlines(); start=next(i for i,l in enumerate(lines) if l.startswith('YYYY-MM-DD;'))
    def header(key):
        for l in lines[:start]:
            if l.startswith('# '+key):return l.split(':',1)[1].strip()
        return ''
    unit=header('Unit of measure')
    unit_ok=unit in ('m³/s','m3/s','m^3/s')
    d=pd.read_csv(StringIO('\n'.join(lines[start:])),sep=';',skipinitialspace=True)
    d.columns=d.columns.str.strip()
    d['date']=pd.to_datetime(d['YYYY-MM-DD'],errors='coerce')
    d['q']=pd.to_numeric(d.Calculated,errors='coerce')
    d['flag']=pd.to_numeric(d.Flag,errors='coerce')
    d['valid']=unit_ok&d.date.notna()&np.isfinite(d.q)&d.q.ge(0)&d.flag.eq(100)
    return d,dict(unit=unit,unit_ok=unit_ok,header_GRDC_id=header('GRDC-No.'),rows=len(d))

def main():
    protocol_path=ROOT/'IDENTITY_REVIEW_PROTOCOL.json'
    inputs=[LOCAL/'unmapped926_native_ID_location_review_candidates.csv',OLD/'processed_native_GRDC_station_inventory.csv',OLD/'station_identity_crosswalk.csv',OLD/'secondary_national_ID_crosswalk.csv',CAT,OFFICIAL/'attributes_additional_grdc.csv',OFFICIAL/'attributes_other_grdc.csv',R3/'global_data/raw_Q.npy',CODE/'recoverability/ids.npy',CODE/'gsim_near_duplicates_checked.csv']
    protocol=dict(created_utc=datetime.now(timezone.utc).isoformat(),universe='All 926 previously unresolved native GRDC IDs; full 30,959-row GSIM catalogue for identity review, not the filtered R3 source pool.',
      already_seen='Metadata-only exploratory counts showed 479 official GRDC-Caravan matches, including 137 South African no-chain records; no full identity outcomes or G reconstruction scores were inspected.',
      primary_identity='Independent official GRDC-Caravan gauge ID, national ID, country, station/river name and coordinates must corroborate native source. Complete frozen GSIM GRDC and agency IDs, exact names, nearby near-names/river-area matches and previous crosswalk candidates are searched. Only previously no-chain candidates with formal identity corroboration and no alias suspicion may enter.',
      native_official_agreement='Exact nonempty country; positive native catchment area; unique nonempty official national ID; official GRDC gauge name includes normalized native station name and river name; native-official coordinates <=1 km. Official polygon area is NOT treated as independently reported drainage area.',
      national_ID_rule='GSIM reference.no and paired.db.no searched as normalized national tokens only for non-GRDC agencies, scoped by country; numeric leading zeros ignored. All original grdb.no and explicit grdb/grdc source IDs searched globally as GRDC IDs. Official national IDs associated with any GSIM grdb.no are also searched. Old conflicts/review cases remain excluded, not automatically overturned.',
      distinctness_evidence_grade='A_CATALOGUE_CORROBORATED_DISTINCT requires countries with comprehensive single-agency source scheme in this inventory (US usgs, CA hydat, BR ana, AU bom, or ZA grdb), no exact identifier or station-name candidate, no station within1km, no suspicious nearby river/area or fuzzy station match, and no near-duplicate discharge trace. This is operational distinction from the frozen GSIM catalogue, not proof against undocumented aliases or field verification.',
      conservative_alias_flags='Same-country exact normalized station name at any distance; any GSIM location <=1 km (all countries); within25km same normalized river + positive area relative difference <=10%; within50km station SequenceMatcher ratio >=0.90; any prior identity chain. Retain all flagged GSIM IDs for audit and group expansion.',
      flow_duplicate_exclusion='Metadata candidate neighbours within50km, nearest3 globally and all station-name/identifier candidates: if >=24 overlapping nonnegative months, same values in >=95% (rtol1e-5, atol1e-5), or raw correlation>=0.9995 with median symmetric relative difference<=0.005, flag possible same-station duplicate. This audit only excludes; low agreement never proves distinctness and no reconstruction score is calculated.',
      GRDC_between_source_duplicates='All 926 and 1,077 mapped native IDs: same national key, or within1km with same station name, or within1km with same river and areas within5%, are ambiguous physical aliases and excluded pending review.',
      source_quality='Parse every native version; SHA must match prior inventory; unit m3/s/m³/s only; Calculated is GRDC monthly mean derived from daily records; Flag100 means 100% daily coverage, not an accuracy score. Nonnegative finite values, one value per source-month, conflicting versions excluded. Require >=24 valid months in1980–2015 for deployable inventory; no target outcomes involved.',
      output='candidate_sources.csv and candidate_values.npz ordered identically, all eligible candidates retained; reviewed926_with_reasons.csv retains failures; no site recommendation or claim that candidates are presently unmonitored.',
      no_reconstruction_model_or_G_score_read=True,input_sha256={str(p):sha(p) for p in inputs})
    assert not protocol_path.exists(),'Protocol already frozen; use a new version for rule changes.'
    protocol_path.write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
    u=pd.read_csv(inputs[0],dtype=str,keep_default_na=False)
    inv=pd.read_csv(inputs[1],dtype=str,keep_default_na=False)
    cross=pd.read_csv(inputs[2],dtype=str,keep_default_na=False)
    sec=pd.read_csv(inputs[3],dtype=str,keep_default_na=False)
    cat=pd.read_csv(CAT,dtype=str,keep_default_na=False)
    off=pd.read_csv(OFFICIAL/'attributes_additional_grdc.csv',dtype=str,keep_default_na=False)
    other=pd.read_csv(OFFICIAL/'attributes_other_grdc.csv',dtype=str,keep_default_na=False)
    off=off.merge(other[['gauge_id','gauge_name','gauge_lat','gauge_lon']],on='gauge_id',validate='one_to_one')
    off['GRDC_id']=off.gauge_id.str.replace('GRDC_','',regex=False)
    off['nat_norm']=off.nat_id.map(identifier)
    offlookup=off.set_index('GRDC_id').to_dict('index')
    natcounts=off[off.nat_norm.ne('')].groupby(['country','nat_norm']).GRDC_id.nunique().to_dict()
    ids=np.load(CODE/'recoverability/ids.npy',allow_pickle=True).astype(str)
    raw=np.load(R3/'global_data/raw_Q.npy',mmap_mode='r')
    assert len(cat)==len(ids)==30959 and set(cat['gsim.no'])==set(ids)
    cat=cat.set_index('gsim.no').loc[ids].reset_index()
    lat=pd.to_numeric(cat.latitude,errors='coerce').to_numpy();lon=pd.to_numeric(cat.longitude,errors='coerce').to_numpy()
    coords_ok=np.isfinite(lat)&np.isfinite(lon)&(np.abs(lat)<=90)&(np.abs(lon)<=180)
    locrows=np.flatnonzero(coords_ok);tree=cKDTree(xyz(lat[locrows],lon[locrows]))
    countries=cat.country.to_numpy(str);sn=cat.station.map(name).to_numpy(str);rn=cat.river.map(name).to_numpy(str);areas=pd.to_numeric(cat.area,errors='coerce').to_numpy()
    by_gsim={s:i for i,s in enumerate(ids)}
    idmap=defaultdict(set);natmap=defaultdict(set);namemap=defaultdict(set)
    twin=pd.read_csv(CODE/'gsim_near_duplicates_checked.csv',keep_default_na=False,dtype=str)
    twinlinks=defaultdict(set)
    for r in twin.to_dict('records'):
        vals=[v for v in r.values() if v in by_gsim]
        for a in vals:twinlinks[a].update(vals)
    for i,r in cat.iterrows():
        if identifier(r['grdb.no']):idmap[identifier(r['grdb.no'])].add(i)
        for db,no in [('reference.db','reference.no'),('paired.db','paired.db.no')]:
            token=identifier(r[no]);agency=r[db].lower()
            if not token:continue
            if agency in ('grdb','grdc'):idmap[token].add(i)
            else:natmap[(r.country,token)].add(i)
        g=offlookup.get(identifier(r['grdb.no']),{})
        if g.get('nat_norm'):natmap[(r.country,g['nat_norm'])].add(i)
        if sn[i]:namemap[(r.country,sn[i])].add(i)
    prior=defaultdict(set)
    for r in cross.itertuples():
        if r.GSIM_id in by_gsim:prior[r.GRDC_id].add(by_gsim[r.GSIM_id])
    for r in sec.itertuples():
        if r.GSIM_id in by_gsim:prior[r.GRDC_id].add(by_gsim[r.GSIM_id])
    months=pd.date_range('1980-01-01','2015-12-01',freq='MS')
    uq=np.full((len(u),432),np.nan,dtype=np.float64)
    native_audit=[];coverage=[];q_by_gid={};date_by_gid={};sourcepaths={};sourcehashes={}
    for k,r in enumerate(u.itertuples()):
        z=inv[inv.GRDC_id.eq(r.GRDC_id)];parts=[];pa=[];ha=[];version_conflicts=[]
        for v in z.itertuples():
            p=Path(v.path);digest=sha(p);assert digest==v.sha256,(r.GRDC_id,'source changed')
            d,h=parse_native(p);assert identifier(h['header_GRDC_id'])==r.GRDC_id
            native_audit.append(dict(grdc_id=r.GRDC_id,path=str(p),sha256=digest,source_key=v.source_key,**h))
            good=d[d.valid][['date','q']].copy();good['source_key']=v.source_key;parts.append(good);pa.append(str(p));ha.append(digest)
        zq=pd.concat(parts,ignore_index=True).sort_values('date')
        nc=zq.groupby('date').q.nunique();conf=set(nc[nc>1].index)
        zq=zq[~zq.date.isin(conf)].drop_duplicates('date')
        qi=(zq.date.dt.year-1980)*12+zq.date.dt.month-1
        ok=qi.between(0,431);uq[k,qi[ok].to_numpy(int)]=zq.loc[ok,'q'].to_numpy(float)
        sourcepaths[r.GRDC_id]=pa;sourcehashes[r.GRDC_id]=ha
        q_by_gid[r.GRDC_id]=uq[k]
        mask=np.isfinite(uq[k]);runs=run_lengths(mask);longest=max((b-a for a,b in runs),default=0)
        c=dict(grdc_id=r.GRDC_id,valid_months_1980_2015=int(mask.sum()),longest_contiguous_months_1980_2015=int(longest),version_conflicting_months_excluded=len(conf),native_valid_first=str(zq.date.min().date()) if len(zq) else '',native_valid_last=str(zq.date.max().date()) if len(zq) else '',native_valid_months_all_periods=len(zq),native_source_file_count=len(pa))
        for n in (24,36,60,84,96,120,180):c[f'has_contiguous_{n}months']=longest>=n
        coverage.append(c)
    pd.DataFrame(native_audit).to_csv(ROOT/'native_source_hash_audit.csv',index=False,encoding='utf-8-sig')
    cover=pd.DataFrame(coverage).set_index('grdc_id')
    # Inventory-level source/source alias flags, using all 2,003 native IDs.
    allnative=pd.read_csv(LOCAL/'all2003_GRDC_ID_identity_status.csv',dtype=str,keep_default_na=False)
    all_lat=pd.to_numeric(allnative.latitude).to_numpy();all_lon=pd.to_numeric(allnative.longitude).to_numpy();alltree=cKDTree(xyz(all_lat,all_lon))
    native_nats=defaultdict(list)
    for rr in allnative.itertuples():
        oo=offlookup.get(rr.GRDC_id,{})
        if oo.get('nat_norm'):native_nats[(rr.country,oo['nat_norm'])].append(rr.GRDC_id)
    pairs=[];rows=[];flowrows=[]
    supported_scheme={'US':'usgs','CA':'hydat','BR':'ana','AU':'bom','ZA':'grdb'}
    for k,r in enumerate(u.itertuples()):
        gid=r.GRDC_id;co=r.country;la=float(r.latitude);lo=float(r.longitude);area=number(r.catchment_area_km2);st=name(r.station);rv=name(r.river)
        pxyz=xyz(np.array([la]),np.array([lo]))[0]
        neighbours=locrows[tree.query_ball_point(pxyz,2*np.sin(50/12742))]
        _,nn=tree.query(pxyz,k=3);nearest=locrows[np.atleast_1d(nn)]
        oo=offlookup.get(gid,{})
        formal=set(idmap[gid])|set(prior[gid])
        natkey=(co,oo.get('nat_norm',''))
        if natkey[1]:formal|=natmap[natkey]
        names=set(namemap[(co,st)]) if st else set()
        checks=set(neighbours)|set(nearest)|formal|names
        suspicious=set(formal)|set(names);flags=[]
        if formal:flags.append('formal_or_prior_identity_chain_to_GSIM')
        if names:flags.append('exact_station_name_in_GSIM_country')
        distances={j:distance(la,lo,lat[j],lon[j]) for j in checks if coords_ok[j]}
        for j in sorted(checks):
            dis=distances.get(j,np.nan);reasons=[]
            if j in formal:reasons.append('formal_or_prior_chain')
            if j in names:reasons.append('exact_station_name')
            if dis<=1:reasons.append('within1km_potential_same_site')
            area_rel=abs(areas[j]-area)/max(areas[j],area) if areas[j]>0 and area>0 else np.nan
            rivers=bool(rv and rn[j] and (rv==rn[j] or rv in rn[j] or rn[j] in rv))
            sim=SequenceMatcher(None,st,sn[j]).ratio() if st and sn[j] else np.nan
            if countries[j]==co and dis<=25 and rivers and area_rel<=.10:reasons.append('near_same_river_similar_area')
            if countries[j]==co and dis<=50 and sim>=.90:reasons.append('near_similar_station_name')
            target=raw[j];valid=np.isfinite(target)&(target>=0)&np.isfinite(uq[k]);n=int(valid.sum())
            corr=med=eq=np.nan;dup=False
            if n>=24:
                x=target[valid];y=uq[k,valid];den=np.abs(x)+np.abs(y)
                med=float(np.median(np.divide(2*np.abs(x-y),den,out=np.zeros_like(den),where=den>0)))
                eq=float(np.isclose(x,y,rtol=1e-5,atol=1e-5).mean())
                if np.std(x)>0 and np.std(y)>0:corr=float(np.corrcoef(x,y)[0,1])
                dup=eq>=.95 or (corr>=.9995 and med<=.005)
                if dup:reasons.append('near_duplicate_monthly_values_EXCLUDE_ONLY')
            if reasons:suspicious.add(j)
            pairs.append(dict(grdc_id=gid,GSIM_id=ids[j],distance_km=dis,native_area_km2=area,GSIM_area_km2=areas[j],area_relative_difference=area_rel,GSIM_station=cat.station.iloc[j],GSIM_river=cat.river.iloc[j],station_name_similarity=sim,alias_reasons=';'.join(reasons),overlap_months=n,overlap_correlation_DUPLICATE_AUDIT_ONLY=corr,overlap_median_symmetric_relative_difference=med,overlap_equal_fraction=eq))
        native_aliases=set()
        if natkey[1]:native_aliases.update(native_nats[natkey])
        for j in alltree.query_ball_point(pxyz,2*np.sin(1/12742)):
            rr=allnative.iloc[j];aa=number(rr.catchment_area_km2);ns=name(rr.station);nr=name(rr.river)
            ar=abs(aa-area)/max(aa,area) if aa>0 and area>0 else np.nan
            if rr.country==co and ((ns and ns==st) or (nr and rv and (nr==rv or nr in rv or rv in nr) and ar<=.05)):native_aliases.add(rr.GRDC_id)
        native_aliases.discard(gid)
        reason=[]
        if r.prior_identity_status!='no_existing_candidate_chain':reason.append('prior_conflict_or_review_not_overturned')
        if not oo:reason.append('no_independent_official_directory_corroboration')
        official_dist=distance(la,lo,number(oo.get('gauge_lat')),number(oo.get('gauge_lon'))) if oo else np.nan
        if oo and oo.get('country')!=co:reason.append('official_country_disagreement')
        if oo and not(official_dist<=1):reason.append('native_official_coordinate_disagreement_gt1km')
        oname=name(oo.get('gauge_name',''))
        if oo and not(st and rv and st in oname and rv in oname):reason.append('native_official_name_not_exactly_corroborated')
        if not natkey[1] or natcounts.get(natkey,0)!=1:reason.append('official_national_ID_missing_or_nonunique')
        if not np.isfinite(area) or area<=0:reason.append('native_catchment_area_unavailable')
        schemes=set(cat.loc[cat.country.eq(co),'reference.db'].str.lower())
        if co not in supported_scheme or schemes!={supported_scheme.get(co)}:reason.append('country_agency_identity_scheme_requires_manual_extension')
        if suspicious:reason.append('potential_GSIM_alias_or_identity_conflict')
        if native_aliases:reason.append('potential_GRDC_source_alias')
        if cover.loc[gid,'valid_months_1980_2015']<24:reason.append('fewer_than24_valid_months_1980_2015')
        admit=not reason
        all_aliases={ids[j] for j in suspicious}
        for sid in list(all_aliases):all_aliases.update(twinlinks[sid])
        cell=f'{int(np.floor(la/5))}:{int(np.floor(lo/5))}'
        fold=int(hashlib.sha256(('R3GLOBAL20261022_outer|'+cell).encode()).hexdigest()[:16],16)%4
        rows.append(dict(grdc_id=gid,country=co,river=r.river,name=r.station,latitude=la,longitude=lo,area_km2=area,identity_evidence_grade='A_CATALOGUE_CORROBORATED_DISTINCT' if admit else 'UNRESOLVED_OR_EXISTING_NOT_ADMITTED',admitted=admit,prior_identity_status=r.prior_identity_status,rejection_or_pending_reasons=';'.join(reason),official_national_id=oo.get('nat_id',''),official_name=oo.get('gauge_name',''),official_latitude=oo.get('gauge_lat',''),official_longitude=oo.get('gauge_lon',''),native_official_distance_km=official_dist,nearest_GSIM_id=ids[nearest[0]],nearest_GSIM_distance_km=distances[nearest[0]],all_same_station_exclusion_ids=json.dumps(sorted(all_aliases)),canonical_GSIM_raw_index='',canonical_GSIM_ids='',physical_group_id=f'GRDC_NATIVE_{gid}',GRDC_alias_candidates=json.dumps(sorted(native_aliases)),spatial_cell=cell,outer_fold=fold,native_source_paths=json.dumps(sourcepaths[gid],ensure_ascii=False),native_source_sha256=json.dumps(sourcehashes[gid]),official_identifier_source=str(OFFICIAL/'attributes_additional_grdc.csv'),official_identifier_source_sha256=sha(OFFICIAL/'attributes_additional_grdc.csv'),official_metadata_source=str(OFFICIAL/'attributes_other_grdc.csv'),official_metadata_source_sha256=sha(OFFICIAL/'attributes_other_grdc.csv'),native_owner=r.owner,current_operation_status='NOT_VERIFIED',interpretation='Existing physical gauge external to frozen GSIM catalogue; historical deployment analogue, not engineering recommendation',**cover.loc[gid].to_dict()))
        if k%100==0:print('review',k,'of',len(u),flush=True)
    result=pd.DataFrame(rows)
    result.to_csv(ROOT/'reviewed926_with_reasons.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(pairs).to_csv(ROOT/'GSIM_identity_candidate_pair_audit.csv.gz',index=False,compression='gzip')
    candidate=result[result.admitted].copy().sort_values('grdc_id').reset_index(drop=True)
    candidate.to_csv(ROOT/'candidate_sources.csv',index=False,encoding='utf-8-sig')
    q=np.array([q_by_gid[g] for g in candidate.grdc_id],dtype=np.float64).reshape((len(candidate),432))
    np.savez_compressed(ROOT/'candidate_values.npz',grdc_ids=candidate.grdc_id.to_numpy(str),Q_m3s=q,months=months.strftime('%Y-%m').to_numpy(str),valid_mask=np.isfinite(q))
    np.savez_compressed(ROOT/'unadmitted_inventory_values_DO_NOT_USE_AS_INPUT.npz',grdc_ids=u.GRDC_id.to_numpy(str),Q_m3s=uq,months=months.strftime('%Y-%m').to_numpy(str),valid_mask=np.isfinite(uq))
    bycountry=candidate.groupby('country').agg(candidates=('grdc_id','size'),valid_months=('valid_months_1980_2015','sum'),median_longest_run=('longest_contiguous_months_1980_2015','median')).reset_index()
    bycountry.to_csv(ROOT/'candidate_country_summary.csv',index=False)
    reason_counts=result.rejection_or_pending_reasons.str.split(';').explode();reason_counts=reason_counts[reason_counts.ne('')].value_counts().to_dict()
    summary=dict(status='CATALOGUE_IDENTITY_REVIEW_COMPLETE_NO_RECONSTRUCTION',reviewed=len(result),admitted=len(candidate),country_counts=candidate.country.value_counts().to_dict(),valid_months=int(np.isfinite(q).sum()),contiguous_counts={str(n):int(candidate[f'has_contiguous_{n}months'].sum()) for n in (24,36,60,84,96,120,180)},pending_or_exclusion_reason_counts=reason_counts,parsed_native_files=len(native_audit),all_native_hashes_match=True,source_unit_semantics='GRDC Calculated monthly means from daily observed discharge, Flag100 daily coverage; not modelled discharge or a guarantee of accuracy.',no_target_predictions_or_G_scores_read=True,metadata_or_duplicate_trace_identity_screen_only=True,candidate_primary_scope='Strict operational catalogue distinction, requiring external official identity corroboration; some genuine independent sources remain conservatively unresolved.',current_station_operation_not_verified=True,creation_is_historical_deployment_analogue=True)
    (ROOT/'IDENTITY_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    manifest={p.name:sha(p) for p in ROOT.iterdir() if p.is_file() and p.name!='DELIVERY_MANIFEST.json'}
    (ROOT/'DELIVERY_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
