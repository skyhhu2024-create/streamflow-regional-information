"""Conservative metadata-only cross-border amendment and independent interface QA."""
from pathlib import Path
from datetime import datetime,timezone
from difflib import SequenceMatcher
import hashlib,json,re,shutil,sys,unicodedata
ROOT=Path(__file__).resolve().parent
CODE=next(p for p in ROOT.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'));sys.stdout.reconfigure(encoding='utf-8')
import numpy as np
import pandas as pd
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def norm(s):
    s=''.join(x for x in unicodedata.normalize('NFKD',str(s)) if not unicodedata.combining(x))
    return re.sub('[^A-Z]','',s.upper())

def run():
    old=ROOT/'pre_crossborder_review'
    assert not old.exists(),'Preserve the first review; do not overwrite it.'
    old.mkdir()
    files=['candidate_sources.csv','candidate_values.npz','reviewed926_with_reasons.csv','IDENTITY_SUMMARY.json','DELIVERY_MANIFEST.json']
    for f in files:shutil.copy2(ROOT/f,old/f)
    protocol=dict(utc=datetime.now(timezone.utc).isoformat(),reason='Independent metadata review found that same-country restriction could overlook cross-border aliases. Re-evaluate every one of the 926 IDs, not only the 114 initially admitted.',prior_examined='Seven metadata-neighbour pairs of initial candidates were inspected; five cross-border cases remained uncertain. No reconstruction result was read.',rule='Flag cross-country GSIM pairs within25km with river-name SequenceMatcher>=0.70 and positive reported areas within15%; also flag within5km with river-name similarity>=0.70 regardless of area, because a factor10 area transcription discrepancy was observed at GSIM MZ_0000010. A flag means insufficient physical distinctness evidence, NOT proven duplicate. All affected candidates move to pending before reconstruction.',positive_nearby_example='GRDC1160703 Shozi/U1H009 and GRDC1160701 Delos Estate/U1H006 are separate entries in the official GRDC-Caravan directory with differing coordinates/names and coexisting 2004–2007 record ranges; keep the first as a distinct external location, but mark its close neighbour.',prior_delivery_sha256={f:sha(old/f) for f in files},no_target_G_reconstruction_scores_read=True)
    (ROOT/'CROSSBORDER_REVIEW_PROTOCOL.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
    d=pd.read_csv(ROOT/'reviewed926_with_reasons.csv',keep_default_na=False,dtype={'grdc_id':str})
    pairs=pd.read_csv(ROOT/'GSIM_identity_candidate_pair_audit.csv.gz',keep_default_na=False,dtype={'grdc_id':str})
    z=pairs.merge(d[['grdc_id','river','country']],on='grdc_id',validate='many_to_one')
    for c in ['distance_km','area_relative_difference']:z[c]=pd.to_numeric(z[c],errors='coerce')
    z['GSIM_country']=z.GSIM_id.str[:2]
    z=z[z.country.ne(z.GSIM_country)&z.distance_km.le(25)].copy()
    z['river_name_similarity']=[SequenceMatcher(None,norm(a),norm(b)).ratio() if norm(a) and norm(b) else 0 for a,b in zip(z.river,z.GSIM_river)]
    z['crossborder_identity_pending']=(z.river_name_similarity.ge(.70)&(z.area_relative_difference.le(.15)|z.distance_km.le(5)))
    z['not_a_proven_duplicate']=True
    z['native_GSIM_linked_GRDC_area_km2']=''
    z['area_discrepancy_evidence']=''
    # Preserve the original GSIM area; record independent native value separately.
    m=z.GSIM_id.eq('MZ_0000010')
    z.loc[m,'native_GSIM_linked_GRDC_area_km2']='21773'
    z.loc[m,'area_discrepancy_evidence']='Original GSIM area217773; native GRDC1897501 reports21773. No source catalogue edited.'
    z.to_csv(ROOT/'all926_crossborder_neighbour_audit.csv',index=False,encoding='utf-8-sig')
    flagged=z[z.crossborder_identity_pending].groupby('grdc_id').GSIM_id.agg(lambda s:sorted(set(s))).to_dict()
    initial=set(d.loc[d.admitted.astype(str).str.lower().eq('true'),'grdc_id'])
    for i,r in d.iterrows():
        if r.grdc_id not in flagged:continue
        d.loc[i,'admitted']=False
        d.loc[i,'identity_evidence_grade']='UNRESOLVED_CROSSBORDER_PHYSICAL_IDENTITY'
        reason=str(r.rejection_or_pending_reasons)
        d.loc[i,'rejection_or_pending_reasons']=(reason+';' if reason else '')+'crossborder_physical_identity_not_sufficiently_resolved'
        d.loc[i,'all_same_station_exclusion_ids']=json.dumps(sorted(set(json.loads(r.all_same_station_exclusion_ids))|set(flagged[r.grdc_id])))
    selected=d[d.admitted.astype(str).str.lower().eq('true')].copy().sort_values('grdc_id').reset_index(drop=True)
    meta=pd.read_csv(CODE/'V45/experiments/r4_external_information_20261024/location_audit_20261025/unmapped926_native_ID_location_review_candidates.csv',dtype=str,keep_default_na=False).set_index('GRDC_id')
    network={'ZA':'South Africa Department of Water and Sanitation','US':'USGS','AU':'Australian Bureau of Meteorology'}
    for frame in [d,selected]:
        frame['canonical_discharge_unit']='m3/s'
        frame['monthly_value_definition']='GRDC Calculated mean monthly discharge derived from daily observations'
        frame['completeness_rule']='Flag=100; all calendar days covered in GRDC calculation'
        frame['native_missing_value_code']='-999.000'
        frame['coordinate_source']='GRDC native station header; corroborated against official GRDC-Caravan catalogue'
        frame['coordinate_accuracy']='Not specified; source decimal precision is not positional accuracy'
        frame['latitude_native_text']=frame.grdc_id.map(meta.latitude)
        frame['longitude_native_text']=frame.grdc_id.map(meta.longitude)
        frame['national_identifier_network']=frame.country.map(network).fillna('Requires agency-specific review')
        frame['formal_identifier_key']=['|'.join([str(a),str(b),str(c)]) for a,b,c in zip(frame.country,frame.national_identifier_network,frame.official_national_id)]
        frame['nearby_distinct_site_note']=''
        frame.loc[frame.grdc_id.eq('1160703'),'nearby_distinct_site_note']='Official simultaneous catalogue entries: Shozi U1H009 (2004–2023) versus Delos Estate U1H006 (1962–2007), separated4.32km; distinct formal IDs and coexisting record periods.'
    d.to_csv(ROOT/'reviewed926_with_reasons.csv',index=False,encoding='utf-8-sig')
    selected.to_csv(ROOT/'candidate_sources.csv',index=False,encoding='utf-8-sig')
    archive=np.load(old/'candidate_values.npz',allow_pickle=False)
    idx=pd.Index(archive['grdc_ids'].astype(str)).get_indexer(selected.grdc_id)
    assert (idx>=0).all()
    q=archive['Q_m3s'][idx];months=archive['months'].astype(str)
    np.savez_compressed(ROOT/'candidate_values.npz',grdc_ids=selected.grdc_id.to_numpy(str),Q_m3s=q,months=months,valid_mask=np.isfinite(q))
    # Independent parsing directly from every admitted original file.
    expected_months=pd.date_range('1980-01','2015-12',freq='MS').strftime('%Y-%m').to_numpy(str)
    assert np.array_equal(months,expected_months)
    assert len(selected)==len(set(selected.grdc_id))==q.shape[0]
    assert np.isfinite(q).sum()==selected.valid_months_1980_2015.sum()
    reconstructed=np.full_like(q,np.nan);source_n=0
    for i,r in selected.iterrows():
        values={};conflicts=set()
        for path,digest in zip(json.loads(r.native_source_paths),json.loads(r.native_source_sha256)):
            p=Path(path);assert sha(p)==digest;source_n+=1
            text=p.read_bytes().decode('latin-1');unit=[x.split(':',1)[1].strip() for x in text.splitlines() if x.startswith('# Unit of measure')][0]
            assert unit in ('m³/s','m3/s','m^3/s')
            for line in text.splitlines():
                if not re.match(r'^\d{4}-\d{2}-\d{2};',line):continue
                parts=[x.strip() for x in line.split(';')]
                date=parts[0][:7];yr,mo=map(int,date.split('-'));t=(yr-1980)*12+mo-1
                if not(0<=t<432):continue
                value=float(parts[3]);flag=float(parts[4])
                if flag!=100 or not np.isfinite(value) or value<0:continue
                if t in values and values[t]!=value:conflicts.add(t)
                values[t]=value
        for t,value in values.items():
            if t not in conflicts:reconstructed[i,t]=value
        cell=f'{int(np.floor(r.latitude/5))}:{int(np.floor(r.longitude/5))}'
        fold=int(hashlib.sha256(('R3GLOBAL20261022_outer|'+cell).encode()).hexdigest()[:16],16)%4
        assert cell==r.spatial_cell and fold==r.outer_fold
        assert json.loads(r.all_same_station_exclusion_ids)==[]
    assert np.array_equal(q,reconstructed,equal_nan=True)
    rejected=sorted(initial-set(selected.grdc_id))
    summary=dict(status='PASS_FULL926_IDENTITY_REVIEW_AND_INDEPENDENT_ALL_ADMITTED_NATIVE_REPLAY',reviewed=926,initial_admitted=len(initial),crossborder_pending_IDs_all926=len(flagged),newly_pending_initial_candidates=rejected,admitted=len(selected),country_counts=selected.country.value_counts().to_dict(),valid_months=int(np.isfinite(q).sum()),contiguous_counts={str(n):int(selected[f'has_contiguous_{n}months'].sum()) for n in (24,36,60,84,96,120,180)},candidate_matrix_shape=list(q.shape),all_admitted_native_files_reparsed_independently=source_n,raw_value_matrix_replay_exact=True,all_hashes_rechecked=True,all_months_and_folds_match=True,no_target_predictions_or_G_scores_read=True,identity_scope='Corroborated external physical locations relative to frozen GSIM catalogue; no current operation or field construction feasibility verified.',regional_scope='107 South African and two other candidates; this source sample is not globally representative.',input_matrix_sha256=sha(ROOT/'candidate_values.npz'),input_metadata_sha256=sha(ROOT/'candidate_sources.csv'))
    (ROOT/'IDENTITY_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    selected.groupby('country').agg(candidates=('grdc_id','size'),valid_months=('valid_months_1980_2015','sum'),median_longest_run=('longest_contiguous_months_1980_2015','median')).reset_index().to_csv(ROOT/'candidate_country_summary.csv',index=False)
    (ROOT/'INDEPENDENT_INTERFACE_QA.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    manifest={str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('*') if p.is_file() and p!=ROOT/'DELIVERY_MANIFEST.json'}
    (ROOT/'DELIVERY_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':run()
