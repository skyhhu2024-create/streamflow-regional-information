"""Pure numerical scoring: no file I/O, fitting or parameter selection."""
import numpy as np

THRESHOLDS=(('r06',.6),('r07',.7),('r08',.8))
TOL=1e-12


def divide(a,b):
    return np.divide(a,b,out=np.full(np.broadcast_shapes(np.shape(a),np.shape(b)),np.nan),where=np.asarray(b)>0)


def correlation(x,y):
    x=np.asarray(x,float);y=np.asarray(y,float)
    xc=x-x.mean(1)[:,None];yc=y-y.mean(1)[:,None]
    xx=(xc*xc).sum(1);yy=(yc*yc).sum(1)
    xx[np.all(x==x[:,:1],axis=1)]=0;yy[np.all(y==y[:,:1],axis=1)]=0
    return np.clip(divide((xc*yc).sum(1),np.sqrt(xx*yy)),-1,1)


def metrics(truth,prediction,seasonal,estimable,support):
    y=np.asarray(truth,float);p=np.asarray(prediction,float);b=np.asarray(seasonal,float)
    assert y.shape==p.shape==b.shape and np.asarray(support).shape==y.shape
    L=y.shape[1];ym=y.mean(1);pm=p.mean(1)
    sy=((y-ym[:,None])**2).sum(1);sp=((p-pm[:,None])**2).sum(1)
    sy[np.all(y==y[:,:1],axis=1)]=0;sp[np.all(p==p[:,:1],axis=1)]=0
    sse=((p-y)**2).sum(1);sseb=((b-y)**2).sum(1)
    valid=np.isfinite(y).all(1)&(y>=0).all(1)&(sy>0)
    output=np.isfinite(p).all(1)&(p>=0).all(1)
    supported=np.asarray(support,bool).sum(1);fit=np.asarray(estimable,bool)
    eligible=valid&output&fit&(supported>0)
    r=correlation(p,y);rd=correlation(p-b,y-b);br=correlation(b,y)
    alpha=divide(np.sqrt(sp),np.sqrt(sy));delta=divide(pm-ym,np.sqrt(sy/L))
    nse=1-divide(sse,sy);bn=1-divide(sseb,sy)
    out=dict(r=r,H_deseasonal_r=rd,seasonal_r=br,alpha=alpha,delta=delta,
        absolute_alpha_error=np.abs(alpha-1),absolute_delta_error=np.abs(delta),
        NSE=nse,seasonal_NSE=bn,S=1-divide(sse,sseb),valid_truth=valid,
        finite_prediction=np.isfinite(p).all(1),nonnegative_prediction=(p>=0).all(1),
        actual_model_estimable=fit,support_months=supported,eligible=eligible,
        undefined_r=~np.isfinite(r),undefined_H_deseasonal_r=~np.isfinite(rd),
        old_NSE_pass=eligible&(nse>=.5)&(nse>bn),NSE_below_minus100=np.isfinite(nse)&(nse< -100))
    for name,t in THRESHOLDS:
        numeric=valid&output&np.isfinite(r)&(r>t)
        out[name+'_pass']=eligible&numeric;out['numeric_'+name]=numeric
    return out


def transition(a,b,mask):
    a=np.asarray(a,bool);b=np.asarray(b,bool);m=np.asarray(mask,bool)
    n=int(m.sum());new=int((m&a&~b).sum());lost=int((m&~a&b).sum())
    both=int((m&a&b).sum());neither=int((m&~a&~b).sum())
    assert new+lost+both+neither==n
    return dict(n_subset=n,arm_pass=int((m&a).sum()),reference_pass=int((m&b).sum()),
        new_pass=new,lost_pass=lost,both_pass=both,neither_pass=neither,
        net_change_pp=100*(new-lost)/n if n else np.nan)


def paired(value,eligible,mask,cells,draws,binary=False):
    """Spatial-cell bootstrap CI for the station-weighted MEAN, not median."""
    value=np.asarray(value,float);mask=np.asarray(mask,bool)
    ok=mask&np.isfinite(value)
    if not binary:ok &= np.asarray(eligible,bool)
    vv=value[ok];k=draws.shape[1];B=len(draws)
    num=np.bincount(cells[ok],weights=vv,minlength=k)
    den=np.bincount(cells[ok],minlength=k);bd=draws@den
    boot=np.divide(draws@num,bd,out=np.full(B,np.nan),where=bd>0)
    boot=boot[np.isfinite(boot)];factor=100 if binary else 1
    low,high=np.quantile(boot,[.025,.975])*factor if len(boot) else (np.nan,np.nan)
    tol=0 if binary else TOL
    return dict(n_subset=int(mask.sum()),n_paired_finite=int(ok.sum()),
        n_spatial_cells=int(np.unique(cells[ok]).size),
        mean_gain=float(np.mean(vv)*factor) if len(vv) else np.nan,
        median_gain=float(np.median(vv)*factor) if len(vv) else np.nan,
        mean_gain_ci025=float(low),mean_gain_ci975=float(high),
        positive_pct=float(100*np.mean(vv>tol)) if len(vv) else np.nan,
        negative_pct=float(100*np.mean(vv< -tol)) if len(vv) else np.nan,
        unchanged_pct=float(100*np.mean(np.abs(vv)<=tol)) if len(vv) else np.nan,
        numerical_tolerance=tol,bootstrap_valid_replicates=len(boot),
        ci_estimand='spatial-cell-bootstrap CI of station-weighted MEAN gain; NOT median CI')


def synthetic_checks():
    # Synthetic arrays only; no real observations or prediction files.
    y=np.tile(np.arange(1,121.),(5,1));b=np.ones_like(y)*50;p=y.copy()
    p[1]=3*y[1]+2;p[2]=7;p[3]=y[3];p[4]=y[4]
    fit=np.ones(5,bool);fit[3]=False
    support=np.ones_like(y,bool);support[4]=False
    m=metrics(y,p,b,fit,support)
    assert np.allclose(m['r'][[0,1,3,4]],1) and np.isnan(m['r'][2])
    assert m['r07_pass'].tolist()==[True,True,False,False,False]
    assert m['numeric_r07'].tolist()==[True,True,False,True,True]
    assert m['NSE'][1]<.5 and m['r07_pass'][1]  # NO NSE gate.
    assert not m['old_NSE_pass'][1]
    sy=np.std(y,axis=1)
    assert np.isclose(m['alpha'][1],3) and np.isclose(m['delta'][1],(p[1].mean()-y[1].mean())/sy[1])
    good=np.isfinite(m['r']);np.testing.assert_allclose(m['NSE'][good],(2*m['r']*m['alpha']-m['alpha']**2-m['delta']**2)[good])
    tr=transition([1,1,0,0],[1,0,1,0],[1,1,1,1])
    assert tr['new_pass']==tr['lost_pass']==1 and tr['net_change_pp']==0
    draws=np.array([[2,0],[0,2],[1,1]]);cells=np.array([0,0,1,1])
    z=paired(np.array([1.,1.,-1.,-1.]),np.ones(4,bool),np.ones(4,bool),cells,draws)
    assert z['mean_gain']==0 and z['median_gain']==0 and z['positive_pct']==50
    z0=paired(np.zeros(4),np.zeros(4,bool),np.ones(4,bool),cells,draws,binary=True)
    assert z0['n_paired_finite']==4 and z0['mean_gain']==0  # Mother denominator.
    poisoned=y.copy();poisoned[0,1]=-1
    bad=metrics(poisoned,p,b,fit,support);assert not bad['valid_truth'][0] and not bad['r07_pass'][0]
    const=y.copy();const[0]=1
    bad=metrics(const,p,b,fit,support);assert not bad['valid_truth'][0] and np.isnan(bad['r'][0])
    return dict(passed=True,checks=['raw r affine invariance','constant prediction undefined r',
        'actual fit and source support eligibility','numeric versus operational thresholds',
        'no NSE gate in r primary','NSE decomposition','new/lost identity',
        'common spatial bootstrap mean versus median','binary mother denominator',
        'negative truth stays ineligible','constant truth stays ineligible'],real_files_read=False)
