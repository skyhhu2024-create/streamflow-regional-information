"""Independent post-score audit; never changes frozen inputs or score outputs."""
from pathlib import Path
from datetime import datetime,timezone
import os,sys,json,hashlib
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
CODE=next(p for p in HERE.parents if p.name=='code');sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd
N=8898;ANA=ROOT/'trial_analysis';PRED=ROOT/'trial_predictions';LOS=ROOT/'source_contribution_analysis'
OLD=ROOT.parent/'r3_global_single_condition_20261022';PREV=ROOT.parent/'r4_global_information_20261025'
ARMS=['STRICT_BASE','FULL_BASE','STRICT_H24','STRICT_H36','STRICT_H60','BRIDGE_H24','BRIDGE_H36','BRIDGE_H60','FULL_H24','FULL_H36','FULL_H60']
METHODS=['ridge','rbf_ridge']


def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def boolean(s):
    if s.dtype==bool:return s.to_numpy()
    v=s.astype(str).str.lower();assert v.isin(['true','false']).all();return v.eq('true').to_numpy()
def close(a,b,atol=1e-10):np.testing.assert_allclose(a,b,rtol=1e-10,atol=atol,equal_nan=True)
def save(path,obj):
    def clean(v):
        if isinstance(v,dict):return {str(k):clean(x) for k,x in v.items()}
        if isinstance(v,(list,tuple,np.ndarray)):return [clean(x) for x in v]
        if isinstance(v,np.generic):return clean(v.item())
        if isinstance(v,float) and not np.isfinite(v):return None
        return v
    Path(path).write_text(json.dumps(clean(obj),ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
def verify_outputs(path):
    o=read(path)
    for name,e in o['output_files'].items():assert sha(Path(path).parent/name)==e['sha256']
    return o
def corr(x,y):
    xc=x-x.mean(1)[:,None];yc=y-y.mean(1)[:,None]
    nx=np.linalg.norm(xc,axis=1);ny=np.linalg.norm(yc,axis=1)
    nx[np.all(x==x[:,:1],axis=1)]=0;ny[np.all(y==y[:,:1],axis=1)]=0
    r=np.full(len(x),np.nan);ok=(nx>0)&(ny>0)
    r[ok]=np.einsum('ij,ij->i',xc[ok]/nx[ok,None],yc[ok]/ny[ok,None])
    return np.clip(r,-1,1)
def numerical(y,p,b):
    sd=y.std(1);ps=p.std(1);sd[np.all(y==y[:,:1],axis=1)]=0;ps[np.all(p==p[:,:1],axis=1)]=0
    valid=np.isfinite(y).all(1)&(y>=0).all(1)&(sd>0)
    alpha=np.divide(ps,sd,out=np.full(len(y),np.nan),where=sd>0)
    delta=np.divide(p.mean(1)-y.mean(1),sd,out=np.full(len(y),np.nan),where=sd>0)
    nse=1-np.divide(((y-p)**2).sum(1),len(y[0])*sd*sd,out=np.full(len(y),np.nan),where=sd>0)
    return dict(r=corr(p,y),H_deseasonal_r=corr(p-b,y-b),alpha=alpha,delta=delta,NSE=nse,valid=valid)
def stats(values,eligible,mask,cell,draws,binary=False):
    ok=np.asarray(mask)&np.isfinite(values)
    if not binary:ok &= eligible
    v=values[ok];num=np.zeros(draws.shape[1]);den=np.zeros_like(num)
    np.add.at(num,cell[ok],v);np.add.at(den,cell[ok],1)
    bd=draws@den;boot=np.divide(draws@num,bd,out=np.full(len(draws),np.nan),where=bd>0)
    boot=boot[np.isfinite(boot)];fac=100 if binary else 1
    ci=np.quantile(boot,[.025,.975])*fac if len(boot) else [np.nan,np.nan]
    return [float(v.mean()*fac) if len(v) else np.nan,float(np.median(v)*fac) if len(v) else np.nan,*ci],int(ok.sum())


def main():
    complete=verify_outputs(ANA/'ANALYSIS_COMPLETE.json');assert complete['score_rows']==195756
    cases=pd.read_csv(PRED/'cases.csv');scores=pd.read_csv(ANA/'scores_long.csv.gz',low_memory=False)
    assert len(scores)==195756 and scores.model_key.nunique()==22
    groups={}
    for (m,a),f in scores.groupby(['method','arm']):
        f=f.sort_values('row').reset_index(drop=True);assert len(f)==N and np.array_equal(f.row,np.arange(N))
        assert np.array_equal(f.station_id,cases.station_id);groups[(m,a)]=f
    qc=np.load(OLD/'global_data/QC20_Q.npy',mmap_mode='r')
    truth=np.stack([qc[int(e.raw_index),int(e.gap_start):int(e.gap_end)] for e in cases.itertuples()])
    cal=np.load(PREV/'prepared_inputs/target_H_raw_calendar.npy')
    base=cal[np.arange(N)[:,None],(cases.gap_start.to_numpy()[:,None]+np.arange(120))%12]
    predictions=np.load(PRED/'predictions.npy',mmap_mode='r');support=np.load(PRED/'support.npy',mmap_mode='r');fits=np.load(PRED/'fit_estimable.npy',mmap_mode='r')
    totals=[]
    for ai,a in enumerate(ARMS):
        for mi,m in enumerate(METHODS):
            f=groups[(m,a)];p=predictions[:,ai,mi];v=numerical(truth,p,base)
            for key in ['r','H_deseasonal_r','alpha','delta','NSE']:close(v[key],f[key],atol=1e-8 if key=='NSE' else 1e-10)
            eligibility=v['valid']&fits[:,ai,mi]&(support[:,ai,mi].sum(1)>0)&np.isfinite(p).all(1)&(p>=0).all(1)
            assert np.array_equal(eligibility,boolean(f.eligible))
            for name,t in [('r06',.6),('r07',.7),('r08',.8)]:
                numeric=v['valid']&np.isfinite(p).all(1)&(p>=0).all(1)&np.isfinite(v['r'])&(v['r']>t)
                assert np.array_equal(numeric,boolean(f['numeric_'+name]))
                assert np.array_equal(numeric&eligibility,boolean(f[name+'_pass']))
            use=np.isfinite(v['r'])&np.isfinite(v['NSE'])
            close(2*v['r'][use]*v['alpha'][use]-v['alpha'][use]**2-v['delta'][use]**2,v['NSE'][use],atol=1e-8)
            totals.append(dict(method=m,arm=a,r07_pass=int(f.r07_pass.sum()),n_eligible=int(eligibility.sum()),mother_N=N))
    bi=pd.read_csv(HERE/'BASELINE_REUSE_INDEX.csv');oldfail=boolean(bi.baseline_failed_r07);pa=boolean(bi.P_available)
    masks={('all8898','all'):np.ones(N,bool),('old_QP_r07','failed'):oldfail,('old_QP_r07','passed'):~oldfail,
        ('old_QP_eligibility','unevaluable'):boolean(bi.baseline_unestimable_or_unevaluable),('P_available','yes'):pa,('P_available','no'):~pa}
    for col in ['continent','kg_major']:
        v=cases[col].fillna('Unknown').astype(str).to_numpy()
        for name in np.unique(v):masks[(col,name)]=v==name
    denoms=pd.read_csv(ANA/'stratum_denominators.csv')
    for r in denoms.itertuples():assert r.n_subset==int(masks[(r.subset,str(r.stratum))].sum())
    counts=pd.read_csv(ANA/'new_lost_threshold_counts.csv')
    for r in counts.itertuples():
        a,c=groups[(r.method,r.arm)],groups[(r.method,r.reference_arm)];mask=masks[(r.subset,str(r.stratum))]
        col=r.threshold+'_pass' if r.pass_type=='eligible' else 'numeric_'+r.threshold
        av,bv=boolean(a[col]),boolean(c[col]);actual=[(mask&av).sum(),(mask&bv).sum(),(mask&av&~bv).sum(),(mask&~av&bv).sum(),(mask&av&bv).sum(),(mask&~av&~bv).sum()]
        assert actual==[r.arm_pass,r.reference_pass,r.new_pass,r.lost_pass,r.both_pass,r.neither_pass]
        assert r.arm_pass-r.reference_pass==r.new_pass-r.lost_pass and r.new_pass+r.lost_pass+r.both_pass+r.neither_pass==r.n_subset
        close(100*(r.new_pass-r.lost_pass)/r.n_subset if r.n_subset else np.nan,r.net_change_pp)
    names,cell=np.unique(cases.spatial_cell.astype(str),return_inverse=True)
    draws=np.random.default_rng(20261025).multinomial(len(names),np.ones(len(names))/len(names),size=2000)
    # This local file was SHA256-verified above against ANALYSIS_COMPLETE.
    saved=np.load(ANA/'bootstrap_spatial_cell_draws.npz',allow_pickle=True)
    assert np.array_equal(names,saved['spatial_cells'].astype(str)) and np.array_equal(draws,saved['draws'])
    table=pd.read_csv(ANA/'paired_bootstrap.csv');tested=0
    for r in table.itertuples():
        if r.metric not in ['r','H_deseasonal_r','r06_pass','r07_pass','r08_pass']:continue
        if (r.subset,str(r.stratum)) not in [('all8898','all'),('old_QP_r07','failed'),('P_available','yes'),('continent','Africa')]:continue
        a,c=groups[(r.method,r.arm)],groups[(r.method,r.reference_arm)]
        value=a[r.metric].to_numpy(float)-c[r.metric].to_numpy(float)
        v,n=stats(value,boolean(a.eligible)&boolean(c.eligible),masks[(r.subset,str(r.stratum))],cell,draws,r.metric.endswith('_pass'))
        close(v,[r.mean_gain,r.median_gain,r.mean_gain_ci025,r.mean_gain_ci975]);assert n==r.n_paired_finite
        tested+=1
    assert tested==1000
    maincheck=dict(passed=True,score_rows=195756,all22_arms_recomputed_from_frozen_predictions=True,
        all_threshold_transition_rows_checked=len(counts),mean_CI_rows_independently_recomputed=tested,
        spatial_cells=len(names),shared_draws=2000,whole_mother_denominator=N,
        no_NSE_or_seasonal_gate=True,arm_totals=totals)
    losocheck=None
    if (LOS/'ABLATION_ANALYSIS_COMPLETE.json').exists():
        done=verify_outputs(LOS/'ABLATION_ANALYSIS_COMPLETE.json')
        assert done['not_standalone_site_addition'] and done['site_contributions_not_additive']
        index=pd.read_csv(PRED/'ablation_index.csv',dtype={'physical_source_id':str})
        detail=pd.read_csv(LOS/'target_source_conditional_contributions.csv.gz',dtype={'physical_source_id':str},low_memory=False)
        assert len(index)==681 and len(detail)==1362
        abp=np.load(PRED/'ablation_predictions.npy',mmap_mode='r');absup=np.load(PRED/'ablation_support.npy',mmap_mode='r');abfit=np.load(PRED/'ablation_fit_estimable.npy',mmap_mode='r')
        for mi,m in enumerate(METHODS):
            d=detail.loc[detail.method==m].sort_values('ablation_index').reset_index(drop=True)
            assert np.array_equal(d.row,index.row) and np.array_equal(d.physical_source_id,index.physical_source_id)
            rr=index.row.to_numpy(int);v=numerical(truth[rr],abp[:,mi],base[rr])
            for key in ['r','H_deseasonal_r','alpha','delta','NSE']:close(v[key],d[key+'_without'],atol=1e-8 if key=='NSE' else 1e-10)
            eligible=v['valid']&abfit[:,mi]&(absup[:,mi].sum(1)>0)&np.isfinite(abp[:,mi]).all(1)&(abp[:,mi]>=0).all(1)
            assert np.array_equal(eligible,boolean(d.eligible_without))
            for row in d.itertuples():
                current=groups[(m,row.arm)].iloc[row.row];baselinearm='FULL_BASE' if row.policy=='FULL' else 'STRICT_BASE';old=groups[(m,baselinearm)].iloc[row.row]
                close([row.r_new,row.r_baseline],[current.r,old.r])
                assert row.conditional_additional_r07==bool(row.r07_pass_new and not row.r07_pass_without)
                assert row.conditional_lost_r07==bool(not row.r07_pass_new and row.r07_pass_without)
                assert row.source_necessary_for_this_network_recovery==bool(row.r07_pass_new and not row.r07_pass_baseline and not row.r07_pass_without)
                assert row.source_responsible_for_this_network_loss==bool(not row.r07_pass_new and row.r07_pass_baseline and row.r07_pass_without)
        sites=pd.read_csv(LOS/'site_by_duration_conditional_summary.csv',dtype={'physical_source_id':str})
        assert len(sites)==109*2*3*2 and sites.physical_source_id.nunique()==109
        for r in sites.itertuples():
            g=detail.loc[(detail.physical_source_id==r.physical_source_id)&(detail.policy==r.policy)&(detail.method==r.method)&(detail.new_H_months==r.new_H_months)]
            assert r.selected_targets==len(g) and r.additional_r07==int(g.conditional_additional_r07.sum()) and r.lost_r07==int(g.conditional_lost_r07.sum())
            assert r.net_conditional_r07==r.additional_r07-r.lost_r07
            assert r.necessary_for_network_recovery_vs_baseline==int(g.source_necessary_for_this_network_recovery.sum())
            arm=f'{r.policy}_H{r.new_H_months}';main=groups[(r.method,arm)];value=np.zeros(N);eligible=boolean(main.eligible).copy()
            ix=g.row.to_numpy(int);value[ix]=g.r_new.to_numpy()-g.r_without.to_numpy();eligible[ix]=boolean(g.eligible_new)&boolean(g.eligible_without)
            v,n=stats(value,eligible,np.ones(N,bool),cell,draws)
            close([v[0],v[2],v[3]],[r.r_mean_gain_all_mothers,r.r_mean_gain_all_mothers_ci025,r.r_mean_gain_all_mothers_ci975])
        stability=pd.read_csv(LOS/'site_duration_stability.csv',dtype={'physical_source_id':str})
        for r in stability.itertuples():
            g=sites.loc[(sites.physical_source_id==r.physical_source_id)&(sites.policy==r.policy)&(sites.method==r.method)].sort_values('new_H_months')
            values=g.net_conditional_r07.to_numpy();good=np.flatnonzero(values>0);first=good[0] if len(good) else None
            expected=[24,36,60][first] if first is not None else np.nan
            close(r.earliest_tested_H_with_positive_net_r07,expected)
            reverse=bool((values[first+1:]<0).any()) if first is not None else False
            assert r.later_negative_net_r07_after_first_gain==reverse
            assert r.net_r07_non_decreasing_over_tested_durations==bool((np.diff(values)>=0).all())
        targetst=pd.read_csv(LOS/'target_site_duration_stability.csv.gz',dtype={'physical_source_id':str})
        for r in targetst.itertuples():
            g=detail.loc[(detail.physical_source_id==r.physical_source_id)&(detail.policy==r.policy)&(detail.method==r.method)&(detail.row==r.row)]
            vals=[];nets=[]
            for H in [24,36,60]:
                gg=g.loc[g.new_H_months==H];selected=len(gg)>0
                value=float(gg.iloc[0].r_new-gg.iloc[0].r_without) if selected else 0.
                net=int(gg.iloc[0].conditional_additional_r07)-int(gg.iloc[0].conditional_lost_r07) if selected else 0
                assert bool(getattr(r,f'selected_H{H}'))==selected;close(getattr(r,f'r_conditional_gain_H{H}'),value)
                assert getattr(r,f'r07_conditional_net_H{H}')==net;vals.append(value);nets.append(net)
            assert r.any_positive_to_negative_r_reversal==any(np.isfinite(vals[i]) and np.isfinite(vals[j]) and vals[i]>1e-12 and vals[j]<-1e-12 for i in range(3) for j in range(i+1,3))
            assert r.any_positive_to_negative_r07_reversal==any(nets[i]>0 and nets[j]<0 for i in range(3) for j in range(i+1,3))
        # Source-month ledger rechecked from frozen selected identities.
        ids=np.load(PRED/'selected_ids.npy',mmap_mode='r');loc=pd.read_csv(PRED/'physical_locations.csv',dtype={'grdc_id':str}).set_index('grdc_id')
        ledger=pd.read_csv(LOS/'source_month_use_ledger.csv',dtype={'physical_source_id':str})
        for r in ledger.itertuples():
            a=ARMS.index(f'{r.policy}_H{r.new_H_months}');source=40000+loc.index.get_loc(r.physical_source_id)
            rr,mm,slot=np.where(ids[:,a]==source);sel=mm<60 if r.period=='H' else mm>=60;rr,mm=rr[sel],mm[sel]
            dates=cases.history_start.to_numpy()[rr]+mm
            assert r.unique_source_months==len(np.unique(dates)) and r.reused_target_months==len(dates) and r.unique_targets==len(np.unique(rr))
        losocheck=dict(passed=True,all_source_target_pairs=681,all_method_deletion_score_rows=1362,
            all109_locations_retained=True,site_duration_rows_checked=len(sites),source_mean_r_CI_rows_independently_recomputed=len(sites),
            target_duration_reversal_rows_checked=len(targetst),unique_source_month_ledger_rows_checked=len(ledger),
            necessary_recovery_and_loss_logic_verified=True,non_additive_conditional_not_standalone_scope_verified=True,
            source_analysis_complete_sha256=sha(LOS/'ABLATION_ANALYSIS_COMPLETE.json'))
    report=dict(status='PASS_MAIN_AND_LOSO_POST_SCORING_QA' if losocheck else 'PASS_MAIN_POST_SCORING_QA_LOSO_PENDING',
        passed=True,checked_at_utc=datetime.now(timezone.utc).isoformat(),audit_script_sha256=sha(__file__),
        predictions_freeze_sha256=sha(PRED/'PREDICTIONS_FROZEN.json'),main_analysis_complete_sha256=sha(ANA/'ANALYSIS_COMPLETE.json'),
        main=maincheck,LOSO=losocheck,
        interpretation_checks=['FULL_BASE opens previously excluded existing GSIM source folds; its improvement is neither new external observations nor an algorithm gain.',
            'FULL is a single-target missing-record counterfactual using other existing gauges, not the original spatially independent source-domain test.',
            'Known self/twin exclusion is independently audited; unrecorded duplicates cannot be claimed absent.',
            'Whole8898 results describe this fixed H60/G120 evaluation cohort, not global natural-gap recoverability.',
            '109 external locations are107 South African plus1 US and1 Australian gauge; they are archive-external existing sites, not certified contemporary construction recommendations.',
            'Conditional source deletion effects are not additive and not standalone site-deployment gains; later duration reversals remain visible.'],
        frozen_predictions_protocol_identity_and_scores_modified=False)
    save(HERE/'POST_SCORING_QA.json',report)
    note='# 评分后独立核查\n\n主评分核验通过：22臂共195,756行；全部r、α、δ、NSE和达标资格独立重算一致；新增/失去计数与8,898母分母一致；1,000行配对空间均值置信区间重算一致。\n\nFULL_BASE的提升来自开放既有GSIM来源域，不能记为新增观测或算法收益。FULL是单目标缺测反事实，和原空间隔离评价必须分开报告；94.10%只属于当前固定H60/G120验证队列。自体及已知孪生已排除，但不能声称未知重复不存在。\n\n'
    note+=('逐来源核验也通过：681组移除对照、1,362行分方法评价、全部109位置与1,308行年限条件贡献复核；必要恢复、负收益和后续反转保留。移除贡献不可相加，也不是单站建设收益。\n' if losocheck else '逐来源统计尚未产生完整完成标记，本回执只确认主评分；待完成后继续核验。\n')
    note+='\n未修改身份、冻结预测、协议或正式统计。\n';(HERE/'POST_SCORING_QA说明.md').write_text(note,encoding='utf8')
    print(json.dumps({k:v for k,v in report.items() if k!='main'},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
