"""Prepared scoring harness. All real scoring requires freeze + independent QA.

Expected prediction interface is finalized by the producer before freezing.
Import and --synthetic-check read no target truth or prediction arrays.
"""
from pathlib import Path
from datetime import datetime,timezone
import os,sys,json,hashlib,argparse
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
CODE=next(p for p in HERE.parents if p.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd
from trial_score_core import metrics,paired,transition,synthetic_checks,THRESHOLDS
PRED=ROOT/'trial_predictions';OUT=ROOT/'trial_analysis'
PREV=ROOT.parent/'r4_global_information_20261025'
OLD=ROOT.parent/'r3_global_single_condition_20261022'
ARMS=['STRICT_BASE','FULL_BASE','STRICT_H24','STRICT_H36','STRICT_H60',
      'BRIDGE_H24','BRIDGE_H36','BRIDGE_H60','FULL_H24','FULL_H36','FULL_H60']
METHODS=['ridge','rbf_ridge'];N=8898;L=120;B=2000;SEED=20261025
NUMERIC=['r','H_deseasonal_r','alpha','delta','absolute_alpha_error','absolute_delta_error','NSE','S']
GAIN=[('r',1),('H_deseasonal_r',1),('absolute_alpha_error',-1),('absolute_delta_error',-1),('NSE',1),('S',1)]


def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()


def read(path):return json.loads(Path(path).read_text(encoding='utf8'))


def save(path,obj):
    def clean(v):
        if isinstance(v,dict):return {str(k):clean(x) for k,x in v.items()}
        if isinstance(v,(list,tuple,np.ndarray)):return [clean(x) for x in v]
        if isinstance(v,np.generic):return clean(v.item())
        if isinstance(v,float) and not np.isfinite(v):return None
        return v
    Path(path).write_text(json.dumps(clean(obj),ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')


def truth(s):
    if s.dtype==bool:return s.to_numpy()
    v=s.astype(str).str.lower();assert v.isin(['true','false','1','0','1.0','0.0']).all()
    return v.isin(['true','1','1.0']).to_numpy()


def resolve(name,base):
    p=Path(name);return p if p.is_absolute() else Path(base)/p


def verify(path,base):
    obj=read(path)
    for name,expected in obj['files'].items():
        expected=expected['sha256'] if isinstance(expected,dict) else expected
        assert sha(resolve(name,base))==expected,f'Frozen dependency changed: {name}'
    return obj


def guard(authorized):
    # This function must complete before real predictions or target G are read.
    if not authorized:raise RuntimeError('Require explicit --authorized-after-freeze. No real scores read.')
    fpath=PRED/'PREDICTIONS_FROZEN.json';qpath=HERE/'PRE_SCORING_QA_PASS.json'
    if not fpath.exists() or not qpath.exists():raise RuntimeError('Await all predictions frozen and independent pre-score QA.')
    qa=read(qpath);assert qa.get('passed') is True and 'PASS' in qa.get('status','')
    assert qa.get('predictions_freeze_sha256')==sha(fpath)
    freeze=verify(fpath,PRED)
    interface=PRED/'SCORING_INTERFACE.json';spec=read(interface)
    listed={str(resolve(p,PRED).resolve()) for p in freeze['files']}
    assert str(interface.resolve()) in listed,'Scoring interface must be frozen with predictions.'
    assert spec['arms']==ARMS and spec['methods']==METHODS and spec['N']==N and spec['G']==L
    for key in ['predictions','support','fit_estimable','training_mask']:
        assert str(resolve(spec[key],PRED).resolve()) in listed,f'Unfrozen array: {key}'
    cf=resolve(spec['code_freeze_file'],ROOT)
    assert qa.get('code_freeze_sha256')==sha(cf),'QA must also bind the code/input freeze.'
    verify(cf,ROOT)
    # The scorer itself must be fixed in the independent QA before permission.
    assert qa.get('scoring_code_sha256')==sha(__file__)
    assert qa.get('scoring_core_sha256')==sha(HERE/'trial_score_core.py')
    audit=read(HERE/'BASELINE_INPUT_REUSE_QA.json');assert audit['passed']
    for p,entry in audit['frozen_dependency_files'].items():assert sha(p)==entry['sha256']
    return spec,freeze,qa


def finite(v,stat):
    v=np.asarray(v,float);v=v[np.isfinite(v)]
    return float(np.mean(v) if stat=='mean' else np.median(v)) if len(v) else np.nan


def groups(cases,baseindex):
    oldfail=truth(baseindex.baseline_failed_r07);p=truth(baseindex.P_available)
    ans=[('all8898','all',np.ones(N,bool)),('old_QP_r07','failed',oldfail),('old_QP_r07','passed',~oldfail),
         ('old_QP_eligibility','unevaluable',truth(baseindex.baseline_unestimable_or_unevaluable)),
         ('P_available','yes',p),('P_available','no',~p)]
    for name in ['continent','kg_major']:
        val=cases[name].fillna('Unknown').astype(str).to_numpy()
        for x in np.unique(val):ans.append((name,x,val==x))
    return ans


def pair_definitions():
    pairs=[]
    for policy in ['STRICT','BRIDGE','FULL']:
        base='FULL_BASE' if policy=='FULL' else 'STRICT_BASE'
        for h in [24,36,60]:pairs.append((f'{policy}_H{h}',base,'added_external_sources'))
        for new,old in [(36,24),(60,36),(60,24)]:pairs.append((f'{policy}_H{new}',f'{policy}_H{old}','additional_common_history'))
    pairs.append(('FULL_BASE','STRICT_BASE','old_source_domain_change'))
    for h in [24,36,60]:
        pairs.append((f'BRIDGE_H{h}',f'STRICT_H{h}','external_source_fold_release'))
        pairs.append((f'FULL_H{h}',f'BRIDGE_H{h}','old_source_fold_release'))
    assert len(pairs)==25
    return pairs


def score(authorized=False):
    spec,freeze,qa=guard(authorized)
    assert not (OUT/'ANALYSIS_COMPLETE.json').exists(),'Never overwrite completed analysis.'
    OUT.mkdir(exist_ok=True)
    save(OUT/'SCORING_AUTHORIZATION.json',dict(authorized_at_utc=datetime.now(timezone.utc).isoformat(),
        prediction_freeze_sha256=sha(PRED/'PREDICTIONS_FROZEN.json'),pre_score_QA_sha256=sha(HERE/'PRE_SCORING_QA_PASS.json'),
        scoring_code_sha256=sha(__file__),scoring_core_sha256=sha(HERE/'trial_score_core.py'),
        parameter_tuning_or_source_selection=False))
    cases=pd.read_csv(resolve(spec['cases_file'],ROOT));bi=pd.read_csv(HERE/'BASELINE_REUSE_INDEX.csv')
    assert len(cases)==N and np.array_equal(cases.row,np.arange(N))
    for col in ['station_id','case_id','raw_index','history_start','history_end','gap_start','gap_end','outer_fold']:
        assert np.array_equal(cases[col],bi[col]),col
    arrays={key:np.load(resolve(spec[key],PRED),mmap_mode='r') for key in ['predictions','support','fit_estimable','training_mask']}
    assert arrays['predictions'].shape==arrays['support'].shape==(N,11,2,L)
    assert arrays['fit_estimable'].shape==(N,11,2) and arrays['training_mask'].shape==(N,11,60)
    oldp=np.load(PREV/'predictions/predictions.npy',mmap_mode='r')[:,:,1]
    olds=np.load(PREV/'predictions/support.npy',mmap_mode='r')[:,:,1]
    oldfit=np.load(PREV/'predictions/flags.npy',mmap_mode='r')[:,:,1,0]
    np.testing.assert_allclose(arrays['predictions'][:,0],oldp,rtol=0,atol=0,equal_nan=True)
    assert np.array_equal(arrays['support'][:,0],olds) and np.array_equal(arrays['fit_estimable'][:,0],oldfit)
    # First target-G access occurs below, after all authorization and anchors.
    cache=np.load(OLD/'global_data/QC20_Q.npy',mmap_mode='r')
    y=np.stack([cache[int(e.raw_index),int(e.gap_start):int(e.gap_end)] for e in cases.itertuples()])
    calendar=np.load(PREV/'prepared_inputs/target_H_raw_calendar.npy')
    b=calendar[np.arange(N)[:,None],(cases.gap_start.to_numpy()[:,None]+np.arange(L))%12]
    frames=[];models={};idcols=['row','case_id','station_id','raw_index','latitude','longitude','continent','country','kg_major','spatial_cell','outer_fold','history_start','history_end','gap_start','gap_end']
    for ai,arm in enumerate(ARMS):
        for mi,method in enumerate(METHODS):
            m=pd.DataFrame(metrics(y,arrays['predictions'][:,ai,mi],b,arrays['fit_estimable'][:,ai,mi],arrays['support'][:,ai,mi]))
            f=pd.concat([cases[idcols].reset_index(drop=True),m],axis=1)
            f['arm']=arm;f['method']=method;f['model_key']=f'{method}|{arm}'
            f['training_months']=arrays['training_mask'][:,ai].sum(1)
            frames.append(f);models[(method,arm)]=f
    scores=pd.concat(frames,ignore_index=True);assert len(scores)==195756
    assert np.array_equal(models[('ridge','STRICT_BASE')].r07_pass.to_numpy(),truth(bi.r07_pass))
    scores.to_csv(OUT/'scores_long.csv.gz',index=False)
    base=metrics(y,b,b,np.ones(N,bool),np.ones((N,L),bool))
    seasonal=pd.concat([cases[idcols].reset_index(drop=True),pd.DataFrame(base)],axis=1)
    seasonal['eligibility_note']='Numerically evaluable seasonal reference, not a fitted source-supported model.'
    seasonal['actual_model_estimable']=False;seasonal['support_months']=0
    seasonal.to_csv(OUT/'seasonal_reference.csv',index=False)
    grouping=groups(cases,bi);names,cell=np.unique(cases.spatial_cell.astype(str),return_inverse=True)
    draws=np.random.default_rng(SEED).multinomial(len(names),np.ones(len(names))/len(names),size=B)
    olddraw=np.load(PREV/'analysis/bootstrap_spatial_cell_draws.npz')
    assert np.array_equal(names,olddraw['spatial_cells'].astype(str)) and np.array_equal(draws,olddraw['draws'])
    np.savez_compressed(OUT/'bootstrap_spatial_cell_draws.npz',draws=draws.astype(np.int16),spatial_cells=names)
    pd.DataFrame([dict(subset=s,stratum=t,n_subset=int(m.sum())) for s,t,m in grouping]).to_csv(OUT/'stratum_denominators.csv',index=False)
    summaries=[]
    for (method,arm),f in models.items():
        eligible=truth(f.eligible)
        for subset,stratum,mask in grouping:
            ok=eligible&mask;nn=int(mask.sum())
            rec=dict(method=method,arm=arm,subset=subset,stratum=stratum,n_subset=nn,n_eligible=int(ok.sum()),n_unestimable_or_unevaluable=int((mask&~eligible).sum()))
            for name,_ in THRESHOLDS:
                cnt=int((mask&truth(f[name+'_pass'])).sum());rec[name+'_pass']=cnt;rec[name+'_pct_mother']=100*cnt/nn if nn else np.nan
            for name in NUMERIC:
                for stat in ['mean','median']:rec[name+'_'+stat]=finite(f.loc[ok,name],stat)
            rec['NSE_below_minus100']=int((mask&truth(f.NSE_below_minus100)).sum())
            summaries.append(rec)
    pd.DataFrame(summaries).to_csv(OUT/'summary_by_predefined_stratum.csv',index=False)
    pairedrows=[];countrows=[];stationrows=[]
    for method in METHODS:
        for aa,bb,interpretation in pair_definitions():
            a,c=models[(method,aa)],models[(method,bb)];eligible=truth(a.eligible)&truth(c.eligible)
            label=f'{method}:{aa}-{bb}'
            ss=cases[idcols].copy();ss['contrast']=label;ss['interpretation']=interpretation
            ss['new_r07']=truth(a.r07_pass)&~truth(c.r07_pass);ss['lost_r07']=~truth(a.r07_pass)&truth(c.r07_pass)
            for metric,direction in GAIN:ss[metric+'_gain']=direction*(a[metric].to_numpy()-c[metric].to_numpy())
            ss['paired_eligible']=eligible;stationrows.append(ss)
            for subset,stratum,mask in grouping:
                head=dict(contrast=label,method=method,arm=aa,reference_arm=bb,interpretation=interpretation,subset=subset,stratum=stratum)
                for name,_ in THRESHOLDS:
                    for prefix,typ in [('','eligible'),('numeric_','numeric')]:
                        col=name+'_pass' if not prefix else prefix+name
                        countrows.append({**head,'threshold':name,'pass_type':typ,**transition(truth(a[col]),truth(c[col]),mask)})
                for metric,direction in GAIN+[(name+'_pass',1) for name,_ in THRESHOLDS]+[('support_months',1)]:
                    v=direction*(a[metric].to_numpy(float)-c[metric].to_numpy(float));binary=metric.endswith('_pass')
                    use=np.ones(N,bool) if metric=='support_months' else eligible
                    pairedrows.append({**head,'metric':metric,'benefit_direction':direction,**paired(v,use,mask,cell,draws,binary=binary)})
    pd.DataFrame(pairedrows).to_csv(OUT/'paired_bootstrap.csv',index=False)
    pd.DataFrame(countrows).to_csv(OUT/'new_lost_threshold_counts.csv',index=False)
    pd.concat(stationrows,ignore_index=True).to_csv(OUT/'paired_station_changes.csv.gz',index=False)
    files={p.name:dict(sha256=sha(p),bytes=p.stat().st_size) for p in OUT.iterdir() if p.is_file()}
    save(OUT/'ANALYSIS_COMPLETE.json',dict(status='COMPLETE_FIXED8898_OBSERVATION_LOCATION_TRIAL',N=N,score_rows=len(scores),
        arms=ARMS,methods=METHODS,spatial_cells=len(names),bootstrap_replicates=B,seed=SEED,
        baseline_alignment_exact=True,old_QP_r07_pass=int(truth(bi.r07_pass).sum()),
        no_NSE_or_seasonal_gate=True,new_source_conditional_contribution_analysis_included=False,
        primary_r07_scope='basic monthly timing agreement; not water-volume, extremes or trend fidelity',
        output_files=files))
    print('OBSERVATION_LOCATION_ANALYSIS_COMPLETE',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--synthetic-check',action='store_true')
    parser.add_argument('--authorized-after-freeze',action='store_true');args=parser.parse_args()
    if args.synthetic_check:
        result=synthetic_checks();result['core_sha256']=sha(HERE/'trial_score_core.py')
        result['script_sha256']=sha(__file__);save(HERE/'SCORING_SYNTHETIC_QA.json',result)
        print(json.dumps(result,ensure_ascii=False,indent=2))
    else:score(args.authorized_after_freeze)
