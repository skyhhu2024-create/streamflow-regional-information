"""Read-only decomposition of frozen natural-gap validation and archive evidence.

No new prediction, refit, quality gate or spatial plotting is performed.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
CODE = HERE.parents[2]
OLD = CODE / 'V42.3/experiments'
SCREEN = OLD / 'grdc_tuopu_screen_20261015'
VALID = OLD / 'grdc_natural_gap_validation_20261015'
ARCHIVE = CODE / 'V42.2/experiments/r3_global_k4_20261014/outputs/R1_scope'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def jwrite(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def med(series):
    values = np.asarray(series, float)
    values = values[np.isfinite(values)]
    return float(np.median(values)) if len(values) else None


def ci(group, column):
    finite = group[np.isfinite(group[column])]
    cells = [v[column].to_numpy(float) for _, v in finite.groupby('cell', sort=True)]
    if len(cells) < 5:
        return [None, None]
    rng = np.random.default_rng(441015)
    draws = [np.median(np.concatenate([cells[j] for j in rng.integers(0, len(cells), len(cells))])) for _ in range(2000)]
    return [float(x) for x in np.quantile(draws, [.025, .975])]


def freeze():
    path = HERE / 'protocol.json'
    assert not path.exists(), 'Do not replace a completed protocol.'
    files = [VALID/'monthly_evaluation_evidence.csv.gz', VALID/'complete_calendar_year_scores.csv',
             VALID/'station_paired_comparisons.csv', SCREEN/'station_opportunities_with_area_tiers.csv',
             SCREEN/'alias_flags/monthly_alias_input_flags.csv', ARCHIVE/'archive_completion.npz',
             ARCHIVE/'station_completion.csv', SCREEN/'gsim_frozen_inputs.json']
    protocol = {
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'TASK_DECOMPOSITION_AND_AVAILABILITY_PROTOCOL_FIXED_BEFORE_NEW_SUMMARIES',
        'prior_knowledge': 'Original full-cohort validation has already been seen and is reported in V45. This is a new predeclared decomposition, not a prospectively unseen validation dataset.',
        'C': {
            'cohort': 'Existing primary A: exact identity, verified units, positive comparable areas, original observed-overlap agreement, Calculated Flag100 truth, frozen predictions, no metadata-flagged actual same-gauge alias; retain all outcomes.',
            'year_task': 'Reconstruct each station/calendar-year label from all 12 monthly original-gap labels, and independently verify against original GSIM observed bounds. Do not use mixed station labels for task assignment. A full originally missing calendar year must have one task.',
            'statistic': 'For each station and task, median full-calendar-year absolute runoff-volume percentage error separately for DAT4 and arithmetic seasonal baseline; station paired gain is baseline median minus DAT4 median. Then take median across stations equally. Pool forward/backward annual rows before station medians for extensions combined; preserve all original directions separately.',
            'groups': ['all', 'internal', 'forward', 'backward', 'extensions'],
            'uncertainty': '2,000 whole 5-degree-cell resamples, seed441015, cells retain complete station metrics, no CI below5 cells. This is an inherited uncertainty method, not a new map template.',
            'robustness': 'Country leave-one-out for every task regardless of sign; counts, undefined and adverse outcomes retained.'
        },
        'F': {
            'main_denominator': 'Every originally missing 1980-2015 month at all original identity-confirmed, unit-verified, positive-area-comparable, observed-overlap-compatible A gauges, including gauges with no external truth during gaps. Do not restrict denominator to gauges with retrieved missing-month truth or predictions.',
            'quality_sensitivities': ['A+B overlap-compatible, missing-area B identified separately', 'All1029 identity/unit-confirmed gauges without an observed-overlap gate: broader archive-record-existence screen only, not established validation truth'],
            'numerator': 'Unique GSIM gauge-months in original missing mask with finite nonnegative native GRDC Calculated and Flag100. For A require same established overlap-compatible identity. No need to remove alias-input months because this endpoint is existence of target observations rather than predictive accuracy.',
            'states': ['U1: missing and no qualifying relationship', 'U2: missing and qualifying relationship but no synchronous report', 'synchronous_no_target_calendar_calibration: missing with qualified synchronous report but no accepted frozen prediction', 'synchronous_reconstructed: missing with qualified synchronous report and accepted frozen prediction'],
            'unknown': 'Every denominator month without retrieved Flag100 is unknown/not demonstrated here, never evidence that no measurement exists. Retrieval identifies target truth at originally U2 months, not successful restoration of original-qualified reference support.',
            'limits': 'Conditional matched local-file sample only, not representative global fraction. Does not prove these records were openly shared or accessible when GSIM was compiled; source archive later-added records possible. No extrapolation to Africa/Asia retrieval priority or comparative cost evidence.'
        },
        'source_sha256': {str(p.resolve()): sha(p) for p in files},
    }
    jwrite(path, protocol)


def task_results(months, original_observed, active_ids):
    active_index = {str(s): i for i, s in enumerate(active_ids)}
    paired = months[months.paired_metric_eligible & months.comparable_positive_area].copy()
    assert len(paired) == 7326 and paired.GSIM_id.nunique() == 362
    paired['year'] = pd.to_datetime(paired.date).dt.year
    years = []
    for (sid, year), group in paired.groupby(['GSIM_id', 'year'], sort=True):
        dates = pd.to_datetime(group.date)
        if len(group) != 12 or set(dates.dt.month) != set(range(1, 13)):
            continue
        assert group.original_gap_type.nunique() == 1, (sid, year)
        task = group.original_gap_type.iloc[0]
        original = original_observed[active_index[sid]]
        observed_at = np.flatnonzero(original)
        ti = (year - 1980) * 12 + np.arange(12)
        assert not original[ti].any()
        check = 'backward' if max(ti) < min(observed_at) else 'forward' if min(ti) > max(observed_at) else 'internal'
        assert check == task
        truth_volume = float((group.truth_m3s * group.days_in_month * 86400).sum())
        row = {'GSIM_id': sid, 'year': int(year), 'task': task, 'country': group.country.iloc[0],
               'latitude': float(group.latitude.iloc[0]), 'longitude': float(group.longitude.iloc[0]),
               'truth_volume_m3': truth_volume, 'zero_truth_volume': truth_volume <= 0}
        for model in ['DAT4', 'seasonal_arithmetic', 'seasonal_zero_anomaly']:
            volume = float((group[model] * group.days_in_month * 86400).sum())
            row[model + '_error_pct'] = 100 * abs(volume - truth_volume) / truth_volume if truth_volume > 0 else np.nan
        years.append(row)
    annual = pd.DataFrame(years)
    # Independent agreement with previously frozen annual score output.
    previous = pd.read_csv(VALID/'complete_calendar_year_scores.csv')
    previous = previous[previous.scope.eq('all_paired') & previous.evidence_tier.eq('A_positive_areas')]
    for model in ['DAT4', 'seasonal_arithmetic', 'seasonal_zero_anomaly']:
        old = previous[previous.model.eq(model)].set_index(['GSIM_id', 'year'])
        new = annual.set_index(['GSIM_id', 'year'])
        assert new.index.equals(old.index)
        assert np.allclose(new[model + '_error_pct'], old.absolute_annual_error_pct, atol=1e-10, rtol=1e-12, equal_nan=True)
    annual.to_csv(HERE/'C_complete_year_task_evidence.csv', index=False, encoding='utf-8-sig')
    station_rows = []
    for task in ['all', 'internal', 'forward', 'backward', 'extensions']:
        data = annual if task == 'all' else annual[annual.task.isin(['forward', 'backward'])] if task == 'extensions' else annual[annual.task.eq(task)]
        for sid, group in data.groupby('GSIM_id', sort=True):
            row = {'task': task, 'GSIM_id': sid, 'country': group.country.iloc[0],
                   'n_calendar_years': len(group), 'n_defined_years': int(group.DAT4_error_pct.notna().sum()),
                   'original_tasks': ','.join(sorted(group.task.unique())),
                   'cell': f'{int(np.floor(group.longitude.iloc[0]/5))}|{int(np.floor(group.latitude.iloc[0]/5))}'}
            for model in ['DAT4', 'seasonal_arithmetic', 'seasonal_zero_anomaly']:
                row[model + '_median_error_pct'] = med(group[model + '_error_pct'])
            row['paired_annual_gain_pp'] = row['seasonal_arithmetic_median_error_pct'] - row['DAT4_median_error_pct'] if row['DAT4_median_error_pct'] is not None else np.nan
            station_rows.append(row)
    stations = pd.DataFrame(station_rows)
    stations.to_csv(HERE/'C_station_task_paired_gains.csv', index=False, encoding='utf-8-sig')
    summaries = []
    loo = []
    for task, group in stations.groupby('task', sort=False):
        valid = group[np.isfinite(group.paired_annual_gain_pp)]
        low, high = ci(group, 'paired_annual_gain_pp')
        summaries.append({'task': task, 'n_gauges': len(group), 'n_defined_gauges': len(valid), 'n_undefined_gauges': len(group)-len(valid),
                          'n_calendar_station_years': int(group.n_calendar_years.sum()), 'n_spatial_cells': valid.cell.nunique(),
                          'median_target_history_only_error_pct': med(valid.seasonal_arithmetic_median_error_pct),
                          'median_plus_reference_error_pct': med(valid.DAT4_median_error_pct),
                          'median_paired_gain_pp': med(valid.paired_annual_gain_pp), 'ci95_low': low, 'ci95_high': high,
                          'improved': int(valid.paired_annual_gain_pp.gt(0).sum()), 'worse': int(valid.paired_annual_gain_pp.lt(0).sum()),
                          'tied': int(valid.paired_annual_gain_pp.eq(0).sum())})
        for country in sorted(group.country.unique()):
            remaining = group[~group.country.eq(country)]
            loo.append({'task': task, 'excluded_country': country, 'n_remaining_gauges': len(remaining),
                        'median_paired_gain_pp': med(remaining.paired_annual_gain_pp),
                        'median_target_history_only_error_pct': med(remaining.seasonal_arithmetic_median_error_pct),
                        'median_plus_reference_error_pct': med(remaining.DAT4_median_error_pct)})
    pd.DataFrame(summaries).to_csv(HERE/'C_task_summary.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(loo).to_csv(HERE/'C_task_country_leave_one_out.csv', index=False, encoding='utf-8-sig')
    return summaries


def archive_results(stations, truth, observed, support, filled, active_ids, station_info):
    index = {str(s): i for i, s in enumerate(active_ids)}
    station_info = station_info.set_index('station_id')
    qualified = station_info.loc[active_ids, 'n_qualified'].to_numpy(int)
    missing = ~observed
    states = {
        'U1': missing & (qualified == 0)[:, None],
        'U2': missing & (qualified > 0)[:, None] & ~support,
        'synchronous_no_target_calendar_calibration': missing & support & ~filled,
        'synchronous_reconstructed': missing & support & filled,
    }
    assert np.array_equal(np.stack(list(states.values())).sum(axis=0), missing)
    # All identity-confirmed target observations remain retained, including incompatible rows.
    assert len(truth) == 21535
    truth['t'] = (pd.to_datetime(truth.date).dt.year - 1980) * 12 + pd.to_datetime(truth.date).dt.month - 1
    truth_mask = np.zeros_like(observed)
    assert not truth.duplicated(['GSIM_id', 'date']).any()
    for row in truth.itertuples():
        j = index[row.GSIM_id]
        assert missing[j, row.t] and float(row.GRDC_Calculated_m3s) >= 0 and int(row.Flag) == 100
        truth_mask[j, row.t] = True
    cohorts = {
        'A_primary_positive_area_overlap_compatible': stations.observed_overlap_compatible & stations.comparable_positive_area,
        'B_missing_area_overlap_compatible': stations.observed_overlap_compatible & ~stations.comparable_positive_area,
        'AB_overlap_compatible_sensitivity': stations.observed_overlap_compatible,
        'all1029_identity_unit_only_existence_sensitivity': np.ones(len(stations), bool),
    }
    summaries = []
    country_rows = []
    station_rows = []
    for cohort, selected in cohorts.items():
        eligible = stations.loc[selected].copy()
        rows = np.array([index[s] for s in eligible.GSIM_id], int)
        groups = {'all_missing': missing, **states, 'qualified_synchronous_total': support}
        for label, state in groups.items():
            den = state[rows]
            got = den & truth_mask[rows]
            summaries.append({'cohort': cohort, 'state': label, 'cohort_gauges': len(rows), 'gauges_with_state': int(den.any(axis=1).sum()),
                              'GSIM_missing_months_denominator': int(den.sum()), 'retrieved_GRDC_Flag100_months': int(got.sum()),
                              'gauges_with_retrieved_months': int(got.any(axis=1).sum()), 'not_demonstrated_unknown_months': int(den.sum()-got.sum()),
                              'retrieved_fraction_pct': 100*float(got.sum())/int(den.sum()) if den.sum() else None})
            for country, country_st in eligible.groupby('country', sort=True):
                cr = np.array([index[s] for s in country_st.GSIM_id], int)
                country_den = state[cr]
                country_got = country_den & truth_mask[cr]
                country_rows.append({'cohort': cohort, 'country': country, 'state': label, 'gauges': len(cr),
                                     'GSIM_missing_months_denominator': int(country_den.sum()), 'retrieved_GRDC_Flag100_months': int(country_got.sum()),
                                     'not_demonstrated_unknown_months': int(country_den.sum()-country_got.sum()),
                                     'retrieved_fraction_pct': 100*float(country_got.sum())/int(country_den.sum()) if country_den.sum() else None})
        for st in eligible.itertuples():
            j = index[st.GSIM_id]
            row = {'cohort': cohort, 'GSIM_id': st.GSIM_id, 'country': st.country, 'GRDC_id': str(st.GRDC_id)}
            for label, state in groups.items():
                row[label + '_GSIM_missing'] = int(state[j].sum())
                row[label + '_GRDC_Flag100'] = int((state[j] & truth_mask[j]).sum())
            station_rows.append(row)
    pd.DataFrame(summaries).to_csv(HERE/'F_archive_retrieval_summary.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(country_rows).to_csv(HERE/'F_archive_retrieval_by_country.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(station_rows).to_csv(HERE/'F_station_denominators_and_retrieved_months.csv', index=False, encoding='utf-8-sig')
    return summaries


def main():
    if not (HERE/'protocol.json').exists():
        freeze()
    assert not (HERE/'results.json').exists(), 'Do not overwrite completed results.'
    protocol = json.loads((HERE/'protocol.json').read_text(encoding='utf-8'))
    with np.load(ARCHIVE/'archive_completion.npz', allow_pickle=True) as a:
        ids, observed, support, filled = [a[k] for k in ['station_id', 'observed', 'all_qualified_supported', 'filled']]
    stations = pd.read_csv(SCREEN/'station_opportunities_with_area_tiers.csv', dtype={'GSIM_id':str, 'GRDC_id':str, 'country':str}, keep_default_na=False)
    for col in ['comparable_positive_area', 'observed_overlap_compatible']:
        assert stations[col].dtype == bool
    months = pd.read_csv(VALID/'monthly_evaluation_evidence.csv.gz', dtype={'GSIM_id':str, 'GRDC_id':str, 'country':str}, keep_default_na=False)
    for column in ['truth_m3s', 'days_in_month', 'DAT4', 'seasonal_arithmetic', 'seasonal_zero_anomaly']:
        months[column] = pd.to_numeric(months[column], errors='coerce')
    truth = pd.read_csv(SCREEN/'alias_flags/monthly_alias_input_flags.csv', dtype={'GSIM_id':str, 'GRDC_id':str, 'country':str}, keep_default_na=False)
    C = task_results(months, observed, ids)
    F = archive_results(stations, truth, observed, support, filled, ids, pd.read_csv(ARCHIVE/'station_completion.csv'))
    for path, frozen_sha in protocol['source_sha256'].items():
        assert sha(path) == frozen_sha, path
    jwrite(HERE/'results.json', {'status':'COMPLETE_SOURCE_HASHES_UNCHANGED', 'C':C, 'F':F, 'protocol_sha256':sha(HERE/'protocol.json')})


if __name__ == '__main__':
    main()
