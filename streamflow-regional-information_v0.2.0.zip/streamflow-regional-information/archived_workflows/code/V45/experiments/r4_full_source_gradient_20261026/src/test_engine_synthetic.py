"""Synthetic-only safety/identity/control QA. Does not open project data."""
from pathlib import Path
import os
import sys
import json
import hashlib
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
sys.dont_write_bytecode = True
import engine as E
import numpy as np


def test():
    rng = np.random.default_rng(20261026)
    # Advanced-index layouts can change floating reductions at1e-16. Production
    # preserves old allQ[:, h] Fortran order even when safe source rows differ.
    layout_values = rng.uniform(0, 1000, (100, 432))
    layout_raw, layout_h = np.arange(0, 100, 2), np.arange(10, 70)
    old_layout = layout_values[layout_raw][:, layout_h]
    new_layout = np.asfortranarray(layout_values[layout_raw[:, None], layout_h[None, :]])
    for oldpart, newpart in zip(E.C.prep(old_layout, layout_h), E.C.prep(new_layout, layout_h)):
        np.testing.assert_array_equal(oldpart, newpart)
    h, g = np.arange(60), np.arange(60, 180)
    seasonal = np.sin(np.arange(180)*2*np.pi/12)*0.3
    latent = rng.normal(0, 0.3, 180)
    q = np.expm1(2+seasonal+latent+rng.normal(0, .12, (10, 180)))
    target = np.expm1(2+seasonal[:60]+latent[:60])
    tc, ts, tz = E.C.prep(target[None], h)
    tc, ts, tz = tc[0], float(ts[0]), tz[0]
    raw = np.arange(10)
    distance = np.array([0, 10, 50, 100, 150, 300, 500, 800, 900, 1500.])
    own = {0, 1}
    cl, sd, zh = E.C.prep(q[:, h], h)
    source = dict(raw=raw, Q=E.GuardedSourceAccessor(q, raw, own, 0, 180))
    a = E.build_composites(source, cl, sd, zh, tz, own, distance, h, g)
    assert not np.isin(a['selected_ids'], list(own)).any()
    # Every alias's targetG is unreadable. Poisoning it leaves all inputs identical.
    poisoned = q.copy()
    poisoned[list(own), 60:] = 1e100
    sp = dict(raw=raw, Q=E.GuardedSourceAccessor(poisoned, raw, own, 0, 180))
    b = E.build_composites(sp, cl, sd, zh, tz, own, distance, h, g)
    for k in a:
        np.testing.assert_array_equal(a[k], b[k])
    try:
        sp['Q'][0, g]
    except AssertionError:
        pass
    else:
        raise AssertionError('Identity guard did not stop targetG read')
    # All sources are complete and H-qualified; nearest safe source is50km,
    # including legal distinct sites located exactly on each withdrawal cutoff.
    np.testing.assert_array_equal(a['nearest_qualified_reporter_distance_G'], 50.)
    assert np.all(a['selected_distance'][1][a['selected_ids'][1] >= 0] > 100)
    assert np.all(a['selected_distance'][2][a['selected_ids'][2] >= 0] > 300)
    assert np.all(a['selected_distance'][3][a['selected_ids'][3] >= 0] > 800)
    # Change safe G values only: H composites, selectedIDs and H fits are fixed.
    changed = q.copy()
    changed[2:, 60:] *= 2
    sg = dict(raw=raw, Q=E.GuardedSourceAccessor(changed, raw, own, 0, 180))
    c = E.build_composites(sg, cl, sd, zh, tz, own, distance, h, g)
    np.testing.assert_array_equal(a['composites'][:, :60], c['composites'][:, :60])
    np.testing.assert_array_equal(a['selected_ids'], c['selected_ids'])
    np.testing.assert_array_equal(a['eligible_source_counts'], c['eligible_source_counts'])
    assert not np.array_equal(a['composites'][:, 60:], c['composites'][:, 60:])
    p = E.M.prepare_precipitation_lags(rng.uniform(0, 50, 183), history_start_month=0)
    basecl = np.array([target[h % 12 == month].mean() for month in range(12)])
    out = E.fit_arms(a['composites'][0], tz, tc, ts, basecl, True, p.h, p.g, p.g_climatology, True, g)
    out_no_p = E.fit_arms(a['composites'][0], tz, tc, ts, basecl, True, p.h, p.g, p.g_climatology, False, g)
    np.testing.assert_array_equal(out_no_p['predictions'][:, 0], out_no_p['predictions'][:, 1])
    np.testing.assert_array_equal(out_no_p['predictions'][:, 0], out_no_p['predictions'][:, 2])
    assert out['flags'][:, 1, 5].all() and out['flags'][:, 2, 6].all()
    # Climate control leaves H-dated boundary lags intact.
    for j in range(3):
        for lag in range(j+1, 4):
            assert p.g[j, lag] == p.g_climatology[j, lag]
    # Complete streamflow dropout gives no Q/QP supported output, even with P:
    # the design tests augmentation, not an unregistered P-only model.
    missing = np.full(180, np.nan)
    failed = E.fit_arms(missing, tz, tc, ts, basecl, True, p.h, p.g, p.g_climatology, True, g)
    assert not failed['support'].any() and not failed['flags'][..., 0].any()
    np.testing.assert_allclose(failed['predictions'], np.broadcast_to(basecl[g % 12], (2, 3, 120)))
    # E3 retains no-reporter months rather than treating them as0km.
    absent = q.copy()
    absent[2:, 100] = np.nan
    sa = dict(raw=raw, Q=E.GuardedSourceAccessor(absent, raw, own, 0, 180))
    d = E.build_composites(sa, cl, sd, zh, tz, own, distance, h, g)
    assert np.isnan(d['nearest_qualified_reporter_distance_G'][40])
    return dict(passed=True, synthetic_only=True, project_data_read=False,
        own_complete_identity_G_poison_invariant=True, safe_source_G_changes_do_not_change_H=True,
        original_source_H_reduction_layout_exact=True,
        D_masks_and_survivor_H_composites_checked=True, same_QP_fit_climate_control_enforced=True,
        noP_exactQ_fallback=True, noQ_not_mislabelled_as_P_only=True,
        nearest_all_qualified_and_no_report_preserved=True,
        engine_sha256=hashlib.sha256((Path(__file__).parent/'engine.py').read_bytes()).hexdigest())


if __name__ == '__main__':
    record = test()
    dest = Path(__file__).parent/'SYNTHETIC_QA.json'
    dest.write_text(json.dumps(record, indent=2)+'\n', encoding='utf8')
    print(json.dumps(record))
