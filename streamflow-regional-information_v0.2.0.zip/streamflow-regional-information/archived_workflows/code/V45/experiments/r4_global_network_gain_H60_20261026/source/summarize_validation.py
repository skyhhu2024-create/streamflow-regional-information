"""Read frozen scores; no selection, tuning, refitting or candidate reordering."""
from pathlib import Path
import sys,os,json,hashlib
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[k]='4'
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1];CODE=next(x for x in ROOT.parents if x.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
MODE=sys.argv[1] if len(sys.argv)>1 else 'all_inputs'
assert MODE in ('all_inputs','filtered_inputs')
E=ROOT/('evaluation' if MODE=='all_inputs' else 'evaluation_filtered');S=ROOT/'selection';OUT=ROOT/('results' if MODE=='all_inputs' else 'results_filtered');OUT.mkdir(exist_ok=True)

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def clean(x):
 if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
 if isinstance(x,(list,tuple,np.ndarray)):return [clean(v) for v in x]
 if isinstance(x,np.generic):return clean(x.item())
 if isinstance(x,float) and not np.isfinite(x):return None
 return x
def run():
 for f in [S/'SELECTION_FROZEN.json',E/'single/SCORES_FROZEN.json',E/'layouts/SCORES_FROZEN.json']:
  d=json.loads(f.read_text(encoding='utf8'))
  assert all(sha(p)==h for p,h in d['files'].items()),str(f)
 cand=pd.read_csv(ROOT/'design/selector_inputs/candidate_locations.csv',keep_default_na=False)
 target=pd.read_csv(S/'target_selection_status.csv',keep_default_na=False)
 cases=pd.read_csv(ROOT/'evaluation/background/cases.csv',keep_default_na=False)
 b=np.load(E/'single/baseline_metrics.npz');strict=b['identity_strict'];bp=b['success'];mother=b['mother_row'];elig=target.proxy_estimable.to_numpy(bool)[mother]
 paired=strict&elig
 proxy=np.load(S/'predicted_candidate_target_gain.npy',mmap_mode='r')
 pred=np.zeros(len(cand));pred_used=np.zeros(len(cand));nproxy=0
 policy=np.load(ROOT/'selection_usage/single_use_mask.npy',mmap_mode='r') if MODE=='filtered_inputs' else None
 allowed_targets=np.zeros(len(cand),int)
 for lo in range(0,len(cases),128):
  pick=mother[lo:lo+128][paired[lo:lo+128]]
  if len(pick):
   vals=proxy[pick];pred+=np.nansum(vals,axis=0);nproxy+=len(pick)
   allow=policy[pick] if policy is not None else np.isfinite(vals)
   pred_used+=np.nansum(np.where(allow,vals,0),axis=0);allowed_targets+=allow.sum(0)
 actual=pd.read_csv(E/'single/summary_by_candidate_or_layout_and_continent.csv');glob=actual[actual.region=='Global'].sort_values('arm_index').reset_index(drop=True)
 assert (glob.arm.to_numpy()==cand.station_id.to_numpy()).all()
 success=np.load(E/'single/success.npy',mmap_mode='r');met=np.load(E/'single/metrics.npy',mmap_mode='r');used=np.load(E/'single/new_channel_used.npy',mmap_mode='r');new=np.zeros(len(cand),int);lost=new.copy();r_sum=np.zeros(len(cand));r_n=np.zeros(len(cand),int)
 strict_used=np.sum(used[strict],axis=0);matched_used=np.sum(used[paired],axis=0)
 for lo in range(0,len(cases),128):
  ix=np.arange(lo,min(lo+128,len(cases)));ix=ix[paired[ix]]
  if not len(ix):continue
  ss=success[ix];new+=(ss&~bp[ix,None]).sum(0);lost+=(~ss&bp[ix,None]).sum(0)
  change=met[ix,:,0]-b['metrics'][ix,0,None];ok=np.isfinite(change);r_sum+=np.nansum(change,axis=0);r_n+=ok.sum(0)
 result=cand[['raw_index','station_id','physical_group_id','latitude','longitude','continent','country','header_river','header_station','spatial_cell']].copy()
 rank=pd.read_csv(S/'all_candidates_predicted_global_ranking.csv').set_index('raw_index').loc[cand.raw_index]
 result['frozen_global_rank']=rank.initial_rank.to_numpy();result['proxy_original_mother_sum']=rank.predicted_global_variance_gain.to_numpy();result['proxy_same_verified_targets']=pred
 result['proxy_for_frozen_usage_on_verified_targets']=pred_used;result['usage_allowed_matched_targets']=allowed_targets
 for col in ('new_passes','lost_passes','net_passes','net_pct_strict_evaluable','new_channel_used_n','mean_r_gain'):result[col]=glob[col].to_numpy()
 result['matched_target_n']=int(paired.sum());result['matched_r_n']=r_n;result['strict_used_n']=strict_used;result['matched_used_n']=matched_used
 result['matched_new_passes']=new;result['matched_lost_passes']=lost;result['matched_net_passes']=new-lost;result['matched_net_percentage_points']=100*(new-lost)/paired.sum();result['matched_mean_r_gain']=np.divide(r_sum,r_n,out=np.full(len(cand),np.nan),where=r_n>0)
 avail=pd.read_csv(ROOT/'evaluation/candidate_inputs/availability.csv');assert (avail.raw_index==cand.raw_index).all()
 for col in ('H_valid_months','H_quality','G_report_months'):result[col]=avail[col].to_numpy()
 complete=(avail.H_valid_months==60)&(avail.G_report_months==24)&avail.H_quality
 result['complete_HG']=complete;result.to_csv(OUT/'candidate_predicted_vs_observed.csv',index=False,encoding='utf-8-sig')
 corr=[];groups=[]
 for label,mask in [('All_candidates',np.ones(len(cand),bool)),('Complete_H60_G24',complete.to_numpy())]:
  checks=[('proxy_original_mother_sum','net_passes'),('proxy_same_verified_targets','matched_net_passes'),('proxy_same_verified_targets','matched_mean_r_gain')]
  if MODE=='filtered_inputs':checks += [('proxy_for_frozen_usage_on_verified_targets','matched_net_passes'),('proxy_for_frozen_usage_on_verified_targets','matched_mean_r_gain')]
  for x,y in checks:
   valid=mask&np.isfinite(result[x])&np.isfinite(result[y]);rho,p=spearmanr(result.loc[valid,x],result.loc[valid,y]);corr.append(dict(domain=label,predictor=x,outcome=y,n=int(valid.sum()),spearman_rho=rho,nominal_p=p))
  # Deciles remain the full frozen ranking; no outcome-dependent cutoff.
  for dec in range(10):
   pick=mask&(result.frozen_global_rank>dec*493)&(result.frozen_global_rank<=(dec+1)*493)
   groups.append(dict(domain=label,frozen_decile=dec+1,n=int(pick.sum()),mean_net_passes=result.loc[pick,'net_passes'].mean(),median_net_passes=result.loc[pick,'net_passes'].median(),mean_r_gain=result.loc[pick,'mean_r_gain'].mean(),mean_used_targets=result.loc[pick,'new_channel_used_n'].mean()))
 pd.DataFrame(corr).to_csv(OUT/'prediction_validation_correlations.csv',index=False);pd.DataFrame(groups).to_csv(OUT/'frozen_ranking_deciles.csv',index=False)
 layouts=pd.read_csv(E/'layouts/summary_by_candidate_or_layout_and_continent.csv');layouts.to_csv(OUT/'common_layout_results.csv',index=False)
 locations=pd.read_csv(S/'layouts.csv').merge(result,left_on='candidate_raw_index',right_on='raw_index',how='left')
 locations.to_csv(OUT/'common_layout_locations_and_single_results.csv',index=False,encoding='utf-8-sig')
 report=dict(mode=MODE,main_strict_targets=int(strict.sum()),proxy_estimable_within_main=int(paired.sum()),baseline_passes=int(bp[strict].sum()),baseline_pct=100*bp[strict].mean(),candidate_complete_H60_G24=int(complete.sum()),candidate_any_new_channel=int((result.strict_used_n>0).sum()),candidate_positive_net=int((result.net_passes>0).sum()),candidate_zero_net=int((result.net_passes==0).sum()),candidate_zero_net_without_used_observations=int(((result.net_passes==0)&(result.strict_used_n==0)).sum()),candidate_zero_net_with_used_observations=int(((result.net_passes==0)&(result.strict_used_n>0)).sum()),candidate_negative_net=int((result.net_passes<0).sum()),correlations=corr,global_layouts=layouts[layouts.region=='Global'].to_dict('records'),caveats=['Conditional variance is an uncalibrated proxy, not raw-r success probability.','Selected sites restore withdrawn locations, not additions beyond complete GSIM.','Future-complete candidate domain is interpretation only; no re-selection.','5905 evaluated targets do not represent a measured success rate for all17161 mother targets.','No added observations used means contribution was not tested in this arm; it does not establish zero information.','Spatial dependence makes nominal correlation p values descriptive only; effect sizes and layout controls are primary.','Filtered contrast was added before targetG scoring but after original candidate-based predictions; it is not retrospectively claimed preregistered before candidate flow access.'])
 (OUT/'SUMMARY.json').write_text(json.dumps(clean(report),ensure_ascii=False,indent=2),encoding='utf8')
 (OUT/'RESULTS_FROZEN.json').write_text(json.dumps(dict(files={str(p):sha(p) for p in OUT.iterdir() if p.is_file() and p.name!='RESULTS_FROZEN.json'},source_scores={str(E/k/'SCORES_FROZEN.json'):sha(E/k/'SCORES_FROZEN.json') for k in ('single','layouts')},script_sha256=sha(__file__)),ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps(clean(report),ensure_ascii=False,indent=2))
if __name__=='__main__':run()
