"""Global pre-1995 selection prototype. Formal candidate Q is never indexed."""
from pathlib import Path
import os,sys,json,hashlib,time,pickle,argparse,warnings
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[k]='8'
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1];CODE=next(x for x in ROOT.parents if x.name=='code')
sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np
import pandas as pd
from scipy.stats import rankdata
import conditional_covariance as C
D=ROOT/'design/selector_inputs';OUT=ROOT/'selection';OUT.mkdir(exist_ok=True)
OLD=ROOT.parent/'r3_global_single_condition_20261022'
RAIN=ROOT.parent/'r4_global_siting_20261026/inputs/rainfall.npz'

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def clean(x):
 if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
 if isinstance(x,(list,tuple,np.ndarray)):return [clean(v) for v in x]
 if isinstance(x,np.generic):return clean(x.item())
 if isinstance(x,float) and not np.isfinite(x):return None
 return x
def js(p,x):Path(p).write_text(json.dumps(clean(x),ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
def read():
 b=pd.read_csv(D/'background_sources.csv',keep_default_na=False);t=pd.read_csv(D/'target_mother.csv',keep_default_na=False);c=pd.read_csv(D/'candidate_locations.csv',keep_default_na=False)
 assert set(b.physical_group_id).isdisjoint(set(c.physical_group_id)) and set(t.physical_group_id).isdisjoint(set(c.physical_group_id))
 return b,t,c
def attrs(df):
 lat=pd.to_numeric(df.latitude,errors='coerce').to_numpy();lon=pd.to_numeric(df.longitude,errors='coerce').to_numpy()
 lon=np.where(np.abs(lon)<=180,lon,np.nan)
 xyz=C.spherical_xyz(lat,lon);area=pd.to_numeric(df.official_area_km2,errors='coerce').to_numpy()
 return xyz,np.full(len(df),'Unknown'),np.log(np.where(area>0,area,np.nan))
def register():
 assert not (ROOT/'FIRST_GATE_PROTOCOL.json').exists()
 p=dict(status='REGISTERED_BEFORE_PRODUCTION',date='2026-10-26',scope='First global contribution-prediction gate; not a final validated r-threshold optimiser.',
  time=dict(selection='1995-01',pre='1980-01/1994-12',H='1995-01/1999-12',G='2000-01/2001-12'),
  time_choice='Analyst-selected mid-archive common example; user approved five years, not these particular dates. Earlier mask-only census was known; no outcome-based date search.',
  population='Deployment-pre target mother from all30959 catalogue; single pre-selected physical representative; no future complete-window target filter in selection. Pending identities retain mother but no ranking weight.',
  candidate_frame='4930 pre-existing frozen simulated candidate IDs, all their Q excluded from selection. Retrospective catalogue frame; adding them restores withheld network information, not complete-GSIM-external observations.',
  attributes='Whitelist latitude, longitude, official drainage area only. KG all Unknown; no modern climate/dams/population/night-light or future flow-derived fields. Coordinates/area treated stable physical descriptors.',
  covariance='Observed-data Gaussian factor EM; 24 latent factors, 40 maximum iterations, log1p monthly anomalies standardized from pre only; min24 observations and >=2 per calendar month; psi>=.05. Unknown rows retained with reason.',
  mapping='Nystrom256; fixed PSD spherical-chord kernels250/1000/4000km equal mix times logarea kernel; lambda=.01 on mean loss. Missing area imputed using training median+flag. No outcome tuning.',
  validation='Four pre spatial-cell hash folds. Entire held-out station flow excluded from both factor and map training. Evaluate their pre anomalies; no formal candidate flow or future G.',
  conditioning='Pre-only stationary K4 approximation chosen by anomaly r and distance ranks, positive-r weighting; source identities distinct from target. Known P lag0..3 included when whole pre product available, using same latent coordinates and full PSD residual noise. This is a surrogate for future monthly-dynamic K4, not identical realised inputs.',
  primary_proxy='Conditional target-standardized anomaly variance reduction, summed equally over estimable non-pending global mother targets; no conversion to raw r>.7 probability.',
  layouts='Score all4930 candidates first. Greedy conditional update among initial top256 to K10/25/50; approximate shortlist search, not global optimality. Compare unconditional-information top, global distance-coverage greedy, and five seeded random common layouts. All chosen pre candidate Q and targetG.',
  reconstructor='Fixed ridge lambda.1; existing QP baseline (Q fallback where P unavailable) plus independent candidate anomaly channel(s). New source does not compete for K4 and may have negative correlation. H60-only transforms; >=24 common valid nonnegative months, >=2 per calendar month. Normal baseline-available branch uses identical baseline training rows. Prespecified rescue branch: where baseline cannot fit or its G inputs are unavailable, use candidate-only ridge trained on target-valid H rows, with the same lambda and admission. Joint missing candidate features use training means. No added G reports returns original baseline exactly. Separate normal and rescue domain results; never select branch using target G truth.',
  assessment='Freeze all proxy scores and layouts before reading formal candidate H/G for production; freeze predictions/parameters before targetG scoring. Compare same-verifiable-target proxy ranks to signed actual gains, additionally restrict candidate complete H/G for interpretation only. New and lost passes both count; unverified source coverage != no information.',
  source_revision='Old full-period source admission replaced by new pre-only source census. T selection, candidate frame, source B kept distinct. Shared common layout evaluated over targetwise dropout scenarios; not simultaneous removal of every target.',
  outputs='Local only; no manuscript/SI/figure/cloud changes.')
 js(ROOT/'FIRST_GATE_PROTOCOL.json',p)
 paths=[Path(__file__),ROOT/'source/conditional_covariance.py',ROOT/'design/DESIGN_FROZEN.json',ROOT/'FIRST_GATE_PROTOCOL.json',OLD/'global_data/QC20_Q.npy',RAIN]
 paths+=list(D.glob('*.csv'))
 js(ROOT/'SELECTION_CODE_INPUTS_FROZEN.json',dict(files={str(x):sha(x) for x in paths},production_started=False))
 print('REGISTERED',flush=True)
def verify():
 p=json.loads((ROOT/'SELECTION_CODE_INPUTS_FROZEN.json').read_text(encoding='utf8'))
 assert all(sha(k)==v for k,v in p['files'].items())
def fit():
 verify();b,t,c=read();q=np.load(OLD/'global_data/QC20_Q.npy',mmap_mode='r')
 # Only background pre indices materialized. Candidate values cannot enter.
 raw=b.raw_index.to_numpy(int);qb=np.asarray(q[raw,:180],float)
 bx,bk,ba=attrs(b);cx,ck,ca=attrs(c)
 folds=np.array([int(hashlib.sha256(('pre_spatial|'+str(x)).encode()).hexdigest()[:8],16)%4 for x in b.spatial_cell])
 cv=[]
 for fold in range(4):
  keep=folds!=fold;test=~keep;st=time.time()
  f=C.fit_pre_covariance(qb[keep]);m=C.fit_map(bx[keep],bk[keep],ba[keep],f['loadings'],f['psi'],eligible=f['eligible'],station_ids=b.station_id.to_numpy()[keep])
  mp=C.predict_map(m,bx[test],bk[test],ba[test],station_ids=b.station_id.to_numpy()[test]);pred=mp['loadings']@f['factors']
  qt=qb[test];valid=np.isfinite(qt)&(qt>=0);z=np.full_like(qt,np.nan);z[valid]=np.log1p(qt[valid])
  for month in range(12):z[:,month::12]-=np.nanmean(z[:,month::12],axis=1)[:,None]
  sd=np.nanstd(z,axis=1);z=np.divide(z,sd[:,None],out=np.full_like(z,np.nan),where=sd[:,None]>1e-12)
  for j,(ix,e) in enumerate(zip(np.flatnonzero(test),b[test].itertuples())):
   ok=np.isfinite(z[j])&np.isfinite(pred[j]);n=int(ok.sum());r=np.corrcoef(z[j,ok],pred[j,ok])[0,1] if n>=24 and np.std(pred[j,ok])>1e-12 and np.std(z[j,ok])>1e-12 else np.nan
   cv.append(dict(station_id=e.station_id,physical_group_id=e.physical_group_id,continent=e.continent,spatial_cell=e.spatial_cell,fold=fold,pre_valid=n,predicted_anomaly_r=r,standardized_mse=float(np.mean((z[j,ok]-pred[j,ok])**2)) if n else np.nan,attribute_map_eligible=bool(mp['eligible'][j])))
  print('spatial CV',fold,int(test.sum()),round(time.time()-st,2),flush=True)
 pd.DataFrame(cv).to_csv(OUT/'pre_spatial_validation.csv',index=False,encoding='utf-8-sig')
 f=C.fit_pre_covariance(qb);m=C.fit_map(bx,bk,ba,f['loadings'],f['psi'],eligible=f['eligible'],station_ids=b.station_id.to_numpy());mp=C.predict_map(m,cx,ck,ca,station_ids=c.station_id.to_numpy())
 np.savez_compressed(OUT/'pre_factors.npz',**{k:v for k,v in f.items() if isinstance(v,(np.ndarray,int,float,bool,str))})
 np.savez_compressed(OUT/'candidate_covariance_predicted.npz',**mp)
 with (OUT/'attribute_map.pkl').open('wb') as out:pickle.dump(m,out)
 js(OUT/'COVARIANCE_FIT_COMPLETE.json',dict(only_background_pre_read=True,pre_backgrounds=len(b),factor_estimable=int(f['eligible'].sum()),candidate_attribute_estimable=int(mp['eligible'].sum()),iterations=f['iterations'],converged=f['converged'],formal_candidate_Q_read=False))
 print('COVARIANCE FIT COMPLETE',int(f['eligible'].sum()),flush=True)
def prep_anom(q):
 q=np.asarray(q,float);valid=np.isfinite(q)&(q>=0);x=np.where(valid,np.log1p(np.maximum(q,0)),np.nan);cl=np.stack([np.nanmean(x[:,m::12],axis=1) for m in range(12)],axis=1);z=x-cl[:,np.arange(q.shape[1])%12];sd=np.nanstd(z,axis=1);z=np.divide(z,sd[:,None],out=np.full_like(z,np.nan),where=sd[:,None]>1e-12);return z
def conditions():
 verify();b,t,c=read();f=np.load(OUT/'pre_factors.npz');q=np.load(OLD/'global_data/QC20_Q.npy',mmap_mode='r');zb=prep_anom(q[b.raw_index.to_numpy(int),:180]);zt=prep_anom(q[t.raw_index.to_numpy(int),:180]);bx,bk,ba=attrs(b);tx,tk,ta=attrs(t)
 L=f['loadings'];psi=f['psi'];Bpos={p:i for i,p in enumerate(b.physical_group_id)};own=np.array([Bpos.get(p,-1) for p in t.physical_group_id]);N=len(t);LT=np.zeros((N,24));PT=np.ones(N);eligible=np.zeros(N,bool)
 match=own>=0;LT[match]=L[own[match]];PT[match]=psi[own[match]];eligible[match]=f['eligible'][own[match]]
 pending=t.pending_alias_target.astype(str).str.lower().eq('true').to_numpy();eligible&=~pending
 idx=np.full((N,4),-1,int);weights=np.zeros((N,4));CL=np.zeros((N,5,24));NO=np.zeros((N,5,5));usesp=np.zeros(N,bool)
 bm=np.isfinite(zb).astype(float);zz=np.nan_to_num(zb);z2=zz*zz
 for lo in range(0,N,128):
  hi=min(lo+128,N);ym=np.isfinite(zt[lo:hi]).astype(float);yy=np.nan_to_num(zt[lo:hi]);nn=ym@bm.T;sx=ym@zz.T;sy=yy@bm.T;vx=ym@z2.T-np.divide(sx*sx,nn,out=np.zeros_like(nn),where=nn>0);vy=(yy*yy)@bm.T-np.divide(sy*sy,nn,out=np.zeros_like(nn),where=nn>0);cv=yy@zz.T-np.divide(sx*sy,nn,out=np.zeros_like(nn),where=nn>0)
  rr=np.divide(cv,np.sqrt(np.maximum(vx*vy,0)),out=np.full_like(cv,np.nan),where=(nn>=12)&(vx>1e-20)&(vy>1e-20))
  for p in range(hi-lo):
   i=lo+p
   if not eligible[i] or not np.isfinite(tx[i]).all():continue
   dist=6371*np.arccos(np.clip(bx@tx[i],-1,1));ok=np.isfinite(rr[p])&(rr[p]>0)&np.isfinite(dist)&f['eligible'];ok[own[i]]=False
   choices=np.flatnonzero(ok)
   if not len(choices):continue
   ranks=rankdata(-rr[p,choices])+rankdata(dist[choices]);ordr=np.lexsort((b.raw_index.to_numpy()[choices],-rr[p,choices],ranks));sel=choices[ordr[:4]];w=rr[p,sel];w=w/w.sum();idx[i,:len(sel)]=sel;weights[i,:len(sel)]=w;CL[i,0]=w@L[sel];NO[i,0,0]=np.sum(w*w*psi[sel])
  if lo%2048==0:print('pre references',lo,N,flush=True)
 # Rain is used only if all pre lags available in an already admitted product.
 rain=np.load(RAIN,allow_pickle=False);rp={s:i for i,s in enumerate(rain['station_ids'].astype(str))};F=f['factors'];inv=np.linalg.inv(F@F.T+0.1*np.eye(24));rain_admission=rain['admission_mask'];rain_pre=rain['precip_mm_month'][:,:183]
 for i,s in enumerate(t.station_id):
  j=rp.get(s,-1)
  if j<0 or not rain_admission[j] or not eligible[i]:continue
  v=np.asarray(rain_pre[j],float)
  if not (np.isfinite(v)&(v>=0)).all():continue
  v=np.log1p(v);P=np.array([v[3-l:183-l] for l in range(4)])
  for month in range(12):P[:,month::12]-=P[:,month::12].mean(1)[:,None]
  sd=P.std(1)
  if np.any(sd<1e-12):continue
  P/=sd[:,None];lp=P@F.T@inv;res=P-lp@F;nc=res@res.T/180+0.01*np.eye(4);CL[i,1:]=lp;NO[i,1:,1:]=nc;usesp[i]=True
 np.savez_compressed(OUT/'target_conditions_pre.npz',target_loadings=LT,target_psi=PT,eligible=eligible,target_background=own,condition_loadings=CL,condition_noise=NO,ref_idx=idx,ref_weights=weights,uses_pre_P=usesp)
 print('CONDITIONS',int(eligible.sum()),int(usesp.sum()),flush=True)
def score_layouts():
 verify();b,t,c=read();f=np.load(OUT/'target_conditions_pre.npz');m=np.load(OUT/'candidate_covariance_predicted.npz');eligible=f['eligible'];ix=np.flatnonzero(eligible);cl=m['loadings'];cp=m['psi'];valid=m['eligible']
 gain=C.gain_given_condition(f['target_loadings'],f['target_psi'],f['condition_loadings'],f['condition_noise'],cl,cp);gain[~eligible]=np.nan;gain[:,~valid]=np.nan
 np.save(OUT/'predicted_candidate_target_gain.npy',gain);total=np.nansum(gain,axis=0);total[~valid]=-np.inf
 rank=np.lexsort((c.raw_index.to_numpy(),-total));ranking=c[['raw_index','station_id','physical_group_id','latitude','longitude','continent','country','header_river','header_station']].copy();ranking['predicted_global_variance_gain']=total;ranking['initial_rank']=np.argsort(rank)+1;ranking.to_csv(OUT/'all_candidates_predicted_global_ranking.csv',index=False,encoding='utf-8-sig')
 # Joint update: initial global top256, Schur-conditioning on selected locations.
 pool=rank[:256];selected=[];rows=[];main=[]
 TL=f['target_loadings'][ix];TP=f['target_psi'][ix];baseL=f['condition_loadings'][ix];baseN=f['condition_noise'][ix]
 for k in range(1,51):
  nc=5+len(selected);cond=np.zeros((len(ix),nc,24));noise=np.zeros((len(ix),nc,nc));cond[:,:5]=baseL;noise[:,:5,:5]=baseN
  if selected:cond[:,5:]=cl[selected];noise[:,np.arange(5,nc),np.arange(5,nc)]=cp[selected]
  g=C.gain_given_condition(TL,TP,cond,noise,cl[pool],cp[pool]);v=g.sum(0,dtype=float);v[np.isin(pool,selected)]=-np.inf;j=int(pool[np.lexsort((c.raw_index.to_numpy()[pool],-v))[0]]);selected.append(j)
  rows.append(dict(step=k,candidate_raw_index=int(c.raw_index.iloc[j]),candidate_id=c.station_id.iloc[j],predicted_conditional_variance_gain=float(v[np.flatnonzero(pool==j)[0]])))
  if k in (10,25,50):
   for n,jj in enumerate(selected,1):main.append(dict(layout_id=f'CONDITIONAL_K{k}',candidate_raw_index=int(c.raw_index.iloc[jj]),rank=n))
  if k%10==0:print('joint selection',k,flush=True)
 # Static distance-coverage control: entire mother, globally shared greedy.
 tx,_,_=attrs(t);cx,_,_=attrs(c);bx,_,_=attrs(b);dist=6371*np.arccos(np.clip(tx@cx.T,-1,1));dist[~np.isfinite(dist)]=np.inf;best=np.full(len(t),np.pi*6371.);geos=[]
 # Coverage increment relative to the pre-existing network, excluding each
 # target's own physical identity in its targetwise dropout scenario.
 bp={p:j for j,p in enumerate(b.physical_group_id)}
 for lo in range(0,len(t),256):
  hi=min(lo+256,len(t));cosine=tx[lo:hi]@bx.T;cosine[~np.isfinite(cosine)]=-np.inf
  for ii,p in enumerate(t.physical_group_id.iloc[lo:hi]):
   jj=bp.get(p,-1)
   if jj>=0:cosine[ii,jj]=-np.inf
  best[lo:hi]=6371*np.arccos(np.clip(cosine.max(1),-1,1))
 for k in range(1,51):
  vv=np.maximum(best[:,None]-dist,0);vv[pending_mask(t)]=0;ss=vv.sum(0);ss[~valid]=-np.inf;ss[geos]=-np.inf;j=int(np.lexsort((c.raw_index.to_numpy(),-ss))[0]);geos.append(j);best=np.minimum(best,dist[:,j])
  if k in (10,25,50):
   for n,jj in enumerate(geos,1):main.append(dict(layout_id=f'GEOGRAPHIC_K{k}',candidate_raw_index=int(c.raw_index.iloc[jj]),rank=n))
 for seed in range(5):
  order=np.random.default_rng(202610260+seed).permutation(np.flatnonzero(valid))
  for k in (10,25,50):
   for n,j in enumerate(order[:k],1):main.append(dict(layout_id=f'RANDOM{seed}_K{k}',candidate_raw_index=int(c.raw_index.iloc[j]),rank=n))
 # Unconditioned information control under exactly the same covariance map.
 g0=(TL@cl.T)**2;v0=g0.sum(0);v0[~valid]=-np.inf;u=np.lexsort((c.raw_index.to_numpy(),-v0))
 for k in (10,25,50):
  for n,j in enumerate(u[:k],1):main.append(dict(layout_id=f'UNCONDITIONED_K{k}',candidate_raw_index=int(c.raw_index.iloc[j]),rank=n))
 pd.DataFrame(main).to_csv(OUT/'layouts.csv',index=False);pd.DataFrame(rows).to_csv(OUT/'conditional_selection_steps.csv',index=False)
 meta=t[['raw_index','station_id','physical_group_id','continent','spatial_cell']].copy();meta['proxy_estimable']=eligible;meta['uses_pre_P']=f['uses_pre_P'];meta['pending_alias']=pending_mask(t);meta.to_csv(OUT/'target_selection_status.csv',index=False)
 outputs=[p for p in OUT.iterdir() if p.is_file() and p.name!='SELECTION_FROZEN.json']
 js(OUT/'SELECTION_FROZEN.json',dict(status='ALL_CANDIDATE_PROXY_AND_COMMON_LAYOUTS_FROZEN_BEFORE_CANDIDATE_Q_ACCESS',files={str(p):sha(p) for p in outputs},code_freeze=sha(ROOT/'SELECTION_CODE_INPUTS_FROZEN.json'),target_mothers=len(t),proxy_estimable=int(eligible.sum()),candidates=len(c),layout_count=pd.DataFrame(main).layout_id.nunique(),shortlist=256,formal_candidate_Q_read=False,target_future_G_scored=False,proxy_is_not_raw_r_probability=True))
 print('SELECTION FROZEN',len(t),int(eligible.sum()),len(c),flush=True)
def pending_mask(t):return t.pending_alias_target.astype(str).str.lower().eq('true').to_numpy()
if __name__=='__main__':
 warnings.filterwarnings('ignore',category=RuntimeWarning)
 p=argparse.ArgumentParser();p.add_argument('step',choices=['register','fit','conditions','score_layouts']);a=p.parse_args();globals()[a.step]()
