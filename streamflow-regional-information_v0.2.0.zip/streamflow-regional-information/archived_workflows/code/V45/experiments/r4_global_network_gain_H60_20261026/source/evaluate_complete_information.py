"""Complete-observation scenario. Reuses immutable original numerical kernels.

Outputs only evaluation_complete/{all_inputs,filtered_inputs}/layouts. Module
variables route the shared filtered runner's IO; original E.OUT is never changed
and no previous script, binding, protocol or output is overwritten.
"""
from pathlib import Path
import os,sys,json,argparse,importlib.util,time
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
ROOT=Path(__file__).resolve().parents[1];CODE=next(p for p in ROOT.parents if p.name=='code');sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np,pandas as pd
from concurrent.futures import ProcessPoolExecutor
sp=importlib.util.spec_from_file_location('filtered_kernel',ROOT/'source/evaluate_filtered_information.py');F=importlib.util.module_from_spec(sp);sp.loader.exec_module(F)
E=F.E;BASE=ROOT/'evaluation_complete';ORIGINAL=E.OUT;CTX={}

def sha(p):return E.sha(p)
def files_of(path):
    path=Path(path).resolve();d=E.verify(path);files=[]
    for k in ['files','outputs']:
        for p in d.get(k,{}):
            p=Path(p);files.append(p if p.is_absolute() else path.parent/p)
    return d,files
def layout_usage_path(freeze):
    _,files=files_of(freeze);npzs=[]
    for path in files:
        if path.suffix=='.npz':
            with np.load(path,allow_pickle=False) as z:
                if {'candidate_positions','global_candidate_positions','layout_order','mother_raw_indices'}<=set(z.files):npzs.append(path)
    assert len(npzs)==1,npzs
    return npzs[0]
def configure(variant,freeze):
    assert variant in ['all_inputs','filtered_inputs'];CTX.update(variant=variant,freeze=str(Path(freeze).resolve()))
    F.OUT=BASE/variant;assert E.OUT==ORIGINAL
def gate(freeze):
    freeze=Path(freeze).resolve();F.original_frozen();fr,_=files_of(freeze)
    protocol=json.loads((BASE/'PROTOCOL.json').read_text(encoding='utf8'))
    assert protocol['complete_code_sha256']==sha(__file__) and protocol['filtered_kernel_sha256']==sha(F.__file__) and protocol['original_kernel_sha256']==sha(E.__file__)
    core=json.loads((ORIGINAL/'single/BINDING.json').read_text(encoding='utf8'));now=E.production_gate(core['selection_freeze']);assert all(core[k]==v for k,v in now.items())
    return dict(mode='complete_observation_scenario',variant=CTX['variant'],complete_code_sha256=sha(__file__),filtered_kernel_sha256=sha(F.__file__),original_kernel_sha256=sha(E.__file__),usage_freeze_path=str(freeze),usage_freeze_sha256=sha(freeze),complete_protocol_sha256=sha(BASE/'PROTOCOL.json'),original_single_prediction_freeze_sha256=sha(ORIGINAL/'single/PREDICTIONS_FROZEN.json'),original_layout_prediction_freeze_sha256=sha(ORIGINAL/'layouts/PREDICTIONS_FROZEN.json'),original_background_freeze_sha256=sha(ORIGINAL/'background/BACKGROUND_FROZEN.json'),original_candidate_input_freeze_sha256=sha(ORIGINAL/'candidate_inputs/CANDIDATE_INPUTS_FROZEN.json'),original_core_binding=core)

def init_for_score(freeze):
    E.init_eval();path=layout_usage_path(freeze)
    with np.load(path,allow_pickle=False) as z:u={k:z[k] for k in z.files}
    mother=pd.read_csv(ROOT/'design/selector_inputs/target_mother.csv',keep_default_na=False);np.testing.assert_array_equal(u['mother_raw_indices'],mother.raw_index.to_numpy(int))
    cases=E.W['cases'];mi=cases.mother_row.to_numpy(int);np.testing.assert_array_equal(u['mother_raw_indices'][mi],cases.raw_index.to_numpy(int));names=u['layout_order'].astype(str).tolist()
    assert len(names)==24 and u['candidate_positions'].shape==(17161,24,4) and u['global_candidate_positions'].shape==(24,50)
    cp=E.W['cp'];complete=cp['h_valid'].all(1)&cp['g_valid'].all(1);assert complete.sum()==1444
    globalpos=u['global_candidate_positions'];assert ((globalpos>=-1)&(globalpos<4930)).all();assert complete[globalpos[globalpos>=0]].all()
    layoutcsv=pd.read_csv(Path(freeze).parent/'layouts.csv',keep_default_na=False)
    listedraw=np.asarray(u['candidate_raw_indices'],int)
    assert set(listedraw.tolist()) in [set(cp['raw_index'].tolist()),set(cp['raw_index'][complete].tolist())]
    allowed=u['candidate_positions'][mi];assert ((allowed>=-1)&(allowed<4930)).all()
    for j in range(24):
        indices=globalpos[j][globalpos[j]>=0];assert len(indices) in (10,25,50) and len(np.unique(indices))==len(indices)
        assert set(cp['raw_index'][indices].tolist())==set(layoutcsv.loc[layoutcsv.layout_id.eq(names[j]),'candidate_raw_index'].astype(int).tolist()),'Joint positions must map to exactly frozen physical layout IDs'
        assert np.isin(allowed[:,j][allowed[:,j]>=0],indices).all()
    positions=np.broadcast_to(globalpos,(len(cases),24,50)) if CTX['variant']=='all_inputs' else allowed
    F.U.update(joint_positions=positions,names=names,mother_rows=mi,usage_path=str(Path(freeze).resolve()))
    assert E.OUT==ORIGINAL
def initialize(variant,freeze):configure(variant,freeze);init_for_score(freeze)
def work(i):return F.layout_one(i)

def produce(variant,freeze,workers):
    configure(variant,freeze);binding=gate(freeze);out=F.OUT/'layouts';(out/'blocks').mkdir(parents=True,exist_ok=True)
    if (out/'PREDICTIONS_FROZEN.json').exists():E.verify(out/'PREDICTIONS_FROZEN.json');return
    if (out/'BINDING.json').exists():assert json.loads((out/'BINDING.json').read_text(encoding='utf8'))==binding
    else:E.js(out/'BINDING.json',binding)
    init_for_score(freeze);N=len(E.W['cases']);todo=[i for i in range(N) if not (out/'blocks'/f'target_{i:05d}.npz').exists()];st=time.time()
    with ProcessPoolExecutor(max_workers=workers,initializer=initialize,initargs=(variant,freeze)) as pool:
        for k,i in enumerate(pool.map(work,todo,chunksize=4),1):
            if k%100==0 or k==len(todo):print(f'complete {variant} {N-len(todo)+k}/{N} sec={time.time()-st:.1f}',flush=True)
    files=sorted((out/'blocks').glob('target_*.npz'));assert len(files)==N
    E.freeze(out,'PREDICTIONS_FROZEN.json',files+[out/'BINDING.json'],N=N,L=24,layout_order=F.U['names'],binding=binding,status='COMPLETE_OBSERVATION_SCENARIO_BEFORE_TARGET_G_SCORING',variant=variant,candidate_frame=1444,global_mother=17161,strict_validation_domain=5905)
def score(variant,qa):
    configure(variant,ROOT/'selection_complete/COMPLETE_SELECTION_FROZEN.json')
    # Explicit dependency injection for IO/chain checks only. Numerical fitting,
    # inverse transforms, scoring and bootstrap remain the frozen shared code.
    F.gate=gate;F.init=init_for_score
    original_freeze=E.freeze
    def scenario_freeze(folder,name,files,**meta):
        assert Path(folder).resolve().is_relative_to(BASE.resolve())
        if name=='SCORES_FROZEN.json':meta['mode']='complete_observation_'+variant
        return original_freeze(folder,name,files,**meta)
    E.freeze=scenario_freeze
    try:F.score('layouts',qa)
    finally:E.freeze=original_freeze
    assert E.OUT==ORIGINAL

def fixture():
    rng=np.random.default_rng(20261026);x=rng.normal(size=(60,5));y=rng.normal(size=60);g=rng.normal(size=(24,5));h=rng.normal(size=(50,60));cg=rng.normal(size=(50,24))
    fit,_=E.M.fit_transfer(x,y,method='ridge');cl=np.linspace(.5,1.,12);sd=.8;season=np.expm1(cl[E.G%12]);baseline,sup=E.C.transfer(fit.predict(g),y,cl,sd,E.G,season,True)
    E.W['base']=dict(feature_count=np.array([5]),fit=np.array([True]),target_estimable=np.array([True]),train=np.ones((1,60),bool),target_z=y[None],xh=x[None],xg=g[None],target_log_calendar=cl[None],target_sd=np.array([sd]),predictions=baseline[None],seasonal=season[None])
    E.W['cp']=dict(h_anomaly=h,g_anomaly=cg,g_valid=np.isfinite(cg),H_quality=np.ones(50,bool))
    all_indices=np.full((3,50),-1,int)
    for j,K in enumerate([10,25,50]):all_indices[j,:K]=np.arange(K)
    names=['K10','K25','K50'];out=F.fitted_layout(0,all_indices,names);errors=[]
    for key,K in zip(names,[10,25,50]):
        model,_=E.M.fit_transfer(np.c_[x,h[:K].T],y,method='ridge');expected,sup=E.C.transfer(model.predict(np.c_[g,cg[:K].T]),y,cl,sd,E.G,season,True)
        actual=E.full_precision_layout(0,out,key);errors.append(float(np.max(np.abs(actual-expected))))
    selected=np.array([[0,2,4,-1],[-1,-1,-1,-1],[1,4,5,9]]);f=F.fitted_layout(0,selected,names);np.testing.assert_array_equal(f['predictions'][1],baseline.astype(np.float32));assert E.OUT==ORIGINAL and max(errors)<1e-12
    E.W.clear();BASE.mkdir(exist_ok=True)
    E.js(BASE/'SYNTHETIC_COMPLETE_QA.json',dict(passed=True,complete_code_sha256=sha(__file__),max_absolute_difference=max(errors),K10_25_50_direct_ridge_checked=True,filtered_empty_exact_baseline=True,original_output_path_unchanged=True,no_observed_flow_read=True))
    E.js(BASE/'PROTOCOL.json',dict(complete_code_sha256=sha(__file__),filtered_kernel_sha256=sha(F.__file__),original_kernel_sha256=sha(E.__file__),purpose='Complete five-year H60 plus G24 observation scenario, complementary to4930-retrospective-inventory trial',candidate_frame='All1444 frozen candidate positions whose H60/G24 masks are complete/nonnegative. Mask availability defines a retrospectively verifiable scenario, not knowledge of real future station reporting. No targetG values/scores used for pool or selection.',targets='Same17161 premother,5914predictions,5905strictdomain',layouts='Same global preproxy/geographic/unconditional/random methods and K10/25/50, separately frozen on complete1444frame. Original4930layouts/results unchanged.',input_use='Both all_selected_channels and frozenpreproxy-atmost4 with1percent conditional-variance rule; no H/G-performance-driven replacements.',models='Precisely original standardizedridge lambda0.1, H60 transforms, fixedbaselineH rows, independentcandidate channels, candidate-onlyrescue. Complete-sourcepool does not mean model or target information is sufficient.',kernels='Imports original and filtered numericalfunctions; originalE.OUT and originalfiles never modified. Sharedscore function called with new IO and binding adapters only.',gates='All layouts and usage frozenbeforetargetGscore, wholepredictions+float64params frozen and independentQA before all scenario scoring.'))
    print('COMPLETE_SYNTHETIC_PASS',max(errors),flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('step',choices=['fixture','produce','score']);ap.add_argument('--variant',choices=['all_inputs','filtered_inputs']);ap.add_argument('--selection-freeze',default=str(ROOT/'selection_complete/COMPLETE_SELECTION_FROZEN.json'));ap.add_argument('--prediction-qa');ap.add_argument('--workers',type=int,default=8);a=ap.parse_args()
    if a.step=='fixture':fixture()
    elif a.step=='produce':produce(a.variant,a.selection_freeze,a.workers)
    else:score(a.variant,a.prediction_qa)

if __name__=='__main__':main()
