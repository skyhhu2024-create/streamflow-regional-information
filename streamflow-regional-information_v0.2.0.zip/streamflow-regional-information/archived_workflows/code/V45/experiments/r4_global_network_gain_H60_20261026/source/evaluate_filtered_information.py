"""Pre-frozen input-use contrast. Original all-input products remain immutable."""
from pathlib import Path
import os,sys,json,hashlib,argparse,importlib.util,time
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
ROOT=Path(__file__).resolve().parents[1];CODE=next(p for p in ROOT.parents if p.name=='code');sys.path.insert(0,str(CODE/'V42/dependencies'))
import numpy as np,pandas as pd
from concurrent.futures import ProcessPoolExecutor
sp=importlib.util.spec_from_file_location('original_evaluation',ROOT/'source/evaluate_added_information.py');E=importlib.util.module_from_spec(sp);sp.loader.exec_module(E)
ORIGINAL=E.OUT;OUT=ROOT/'evaluation_filtered';U={}

def js(p,x):E.js(p,x)
def sha(p):return E.sha(p)
def original_frozen():
    for path in [ORIGINAL/'background/BACKGROUND_FROZEN.json',ORIGINAL/'candidate_inputs/CANDIDATE_INPUTS_FROZEN.json',ORIGINAL/'single/PREDICTIONS_FROZEN.json',ORIGINAL/'layouts/PREDICTIONS_FROZEN.json']:E.verify(path)
    assert E.OUT==ORIGINAL,'Original module output path must never be changed'

def usage_files(freeze):
    path=Path(freeze).resolve();x=E.verify(path);files=[]
    for key in ['files','outputs']:
        for p in x.get(key,{}):
            p=Path(p);files.append(p if p.is_absolute() else path.parent/p)
    masks=[p for p in files if p.suffix=='.npy' and 'mask' in p.name.lower()]
    joint=[]
    for p in files:
        if p.suffix=='.npz':
            with np.load(p,allow_pickle=False) as z:
                if {'candidate_positions','layout_order','mother_raw_indices'}<=set(z.files):joint.append(p)
    assert len(masks)==len(joint)==1,('Need unique frozen single-use mask and joint-usage NPZ',masks,joint)
    return path,masks[0],joint[0]

def gate(usage):
    original_frozen();up,mp,jp=usage_files(usage)
    proto=json.loads((OUT/'PROTOCOL.json').read_text(encoding='utf8'));assert proto['code_sha256']==sha(__file__),'Run updated synthetic fixture before production'
    core=json.loads((ORIGINAL/'single/BINDING.json').read_text(encoding='utf8'))
    current=E.production_gate(core['selection_freeze']);assert all(core[k]==v for k,v in current.items())
    return dict(filtered_code_sha256=sha(__file__),filtered_protocol_sha256=sha(OUT/'PROTOCOL.json'),original_code_sha256=sha(E.__file__),usage_freeze_path=str(up),usage_freeze_sha256=sha(up),single_use_mask_path=str(mp),joint_usage_path=str(jp),original_single_prediction_freeze_sha256=sha(ORIGINAL/'single/PREDICTIONS_FROZEN.json'),original_layout_prediction_freeze_sha256=sha(ORIGINAL/'layouts/PREDICTIONS_FROZEN.json'),original_background_freeze_sha256=sha(ORIGINAL/'background/BACKGROUND_FROZEN.json'),original_candidate_input_freeze_sha256=sha(ORIGINAL/'candidate_inputs/CANDIDATE_INPUTS_FROZEN.json'),original_core_binding=core)

def init(usage):
    E.init_eval();up,mp,jp=usage_files(usage);mask=np.load(mp,mmap_mode='r');assert mask.shape==(17161,4930) and mask.dtype==bool
    with np.load(jp,allow_pickle=False) as z:joint={k:z[k] for k in z.files}
    mother=pd.read_csv(ROOT/'design/selector_inputs/target_mother.csv',keep_default_na=False)
    np.testing.assert_array_equal(joint['mother_raw_indices'],mother.raw_index.to_numpy(int))
    names=joint['layout_order'].astype(str).tolist();orig=json.loads((ORIGINAL/'layouts/PREDICTIONS_FROZEN.json').read_text(encoding='utf8'))
    assert names==orig['layout_order'];assert joint['candidate_positions'].shape==(17161,24,4)
    cases=E.W['cases'];mi=cases.mother_row.to_numpy(int);np.testing.assert_array_equal(joint['mother_raw_indices'][mi],cases.raw_index.to_numpy(int))
    pos=joint['candidate_positions'][mi];assert ((pos>=-1)&(pos<4930)).all()
    original_layouts=E.load_layouts(ROOT/'selection/layouts.csv')
    for j,name in enumerate(names):assert np.isin(pos[:,j][pos[:,j]>=0],original_layouts[name]).all()
    U.update(mask=mask,mother_rows=mi,joint_positions=pos,names=names,usage_path=str(up))

def single_one(i):
    keep=np.asarray(U['mask'][U['mother_rows'][i]]);base=E.W['base']['predictions'][i]
    with np.load(ORIGINAL/'single/blocks'/f'target_{i:05d}.npz',allow_pickle=False) as z:pred=z['predictions'];branch=z['input_branch']
    pred[~keep]=base.astype(np.float32);branch[~keep]=0
    E.atomic_npz(OUT/'single/blocks'/f'target_{i:05d}.npz',predictions=pred,input_branch=branch,preselected_use_mask=keep)
    return i

def fitted_layout(i,indices,names):
    b=E.W['base'];c=E.W['cp'];p=int(b['feature_count'][i]);params={};pred=[];branches=[];normal_n=[];rescue_n=[]
    for key,rawidx in zip(names,indices):
        idx=rawidx[rawidx>=0];assert len(np.unique(idx))==len(idx)
        counts={'aug':0,'rescue':0}
        for mode in ['aug','rescue']:
            if not len(idx) or not bool(b['fit'][i] if mode=='aug' else b['target_estimable'][i]):continue
            tr=np.asarray(b['train'][i]) if mode=='aug' else np.isfinite(b['target_z'][i]);ch=c['h_anomaly'][idx][:,tr].T;obs=np.isfinite(ch);ch=np.where(obs,ch,0.)
            eligible=c['H_quality'][idx]&(obs.sum(0)>=24)&(ch.std(0)>E.EPS);chosen=idx[eligible];counts[mode]=len(chosen)
            if not len(chosen):continue
            x=np.c_[b['xh'][i,tr,:p],ch[:,eligible]] if mode=='aug' else ch[:,eligible]
            fit,status=E.M.fit_transfer(x,np.asarray(b['target_z'][i,tr]),method='ridge');assert fit is not None,status
            tag=key+'__'+mode+'__';params.update({tag+'mean':fit.feature_mean,tag+'scale':fit.feature_scale,tag+'coef':fit.coefficients,tag+'target_mean':np.array(fit.target_mean),tag+'active_candidate_positions':chosen})
        pp,branch=E.full_precision_layout(i,params,key,return_branch=True);pred.append(pp);branches.append(branch);normal_n.append(counts['aug']);rescue_n.append(counts['rescue'])
    return dict(predictions=np.stack(pred).astype(np.float32),input_branch=np.stack(branches),preselected_candidate_positions=indices,active_candidate_n=np.array(normal_n,np.int8),rescue_active_candidate_n=np.array(rescue_n,np.int8),**params)

def layout_one(i):
    E.atomic_npz(OUT/'layouts/blocks'/f'target_{i:05d}.npz',**fitted_layout(i,U['joint_positions'][i],U['names']));return i

def produce(kind,usage,workers):
    binding=gate(usage);out=OUT/kind;(out/'blocks').mkdir(parents=True,exist_ok=True)
    if (out/'PREDICTIONS_FROZEN.json').exists():E.verify(out/'PREDICTIONS_FROZEN.json');return
    if (out/'BINDING.json').exists():assert json.loads((out/'BINDING.json').read_text(encoding='utf8'))==binding
    else:js(out/'BINDING.json',binding)
    init(usage);N=len(E.W['cases']);todo=[i for i in range(N) if not (out/'blocks'/f'target_{i:05d}.npz').exists()];st=time.time()
    with ProcessPoolExecutor(max_workers=workers,initializer=init,initargs=(usage,)) as pool:
        for k,i in enumerate(pool.map(single_one if kind=='single' else layout_one,todo,chunksize=4),1):
            if k%100==0 or k==len(todo):print(f'filtered {kind} {N-len(todo)+k}/{N} sec={time.time()-st:.1f}',flush=True)
    files=sorted((out/'blocks').glob('target_*.npz'));assert len(files)==N
    E.freeze(out,'PREDICTIONS_FROZEN.json',files+[out/'BINDING.json'],N=N,L=24,layout_order=U['names'] if kind=='layouts' else None,binding=binding,status='PREFROZEN_USE_POLICY_PREDICTIONS_BEFORE_TARGET_G_SCORING',rule='preproxy_fixed_threshold_plus_top4_no_HG_availability_replacement')

def fixture():
    rng=np.random.default_rng(20261026);n=60;p=5;k=8;x=rng.normal(size=(n,p));y=rng.normal(size=n);g=rng.normal(size=(24,p));cg=rng.normal(size=(k,24));h=rng.normal(size=(k,n));h[1,3]=np.nan;cg[2,5]=np.nan
    fit,_=E.M.fit_transfer(x,y,method='ridge');cl=np.linspace(.5,1.2,12);sd=.7;season=np.expm1(cl[E.G%12]);bp,sup=E.C.transfer(fit.predict(g),y,cl,sd,E.G,season,True)
    E.W['base']=dict(feature_count=np.array([p]),fit=np.array([True]),target_estimable=np.array([True]),train=np.ones((1,60),bool),target_z=y[None],xh=x[None],xg=g[None],target_log_calendar=cl[None],target_sd=np.array([sd]),predictions=bp[None],seasonal=season[None])
    E.W['cp']=dict(h_anomaly=h,g_anomaly=cg,g_valid=np.isfinite(cg),H_quality=np.ones(k,bool))
    indices=np.array([[2,5,-1,-1],[-1,-1,-1,-1],[1,3,6,7]])
    result=fitted_layout(0,indices,['A','B','C']);errs=[]
    np.testing.assert_array_equal(result['predictions'][1],bp.astype(np.float32));assert not result['input_branch'][1].any()
    for ai,key in enumerate(['A','B','C']):
        keep=indices[ai][indices[ai]>=0]
        if not len(keep):continue
        ch=np.where(np.isfinite(h[keep].T),h[keep].T,0.);direct,_=E.M.fit_transfer(np.c_[x,ch],y,method='ridge');gg=cg[keep].T;valid=np.isfinite(gg);gg=np.where(valid,gg,direct.feature_mean[p:]);pred,ds=E.C.transfer(direct.predict(np.c_[g,gg]),y,cl,sd,E.G,season,True);pred[~valid.any(1)]=bp[~valid.any(1)]
        rebuilt=E.full_precision_layout(0,result,key);errs.append(float(np.max(np.abs(pred-rebuilt))))
        np.testing.assert_array_equal(result[key+'__aug__active_candidate_positions'],keep)
    # Filtering never selects a replacement for a preselected missing source.
    E.W['cp']['H_quality'][2]=False;out=fitted_layout(0,indices[:1],['A']);np.testing.assert_array_equal(out['A__aug__active_candidate_positions'],[5])
    assert max(errs)<1e-12
    E.W.clear();OUT.mkdir(exist_ok=True)
    js(OUT/'SYNTHETIC_FILTER_QA.json',dict(passed=True,code_sha256=sha(__file__),original_code_sha256=sha(E.__file__),max_absolute_difference=max(errs),empty_selection_exact_baseline=True,no_availability_driven_replacement=True,no_observed_flow_read=True))
    js(OUT/'PROTOCOL.json',dict(code_sha256=sha(__file__),original_code_sha256=sha(E.__file__),purpose='Prespecified input-use contrast, not optimized policy',rule='Use the frozen pre-period conditional covariance ranking; each conditional variance increment >=.01 of original baseline conditional variance; no more than4 channels pertarget/layout. No substitution after H/G availability is revealed.',original_layouts_unchanged=True,old_models_and_outputs_unchanged=True,single='Reuse original frozen predictions/float64coefficients where prespecified use mask true; otherwise exactoriginalbaseline. No new fit.',layouts='Only preselected subset enters unchangedlambda.1 ridge; sameH masks/admission/transforms and candidate-onlyrescue as original. Missing selected candidates are not replaced.',case_domain='5914 predictions,5905 strict main domain; original targetmother17161 unchanged',gates='Allglobal layouts and usage policy frozen before targetG scoring; prediction+parameter freeze then independentQA; source chain includes originalcode,originalpredictions,usagefreeze.',comparison='Report filtered and all-input separately; a fifty-position layout may expose atmost4 selected channels pertarget. Data availability and completed fiveyear observations remain explicit.'))
    print('FILTER_SYNTHETIC_PASS',max(errs),flush=True)

def score(kind,qa_path):
    out=OUT/kind;fr=E.verify(out/'PREDICTIONS_FROZEN.json');qa=json.loads(Path(qa_path).read_text(encoding='utf8'))
    assert qa.get('passed') and qa.get('prediction_freeze_sha256')==sha(out/'PREDICTIONS_FROZEN.json'),'Independent filtered prediction QA required'
    if (out/'SCORES_FROZEN.json').exists():E.verify(out/'SCORES_FROZEN.json');return
    binding=fr['binding'];assert binding==gate(binding['usage_freeze_path'])
    init(binding['usage_freeze_path']);cases=E.W['cases'];b=E.W['base'];c=E.W['cp'];N=len(cases);A=4930 if kind=='single' else len(U['names']);names=c['station_id'].astype(str).tolist() if kind=='single' else U['names']
    av=pd.read_csv(ROOT/'design/evaluation_only/target_future_availability.csv',keep_default_na=False).set_index('raw_index').loc[cases.raw_index]
    domain=(av.fixed_representative_H_nonnegative_complete&av.fixed_representative_G_nonnegative_complete).to_numpy(bool)
    strict=domain&~cases.station_id.isin(E.RISK).to_numpy();assert strict.sum()==5905
    # First targetG access in this module, after all gates and hashes passed.
    Q=np.load(E.GDATA/'QC20_Q.npy',mmap_mode='r');truth=np.asarray(Q[np.ix_(cases.raw_index.to_numpy(int),E.G)],float)
    arr=np.lib.format.open_memmap(out/'metrics.npy',mode='w+',shape=(N,A,5),dtype='float64');success=np.lib.format.open_memmap(out/'success.npy',mode='w+',shape=(N,A),dtype=bool)
    operational=np.lib.format.open_memmap(out/'new_channel_used.npy',mode='w+',shape=(N,A),dtype=bool);bc=np.lib.format.open_memmap(out/'branch_month_counts.npy',mode='w+',shape=(N,A,2),dtype='int8')
    ba=np.stack([E.baseline_available_months(i) for i in range(N)]);bs=np.full((N,5),np.nan);bp=np.zeros(N,bool);defined=np.zeros(N,bool);boundary=[]
    for i in range(N):
        bm,v=E.metrics(np.asarray(b['predictions'][i])[None,:],truth[i],np.asarray(b['raw_calendar'][i]));bs[i]=bm[0];defined[i]=v;support=bool(b['fit'][i] and b['support'][i].any());bp[i]=strict[i] and support and bm[0,0]>.7
        with np.load(out/'blocks'/f'target_{i:05d}.npz',allow_pickle=False) as z:par={k:z[k] for k in z.files}
        stored,_=E.metrics(par['predictions'],truth[i],np.asarray(b['raw_calendar'][i]))
        if kind=='single':
            with np.load(ORIGINAL/'single/blocks'/f'target_{i:05d}.npz',allow_pickle=False) as z:original={k:z[k] for k in z.files if k!='predictions'}
            keep=np.asarray(U['mask'][U['mother_rows'][i]]);np.testing.assert_array_equal(keep,par['preselected_use_mask'])
            exact=np.tile(b['predictions'][i],(A,1));branch=np.zeros((A,24),np.uint8);positions=np.flatnonzero(keep)
            if len(positions):exact[positions],branch[positions]=E.full_precision_single(i,original,positions,return_branch=True)
        else:
            rebuilt=[E.full_precision_layout(i,par,key,return_branch=True) for key in names];exact=np.stack([x[0] for x in rebuilt]);branch=np.stack([x[1] for x in rebuilt])
        np.testing.assert_array_equal(branch,par['input_branch']);used=(branch>0).any(1);bc[i,:,0]=(branch==1).sum(1);bc[i,:,1]=(branch==2).sum(1)
        met,_=E.metrics(exact,truth[i],np.asarray(b['raw_calendar'][i]));np.testing.assert_array_equal(exact[~used],np.tile(b['predictions'][i],((~used).sum(),1)));met[~used]=bm[0]
        near=np.flatnonzero((np.abs(met[:,0]-.7)<=1e-5)|(np.abs(stored[:,0]-.7)<=1e-5)|((met[:,0]>.7)!=(stored[:,0]>.7)))
        for j in near:boundary.append(dict(target_row=i,arm=int(j),r_float32=stored[j,0],r_float64=met[j,0],pass_changed=bool((stored[j,0]>.7)!=(met[j,0]>.7))))
        arr[i]=met;operational[i]=used;success[i]=strict[i]&(support|used)&(met[:,0]>.7)
        if (i+1)%500==0:print(f'filtered score {kind} {i+1}/{N}',flush=True)
    for x in [arr,success,operational,bc]:x.flush()
    np.savez(out/'baseline_metrics.npz',metrics=bs,success=bp,nonnegative_HG_domain=domain,truth_variability_metrics_defined=defined,identity_strict=strict,baseline_available_G_months=ba,raw_index=cases.raw_index.to_numpy(int),mother_row=cases.mother_row.to_numpy(int))
    pd.DataFrame(boundary,columns=['target_row','arm','r_float32','r_float64','pass_changed']).to_csv(out/'threshold_precision_audit.csv',index=False)
    summary=[];domains=[];boots=[];mother=pd.read_csv(ROOT/'design/selector_inputs/target_mother.csv',keep_default_na=False)
    regions=[('Global',np.ones(N,bool))]+[(r,cases.continent.eq(r).to_numpy()) for r in sorted(cases.continent.unique())]
    for region,mask in regions:
        ev=mask&strict;validn=int(ev.sum());mothern=len(mother) if region=='Global' else int(mother.continent.eq(region).sum())
        for j,name in enumerate(names):
            passed=np.asarray(success[:,j]);new=int((mask&passed&~bp).sum());lost=int((mask&~passed&bp).sum());delta=np.asarray(arr[:,j,0])-bs[:,0];paired=ev&np.isfinite(delta)
            summary.append(dict(region=region,arm=name,arm_index=j,mother_n=mothern,future_complete_n=int(mask.sum()),strict_evaluable_n=validn,baseline_pass_n=int(bp[mask].sum()),pass_n=int(passed[mask].sum()),new_passes=new,lost_passes=lost,net_passes=new-lost,pass_pct_strict_evaluable=100*passed[mask].sum()/validn if validn else np.nan,net_pct_strict_evaluable=100*(new-lost)/validn if validn else np.nan,new_channel_used_n=int((mask&operational[:,j]).sum()),paired_r_n=int(paired.sum()),mean_r_gain=float(np.mean(delta[paired])) if paired.any() else np.nan,median_r_gain=float(np.median(delta[paired])) if paired.any() else np.nan,median_r=float(np.nanmedian(arr[ev,j,0])) if validn else np.nan,median_NSE=float(np.nanmedian(arr[ev,j,1])) if validn else np.nan,median_abs_alpha_error=float(np.nanmedian(np.abs(arr[ev,j,2]-1))) if validn else np.nan,median_abs_delta_error=float(np.nanmedian(np.abs(arr[ev,j,3]))) if validn else np.nan,median_deseasonal_r=float(np.nanmedian(arr[ev,j,4])) if validn else np.nan,precision_denominator='strict_evaluable_n;mother_n_descriptive_not_unvalidated_success_rate'))
            for label,dm in [('baseline_available_all24',ba.all(1)),('rescue_needed_any_month',~ba.all(1)),('baseline_unavailable_all24',~ba.any(1))]:
                use=ev&dm;nn=int(use.sum());nw=int((use&passed&~bp).sum());ls=int((use&~passed&bp).sum());paired_domain=use&np.isfinite(delta)
                domains.append(dict(region=region,arm=name,domain=label,n=nn,baseline_pass_n=int(bp[use].sum()),pass_n=int(passed[use].sum()),new_passes=nw,lost_passes=ls,net_passes=nw-ls,net_percentage_points=100*(nw-ls)/nn if nn else np.nan,baseline_available_months=int(ba[use].sum()),potential_rescue_months=int((~ba[use]).sum()),augmented_input_months=int(bc[use,j,0].sum()),rescue_input_months=int(bc[use,j,1].sum()),targets_with_actual_rescue=int((use&(bc[:,j,1]>0)).sum()),paired_r_n=int(paired_domain.sum()),mean_r_gain=float(np.mean(delta[paired_domain])) if paired_domain.any() else np.nan,median_r_gain=float(np.median(delta[paired_domain])) if paired_domain.any() else np.nan,domain_defined_without_G_truth=True))
            if kind=='layouts':
                for metric,val,ok in [('pass_pp',100*(passed.astype(float)-bp),ev),('r',delta,paired),('NSE',np.asarray(arr[:,j,1])-bs[:,1],ev&np.isfinite(arr[:,j,1])&np.isfinite(bs[:,1])),('abs_alpha_error',np.abs(bs[:,2]-1)-np.abs(np.asarray(arr[:,j,2])-1),ev&np.isfinite(arr[:,j,2])&np.isfinite(bs[:,2])),('abs_delta_error',np.abs(bs[:,3])-np.abs(np.asarray(arr[:,j,3])),ev&np.isfinite(arr[:,j,3])&np.isfinite(bs[:,3]))]:
                    cells,cc=np.unique(cases.loc[ok,'spatial_cell'].astype(str).to_numpy(),return_inverse=True);K=len(cells);seed=int(hashlib.sha256(('20261026|global1995|'+region+'|'+metric+'|'+','.join(cells)).encode()).hexdigest()[:8],16);lo=hi=np.nan
                    if K>=5:
                        draw=np.random.default_rng(seed).multinomial(K,np.ones(K)/K,size=2000);den=np.bincount(cc,minlength=K);num=np.bincount(cc,weights=val[ok],minlength=K);lo,hi=np.quantile((draw@num)/(draw@den),[.025,.975])
                    boots.append(dict(region=region,arm=name,metric=metric,paired_n=int(ok.sum()),spatial_cells=K,mean_gain=float(np.mean(val[ok])) if ok.any() else np.nan,ci025=lo,ci975=hi,bootstrap_seed=seed,bootstrap_replicates=2000,equal_station_weight=True))
    pd.DataFrame(summary).to_csv(out/'summary_by_candidate_or_layout_and_continent.csv',index=False,encoding='utf-8-sig');pd.DataFrame(domains).to_csv(out/'baseline_available_and_rescue_domains.csv',index=False,encoding='utf-8-sig')
    files=[out/p for p in ['metrics.npy','success.npy','new_channel_used.npy','branch_month_counts.npy','baseline_metrics.npz','threshold_precision_audit.csv','summary_by_candidate_or_layout_and_continent.csv','baseline_available_and_rescue_domains.csv']]
    if kind=='layouts':pd.DataFrame(boots).to_csv(out/'paired_spatial_bootstrap.csv',index=False);files.append(out/'paired_spatial_bootstrap.csv')
    E.freeze(out,'SCORES_FROZEN.json',files,metric_order=['r','NSE','alpha','delta','deseasonal_r'],branch_order=['augmented','candidate_only_rescue'],N=N,arms=A,strict_evaluable=int(strict.sum()),invalid_truth=int((~domain).sum()),pending_identity=int((domain&~strict).sum()),constant_or_undefined_truth_retained_in_denominator=int((strict&~defined).sum()),prediction_freeze_sha256=sha(out/'PREDICTIONS_FROZEN.json'),threshold_near_count=len(boundary),all_metrics_frozen_coefficient_float64_recomputed=True,mode='filtered_inputs')

def main():
    a=argparse.ArgumentParser();a.add_argument('step',choices=['fixture','produce_single','produce_layouts','score_single','score_layouts']);a.add_argument('--usage-freeze');a.add_argument('--prediction-qa');a.add_argument('--workers',type=int,default=8);args=a.parse_args()
    if args.step=='fixture':fixture()
    elif args.step.startswith('produce_'):produce(args.step.removeprefix('produce_'),args.usage_freeze,args.workers)
    else:score(args.step.removeprefix('score_'),args.prediction_qa)

if __name__=='__main__':main()
