from pathlib import Path
import os, sys, json, hashlib, time, argparse, importlib.util
from datetime import datetime, timezone
from concurrent.futures import ProcessPoolExecutor

for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'
HERE = Path(__file__).resolve().parent
CODE = next(p for p in HERE.parents if p.name == 'code')
NAT = CODE / 'V45/experiments/r3_confirmation_20261024/natural'
spec = importlib.util.spec_from_file_location('frozen_natural_distance', NAT / 'run_distance_audit.py')
B = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = B
spec.loader.exec_module(B)
np, pd, G = B.np, B.pd, B.G
THRESHOLDS = ('r > 0', 'r >= 0.5', 'r >= 0.7')


def js(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')


def register():
    assert not (HERE / 'PROTOCOL_FROZEN.json').exists(), 'Do not overwrite a frozen protocol'
    sources = [NAT / 'distance_cases.csv', NAT / 'DISTANCE_PROTOCOL.json', NAT / 'run_distance_audit.py',
               NAT / 'distance_v2/state.npy', NAT / 'distance_v2/distance_and_r.npy',
               B.OLD / 'global_data/raw_Q.npy', B.OLD / 'global_data/station_ids.npy',
               B.OLD / 'design/all_station_roles.csv', Path(__file__)]
    js(HERE / 'PROTOCOL_FROZEN.json', {
        'frozen_utc': datetime.now(timezone.utc).isoformat(),
        'purpose': 'User-requested analysis 5: natural forward-gap support sensitivity to historical correlation qualification.',
        'target_population': 'Same 19,418 targets and 2,612,522 natural forward missing station-months as frozen 20261024 audit; all denominators unchanged.',
        'source_population': 'All 30,959 original GSIM rows, except twin_listed and target itself; no distance restriction or new source screening.',
        'history_and_transform': 'Exactly inherited last up to 60 calendar months before original last target report; each source/target log1p calendar background and anomaly SD estimated only here; at least 12 joint finite standardized anomalies and nondegenerate variance.',
        'sole_intervention': ['Original positive Pearson anomaly r > 0', 'Pearson anomaly r >= 0.5', 'Pearson anomaly r >= 0.7'],
        'no_selection_shortcut': 'Recalculate correlation against every original candidate. Do not filter saved top-four selections, and do not fit or generate reconstructions.',
        'state_codes': {'0': 'outside natural forward gap', '1': 'no qualified historical relationship', '2': 'qualified relationship but no synchronous nonnegative report', '3': 'synchronous report exists but historical calendar transform unavailable', '4': 'synchronous transformable report available'},
        'near_far_rule': 'Within 800 km inclusive vs only beyond 800 km, calculated separately for any nonnegative raw report and H-transformable report. These are exhaustive only among supported months; unsupported months remain separate.',
        'primary_denominator': 'All natural forward missing months in the corresponding global/continent/period stratum, never only supported months.',
        'baseline_acceptance': 'Original r>0 must exactly reproduce every frozen month state and within-800km raw/transformable availability, plus global raw support 2,566,827 and only-far raw reports 244,766. Reject higher-threshold results if baseline fails.',
        'consistency_checks': 'Support and near-support sets are nested under increasing thresholds. Near+far=raw-supported; all four states sum to each fixed stratum denominator.',
        'interpretation': 'Input availability sensitivity only. Does not evaluate natural-gap truth, accuracy or reconstruction success.',
        'sources_sha256': {str(p.relative_to(CODE)): B.sha(p) for p in sources}
    })


def work(e):
    row, j, end = int(e['output_row']), int(e['raw_index']), int(e['history_end_exclusive'])
    gap = np.arange(end, 432)
    length = len(gap)
    h, scl, ssd, sz = B.source_h(end)
    tq = np.asarray(G['raw'][j, h], float)
    tx = np.where(np.isfinite(tq) & (tq >= 0), np.log1p(np.maximum(tq, 0)), np.nan)
    _, tsd, tz = B.transform_log(tx[None, :], h)
    tz = tz[0]
    states = np.ones((3, length), np.uint8)
    raw_near = np.zeros((3, length), bool)
    transform_near = np.zeros((3, length), bool)
    qualified_n = np.zeros(3, np.int32)
    if not np.isfinite(tsd[0]):
        return row, end, states, raw_near, transform_near, qualified_n
    ok = np.isfinite(sz) & np.isfinite(tz)[None, :]
    n = ok.sum(1)
    nn = np.maximum(n, 1)
    xx, yy = np.where(ok, sz, 0), np.where(ok, tz, 0)
    sx, sy = xx.sum(1), yy.sum(1)
    vx = (xx * xx).sum(1) - sx * sx / nn
    vy = (yy * yy).sum(1) - sy * sy / nn
    cv = (xx * yy).sum(1) - sx * sy / nn
    r = np.divide(cv, np.sqrt(np.maximum(vx * vy, 0)), out=np.full(len(n), np.nan),
                  where=(n >= 12) & (vx > 1e-24) & (vy > 1e-24))
    r = np.clip(r, -1, 1)
    r[G['src'] == j] = np.nan
    base = np.isfinite(r) & np.isfinite(ssd)
    # Each threshold uses every qualifying source; no transfer fit or top-k selection.
    for t, rule in enumerate((r > 0, r >= 0.5, r >= 0.7)):
        qual = np.flatnonzero(base & rule)
        qualified_n[t] = len(qual)
        if not len(qual):
            continue
        src = G['src'][qual]
        la, lo = G['lat'][j], G['lon'][j]
        hh = np.sin((G['lat'][src] - la) / 2) ** 2 + np.cos(la) * np.cos(G['lat'][src]) * np.sin((G['lon'][src] - lo) / 2) ** 2
        dd = 12742 * np.arcsin(np.sqrt(np.clip(hh, 0, 1)))
        raw = np.isfinite(G['source_log'][np.ix_(qual, gap)])
        transform = raw & np.isfinite(scl[qual][:, gap % 12])
        raw_any, transform_any = raw.any(0), transform.any(0)
        states[t] = 2
        states[t, raw_any] = 3
        states[t, transform_any] = 4
        near = dd <= 800
        raw_near[t] = raw[near].any(0)
        transform_near[t] = transform[near].any(0)
    return row, end, states, raw_near, transform_near, qualified_n


def summarize(c, state, near_raw, near_transform):
    ri, mi = np.nonzero(state[0] > 0)
    assert len(ri) == 2612522
    continents = c.continent.to_numpy()[ri]
    years = 1980 + mi // 12
    periods = np.where(years < 1990, '1980-1989', np.where(years < 2000, '1990-1999', np.where(years < 2010, '2000-2009', '2010-2015')))
    strata = [('Global', 'Global', 'all', np.ones(len(ri), bool))]
    strata += [('continent', x, 'all', continents == x) for x in sorted(set(continents))]
    strata += [('period', 'Global', x, periods == x) for x in sorted(set(periods))]
    rows = []
    for t, threshold in enumerate(THRESHOLDS):
        st = state[t, ri, mi]
        nr, nt = near_raw[t, ri, mi], near_transform[t, ri, mi]
        for scope, region, period, use in strata:
            s, nraw, ntrans = st[use], nr[use], nt[use]
            den = len(s)
            rec = {'threshold': threshold, 'scope': scope, 'region': region, 'period': period,
                   'targets': int(len(np.unique(ri[use]))), 'forward_missing_months': den,
                   'no_qualified_relation_months': int((s == 1).sum()),
                   'qualified_but_no_synchronous_report_months': int((s == 2).sum()),
                   'raw_report_not_transformable_months': int((s == 3).sum()),
                   'transformable_support_months': int((s == 4).sum()),
                   'raw_synchronous_support_months': int((s >= 3).sum()),
                   'raw_near_800_months': int(nraw.sum()),
                   'raw_only_far_800_months': int(((s >= 3) & ~nraw).sum()),
                   'transformable_near_800_months': int(ntrans.sum()),
                   'transformable_only_far_800_months': int(((s == 4) & ~ntrans).sum())}
            assert sum(rec[k] for k in ['no_qualified_relation_months', 'qualified_but_no_synchronous_report_months', 'raw_report_not_transformable_months', 'transformable_support_months']) == den
            assert rec['raw_near_800_months'] + rec['raw_only_far_800_months'] == rec['raw_synchronous_support_months']
            assert rec['transformable_near_800_months'] + rec['transformable_only_far_800_months'] == rec['transformable_support_months']
            rec.update({k.replace('_months', '_pct_all_forward'): 100 * v / den for k, v in list(rec.items()) if k.endswith('_months') and k != 'forward_missing_months'})
            rows.append(rec)
    result = pd.DataFrame(rows)
    result.to_csv(HERE / 'support_threshold_summary.csv', index=False)
    result[result.scope == 'Global'].to_csv(HERE / 'Table_S17E_natural_correlation_thresholds.csv', index=False)
    return result


def produce(workers):
    protocol = json.loads((HERE / 'PROTOCOL_FROZEN.json').read_text(encoding='utf8'))
    assert all(B.sha(CODE / p) == sha for p, sha in protocol['sources_sha256'].items())
    assert not (HERE / 'COMPLETE.json').exists(), 'Do not overwrite completed results'
    c = pd.read_csv(NAT / 'distance_cases.csv', keep_default_na=False).sort_values('output_row')
    assert len(c) == 19418
    arrays = {}
    for key, dtype in [('state', np.uint8), ('raw_near_800', bool), ('transformable_near_800', bool)]:
        arrays[key] = np.lib.format.open_memmap(HERE / (key + '.npy'), mode='w+', dtype=dtype, shape=(3, 19418, 432))
        arrays[key][:] = 0
    counts = np.zeros((19418, 3), np.int32)
    start = time.time()
    records = c.sort_values(['history_end_exclusive', 'raw_index']).to_dict('records')
    with ProcessPoolExecutor(max_workers=workers, initializer=B.init) as pool:
        for i, (row, end, st, nr, nt, qn) in enumerate(pool.map(work, records, chunksize=8), 1):
            arrays['state'][:, row, end:] = st
            arrays['raw_near_800'][:, row, end:] = nr
            arrays['transformable_near_800'][:, row, end:] = nt
            counts[row] = qn
            if i % 2000 == 0:
                print('threshold audit', i, '/19418', round(time.time() - start, 1), 's', flush=True)
    for a in arrays.values():
        a.flush()
    old_state = np.load(NAT / 'distance_v2/state.npy', mmap_mode='r')
    old_distance = np.load(NAT / 'distance_v2/distance_and_r.npy', mmap_mode='r')
    assert np.array_equal(arrays['state'][0], old_state), 'Original state differs'
    assert np.array_equal(arrays['raw_near_800'][0], old_distance[:, 0] <= 800), 'Original raw near differs'
    assert np.array_equal(arrays['transformable_near_800'][0], old_distance[:, 1] <= 800), 'Original transformable near differs'
    for lo, hi in [(0, 1), (1, 2)]:
        assert not np.any((arrays['state'][hi] >= 3) & (arrays['state'][lo] < 3))
        assert not np.any((arrays['state'][hi] == 4) & (arrays['state'][lo] != 4))
        assert not np.any(arrays['raw_near_800'][hi] & ~arrays['raw_near_800'][lo])
        assert not np.any(arrays['transformable_near_800'][hi] & ~arrays['transformable_near_800'][lo])
        assert np.all(counts[:, hi] <= counts[:, lo])
    result = summarize(c, arrays['state'], arrays['raw_near_800'], arrays['transformable_near_800'])
    global_rows = result[result.scope == 'Global']
    base = global_rows.iloc[0]
    assert base.raw_synchronous_support_months == 2566827
    assert base.raw_only_far_800_months == 244766
    q = c[['output_row', 'station_id', 'raw_index', 'continent', 'history_end_exclusive']].copy()
    for t, name in enumerate(('r_positive', 'r_ge_05', 'r_ge_07')):
        q[name + '_qualified_sources'] = counts[:, t]
    q.to_csv(HERE / 'target_qualified_counts.csv', index=False)
    js(HERE / 'COMPLETE.json', {'status': 'PASS', 'elapsed_seconds': time.time() - start, 'workers': workers,
        'targets': 19418, 'missing_months': 2612522, 'baseline_state_and_raw_and_transformable_near_exact': True,
        'nested_support_and_qualified_counts_pass': True, 'global_results': global_rows.to_dict('records'),
        'outputs_sha256': {p.name: B.sha(p) for p in HERE.iterdir() if p.suffix in ('.csv', '.npy')},
        'protocol_sha256': B.sha(HERE / 'PROTOCOL_FROZEN.json')})
    print(global_rows.to_string(index=False), flush=True)
    print('COMPLETE', round(time.time() - start, 1), 's', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('step', choices=['register', 'produce'])
    parser.add_argument('--workers', type=int, default=12)
    args = parser.parse_args()
    if args.step == 'register':
        register()
    else:
        produce(args.workers)
