"""H-only, fixed-parameter transfer processors for the R4 input experiment.

This module fits supplied arrays only. It does not read files, qualify/order
gauges, look at target G truth, score predictions, tune parameters, or declare a
final experiment protocol. Ridge and one fixed RBF kernel sensitivity check are
not an exhaustive assessment of reconstruction algorithms.

The returned predictions are target standardized anomalies. The production
runner must retain the original R3 inverse transform, numerical guards and raw
target-H calendar-mean fallback; this module does not replace those steps.
"""
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence
import sys

try:
    import numpy as np
except ModuleNotFoundError:
    _code = next(p for p in Path(__file__).resolve().parents if p.name == 'code')
    sys.path.insert(0, str(_code/'V42/dependencies'))
    import numpy as np

LAMBDA = 0.1
MIN_TRAINING_ROWS = 12
SCALE_FLOOR = 1e-12
METHODS = ('ridge', 'rbf_ridge')
Q_PAIR_ARMS = ('Q', 'QT')
FACTORIAL_ARMS = ('Q', 'QP', 'QT', 'QPT', 'QP_Gclim', 'QPT_Gclim')


@dataclass
class RainInputs:
    """H/G predictors; climatology is estimated from H and substituted in G."""
    h: np.ndarray
    g: np.ndarray
    g_climatology: np.ndarray
    calendar_logmean: np.ndarray
    available: bool
    reason: str
    first_precip_month_index: int


@dataclass
class FittedTransfer:
    method: str
    feature_mean: np.ndarray
    feature_scale: np.ndarray
    target_mean: float
    coefficients: np.ndarray
    standardized_training_x: np.ndarray
    n_training: int

    def predict(self, x: np.ndarray) -> np.ndarray:
        """Predict finite feature rows; no evaluation outcome is accepted."""
        x = _matrix(x, 'prediction predictors')
        p = len(self.feature_mean)
        if x.shape[1] != p:
            raise ValueError('Prediction feature count differs from the H fit.')
        out = np.full(len(x), np.nan)
        ok = np.isfinite(x).all(1)
        if not ok.any():
            return out
        with np.errstate(over='ignore', invalid='ignore', divide='ignore'):
            standardized = (x[ok]-self.feature_mean)/self.feature_scale
            if self.method == 'ridge':
                values = standardized@self.coefficients+self.target_mean
            else:
                train = self.standardized_training_x
                distance = np.maximum(np.sum(standardized*standardized, 1)[:, None]
                    + np.sum(train*train, 1)[None, :]-2*standardized@train.T, 0)
                values = np.exp(-distance/p)@self.coefficients+self.target_mean
        values[~np.isfinite(values)] = np.nan
        out[ok] = values
        return out


@dataclass
class DomainResult:
    """Method x arm x G arrays plus fit/fallback metadata.

    model_estimable concerns the model whose output is actually returned.
    requested_model_estimable concerns the requested information/model arm.
    They differ after a fallback. source_available does not mean useful.
    """
    methods: tuple[str, ...]
    arms: tuple[str, ...]
    training_mask: np.ndarray
    predictions_z: np.ndarray
    support: np.ndarray
    model_estimable: np.ndarray
    requested_model_estimable: np.ndarray
    requested_source_available: np.ndarray
    fallback_applied: np.ndarray
    resolved_arm: np.ndarray
    reason: np.ndarray
    uses_precipitation_H: np.ndarray
    uses_precipitation_G_dynamic: np.ndarray
    uses_precipitation_G_climatology: np.ndarray
    uses_topology_variant: np.ndarray
    fitted_models: Mapping[tuple[str, str], FittedTransfer | None]
    returned_model_keys: np.ndarray
    fit_attempt_status: Mapping[tuple[str, str], str]
    full_factorial_information_available: bool


@dataclass
class CaseResult:
    q_pair: DomainResult
    factorial: DomainResult
    precipitation_available: bool
    precipitation_status: str
    topology_available: bool
    topology_status: str
    topology_H_changed_months: int
    topology_G_changed_months: int
    target_estimable: bool


def _vector(value: np.ndarray, name: str) -> np.ndarray:
    x = np.asarray(value, dtype=np.float64)
    if x.ndim != 1:
        raise ValueError(f'{name} must be a one-dimensional array.')
    return x


def _matrix(value: np.ndarray, name: str) -> np.ndarray:
    x = np.asarray(value, dtype=np.float64)
    if x.ndim != 2:
        raise ValueError(f'{name} must be a two-dimensional array.')
    return x


def _methods(values: Sequence[str]) -> tuple[str, ...]:
    values = tuple(values)
    if not values or len(set(values)) != len(values) or any(m not in METHODS for m in values):
        raise ValueError(f'Only the prespecified methods {METHODS} are supported.')
    return values


def prepare_precipitation_lags(raw_precipitation: np.ndarray, *, history_start_month: int,
                               h_length: int = 60, g_length: int = 120) -> RainInputs:
    """Prepare log1p P lag0..3, using three antecedent months plus H and G.

    Month index zero is January; its absolute year is immaterial. H and G must
    be the contiguous forward-extension windows represented by these lengths.
    Only underlying G months are replaced in the climate control. Antecedent
    lag values dated in H remain observed, including the first three G rows.
    A failed input check records unavailable; it never fabricates actual P.
    """
    raw = _vector(raw_precipitation, 'raw_precipitation')
    if h_length < 1 or g_length < 1 or len(raw) != 3+h_length+g_length:
        raise ValueError('Raw precipitation length must be 3 + H length + G length.')
    finite_nonnegative = np.isfinite(raw) & (raw >= 0)
    logp = np.full(raw.shape, np.nan)
    logp[finite_nonnegative] = np.log1p(raw[finite_nonnegative])
    hmonths = history_start_month+np.arange(h_length)
    calendar = np.full(12, np.nan)
    for month in range(12):
        values = logp[3:3+h_length][hmonths % 12 == month]
        if len(values) and np.isfinite(values).all():
            calendar[month] = values.mean()
    controlled = logp.copy()
    gmonths = history_start_month+h_length+np.arange(g_length)
    controlled[3+h_length:] = calendar[gmonths % 12]
    length = h_length+g_length
    actual_lags = np.stack([logp[3-lag:3-lag+length] for lag in range(4)], axis=1)
    controlled_lags = np.stack([controlled[3-lag:3-lag+length] for lag in range(4)], axis=1)
    available = bool(finite_nonnegative.all() and np.isfinite(calendar).all())
    reason = 'available' if available else ('precipitation_missing_or_invalid'
        if not finite_nonnegative.all() else 'H_calendar_background_unavailable')
    return RainInputs(actual_lags[:h_length], actual_lags[h_length:],
        controlled_lags[h_length:], calendar, available, reason, history_start_month-3)


def fit_transfer(x_h: np.ndarray, y_h: np.ndarray, *, method: str,
                 target_estimable: bool = True) -> tuple[FittedTransfer | None, str]:
    """Fit the same fixed H-only processors as the preceding rainfall trial.

    Caller supplies already-selected common H rows. Nonfinite rows are an
    invalid fit, rather than silently selecting different rows by model/arm.
    """
    _methods((method,))
    x, y = _matrix(x_h, 'H predictors'), _vector(y_h, 'H response')
    if len(x) != len(y) or x.shape[1] < 1:
        raise ValueError('H predictor/response dimensions are inconsistent.')
    if not target_estimable:
        return None, 'target_H_transform_unestimable'
    if len(y) < MIN_TRAINING_ROWS:
        return None, 'fewer_than_12_common_H_rows'
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        return None, 'nonfinite_common_H_input'
    with np.errstate(over='ignore', invalid='ignore', divide='ignore'):
        mean = x.mean(0)
        scale = x.std(0)
        scale = np.where(scale > SCALE_FLOOR, scale, 1.0)
        standardized = (x-mean)/scale
        ymean = float(y.mean())
        yc = y-ymean
        n, p = x.shape
        try:
            if method == 'ridge':
                coefficients = np.linalg.solve(standardized.T@standardized+n*LAMBDA*np.eye(p),
                                               standardized.T@yc)
            else:
                distance = np.maximum(np.sum(standardized*standardized, 1)[:, None]
                    + np.sum(standardized*standardized, 1)[None, :]
                    - 2*standardized@standardized.T, 0)
                coefficients = np.linalg.solve(np.exp(-distance/p)+n*LAMBDA*np.eye(n), yc)
        except np.linalg.LinAlgError:
            return None, 'numerical_linear_solve_failure'
    if not (np.isfinite(mean).all() and np.isfinite(scale).all()
            and np.isfinite(standardized).all() and np.isfinite(coefficients).all()
            and np.isfinite(ymean)):
        return None, 'nonfinite_fitted_parameters'
    return FittedTransfer(method, mean.copy(), scale.copy(), ymean, coefficients.copy(),
                          standardized.copy(), n), 'estimated'


def _evaluate_domain(y, qh, qg, qth, qtg, ph, pg, pcg, *, topology_available,
                     precipitation_available, target_estimable, methods, factorial,
                     topology_reason, precipitation_reason, reuse_q_pair=None):
    arms = FACTORIAL_ARMS if factorial else Q_PAIR_ARMS
    training = np.isfinite(y) & np.isfinite(qh)
    if topology_available:
        training &= np.isfinite(qth)
    if factorial and precipitation_available:
        training &= np.isfinite(ph).all(1)
    h_predictors = {'Q': qh[:, None]}
    g_predictors = {'Q': qg[:, None]}
    if topology_available:
        h_predictors['QT'], g_predictors['QT'] = qth[:, None], qtg[:, None]
    if factorial and precipitation_available:
        h_predictors['QP'] = np.column_stack([qh, ph])
        g_predictors['QP'] = np.column_stack([qg, pg])
        g_predictors['QP_Gclim'] = np.column_stack([qg, pcg])
        if topology_available:
            h_predictors['QPT'] = np.column_stack([qth, ph])
            g_predictors['QPT'] = np.column_stack([qtg, pg])
            g_predictors['QPT_Gclim'] = np.column_stack([qtg, pcg])
    shape = (len(methods), len(arms))
    predicted = np.full((*shape, len(qg)), np.nan)
    support = np.zeros(predicted.shape, bool)
    estimable = np.zeros(shape, bool)
    requested_estimable = np.zeros(shape, bool)
    requested_available = np.zeros(shape, bool)
    fallback = np.zeros(shape, bool)
    resolved = np.full(shape, '', dtype=object)
    reasons = np.full(shape, '', dtype=object)
    used_ph = np.zeros(shape, bool)
    used_pg = np.zeros(shape, bool)
    used_pc = np.zeros(shape, bool)
    used_t = np.zeros(shape, bool)
    model_keys = np.full(shape, '', dtype=object)
    fits, attempts = {}, {}
    for mi, method in enumerate(methods):
        for name, x in h_predictors.items():
            key = (method, name)
            if (reuse_q_pair is not None and name in ('Q', 'QT')
                    and np.array_equal(training, reuse_q_pair.training_mask)
                    and key in reuse_q_pair.fitted_models):
                fits[key] = reuse_q_pair.fitted_models[key]
                attempts[key] = reuse_q_pair.fit_attempt_status[key]
            else:
                fits[key], attempts[key] = fit_transfer(
                    x[training], y[training], method=method, target_estimable=target_estimable)
        for ai, requested in enumerate(arms):
            climate = requested.endswith('_Gclim')
            intended = requested.removesuffix('_Gclim')
            needs_p, needs_t = intended in ('QP', 'QPT'), intended in ('QT', 'QPT')
            available = (not needs_p or precipitation_available) and (not needs_t or topology_available)
            requested_available[mi, ai] = available
            missing = []
            has_p, has_t = needs_p and precipitation_available, needs_t and topology_available
            if needs_p and not precipitation_available:
                missing.append('P_source_unavailable:'+precipitation_reason)
            if needs_t and not topology_available:
                missing.append('T_source_unavailable:'+topology_reason)
            actual = 'QPT' if has_p and has_t else ('QP' if has_p else ('QT' if has_t else 'Q'))
            desired_fit = fits.get((method, intended)) if available else None
            requested_estimable[mi, ai] = available and desired_fit is not None
            model = fits.get((method, actual))
            if model is None:
                missing.append('requested_or_reduced_model_unestimable:'+attempts.get(
                    (method, actual), 'not_attempted_source_unavailable'))
                # No search among alternative models: numerical/fit failure
                # follows the single declared fallback to the Q processor.
                actual = 'Q'
                model = fits.get((method, 'Q'))
            if model is None:
                missing.append('Q_model_unestimable:production_raw_seasonal_fallback_required')
                resolved[mi, ai] = 'raw_seasonal_fallback_required'
                reasons[mi, ai] = '|'.join(missing)
                fallback[mi, ai] = True
                continue
            evaluation = actual+('_Gclim' if climate and actual in ('QP', 'QPT') else '')
            values = model.predict(g_predictors[evaluation])
            predicted[mi, ai] = values
            support[mi, ai] = np.isfinite(values)
            estimable[mi, ai] = True
            resolved[mi, ai] = evaluation
            model_keys[mi, ai] = method+'/'+actual
            fallback[mi, ai] = bool(missing)
            reasons[mi, ai] = '|'.join(missing) if missing else 'estimated_requested_arm'
            used_ph[mi, ai] = actual in ('QP', 'QPT')
            used_pg[mi, ai] = used_ph[mi, ai] and not climate
            used_pc[mi, ai] = used_ph[mi, ai] and climate
            used_t[mi, ai] = actual in ('QT', 'QPT')
    return DomainResult(methods, arms, training, predicted, support, estimable,
        requested_estimable, requested_available, fallback, resolved, reasons,
        used_ph, used_pg, used_pc, used_t, fits, model_keys, attempts,
        bool(topology_available and precipitation_available))


def fit_case(y_h: np.ndarray, q_h: np.ndarray, q_g: np.ndarray,
             qt_h: np.ndarray | None = None, qt_g: np.ndarray | None = None,
             p_h: np.ndarray | None = None, p_g: np.ndarray | None = None,
             p_g_climatology: np.ndarray | None = None, *, topology_available: bool,
             precipitation_available: bool, target_estimable: bool = True,
             topology_status: str = 'declared_by_input_audit',
             precipitation_status: str = 'declared_by_input_audit',
             methods: Sequence[str] = METHODS) -> CaseResult:
    """Fit one fixed case without requiring P for the independent Q/QT pair.

    Source-availability flags must come from the upstream input audit, never G
    performance. They are distinct from whether the supplied model can be fit.
    Full P admission here requires complete H/G lag features and a finite H-only
    climatology control. Missing P does not reduce the Q/QT training mask.

    Unavailable channels are removed by a fixed rule: QP->Q without P;
    QT->Q without T; QPT->QT without P, ->QP without T, ->Q without both.
    A numerical/fit failure in an otherwise available augmented model falls
    directly back to Q, with requested failure and operational fit distinguished.

    Fit/input-missing G rows return NaN for the production seasonal fallback;
    they must not be counted as actual external-input-supported predictions.
    """
    methods = _methods(methods)
    y, qh, qg = _vector(y_h, 'y_h'), _vector(q_h, 'q_h'), _vector(q_g, 'q_g')
    if len(y) != len(qh) or len(y) < 1 or len(qg) < 1:
        raise ValueError('Target H and Q window lengths are inconsistent.')
    th = None if qt_h is None else _vector(qt_h, 'qt_h')
    tg = None if qt_g is None else _vector(qt_g, 'qt_g')
    if th is not None and len(th) != len(y):
        raise ValueError('QT H length differs from Q H.')
    if tg is not None and len(tg) != len(qg):
        raise ValueError('QT G length differs from Q G.')
    t_available = bool(topology_available and th is not None and tg is not None)
    t_reason = 'available' if t_available else (topology_status if not topology_available
        else 'declared_available_but_QT_arrays_missing')
    if not t_available:
        th, tg = qh, qg
    rain = []
    for name, value, rows in [('p_h', p_h, len(y)), ('p_g', p_g, len(qg)),
                              ('p_g_climatology', p_g_climatology, len(qg))]:
        x = None if value is None else _matrix(value, name)
        if x is not None and x.shape != (rows, 4):
            raise ValueError(f'{name} must have shape ({rows},4), for lag0..3.')
        rain.append(x)
    ph, pg, pcg = rain
    rain_arrays_complete = all(x is not None and np.isfinite(x).all() for x in rain)
    p_available = bool(precipitation_available and rain_arrays_complete)
    p_reason = 'available' if p_available else (precipitation_status if not precipitation_available
        else 'declared_available_but_P_or_H_climatology_arrays_missing_or_nonfinite')
    kwargs = dict(topology_available=t_available, precipitation_available=p_available,
                  target_estimable=bool(target_estimable), methods=methods,
                  topology_reason=t_reason, precipitation_reason=p_reason)
    q_pair = _evaluate_domain(y, qh, qg, th, tg, ph, pg, pcg, factorial=False, **kwargs)
    factorial = _evaluate_domain(y, qh, qg, th, tg, ph, pg, pcg, factorial=True,
                                 reuse_q_pair=q_pair, **kwargs)
    h_changed = int((~np.isclose(qh, th, rtol=1e-12, atol=1e-12, equal_nan=True)).sum()) if t_available else 0
    g_changed = int((~np.isclose(qg, tg, rtol=1e-12, atol=1e-12, equal_nan=True)).sum()) if t_available else 0
    return CaseResult(q_pair, factorial, p_available, p_reason, t_available,
                      t_reason, h_changed, g_changed, bool(target_estimable))
