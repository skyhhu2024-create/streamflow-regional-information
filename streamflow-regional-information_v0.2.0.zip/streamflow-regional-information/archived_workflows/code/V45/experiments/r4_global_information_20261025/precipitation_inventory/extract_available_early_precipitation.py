"""Extract only validated same-product raw files, with fixed full-basin weights."""

# Release adapter: filesystem location only; scientific operations are unchanged.
def _release_path(kind, relative):
    import os as _release_os
    from pathlib import Path as _ReleasePath
    code_root = next(p for p in _ReleasePath(__file__).resolve().parents if p.name == "code")
    root = code_root if kind == "code" else _ReleasePath(_release_os.environ.get("STREAMFLOW_DATA_ROOT", str(code_root.parent / "inputs")))
    return str(root / relative)

from pathlib import Path
import json,hashlib,os
import numpy as np
import pandas as pd
import netCDF4
from scipy import sparse

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
P=Path(_release_path('data', '999-论文/Five_part'))
W=P.parent/'GSIM全球插补1995-2015/111-paper/paper/Final/GSIM_extension_2025_20261016'
WEIGHT=OUT/'global8898_existing7826_grid_weights.npz'


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()


def open_nc(p):
    before=Path.cwd()
    os.chdir(p.parent)
    try:return netCDF4.Dataset(p.name,'r')
    finally:os.chdir(before)


def extract(p,matrix):
    ready=np.asarray(matrix.sum(axis=1)).ravel()>0
    with open_nc(p) as ds:
        assert np.allclose(ds['latitude'][:],np.linspace(90,-90,1801))
        assert np.allclose(ds['longitude'][:],np.arange(3600)/10)
        assert ds['tp'].units=='m'
        tv=ds['valid_time'];dates=netCDF4.num2date(tv[:],tv.units)
        months=[f'{d.year:04d}-{d.month:02d}' for d in dates]
        values=np.full((matrix.shape[0],len(months)),np.nan,np.float32)
        coverage=np.zeros_like(values)
        for t,month in enumerate(months):
            field=np.ma.asarray(ds['tp'][t]).filled(np.nan).reshape(-1)
            valid=np.isfinite(field)
            cov=(matrix@valid.astype(np.float64)).astype(np.float32)
            numerator=matrix@np.where(valid,field,0).astype(np.float32)
            v=np.divide(numerator,cov,out=np.full(len(ready),np.nan,np.float64),where=(cov>=.95)&ready)
            v*=1000*pd.Period(month,freq='M').days_in_month
            values[:,t]=v;coverage[:,t]=cov
    assert np.all(values[np.isfinite(values)]>=-.0001)
    return np.array(months),values,coverage


def main():
    d=pd.read_csv(OUT/'global8898_precipitation_input_ledger.csv',low_memory=False)
    weights=sparse.load_npz(WEIGHT).astype(np.float64)
    whash=sha(WEIGHT)
    old=np.load(OUT/'global8898_tp_197910_201512_PARTIAL.npz',allow_pickle=False)
    x=old['tp_mm_month'].copy();periods=old['periods'].astype(str);old.close()
    pos={s:i for i,s in enumerate(periods)}
    annual=OUT/'annual_existing7826';annual.mkdir(exist_ok=True)
    # Independent 12-month numerical replay before use of the extractor.
    checkfile=OUT/'RAW_REEXTRACTION_1994_CHECK.json'
    if not checkfile.exists():
        p=W/'收到的数据_20261019/ERA5_Land/1994/era5_land_monthly_1994.nc'
        months,v,c=extract(p,weights)
        expected=x[:,[pos[m] for m in months]]
        mask=np.isfinite(expected)
        assert np.array_equal(np.isfinite(v),mask)
        diff=np.abs(v[mask]-expected[mask])
        assert np.allclose(v[mask],expected[mask],rtol=2e-6,atol=.0001),(diff.max(),np.median(diff))
        check={'status':'PASS','weight_sha256':whash,'months':months.tolist(),
               'station_months_checked':int(mask.sum()),'max_abs_difference_mm_month':float(diff.max()),
               'median_abs_difference_mm_month':float(np.median(diff)),
               'valid_area_fraction_gate':.95,'raw_path':str(p),
               'no_model_or_target_flow_read':True}
        checkfile.write_text(json.dumps(check,ensure_ascii=False,indent=2),encoding='utf8')
        print('raw 1994 replay PASS',float(diff.max()),flush=True)
    else:
        assert json.loads(checkfile.read_text(encoding='utf8'))['weight_sha256']==whash
    available=[]
    rawroot=ROOT/'acquisition/era5_land_early'
    for folder in sorted(rawroot.iterdir()):
        if not folder.is_dir():continue
        statepath=folder/'request_state.json'
        if not statepath.exists():continue
        state=json.loads(statepath.read_text(encoding='utf8'))
        if state.get('status')!='validated':continue
        assert state['dataset']=='reanalysis-era5-land-monthly-means'
        req=state['request']
        assert req['product_type']==['monthly_averaged_reanalysis'] and req['variable']==['total_precipitation']
        p=folder/f'era5_land_monthly_tp_{folder.name}.nc'
        assert p.exists() and sha(p)==state['validation']['sha256']
        target=annual/f'tp_{folder.name}.npz'
        if target.exists():
            z=np.load(target,allow_pickle=False)
            assert str(z['weight_sha256'])==whash and str(z['raw_sha256'])==state['validation']['sha256']
            months=z['periods'].astype(str);v=z['tp_mm_month'];z.close()
        else:
            months,v,c=extract(p,weights)
            assert months.tolist()==state['validation']['months']
            np.savez_compressed(target,station_ids=d.station_id.to_numpy(dtype=str),periods=months.astype(str),
                tp_mm_month=v,valid_area_fraction=c,units=np.array('mm/month'),
                weight_sha256=np.array(whash),raw_sha256=np.array(state['validation']['sha256']),
                raw_product=np.array('reanalysis-era5-land-monthly-means/monthly_averaged_reanalysis'))
            print('extracted',folder.name,'finite',int(np.isfinite(v).sum()),flush=True)
        for j,m in enumerate(months):
            if m in pos:x[:,pos[m]]=v[:,j]
        available.extend(months.tolist())
    readycases=[]
    for i,r in d.iterrows():
        a=int(r.required_start_index_1980)+3;b=int(r.gap_end)+3
        readycases.append(bool(np.isfinite(x[i,a:b]).all() and (x[i,a:b]>=0).all()))
    np.savez_compressed(OUT/'global8898_tp_197910_201512_PARTIAL_WITH_EARLY.npz',
        station_ids=d.station_id.to_numpy(dtype=str),periods=periods,
        tp_mm_month=x,required_window_complete=np.array(readycases),units=np.array('mm/month'),
        weight_sha256=np.array(whash),completion_status=np.array('PARTIAL_INPUTS_all8898_rows_retained'))
    summary={'validated_early_months_extracted':len(set(available)),
             'validated_early_years':sorted(set(m[:4] for m in available)),
             'fixed_cases_required_window_complete':sum(readycases),'mother_cases':len(d),
             'existing_geometry_weight_rows':int(d.weather_row.ge(0).sum()),
             'no_H_G_shift':True,'all_cases_retained':True,'no_models_or_target_flow_read':True,
             'source_product_mixed':False,'raw_replay_check':str(checkfile)}
    (OUT/'EARLY_EXTRACTION_STATUS.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
