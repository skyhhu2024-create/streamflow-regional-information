from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))

from scripts.analyze_review_round2_robustness import (
    IDX, T, chord, correlations, great_circle_km, prepare_matrix,
    strict_target_standardize, xyz,
)

RADIUS_KM = 800.0
SEARCH_RADIUS_KM = 1600.0
CANDIDATE_CAP = 200
MIN_OVERLAP = 24
MIN_CORR = 0.2
POOL_K = 8
MIN_CONTEXT = 12
EDGE_MARGIN = 6

EXPECTED = {
    "same_stations": 2725,
    "pseudo_n": 85273,
    "pseudo_absent": 566,
    "real_n": 450490,
    "real_absent": 97303,
}


def gap_length_bin(length):
    if length <= 3:
        return "1-3"
    if length <= 12:
        return "4-12"
    if length <= 36:
        return "13-36"
    return ">36"


def record_bin(n_valid):
    if n_valid < 120:
        return "1-119"
    if n_valid < 240:
        return "120-239"
    if n_valid < 360:
        return "240-359"
    return "360-432"


def season(month):
    if month in (12, 1, 2):
        return "DJF"
    if month in (3, 4, 5):
        return "MAM"
    if month in (6, 7, 8):
        return "JJA"
    return "SON"


def era5(year):
    start = 1980 + 5 * ((year - 1980) // 5)
    return f"{start}-{min(start + 4, 2015)}"


def contiguous_runs(mask):
    idx = np.flatnonzero(mask)
    if not len(idx):
        return []
    cuts = np.flatnonzero(np.diff(idx) > 1) + 1
    groups = np.split(idx, cuts)
    return [(int(g[0]), int(g[-1]), int(len(g))) for g in groups]


def pct(absent, total):
    return 100.0 * absent / total if total else float("nan")


def prepare_bootstrap_scheme(cell_counts, station_to_i):
    cells = sorted(cell_counts["cell"].unique())
    cell_to_i = {cell: i for i, cell in enumerate(cells)}
    x = cell_counts.copy()
    x["station_i"] = x["station_id"].map(station_to_i)
    x["cell_i"] = x["cell"].map(cell_to_i)

    def arrays(frame):
        return (
            frame["station_i"].to_numpy(int),
            frame["cell_i"].to_numpy(int),
            frame["n"].to_numpy(float),
            frame["absent"].to_numpy(float),
        )

    return {
        "n_cell": len(cells),
        "pseudo": arrays(x[x["gap_type"] == "pseudo"]),
        "real": arrays(x[x["gap_type"] == "real_benchmark_comparable"]),
    }


def cluster_bootstrap(station_counts, schemes, n_boot, seed):
    stations = sorted(station_counts["station_id"].unique())
    station_to_i = {sid: i for i, sid in enumerate(stations)}
    n_station = len(stations)
    wide_n = (
        station_counts.pivot(index="station_id", columns="metric", values="n")
        .reindex(stations).fillna(0)
    )
    wide_a = (
        station_counts.pivot(index="station_id", columns="metric", values="absent")
        .reindex(stations).fillna(0)
    )
    metrics = list(wide_n.columns)
    n_arr = wide_n.to_numpy(float)
    a_arr = wide_a[metrics].to_numpy(float)
    prepared = {
        name: prepare_bootstrap_scheme(frame, station_to_i)
        for name, frame in schemes.items()
    }

    rng = np.random.default_rng(seed)
    rows = []
    for b in range(n_boot):
        draw = rng.integers(0, n_station, size=n_station)
        sw = np.bincount(draw, minlength=n_station).astype(float)
        total_n = sw @ n_arr
        total_a = sw @ a_arr
        row = {"bootstrap": b}
        for i, metric in enumerate(metrics):
            row[f"{metric}_absent_pct"] = pct(total_a[i], total_n[i])

        pseudo_rate = float(row["pseudo_absent_pct"])
        real_rate = float(row["real_all_absent_pct"])
        exact_rate = float(row["real_benchmark_comparable_absent_pct"])
        row["real_minus_pseudo_pp"] = real_rate - pseudo_rate
        row["real_over_pseudo_ratio"] = (
            real_rate / pseudo_rate if pseudo_rate > 0 else np.nan
        )
        row["exact_minus_pseudo_pp"] = exact_rate - pseudo_rate
        row["exact_over_pseudo_ratio"] = (
            exact_rate / pseudo_rate if pseudo_rate > 0 else np.nan
        )

        for name, data in prepared.items():
            ps, pc, pn, pa = data["pseudo"]
            rs, rc, rn, ra = data["real"]
            n_cell = int(data["n_cell"])
            pden = np.bincount(pc, weights=pn * sw[ps], minlength=n_cell)
            pnum = np.bincount(pc, weights=pa * sw[ps], minlength=n_cell)
            rden = np.bincount(rc, weights=rn * sw[rs], minlength=n_cell)
            rnum = np.bincount(rc, weights=ra * sw[rs], minlength=n_cell)
            common = (pden > 0) & (rden > 0)
            if common.any():
                weights = pden[common] / pden[common].sum()
                pstd = float(np.sum(weights * pnum[common] / pden[common]) * 100)
                rstd = float(np.sum(weights * rnum[common] / rden[common]) * 100)
                share = float(pden[common].sum() / pden.sum() * 100)
            else:
                pstd = rstd = share = float("nan")
            row[f"{name}_pseudo_absent_pct"] = pstd
            row[f"{name}_real_absent_pct"] = rstd
            row[f"{name}_difference_pp"] = rstd - pstd
            row[f"{name}_ratio"] = rstd / pstd if pstd > 0 else np.nan
            row[f"{name}_common_pseudo_share_pct"] = share
        rows.append(row)

    boot = pd.DataFrame(rows)
    ci = {}
    for col in boot.columns:
        if col == "bootstrap":
            continue
        values = boot[col].to_numpy(float)
        values = values[np.isfinite(values)]
        if len(values):
            ci[col] = {
                "lo": float(np.quantile(values, 0.025)),
                "median": float(np.quantile(values, 0.5)),
                "hi": float(np.quantile(values, 0.975)),
            }
    return boot, ci


def build_standardization(cell_counts, strata, name, ci):
    total = (
        cell_counts.groupby(["gap_type", "cell"], as_index=False)[["n", "absent"]]
        .sum()
    )
    p = total[total["gap_type"] == "pseudo"].set_index("cell")
    r = total[
        total["gap_type"] == "real_benchmark_comparable"
    ].set_index("cell")
    common = p.index.intersection(r.index)
    pc = p.loc[common]
    rc = r.loc[common]
    weights = pc["n"] / pc["n"].sum()
    pstd = float((weights * pc["absent"] / pc["n"]).sum() * 100)
    rstd = float((weights * rc["absent"] / rc["n"]).sum() * 100)
    common_set = set(common)
    real_station_n = int(cell_counts[
        (cell_counts["gap_type"] == "real_benchmark_comparable")
        & cell_counts["cell"].isin(common_set)
    ]["station_id"].nunique())
    pseudo_station_n = int(cell_counts[
        (cell_counts["gap_type"] == "pseudo")
        & cell_counts["cell"].isin(common_set)
    ]["station_id"].nunique())
    summary = {
        "scheme": name,
        "target_distribution": "pseudo-gap distribution over common cells",
        "strata": strata,
        "n_common_cells": int(len(common)),
        "pseudo_stations_in_common_cells": pseudo_station_n,
        "real_stations_in_common_cells": real_station_n,
        "pseudo_months_in_common_cells": int(pc["n"].sum()),
        "pseudo_month_share_in_common_cells_pct": float(
            pc["n"].sum() / p["n"].sum() * 100
        ),
        "real_benchmark_comparable_months_in_common_cells": int(rc["n"].sum()),
        "pseudo_absent_pct": pstd,
        "real_absent_pct": rstd,
        "difference_pp": rstd - pstd,
        "ratio": rstd / pstd,
        "pseudo_absent_pct_ci": ci[f"{name}_pseudo_absent_pct"],
        "real_absent_pct_ci": ci[f"{name}_real_absent_pct"],
        "difference_pp_ci": ci[f"{name}_difference_pp"],
        "ratio_ci": ci[f"{name}_ratio"],
        "common_pseudo_share_pct_ci": ci[f"{name}_common_pseudo_share_pct"],
    }
    return summary, total


def run(args):
    t0 = time.time()
    ids = np.load(ROOT / "recoverability" / "ids.npy", allow_pickle=True).astype(str)
    id_to_i = {sid: i for i, sid in enumerate(ids)}
    raw, _, zn0, vis = prepare_matrix(ids)
    n_valid_all = vis.sum(axis=1)

    meta0 = pd.read_csv(ROOT / "global_station_meta_kg.csv")
    meta = meta0.rename(columns={"gsim.no": "gsim_no"}).copy()
    pos = meta.set_index("gsim_no").reindex(ids)
    lat = pos["latitude"].to_numpy(float)
    lon = pos["longitude"].to_numpy(float)
    continent = pos["continent"].fillna("Unknown").astype(str).to_numpy()
    geo_ok = np.isfinite(lat) & np.isfinite(lon)
    vec = np.full((len(ids), 3), np.nan)
    vec[geo_ok] = xyz(lat[geo_ok], lon[geo_ok])
    tree_idx = np.where(geo_ok)[0]
    tree = cKDTree(vec[tree_idx])

    pseudo = pd.read_csv(
        ROOT / "results" / "raw" / "stratified_idw" / "predictions_long.csv",
        usecols=["station_id", "date", "gap_id", "stratum"],
    ).drop_duplicates(["station_id", "date"])
    pseudo["date"] = pd.to_datetime(pseudo["date"])
    pseudo["t"] = (
        (pseudo["date"].dt.year - IDX[0].year) * 12
        + pseudo["date"].dt.month - 1
    ).astype(int)
    pseudo = pseudo[(pseudo["t"] >= 0) & (pseudo["t"] < T)].copy()
    pseudo_by_station = {
        sid: frame.copy()
        for sid, frame in pseudo.groupby("station_id", sort=False)
    }

    month_rows = []
    run_rows = []
    pool_rows = []
    station_rows = []

    for k, (sid, pg) in enumerate(pseudo_by_station.items(), start=1):
        if sid not in id_to_i:
            continue
        j = id_to_i[sid]
        if (not geo_ok[j]) or n_valid_all[j] < 12:
            continue
        pt = np.sort(pg["t"].unique())
        strict_z, strict_vis = strict_target_standardize(raw[j], pt)

        pool = np.empty(0, dtype=int)
        pool_meta = []
        query = tree.query_ball_point(vec[j], r=chord(SEARCH_RADIUS_KM))
        cand = tree_idx[np.asarray(query, dtype=int)]
        cand = cand[cand != j]
        if len(cand):
            dist = great_circle_km(vec[j], vec[cand])
            keep = dist <= SEARCH_RADIUS_KM + 1e-8
            cand, dist = cand[keep], dist[keep]
            if len(cand) > CANDIDATE_CAP:
                nearest = np.argsort(dist)[:CANDIDATE_CAP]
                cand, dist = cand[nearest], dist[nearest]
            overlap, corr = correlations(
                j, cand, zn0, vis, target_z=strict_z, target_vis=strict_vis
            )
            eligible = np.where(
                (dist <= RADIUS_KM + 1e-8)
                & (overlap >= MIN_OVERLAP)
                & np.isfinite(corr)
                & (corr >= MIN_CORR)
            )[0]
            if len(eligible):
                order = eligible[np.argsort(-corr[eligible])]
                chosen = order[:POOL_K]
                pool = cand[chosen]
                pool_meta = [
                    (int(cand[q]), float(dist[q]), float(overlap[q]), float(corr[q]))
                    for q in chosen
                ]

        for rank, (di, distance, overlap, corr) in enumerate(pool_meta, start=1):
            pool_rows.append({
                "target_id": sid,
                "donor_id": ids[di],
                "donor_rank": rank,
                "distance_km": distance,
                "strict_overlap_months": int(overlap),
                "strict_correlation": corr,
            })

        donor_available = (
            vis[pool].sum(axis=0) > 0 if len(pool)
            else np.zeros(T, dtype=bool)
        )
        target_obs = vis[j]
        first_valid = int(np.flatnonzero(target_obs)[0])
        last_valid = int(np.flatnonzero(target_obs)[-1])
        rec_bin = record_bin(int(n_valid_all[j]))
        cont = continent[j]

        pseudo_gap_len = pg.groupby("gap_id")["t"].nunique().to_dict()
        pseudo_absent = 0
        for row in pg.itertuples(index=False):
            tt = int(row.t)
            glen = int(pseudo_gap_len[row.gap_id])
            absent = int(not donor_available[tt])
            pseudo_absent += absent
            date = IDX[tt]
            month_rows.append({
                "station_id": sid, "gap_type": "pseudo", "position": "internal",
                "t": tt, "date": date.strftime("%Y-%m"), "year": int(date.year),
                "month": int(date.month), "season": season(int(date.month)),
                "era5": era5(int(date.year)), "gap_id": str(row.gap_id),
                "gap_length": glen, "gap_length_bin": gap_length_bin(glen),
                "record_bin": rec_bin, "continent": cont,
                "donor_absent": absent, "length_only_comparable": 1,
                "benchmark_comparable": 1,
            })
        for gid, frame in pg.groupby("gap_id", sort=False):
            ts = np.sort(frame["t"].unique())
            run_rows.append({
                "station_id": sid, "gap_type": "pseudo", "position": "internal",
                "gap_id": str(gid), "start": IDX[int(ts[0])].strftime("%Y-%m"),
                "end": IDX[int(ts[-1])].strftime("%Y-%m"),
                "gap_length": int(len(ts)), "gap_length_bin": gap_length_bin(len(ts)),
                "absent_months": int((~donor_available[ts]).sum()),
                "left_context_12": 1, "right_context_12": 1,
                "edge_margin_6": 1, "length_only_comparable": 1,
                "benchmark_comparable": 1,
            })

        real_mask = ~target_obs
        real_absent = 0
        position_counts = {
            "before": [0, 0], "internal": [0, 0], "after": [0, 0],
            "internal_le36": [0, 0], "benchmark_comparable": [0, 0],
        }
        for rid, (start, end, glen) in enumerate(contiguous_runs(real_mask), start=1):
            if end < first_valid:
                position = "before"
            elif start > last_valid:
                position = "after"
            else:
                position = "internal"
            times = np.arange(start, end + 1)
            run_absent = int((~donor_available[times]).sum())
            length_only = int(position == "internal" and glen <= 36)
            left_context = int(
                start >= MIN_CONTEXT
                and bool(target_obs[start - MIN_CONTEXT:start].all())
            )
            right_context = int(
                end + MIN_CONTEXT < T
                and bool(target_obs[end + 1:end + 1 + MIN_CONTEXT].all())
            )
            edge_ok = int(start >= EDGE_MARGIN and end <= T - EDGE_MARGIN - 1)
            comparable = int(length_only and left_context and right_context and edge_ok)
            run_rows.append({
                "station_id": sid, "gap_type": "real", "position": position,
                "gap_id": f"{sid}_real_{rid}",
                "start": IDX[start].strftime("%Y-%m"),
                "end": IDX[end].strftime("%Y-%m"), "gap_length": glen,
                "gap_length_bin": gap_length_bin(glen),
                "absent_months": run_absent, "left_context_12": left_context,
                "right_context_12": right_context, "edge_margin_6": edge_ok,
                "length_only_comparable": length_only,
                "benchmark_comparable": comparable,
            })
            for tt in times:
                absent = int(not donor_available[tt])
                real_absent += absent
                position_counts[position][0] += 1
                position_counts[position][1] += absent
                if length_only:
                    position_counts["internal_le36"][0] += 1
                    position_counts["internal_le36"][1] += absent
                if comparable:
                    position_counts["benchmark_comparable"][0] += 1
                    position_counts["benchmark_comparable"][1] += absent
                date = IDX[int(tt)]
                month_rows.append({
                    "station_id": sid, "gap_type": "real", "position": position,
                    "t": int(tt), "date": date.strftime("%Y-%m"),
                    "year": int(date.year), "month": int(date.month),
                    "season": season(int(date.month)), "era5": era5(int(date.year)),
                    "gap_id": f"{sid}_real_{rid}", "gap_length": glen,
                    "gap_length_bin": gap_length_bin(glen),
                    "record_bin": rec_bin, "continent": cont,
                    "donor_absent": absent,
                    "length_only_comparable": length_only,
                    "benchmark_comparable": comparable,
                })

        station_rows.append({
            "station_id": sid, "n_valid": int(n_valid_all[j]),
            "n_pool": int(len(pool)), "n_pseudo": int(len(pt)),
            "pseudo_absent": int(pseudo_absent), "n_real": int(real_mask.sum()),
            "real_absent": int(real_absent),
            "n_real_before": position_counts["before"][0],
            "real_before_absent": position_counts["before"][1],
            "n_real_internal": position_counts["internal"][0],
            "real_internal_absent": position_counts["internal"][1],
            "n_real_after": position_counts["after"][0],
            "real_after_absent": position_counts["after"][1],
            "n_real_internal_le36": position_counts["internal_le36"][0],
            "real_internal_le36_absent": position_counts["internal_le36"][1],
            "n_real_benchmark_comparable": position_counts["benchmark_comparable"][0],
            "real_benchmark_comparable_absent": position_counts["benchmark_comparable"][1],
        })
        if k % 250 == 0:
            print(f"[pool] {k}/{len(pseudo_by_station)} elapsed={time.time()-t0:.1f}s", flush=True)

    stations = pd.DataFrame(station_rows)
    months = pd.DataFrame(month_rows)
    runs = pd.DataFrame(run_rows)
    pools = pd.DataFrame(pool_rows)

    same_ids = set(stations.loc[stations["n_real"] > 0, "station_id"])
    same = stations[stations["station_id"].isin(same_ids)].copy()
    same_months = months[months["station_id"].isin(same_ids)].copy()
    same_runs = runs[runs["station_id"].isin(same_ids)].copy()
    same_pools = pools[pools["target_id"].isin(same_ids)].copy()

    observed = {
        "same_stations": int(len(same)),
        "pseudo_n": int(same["n_pseudo"].sum()),
        "pseudo_absent": int(same["pseudo_absent"].sum()),
        "real_n": int(same["n_real"].sum()),
        "real_absent": int(same["real_absent"].sum()),
    }
    if observed != EXPECTED:
        raise AssertionError(f"same-cohort reproduction failed: {observed} != {EXPECTED}")

    metric_map = {
        "pseudo": ("n_pseudo", "pseudo_absent"),
        "real_all": ("n_real", "real_absent"),
        "real_before": ("n_real_before", "real_before_absent"),
        "real_internal": ("n_real_internal", "real_internal_absent"),
        "real_after": ("n_real_after", "real_after_absent"),
        "real_internal_le36_length_only": (
            "n_real_internal_le36", "real_internal_le36_absent"
        ),
        "real_benchmark_comparable": (
            "n_real_benchmark_comparable", "real_benchmark_comparable_absent"
        ),
    }
    station_counts_rows = []
    for metric, (ncol, acol) in metric_map.items():
        frame = same[["station_id", ncol, acol]].rename(
            columns={ncol: "n", acol: "absent"}
        )
        frame["metric"] = metric
        station_counts_rows.append(frame)
    station_counts = pd.concat(station_counts_rows, ignore_index=True)

    comp = same_months[
        (same_months["gap_type"] == "pseudo")
        | ((same_months["gap_type"] == "real")
           & (same_months["benchmark_comparable"] == 1))
    ].copy()
    comp["gap_type"] = np.where(
        comp["gap_type"] == "pseudo", "pseudo", "real_benchmark_comparable"
    )

    structure_cols = [
        "continent", "record_bin", "gap_length_bin", "era5", "season"
    ]
    structure = comp.copy()
    structure["cell"] = structure[structure_cols].astype(str).agg("|".join, axis=1)
    structure_counts = (
        structure.groupby(["station_id", "gap_type", "cell"], as_index=False)
        .agg(n=("donor_absent", "size"), absent=("donor_absent", "sum"))
    )

    station_length_cols = ["station_id", "gap_length_bin"]
    station_length = comp.copy()
    station_length["cell"] = (
        station_length[station_length_cols].astype(str).agg("|".join, axis=1)
    )
    station_length_counts = (
        station_length.groupby(["station_id", "gap_type", "cell"], as_index=False)
        .agg(n=("donor_absent", "size"), absent=("donor_absent", "sum"))
    )

    schemes = {
        "structure": structure_counts,
        "same_station_length": station_length_counts,
    }
    boot, ci = cluster_bootstrap(
        station_counts, schemes, n_boot=args.n_boot, seed=args.seed
    )

    summary_rows = []
    for metric, (ncol, acol) in metric_map.items():
        n_months = int(same[ncol].sum())
        absent = int(same[acol].sum())
        summary_rows.append({
            "analysis": "unadjusted", "gap_group": metric,
            "n_stations": int((same[ncol] > 0).sum()),
            "n_months": n_months, "absent_months": absent,
            "donor_absent_pct": pct(absent, n_months),
            "ci_lo": ci[f"{metric}_absent_pct"]["lo"],
            "ci_hi": ci[f"{metric}_absent_pct"]["hi"],
        })
    summary_lookup = {row["gap_group"]: row for row in summary_rows}

    structure_std, structure_total = build_standardization(
        structure_counts, structure_cols, "structure", ci
    )
    station_length_std, station_length_total = build_standardization(
        station_length_counts, station_length_cols, "same_station_length", ci
    )
    standards = {
        "structure": structure_std,
        "same_station_length": station_length_std,
    }

    def raw_contrast(name, metric):
        real_rate = float(summary_lookup[metric]["donor_absent_pct"])
        pseudo_rate = float(summary_lookup["pseudo"]["donor_absent_pct"])
        diffs = (
            boot[f"{metric}_absent_pct"] - boot["pseudo_absent_pct"]
        ).replace([np.inf, -np.inf], np.nan).dropna().to_numpy(float)
        ratios = (
            boot[f"{metric}_absent_pct"] / boot["pseudo_absent_pct"]
        ).replace([np.inf, -np.inf], np.nan).dropna().to_numpy(float)
        return {
            "contrast": name, "real_absent_pct": real_rate,
            "pseudo_absent_pct": pseudo_rate,
            "difference_pp": real_rate - pseudo_rate,
            "difference_ci_lo": float(np.quantile(diffs, 0.025)),
            "difference_ci_hi": float(np.quantile(diffs, 0.975)),
            "ratio": real_rate / pseudo_rate,
            "ratio_ci_lo": float(np.quantile(ratios, 0.025)),
            "ratio_ci_hi": float(np.quantile(ratios, 0.975)),
            "bootstrap_unit": "target station",
            "bootstrap_replicates": args.n_boot,
        }

    def standardized_contrast(name, scheme, result):
        return {
            "contrast": name,
            "real_absent_pct": result["real_absent_pct"],
            "pseudo_absent_pct": result["pseudo_absent_pct"],
            "difference_pp": result["difference_pp"],
            "difference_ci_lo": ci[f"{scheme}_difference_pp"]["lo"],
            "difference_ci_hi": ci[f"{scheme}_difference_pp"]["hi"],
            "ratio": result["ratio"],
            "ratio_ci_lo": ci[f"{scheme}_ratio"]["lo"],
            "ratio_ci_hi": ci[f"{scheme}_ratio"]["hi"],
            "bootstrap_unit": "target station",
            "bootstrap_replicates": args.n_boot,
        }

    contrast_rows = [
        raw_contrast("real_all_vs_pseudo", "real_all"),
        raw_contrast("real_internal_vs_pseudo", "real_internal"),
        raw_contrast(
            "real_internal_le36_length_only_vs_pseudo",
            "real_internal_le36_length_only",
        ),
        raw_contrast(
            "real_benchmark_comparable_vs_pseudo", "real_benchmark_comparable"
        ),
        standardized_contrast(
            "structure_standardized_benchmark_comparable_vs_pseudo",
            "structure", structure_std,
        ),
        standardized_contrast(
            "same_station_length_standardized_benchmark_comparable_vs_pseudo",
            "same_station_length", station_length_std,
        ),
    ]

    hero_groups = [
        ("pseudo", "Random interior pseudo-gaps"),
        ("real_all", "All real gaps"),
        ("real_before", "Before first observation"),
        ("real_internal", "Internal real gaps"),
        ("real_after", "After last observation"),
        ("real_benchmark_comparable", "Benchmark-comparable internal gaps"),
    ]
    hero_rows = []
    pseudo_raw = float(summary_lookup["pseudo"]["donor_absent_pct"])
    for order_i, (key, label) in enumerate(hero_groups, start=1):
        row = summary_lookup[key]
        hero_rows.append({
            "order": order_i, "group": key, "display_label": label,
            "estimate_pct": row["donor_absent_pct"],
            "ci_lo": row["ci_lo"], "ci_hi": row["ci_hi"],
            "n_stations": row["n_stations"], "n_months": row["n_months"],
            "absent_months": row["absent_months"],
            "estimate_type": "raw station-month weighted",
            "comparison_pseudo_pct": pseudo_raw,
            "ratio_to_pseudo": row["donor_absent_pct"] / pseudo_raw,
            "common_pseudo_share_pct": 100.0,
        })
    hero_rows.append({
        "order": 7,
        "group": "benchmark_comparable_structure_standardized",
        "display_label": "Benchmark-comparable, structure-standardized",
        "estimate_pct": structure_std["real_absent_pct"],
        "ci_lo": structure_std["real_absent_pct_ci"]["lo"],
        "ci_hi": structure_std["real_absent_pct_ci"]["hi"],
        "n_stations": structure_std["real_stations_in_common_cells"],
        "n_months": structure_std[
            "real_benchmark_comparable_months_in_common_cells"
        ],
        "absent_months": np.nan,
        "estimate_type": (
            "standardized to the pseudo-gap distribution over common continent x "
            "record-completeness x gap-length x five-year-period x season cells"
        ),
        "comparison_pseudo_pct": structure_std["pseudo_absent_pct"],
        "ratio_to_pseudo": structure_std["ratio"],
        "common_pseudo_share_pct": structure_std[
            "pseudo_month_share_in_common_cells_pct"
        ],
    })
    hero = pd.DataFrame(hero_rows)

    sensitivity_rows = []
    for result in (structure_std, station_length_std):
        sensitivity_rows.append({
            "scheme": result["scheme"], "strata": "|".join(result["strata"]),
            "n_common_cells": result["n_common_cells"],
            "pseudo_stations_in_common_cells": result["pseudo_stations_in_common_cells"],
            "real_stations_in_common_cells": result["real_stations_in_common_cells"],
            "pseudo_months_in_common_cells": result["pseudo_months_in_common_cells"],
            "pseudo_month_share_in_common_cells_pct": result[
                "pseudo_month_share_in_common_cells_pct"
            ],
            "real_months_in_common_cells": result[
                "real_benchmark_comparable_months_in_common_cells"
            ],
            "pseudo_absent_pct": result["pseudo_absent_pct"],
            "pseudo_ci_lo": result["pseudo_absent_pct_ci"]["lo"],
            "pseudo_ci_hi": result["pseudo_absent_pct_ci"]["hi"],
            "real_absent_pct": result["real_absent_pct"],
            "real_ci_lo": result["real_absent_pct_ci"]["lo"],
            "real_ci_hi": result["real_absent_pct_ci"]["hi"],
            "difference_pp": result["difference_pp"],
            "difference_ci_lo": result["difference_pp_ci"]["lo"],
            "difference_ci_hi": result["difference_pp_ci"]["hi"],
            "ratio": result["ratio"],
            "ratio_ci_lo": result["ratio_ci"]["lo"],
            "ratio_ci_hi": result["ratio_ci"]["hi"],
        })

    same.to_csv(HERE / "same_cohort_station_counts.csv", index=False)
    same_pools.to_csv(HERE / "audit_baseline_pool_edges.csv", index=False)
    same_months.to_csv(HERE / "same_cohort_gap_months.csv", index=False)
    same_runs.to_csv(HERE / "same_cohort_gap_runs.csv", index=False)
    station_counts.to_csv(HERE / "station_metric_counts.csv", index=False)
    structure_counts.to_csv(
        HERE / "standardization_structure_station_cells.csv", index=False
    )
    structure_total.to_csv(
        HERE / "standardization_structure_cells.csv", index=False
    )
    station_length_counts.to_csv(
        HERE / "standardization_same_station_length_station_cells.csv", index=False
    )
    station_length_total.to_csv(
        HERE / "standardization_same_station_length_cells.csv", index=False
    )
    pd.DataFrame(summary_rows).to_csv(
        HERE / "gap_structure_summary.csv", index=False
    )
    pd.DataFrame(contrast_rows).to_csv(
        HERE / "gap_structure_contrasts.csv", index=False
    )
    pd.DataFrame(sensitivity_rows).to_csv(
        HERE / "standardization_sensitivity.csv", index=False
    )
    boot.to_csv(HERE / "station_cluster_bootstrap.csv", index=False)
    hero.to_csv(HERE / "Fig3_hero_gap_structure.csv", index=False)

    after_month_share = (
        100 * float(summary_lookup["real_after"]["n_months"])
        / float(summary_lookup["real_all"]["n_months"])
    )
    after_absent_share = (
        100 * float(summary_lookup["real_after"]["absent_months"])
        / float(summary_lookup["real_all"]["absent_months"])
    )
    exact = summary_lookup["real_benchmark_comparable"]
    caption_stats = (
        "At the same 2,725 gauges, the fixed eight-reference pool was "
        f"unavailable for {observed['real_absent']:,}/{observed['real_n']:,} "
        f"real missing months ({pct(observed['real_absent'], observed['real_n']):.2f}%) "
        f"but only {observed['pseudo_absent']:,}/{observed['pseudo_n']:,} random "
        f"interior pseudo-gap months ({pct(observed['pseudo_absent'], observed['pseudo_n']):.2f}%), "
        f"a {pct(observed['real_absent'], observed['real_n']) / pct(observed['pseudo_absent'], observed['pseudo_n']):.1f}-fold difference. "
        f"Absence rates were {summary_lookup['real_before']['donor_absent_pct']:.2f}% "
        f"before the first observation, {summary_lookup['real_internal']['donor_absent_pct']:.2f}% "
        f"within records and {summary_lookup['real_after']['donor_absent_pct']:.2f}% "
        f"after the final observation. Post-record gaps comprised {after_month_share:.1f}% "
        f"of real missing months and {after_absent_share:.1f}% of unsupported months. "
        f"Among benchmark-comparable internal runs (1-36 months, 12 visible months "
        f"on each side and a 6-month archive-edge margin), the absence rate was "
        f"{exact['donor_absent_pct']:.2f}% ({exact['ci_lo']:.2f}-{exact['ci_hi']:.2f}%). "
        f"After standardizing exact-comparable runs to the pseudo-gap distribution "
        f"over common continent, record-completeness, gap-length, five-year-period "
        f"and season cells, the corresponding rates were "
        f"{structure_std['real_absent_pct']:.2f}% versus "
        f"{structure_std['pseudo_absent_pct']:.2f}% "
        f"(ratio {structure_std['ratio']:.2f}; 95% station-cluster bootstrap "
        f"interval {structure_std['ratio_ci']['lo']:.2f}-"
        f"{structure_std['ratio_ci']['hi']:.2f}); common cells retained "
        f"{structure_std['pseudo_month_share_in_common_cells_pct']:.1f}% "
        "of pseudo-gap months. Intervals use 2,000 target-station cluster "
        "bootstrap replicates. A same-station x gap-length sensitivity is reported "
        "separately because its common support retained only "
        f"{station_length_std['pseudo_month_share_in_common_cells_pct']:.1f}% of "
        "pseudo-gap months."
    )
    (HERE / "Fig3_hero_caption_statistics.txt").write_text(
        caption_stats + "\n", encoding="utf-8"
    )

    report = {
        "run_id": args.run_id,
        "provenance": {
            "status": "final context-matched audit",
            "supersedes": "v1 length-only definition archived under v1_length_only",
            "change": (
                "benchmark-comparable real gaps now reproduce pseudo-gap structural "
                "eligibility: internal length 1-36 months, 12 continuous visible "
                "target months on each side, and 6-month archive-edge margin"
            ),
        },
        "protocol": {
            "archive_window": ["1980-01", "2015-12"],
            "pool_selection": (
                "pseudo-gap-excluded target standardization; candidates within "
                "1600 km truncated to nearest 200; baseline eligibility within "
                "800 km, overlap >=24 months, r >=0.2; top 8 by r"
            ),
            "same_cohort_definition": (
                "benchmark stations with at least one real missing month"
            ),
            "real_gap_positions": {
                "before": "months before the first visible target month",
                "internal": "missing runs bounded by visible target months",
                "after": "months after the last visible target month",
            },
            "benchmark_comparable_internal": {
                "position": "internal", "length_months": [1, 36],
                "left_continuous_visible_months": MIN_CONTEXT,
                "right_continuous_visible_months": MIN_CONTEXT,
                "archive_edge_margin_months": EDGE_MARGIN,
                "exact_source": "src/data/pseudo_gap.py",
            },
            "standardization_schemes": {
                "structure": (
                    "continent x target-record completeness x gap-length bin x "
                    "five-year period x season; not a same-station match"
                ),
                "same_station_length": (
                    "target station x gap-length bin; direct standardization to "
                    "the pseudo-gap distribution over common cells"
                ),
            },
            "bootstrap": {
                "unit": "target station", "replicates": args.n_boot,
                "seed": args.seed, "interval": "percentile 95%",
            },
        },
        "reproduction": {
            **observed,
            "pseudo_absent_pct": pct(observed["pseudo_absent"], observed["pseudo_n"]),
            "real_absent_pct": pct(observed["real_absent"], observed["real_n"]),
            "ratio": (
                pct(observed["real_absent"], observed["real_n"])
                / pct(observed["pseudo_absent"], observed["pseudo_n"])
            ),
            "difference_pp": (
                pct(observed["real_absent"], observed["real_n"])
                - pct(observed["pseudo_absent"], observed["pseudo_n"])
            ),
            "ratio_ci": ci["real_over_pseudo_ratio"],
            "difference_pp_ci": ci["real_minus_pseudo_pp"],
        },
        "gap_structure": summary_rows,
        "post_record_contribution": {
            "share_of_real_missing_months_pct": after_month_share,
            "share_of_real_unsupported_months_pct": after_absent_share,
        },
        "contrasts": contrast_rows,
        "standardized_comparisons": standards,
        "runtime_seconds": time.time() - t0,
    }
    (HERE / "gap_structure_audit.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    lines = [
        "Gap-structure audit: final context-matched definition",
        "====================================================",
        f"same cohort: {observed['same_stations']} stations",
        (
            f"pseudo: {observed['pseudo_absent']}/{observed['pseudo_n']} "
            f"= {report['reproduction']['pseudo_absent_pct']:.6f}%"
        ),
        (
            f"real: {observed['real_absent']}/{observed['real_n']} "
            f"= {report['reproduction']['real_absent_pct']:.6f}%"
        ),
        (
            f"unadjusted ratio: {report['reproduction']['ratio']:.6f} "
            f"(95% station-cluster CI {ci['real_over_pseudo_ratio']['lo']:.6f}-"
            f"{ci['real_over_pseudo_ratio']['hi']:.6f})"
        ),
        "", "Position and comparability results:",
    ]
    for row in summary_rows:
        lines.append(
            f"{row['gap_group']}: {row['absent_months']}/{row['n_months']} "
            f"= {row['donor_absent_pct']:.6f}% "
            f"(95% CI {row['ci_lo']:.6f}-{row['ci_hi']:.6f})"
        )
    lines += ["", "Standardization sensitivity:"]
    for result in (structure_std, station_length_std):
        lines.append(
            f"{result['scheme']}: pseudo={result['pseudo_absent_pct']:.6f}%, "
            f"real={result['real_absent_pct']:.6f}%, "
            f"difference={result['difference_pp']:.6f} pp, "
            f"ratio={result['ratio']:.6f} "
            f"(95% CI {result['ratio_ci']['lo']:.6f}-"
            f"{result['ratio_ci']['hi']:.6f}), common pseudo share="
            f"{result['pseudo_month_share_in_common_cells_pct']:.3f}%"
        )
    lines += [
        "",
        f"Post-record gaps: {after_month_share:.3f}% of real missing months; "
        f"{after_absent_share:.3f}% of real unsupported months.",
        f"bootstrap seed={args.seed}; replicates={args.n_boot}",
        f"runtime={report['runtime_seconds']:.1f}s",
    ]
    (HERE / "run.log").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (HERE / "CHANGELOG.md").write_text(
        "# Gap-structure audit change log\n\n"
        "The preliminary v1 audit treated every internal run of 1-36 months as "
        "benchmark-comparable. Its key files are retained in v1_length_only/. "
        "The final audit additionally requires 12 continuous visible target "
        "months on each side and the same six-month archive-edge margin used "
        "by src/data/pseudo_gap.py. Length-only estimates remain a labelled "
        "sensitivity result and are not used as the matched headline.\n",
        encoding="utf-8",
    )
    print("\n".join(lines), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", default="evidence_tightening_20260910")
    parser.add_argument("--n-boot", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=20260910)
    run(parser.parse_args())


if __name__ == "__main__":
    main()
