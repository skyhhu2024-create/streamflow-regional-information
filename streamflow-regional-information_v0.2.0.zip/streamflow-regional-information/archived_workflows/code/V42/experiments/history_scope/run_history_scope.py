"""V42 development audit: does the archive window create natural U1 labels?

This audits relation qualification and reference availability, not accuracy.
All input files are read-only. Outputs stay beside this script. Candidate order,
log-seasonal transform, overlap and correlation rules reproduce the V39 audit.
"""
from __future__ import annotations

import hashlib
import json
import sys
import time
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "dependencies"))
import numpy as np
import pandas as pd
import scipy
from scipy.spatial import cKDTree

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding="utf-8")
OUT = Path(__file__).resolve().parent
CODE = OUT.parents[2]
sys.path.insert(0, str(CODE))
from scripts.analyze_review_round2_robustness import (
    chord, correlations, great_circle_km, xyz,
)
from src.data.gsim_io import read_series

REC = CODE / "recoverability"
RAW = CODE / "GSIM_indices/GSIM_indices/TIMESERIES/monthly"
CONDITIONS = CODE / "revision_gap_length_support_20260914/manuscript_v39/analysis/U1_station_failure_conditions.csv"
SOURCES = [CONDITIONS, REC / "ids.npy", REC / "Z.mm",
           CODE / "global_station_meta_kg.csv",
           CODE / "scripts/analyze_review_round2_robustness.py",
           CODE / "src/data/gsim_io.py",
           CODE / "revision_gap_length_support_20260914/manuscript_v39/analysis/analyze_support_task_composition.py"]


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def normalize(raw):
    """Same float32 log/max/monthly-climatology/std transform as prepare_matrix."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        logq = np.log1p(np.maximum(raw, 0)).astype(np.float32)
        logq[~np.isfinite(raw)] = np.nan
        ly = logq.reshape(len(raw), raw.shape[1] // 12, 12)
        climatology = np.nanmean(ly, axis=1)
        anomaly = (ly - climatology[:, None, :]).reshape(raw.shape)
        scale = np.nanstd(anomaly, axis=1)
        scale[scale == 0] = np.nan
        z = anomaly / scale[:, None]
    vis = np.isfinite(z)
    z0 = np.where(vis, z, 0).astype(np.float32)
    return z0, vis


def read_one(sid):
    path = RAW / f"{sid}.mon"
    before = sha256(path)
    no_qc = read_series(str(path), min_days_available=0)
    qc20 = read_series(str(path), min_days_available=20)
    if not no_qc.index.equals(qc20.index):
        raise AssertionError((sid, "QC index changed"))
    if sha256(path) != before:
        raise AssertionError((sid, "raw file changed during read"))
    return sid, no_qc, qc20, {"station_id": sid, "path": str(path.relative_to(CODE)),
                             "bytes": path.stat().st_size, "sha256": before}


def reason(n_target, n_candidates, overlap, corr):
    if n_target < 24:
        return "target_history_lt24"
    if not n_candidates:
        return "no_candidate_within800_after_cap"
    enough = overlap >= 24
    if not enough.any():
        return "all_candidates_overlap_lt24"
    if not (enough & np.isfinite(corr)).any():
        return "overlap_ge24_but_all_correlations_nonfinite"
    return "overlap_ge24_but_no_finite_correlation_ge0_2"


def main():
    began = time.time()
    OUT.mkdir(parents=True, exist_ok=True)
    before = {str(p.relative_to(CODE)): sha256(p) for p in SOURCES}
    targets = pd.read_csv(CONDITIONS).sort_values("station_id").reset_index(drop=True)
    assert len(targets) == 581 and targets.station_id.is_unique
    assert int(targets.U1.sum()) == 237418
    ids = np.load(REC / "ids.npy", allow_pickle=True).astype(str)
    index = {sid: i for i, sid in enumerate(ids)}
    meta = pd.read_csv(CODE / "global_station_meta_kg.csv").rename(columns={"gsim.no": "station_id"})
    meta = meta.set_index("station_id").reindex(ids)
    lat, lon = meta.latitude.to_numpy(float), meta.longitude.to_numpy(float)
    valid_geo = np.isfinite(lat) & np.isfinite(lon)
    vectors = np.full((len(ids), 3), np.nan)
    vectors[valid_geo] = xyz(lat[valid_geo], lon[valid_geo])
    geo_indices = np.flatnonzero(valid_geo)
    tree = cKDTree(vectors[geo_indices])
    candidate_global, geography_rows = {}, []
    selected = {index[sid] for sid in targets.station_id}
    # Reproduce the original 1600-km query and NumPy default distance order.
    # A station-id tiebreak would be an unannounced protocol change.
    for sid in targets.station_id:
        j = index[sid]
        if not valid_geo[j]:
            cand = np.empty(0, dtype=int)
            distance = np.empty(0)
        else:
            cand = geo_indices[np.asarray(tree.query_ball_point(vectors[j], r=chord(1600.)), int)]
            cand = cand[cand != j]
            distance = great_circle_km(vectors[j], vectors[cand])
            keep = distance <= 1600. + 1e-8
            cand, distance = cand[keep], distance[keep]
            near = np.argsort(distance)
            rank = np.empty(len(cand), dtype=int)
            rank[near] = np.arange(len(cand))
            within = (distance <= 800. + 1e-8) & (rank < 200)
            order_distance = distance[near]
            boundary_tie = bool(len(cand) > 200 and order_distance[199] == order_distance[200]
                                and order_distance[199] <= 800. + 1e-8)
            cand, distance = cand[within], distance[within]
        if not valid_geo[j]:
            boundary_tie = False
        candidate_global[sid] = cand
        selected.update(cand.tolist())
        geography_rows.append({"station_id": sid, "candidate_count": len(cand),
                               "exact_distance_ties_in_selected": len(distance) - len(np.unique(distance)),
                               "tie_at_nearest200_boundary": boundary_tie})
    chosen = np.array(sorted(selected), dtype=int)
    chosen_ids = ids[chosen]
    local_index = {sid: i for i, sid in enumerate(chosen_ids)}
    local_for_global = {int(j): i for i, j in enumerate(chosen)}
    candidate_local = {sid: np.array([local_for_global[int(j)] for j in cand], int)
                       for sid, cand in candidate_global.items()}
    edge_rows = [{"target_id": sid, "candidate_id": ids[j], "candidate_sequence": k}
                 for sid, cand in candidate_global.items() for k, j in enumerate(cand)]
    pd.DataFrame(edge_rows).to_csv(OUT / "frozen_candidate_edges.csv", index=False)
    pd.DataFrame(geography_rows).to_csv(OUT / "candidate_geography.csv", index=False)
    stored = np.memmap(REC / "Z.mm", dtype=np.float32, mode="r", shape=(len(ids), 432))[chosen].copy()
    baseline_z0, baseline_vis = normalize(stored)
    baseline_missing = {}
    for row in targets.itertuples(index=False):
        j = local_index[row.station_id]
        assert int(baseline_vis[j].sum()) == row.n_valid, (row.station_id, "baseline valid months")
        n, r = correlations(j, candidate_local[row.station_id], baseline_z0, baseline_vis)
        qualified = (n >= 24) & np.isfinite(r) & (r >= .2)
        assert not qualified.any(), (row.station_id, "baseline U1 not reproduced")
        assert int((~baseline_vis[j]).sum()) == row.U1
        baseline_missing[row.station_id] = ~baseline_vis[j]
    print(f"Baseline reproduced for all 581 U1 targets; reading {len(chosen_ids)} raw station files", flush=True)
    series, receipts = {}, []
    with ThreadPoolExecutor(max_workers=6) as pool:
        jobs = [pool.submit(read_one, sid) for sid in chosen_ids]
        for seq, job in enumerate(as_completed(jobs), 1):
            sid, s0, s20, receipt = job.result()
            series[sid] = (s0, s20)
            receipts.append(receipt)
            if seq % 1000 == 0:
                print(f"Read {seq}/{len(jobs)} raw files; elapsed {time.time()-began:.1f}s", flush=True)
    first_year = min(s[0].index.min().year for s in series.values() if len(s[0]))
    last_year = max(s[0].index.max().year for s in series.values() if len(s[0]))
    calendar = pd.date_range(f"{first_year}-01-01", f"{last_year}-12-01", freq="MS")
    original_time = calendar.get_indexer(pd.date_range("1980-01-01", "2015-12-01", freq="MS"))
    assert np.all(original_time >= 0)
    all0 = np.full((len(chosen_ids), len(calendar)), np.nan, dtype=np.float32)
    all20 = np.full_like(all0, np.nan)
    for sid, (s0, s20) in series.items():
        j = local_index[sid]
        ti = calendar.get_indexer(s0.index)
        assert np.all(ti >= 0)
        all0[j, ti] = s0.to_numpy(np.float32)
        all20[j, ti] = s20.to_numpy(np.float32)
    del series
    raw_window = all0[:, original_time]
    visible_disagreement = np.isfinite(raw_window) != np.isfinite(stored)
    both = np.isfinite(raw_window) & np.isfinite(stored)
    value_disagreement = both & (raw_window != stored)
    max_difference = float(np.max(np.abs(raw_window[both] - stored[both]))) if both.any() else 0.
    # Raw parser lineage is explicitly checked, rather than assuming counts suffice.
    if visible_disagreement.any() or value_disagreement.any():
        raise AssertionError({"raw_window_visibility_disagreements": int(visible_disagreement.sum()),
                              "raw_window_value_disagreements": int(value_disagreement.sum()),
                              "max_abs_difference": max_difference})
    scenarios = [
        ("window_noQC", all0, calendar.year >= 1980, calendar.year <= 2015),
        ("window_QC20", all20, calendar.year >= 1980, calendar.year <= 2015),
        ("history_to2015_noQC", all0, np.ones(len(calendar), bool), calendar.year <= 2015),
        ("history_to2015_QC20", all20, np.ones(len(calendar), bool), calendar.year <= 2015),
        ("full_archive_noQC", all0, np.ones(len(calendar), bool), np.ones(len(calendar), bool)),
        ("full_archive_QC20", all20, np.ones(len(calendar), bool), np.ones(len(calendar), bool)),
    ]
    station_rows, relation_rows, summary_rows = [], [], []
    for scenario, raw, start_mask, end_mask in scenarios:
        fit_ti = np.flatnonzero(start_mask & end_mask)
        local_window = pd.Index(fit_ti).get_indexer(original_time)
        assert np.all(local_window >= 0)
        current_raw = raw[:, fit_ti]
        z0, vis = normalize(current_raw)
        scenario_rows = []
        for row in targets.itertuples(index=False):
            sid, j = row.station_id, local_index[row.station_id]
            cand = candidate_local[sid]
            n, r = correlations(j, cand, z0, vis)
            qualified = (n >= 24) & np.isfinite(r) & (r >= .2)
            q = cand[qualified]
            missing = baseline_missing[sid]
            available = vis[q][:, local_window].any(0) if len(q) else np.zeros(432, bool)
            supported = int((missing & available).sum())
            absent = int((missing & ~available).sum())
            n_valid = int(vis[j].sum())
            why = "qualified_relation" if len(q) else reason(n_valid, len(cand), n, r)
            result = {"scenario": scenario, "station_id": sid, "continent": row.continent,
                      "original_reason": row.reason, "original_window_n_valid": int(row.n_valid),
                      "original_U1_months": int(row.U1), "target_raw_fit_months": int(np.isfinite(current_raw[j]).sum()),
                      "target_standardized_fit_months": n_valid,
                      "candidate_count": len(cand), "qualified_relations": int(len(q)),
                      "max_candidate_overlap": int(n.max()) if len(n) else 0,
                      "new_reason": why, "original_gap_months_with_reference": supported,
                      "original_gap_months_U1": absent if not len(q) else 0,
                      "original_gap_months_U2": absent if len(q) else 0}
            assert result["original_gap_months_U1"] + result["original_gap_months_U2"] + supported == row.U1
            scenario_rows.append(result)
            if len(q):
                order = np.flatnonzero(qualified)[np.argsort(-r[qualified])]
                for rank, k in enumerate(order, 1):
                    relation_rows.append({"scenario": scenario, "target_id": sid,
                                          "reference_id": chosen_ids[cand[k]], "correlation_rank": rank,
                                          "overlap_months": int(n[k]), "correlation": float(r[k])})
        frame = pd.DataFrame(scenario_rows)
        station_rows.extend(scenario_rows)
        for subgroup, group in [("all_original_U1", frame),
                                ("original_window_history_lt24", frame.loc[frame.original_window_n_valid.lt(24)]),
                                ("original_window_history_ge24", frame.loc[frame.original_window_n_valid.ge(24)])]:
            total = int(group.original_U1_months.sum())
            qualified = group.qualified_relations.gt(0)
            summary_rows.append({"scenario": scenario, "subgroup": subgroup,
                                 "target_stations": len(group), "original_U1_months": total,
                                 "targets_with_qualified_relation": int(qualified.sum()),
                                 "original_months_at_newly_qualified_targets": int(group.loc[qualified, "original_U1_months"].sum()),
                                 "original_gap_months_with_reference": int(group.original_gap_months_with_reference.sum()),
                                 "original_gap_months_U1": int(group.original_gap_months_U1.sum()),
                                 "original_gap_months_U2": int(group.original_gap_months_U2.sum())})
        print(f"{scenario}: {int(frame.qualified_relations.gt(0).sum())}/581 targets qualify; "
              f"{int(frame.original_gap_months_with_reference.sum())}/237418 original gap months have a reference", flush=True)
    station_frame = pd.DataFrame(station_rows)
    baseline = station_frame.loc[station_frame.scenario.eq("window_noQC")]
    assert int(baseline.qualified_relations.sum()) == 0
    assert int(baseline.original_gap_months_U1.sum()) == 237418
    station_frame.to_csv(OUT / "station_history_scope.csv", index=False)
    pd.DataFrame(summary_rows).to_csv(OUT / "history_scope_summary.csv", index=False)
    pd.DataFrame(relation_rows).to_csv(OUT / "qualified_reference_relations.csv", index=False)
    after = {str(p.relative_to(CODE)): sha256(p) for p in SOURCES}
    assert before == after, "A source file changed"
    manifest = {"version": "V42-history-scope-development-1", "created_utc": datetime.now(timezone.utc).isoformat(),
                "status": "DEVELOPMENT_AUDIT_NOT_R4_VALIDATION", "elapsed_seconds": time.time()-began,
                "natural_target_stations": 581, "original_U1_months": 237418,
                "candidate_universe_stations": len(ids), "raw_files_read": len(chosen_ids),
                "full_calendar": [str(calendar[0].date()), str(calendar[-1].date())],
                "original_window": ["1980-01", "2015-12"],
                "primary_history_cutoff": "2015-12", "post2015": "Separate full-archive sensitivity only",
                "rules": {"radius_km": 800, "cap_nearest": 200, "overlap_months": 24, "min_correlation": .2,
                          "candidate_order": "Frozen source 1600km cKDTree query, NumPy default distance argsort",
                          "transform": "float32 log1p(max(Q,0)), allowed-scope monthly climatology and station anomaly std",
                          "QC20": "Official read_series min_days_available=20"},
                "checks": {"baseline_all581_reproduced": True, "baseline_months_reproduced": True,
                           "raw_window_visibility_disagreements": int(visible_disagreement.sum()),
                           "raw_window_value_disagreements": int(value_disagreement.sum()),
                           "sources_unchanged": before == after,
                           "target_gap_values_used": False, "reconstruction_accuracy_measured": False},
                "limitations": ["Only original 581 U1 targets; not a new global decomposition.",
                                "Qualification changes include refitting the seasonal transform on the expanded scope.",
                                "Existing outside-window observations are already archived, not a new monitoring intervention.",
                                "Reference presence is an intermediate endpoint, not skill, annual-water accuracy or causal benefit.",
                                "Original source does not specify deterministic tiebreaks at equal distance; edges are saved.",
                                "Retrospective archive sensitivity; not a prospective decision or independent holdout."],
                "source_hashes_before": before, "source_hashes_after": after,
                "raw_file_receipts": sorted(receipts, key=lambda x: x["station_id"]),
                "software": {"python": sys.version, "numpy": np.__version__, "pandas": pd.__version__,
                             "scipy": scipy.__version__, "dependency_location": "code/V42/dependencies",
                             "script_sha256": sha256(Path(__file__))}}
    write_json(OUT / "run_manifest.json", manifest)
    print(json.dumps({"status": manifest["status"], "elapsed_seconds": round(manifest["elapsed_seconds"], 1),
                      "output": str(OUT)}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
