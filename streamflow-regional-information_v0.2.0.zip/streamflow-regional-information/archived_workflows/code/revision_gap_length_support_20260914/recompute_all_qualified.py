"""Re-evaluate frozen real/pseudo samples using every qualified reference.

No masks, eligibility thresholds, observations or reconstruction outputs change.
The fixed-eight state is reproduced month by month before removing that cap.
"""
from __future__ import annotations

import importlib.util
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
LEGACY = ROOT / 'revision_evidence_tightening_20260910/audits/gap_structure'
OUT = HERE / 'revision_20260916/analysis'
OUT.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location('gap_audit', LEGACY / 'run_gap_structure_audit.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)


def summarize(months, unit='station', n_boot=2000):
    blocks = []
    selectors = {
        'pseudo': months.gap_type.eq('pseudo'),
        'real_all': months.gap_type.eq('real'),
        'real_before': months.gap_type.eq('real') & months.position.eq('before'),
        'real_internal': months.gap_type.eq('real') & months.position.eq('internal'),
        'real_after': months.gap_type.eq('real') & months.position.eq('after'),
        'real_internal_le36_length_only': months.gap_type.eq('real') & months.length_only_comparable.eq(1),
        'real_benchmark_comparable': months.gap_type.eq('real') & months.benchmark_comparable.eq(1),
    }
    sid = 'station_id' if unit == 'station' else 'spatial_block'
    for metric, mask in selectors.items():
        f = months.loc[mask].groupby(sid).agg(n=('donor_absent','size'), absent=('donor_absent','sum')).reset_index()
        f = f.rename(columns={sid:'station_id'})
        f['metric'] = metric
        blocks.append(f)
    counts = pd.concat(blocks, ignore_index=True)
    comp = months.loc[selectors['pseudo'] | selectors['real_benchmark_comparable']].copy()
    comp['gap_type'] = comp.gap_type.replace({'real':'real_benchmark_comparable'})
    strata = ['continent','record_bin','gap_length_bin','era5','season']
    schemes = {}
    for name, fields in [('structure',strata), ('same_station_length',['station_id','gap_length_bin'])]:
        comp['cell'] = comp[fields].astype(str).agg('|'.join, axis=1)
        f = comp.groupby([sid,'gap_type','cell']).agg(n=('donor_absent','size'), absent=('donor_absent','sum')).reset_index()
        schemes[name] = f.rename(columns={sid:'station_id'})
    boot, ci = old.cluster_bootstrap(counts, schemes, n_boot=n_boot, seed=20260916)
    standards = {}
    for name, fields in [('structure',strata),('same_station_length',['station_id','gap_length_bin'])]:
        result, totals = old.build_standardization(schemes[name], fields, name, ci)
        if unit == 'spatial_block':
            # The reused helper calls its clustering identifier station_id.
            # Here those identifiers are spatial blocks, not gauge counts.
            for kind in ['pseudo', 'real']:
                result[f'{kind}_spatial_blocks_in_common_cells'] = result.pop(f'{kind}_stations_in_common_cells')
        standards[name] = result
        totals.to_csv(OUT/f'{unit}_{name}_cells.csv',index=False)
        schemes[name].to_csv(OUT/f'{unit}_{name}_cluster_cells.csv',index=False)
    summary = []
    for metric, mask in selectors.items():
        f = months.loc[mask]
        n, absent = len(f), int(f.donor_absent.sum())
        interval = ci[f'{metric}_absent_pct']
        summary.append({'group':metric,'n_stations':int(f.station_id.nunique()),'n_months':n,
                        'absent_months':absent,'estimate_pct':old.pct(absent,n),
                        'ci_lo':interval['lo'],'ci_hi':interval['hi']})
    frame = pd.DataFrame(summary)
    look = frame.set_index('group')
    a, b = look.loc['real_all'], look.loc['pseudo']
    raw = {'same_stations':int(months.station_id.nunique()), 'real_n':int(a.n_months),
           'pseudo_n':int(b.n_months),'real_absent':int(a.absent_months),'pseudo_absent':int(b.absent_months),
           'real_absent_pct':float(a.estimate_pct),'pseudo_absent_pct':float(b.estimate_pct),
           'ratio':float(a.estimate_pct/b.estimate_pct),'difference_pp':float(a.estimate_pct-b.estimate_pct),
           'ratio_ci':ci['real_over_pseudo_ratio'],'difference_pp_ci':ci['real_minus_pseudo_pp']}
    report = {'bootstrap_unit':unit,'bootstrap_replicates':n_boot,'n_clusters':int(counts.station_id.nunique()),
              'reproduction':raw,'standardized_comparisons':standards,'gap_structure':summary}
    boot.to_csv(OUT/f'{unit}_bootstrap.csv',index=False)
    frame.to_csv(OUT/f'{unit}_gap_structure_summary.csv',index=False)
    counts.to_csv(OUT/f'{unit}_metric_counts.csv',index=False)
    (OUT/f'{unit}_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    return report


def run():
    started = time.time()
    months = pd.read_csv(LEGACY/'same_cohort_gap_months.csv')
    ids = np.load(ROOT/'recoverability/ids.npy',allow_pickle=True).astype(str)
    index = {s:i for i,s in enumerate(ids)}
    raw, _, z0, vis = old.prepare_matrix(ids)
    meta = pd.read_csv(ROOT/'global_station_meta_kg.csv').set_index('gsim.no').reindex(ids)
    lat, lon = meta.latitude.to_numpy(float), meta.longitude.to_numpy(float)
    good = np.isfinite(lat)&np.isfinite(lon)
    vectors = np.full((len(ids),3),np.nan)
    vectors[good] = old.xyz(lat[good],lon[good])
    tree_idx = np.flatnonzero(good)
    tree = cKDTree(vectors[tree_idx])
    states = np.zeros((len(ids),432),dtype=np.uint8)
    fixed_available = np.zeros((len(ids),432),dtype=bool)
    info = []
    # All pseudo masks are taken from the original output, including stations
    # with no real missing months; only the original common cohort is scored.
    pseudo = pd.read_csv(ROOT/'results/raw/stratified_idw/predictions_long.csv',usecols=['station_id','date']).drop_duplicates()
    dates = pd.to_datetime(pseudo.date)
    pseudo['t'] = (dates.dt.year-1980)*12+dates.dt.month-1
    masks = {s:g.t.to_numpy(int) for s,g in pseudo.groupby('station_id')}
    stations = sorted(months.station_id.unique())
    for seq,sid in enumerate(stations,1):
        j=index[sid]
        target_z,target_vis=old.strict_target_standardize(raw[j],masks[sid])
        cand=tree_idx[np.asarray(tree.query_ball_point(vectors[j],r=old.chord(1600.)),dtype=int)]
        cand=cand[cand!=j]
        distance=old.great_circle_km(vectors[j],vectors[cand])
        keep=distance<=1600.+1e-8
        cand,distance=cand[keep],distance[keep]
        if len(cand)>200:
            nearest=np.argsort(distance)[:200]
            cand,distance=cand[nearest],distance[nearest]
        overlap,corr=old.correlations(j,cand,z0,vis,target_z=target_z,target_vis=target_vis)
        eligible=np.flatnonzero((distance<=800.+1e-8)&(overlap>=24)&np.isfinite(corr)&(corr>=.2))
        eligible=eligible[np.argsort(-corr[eligible])]
        selected=cand[eligible]
        top=vis[selected[:8]].any(0) if len(selected) else np.zeros(432,bool)
        available=vis[selected].any(0) if len(selected) else np.zeros(432,bool)
        fixed_available[j]=top
        # 0 supported top-eight; 1 no qualified relation; 2 all qualified silent;
        # 3 qualified observation below fixed rank eight.
        states[j]=np.where(top,0,np.where(available,3,2 if len(selected) else 1))
        info.append({'station_id':sid,'n_qualified':len(selected),
                     'spatial_block':f'{int(np.floor(lat[j]/5))}|{int(np.floor(lon[j]/5))}'})
        if seq%250==0:print(f'[all-qualified] {seq}/{len(stations)} {time.time()-started:.1f}s',flush=True)
    rows=months.station_id.map(index).to_numpy(int)
    tt=months.t.to_numpy(int)
    original=months.donor_absent.to_numpy(int)
    assert np.array_equal(original,(~fixed_available[rows,tt]).astype(int)), 'Frozen fixed-eight definition not reproduced'
    months['fixed8_absent']=original
    months['support_state']=states[rows,tt]
    months['donor_absent']=np.isin(months.support_state,[1,2]).astype(int)
    assert (months.donor_absent<=months.fixed8_absent).all()
    months=months.merge(pd.DataFrame(info),on='station_id',validate='many_to_one')
    assert len(months)==450490+85273 and months.station_id.nunique()==2725
    old_counts=months.groupby('gap_type').fixed8_absent.sum().to_dict()
    assert old_counts=={'pseudo':566,'real':97303},old_counts
    months.to_csv(OUT/'all_qualified_gap_months.csv',index=False)
    pd.DataFrame(info).to_csv(OUT/'qualified_station_information.csv',index=False)
    decomposition=months.groupby(['gap_type','support_state']).agg(months=('t','size'),stations=('station_id','nunique')).reset_index()
    decomposition.to_csv(OUT/'real_pseudo_support_decomposition.csv',index=False)
    for unit in ['station','spatial_block']:
        result=summarize(months,unit)
        print(unit,json.dumps(result['reproduction']),flush=True)
        print('standardized',json.dumps(result['standardized_comparisons']['structure']),flush=True)
    (OUT/'recompute_provenance.json').write_text(json.dumps({'input_months':str(LEGACY/'same_cohort_gap_months.csv'),
        'fixed8_reproduced_month_by_month':True,'fixed8_counts':old_counts,
        'changed':'Remove only top-eight truncation; all other qualification and sampling rules unchanged',
        'runtime_seconds':time.time()-started},indent=2),encoding='utf-8')


if __name__=='__main__':run()
