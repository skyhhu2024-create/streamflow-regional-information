"""Read-only source audit for v39 task composition and qualification sensitivity.

Only this script's directory receives outputs. No old analysis main is invoked.
CSV files are scientific analysis intermediates; no workbook is authored.
"""
from __future__ import annotations

import hashlib
import json
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
sys.path.insert(0, str(ROOT))
from scripts.analyze_review_round2_robustness import (
    chord, correlations, great_circle_km, prepare_matrix, xyz,
)

REC = ROOT / "recoverability"
REV = REC / "review_round2"
TAG = "strict_calibration_20260831_v3"
OLD = ROOT / "revision_evidence_tightening_20260910/audits/unsupported_decomposition"
PRIOR = ROOT / "revision_gap_length_support_20260914/revision_20260916/analysis"
SOURCES = {
    "matrix": REC / "Z.mm",
    "ids": REC / "ids.npy",
    "metadata": ROOT / "global_station_meta_kg.csv",
    "baseline": REV / f"baseline_exact_stations_{TAG}.csv",
    "active": REV / f"global_recoverability_strict_{TAG}.csv",
    "edges": REV / f"baseline_pool_edges_{TAG}.csv",
    "old_station": OLD / "station_decomposition.csv",
    "old_global": OLD / "global_decomposition.csv",
    "old_continent": OLD / "continent_decomposition.csv",
    "events": ROOT / "revision_gap_length_support_20260914/source_data/observed_gap_events.csv",
    "sensitivity_station": PRIOR / "all_qualified_sensitivity_stations.csv",
    "sensitivity_table": PRIOR / "TableS29_all_qualified_sensitivity.csv",
    "matrix_helper": ROOT / "scripts/analyze_review_round2_robustness.py",
    "original_decomposition_code": OLD / "run_unsupported_decomposition.py",
    "original_sensitivity_code": ROOT / "revision_gap_length_support_20260914/check_all_qualified_sensitivity.py",
}
CASES = [
    ("Baseline", 800., 200, 24, .2),
    ("Radius 400 km", 400., 200, 24, .2),
    ("Radius 1200 km", 1200., 200, 24, .2),
    ("Nearest 50 candidates", 800., 50, 24, .2),
    ("All candidates within 800 km", 800., None, 24, .2),
    ("Overlap 12 months", 800., 200, 12, .2),
    ("Overlap 60 months", 800., 200, 60, .2),
    ("Correlation 0.1", 800., 200, 24, .1),
    ("Correlation 0.4", 800., 200, 24, .4),
]
POSITIONS = ["before", "internal", "after"]
CATS = ["S", "U1", "U2", "U3"]
EXPECTED = {"n_missing": 4598259, "S": 3402232, "U1": 237418, "U2": 373861, "U3": 584748}


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def pct(x, n):
    return 100. * x / n if n else np.nan


def records(frame):
    return json.loads(frame.to_json(orient="records"))


def output_csv(frame, name):
    frame.to_csv(OUT / name, index=False)


def aggregate_positions(frame, scope):
    rows = []
    groups = [("Global", frame)] if scope == "global" else list(frame.groupby("continent", dropna=False))
    for region, region_data in groups:
        region_missing = int(region_data.n_missing.sum())
        region_unsupported = int(region_data.unsupported.sum())
        for pos in [*POSITIONS, "all"]:
            g = region_data if pos == "all" else region_data.loc[region_data.position.eq(pos)]
            n = int(g.n_missing.sum())
            row = {"region": region, "position": pos, "n_missing": n,
                   "gap_events": int(g.gap_events.sum()),
                   "n_gauges_with_missing": int(g.loc[g.n_missing.gt(0), "station_id"].nunique()),
                   "region_total_missing": region_missing,
                   "position_share_of_region_missing_pct": pct(n, region_missing)}
            for c in [*CATS, "supported", "unsupported"]:
                row[c] = int(g[c].sum())
                row[f"{c}_pct_of_position_missing"] = pct(row[c], n)
                row[f"{c}_n_gauges"] = int(g.loc[g[c].gt(0), "station_id"].nunique())
            row["U1_share_of_unsupported_pct"] = pct(row["U1"], row["unsupported"])
            row["U2_share_of_unsupported_pct"] = pct(row["U2"], row["unsupported"])
            row["unsupported_share_of_region_unsupported_pct"] = pct(row["unsupported"], region_unsupported)
            rows.append(row)
    return pd.DataFrame(rows)


def sensitivity_summary(frame):
    rows = []
    for subset, g0 in [("all_incomplete_gauges", frame), ("target_n_valid_ge24", frame.loc[frame.n_valid.ge(24)]),
                       ("target_n_valid_lt24", frame.loc[frame.n_valid.lt(24)])]:
        for scenario, g1 in g0.groupby("scenario", sort=False):
            for region, g in [("Global", g1), *list(g1.groupby("continent", dropna=False))]:
                n, u1, u2 = [int(g[c].sum()) for c in ["n_missing", "U1", "U2"]]
                rows.append({"subset": subset, "scenario": scenario, "region": region,
                             "n_gauges": len(g), "n_missing": n,
                             "U1": u1, "U2": u2, "unsupported": u1 + u2,
                             "supported": n - u1 - u2,
                             "U1_pct": pct(u1, n), "U2_pct": pct(u2, n),
                             "unsupported_pct": pct(u1 + u2, n),
                             "U1_share_of_unsupported_pct": pct(u1, u1 + u2),
                             "U2_share_of_unsupported_pct": pct(u2, u1 + u2),
                             "dominant_unsupported_component": "U1" if u1 > u2 else "U2" if u2 > u1 else "equal",
                             "U1_gauges": int(g.U1.gt(0).sum()), "U2_gauges": int(g.U2.gt(0).sum())})
    result = pd.DataFrame(rows)
    baseline = result.loc[result.scenario.eq("Baseline"), ["subset", "region", "unsupported_pct", "U1_share_of_unsupported_pct"]]
    baseline = baseline.rename(columns={c: f"baseline_{c}" for c in ["unsupported_pct", "U1_share_of_unsupported_pct"]})
    result = result.merge(baseline, on=["subset", "region"], validate="many_to_one")
    result["unsupported_delta_from_baseline_pp"] = result.unsupported_pct - result.baseline_unsupported_pct
    result["U1_composition_delta_from_baseline_pp"] = result.U1_share_of_unsupported_pct - result.baseline_U1_share_of_unsupported_pct
    return result


def main():
    began = time.time()
    hashes_before = {str(p.relative_to(ROOT)): sha256(p) for p in SOURCES.values()}
    ids = np.load(SOURCES["ids"], allow_pickle=True).astype(str)
    index = {s: i for i, s in enumerate(ids)}
    raw, z, z0, vis = prepare_matrix(ids)
    del z
    meta = pd.read_csv(SOURCES["metadata"]).rename(columns={"gsim.no": "station_id"}).set_index("station_id").reindex(ids)
    active = pd.read_csv(SOURCES["active"])
    old_station = pd.read_csv(SOURCES["old_station"]).set_index("gsim_no")
    baseline = pd.read_csv(SOURCES["baseline"]).set_index("gsim_no")
    edges = pd.read_csv(SOURCES["edges"])
    pools = {str(s): np.array([index[str(x)] for x in g.sort_values("donor_rank").donor_id], int)
             for s, g in edges.groupby("target_id", sort=False)}
    target_ids = active.gsim_no.astype(str).tolist()
    assert len(target_ids) == len(set(target_ids)) == 24934
    assert set(target_ids) == set(old_station.index)
    active_indices = np.array([index[s] for s in target_ids], int)
    assert np.array_equal(np.isfinite(raw[active_indices]), vis[active_indices]), "Raw/standardized visibility differs"
    n_valid = vis.sum(1).astype(int)
    assert np.all(n_valid[active_indices] > 0)
    lat, lon = meta.latitude.to_numpy(float), meta.longitude.to_numpy(float)
    spatial_ok = np.isfinite(lat) & np.isfinite(lon)
    vectors = np.full((len(ids), 3), np.nan)
    vectors[spatial_ok] = xyz(lat[spatial_ok], lon[spatial_ok])
    tree_indices = np.flatnonzero(spatial_ok)
    tree = cKDTree(vectors[tree_indices])
    sensitivity = pd.read_csv(SOURCES["sensitivity_station"])
    assert not sensitivity.duplicated(["scenario", "station_id"]).any()
    sensitivity_ref = sensitivity.set_index(["scenario", "station_id"])
    events = pd.read_csv(SOURCES["events"])
    event_counts = events.groupby(["station_id", "position"]).agg(n_missing=("gap_length", "sum"), gap_events=("gap_id", "size"))
    assert len(events.gap_id) == events.gap_id.nunique()
    station_rows, pos_rows, u1_rows, eligibility_differences, pool_differences = [], [], [], [], []
    scenario_pos = defaultdict(lambda: np.zeros(5, dtype=np.int64))
    counts = {"eligible_station_mismatches": 0, "old_station_mismatches": 0,
              "gap_event_position_mismatches": 0, "sensitivity_station_rows_checked": 0,
              "sensitivity_station_mismatches": 0}
    tt = np.arange(432)
    for seq, sid in enumerate(target_ids, 1):
        j = index[sid]
        observed = vis[j]
        missing = ~observed
        nm = int(missing.sum())
        first, last = np.flatnonzero(observed)[[0, -1]]
        position_masks = [missing & (tt < first), missing & (tt > first) & (tt < last), missing & (tt > last)]
        continent = str(meta.loc[sid, "continent"])
        country = meta.loc[sid, "country"]
        if spatial_ok[j]:
            cand = tree_indices[np.asarray(tree.query_ball_point(vectors[j], r=chord(1600.)), int)]
            cand = cand[cand != j]
            distance = great_circle_km(vectors[j], vectors[cand])
            keep = distance <= 1600. + 1e-8
            cand, distance = cand[keep], distance[keep]
            near = np.argsort(distance)
            rank = np.empty(len(cand), int)
            rank[near] = np.arange(len(cand))
            keep = (distance <= 800. + 1e-8) | (rank < 200)
            cand, distance, rank = cand[keep], distance[keep], rank[keep]
            overlap, corr = correlations(j, cand, z0, vis)
        else:
            cand = np.array([], int)
            distance = overlap = corr = np.array([], float)
            rank = np.array([], int)
        within = (distance <= 800. + 1e-8) & (rank < 200)
        enough_overlap = within & (overlap >= 24)
        finite_corr = enough_overlap & np.isfinite(corr)
        qualified = finite_corr & (corr >= .2)
        eligible = cand[qualified]
        stored_n_eligible = int(baseline.loc[sid, "n_elig"])
        if len(eligible) != stored_n_eligible:
            counts["eligible_station_mismatches"] += 1
            eligibility_differences.append({"station_id": sid, "n_missing": nm,
                                           "stored_baseline_n_eligible": stored_n_eligible,
                                           "rebuilt_n_eligible": len(eligible),
                                           "existing_sensitivity_baseline_n_qualified": int(sensitivity_ref.loc[("Baseline", sid), "n_qualified"]) if nm else np.nan})
        # The frozen script skipped candidate discovery below its minimum
        # tested overlap (12 months), storing n_cand=0. Rebuilt diagnostic
        # candidate counts for these gauges are useful but are not identical
        # to that intentional early-exit sentinel.
        if n_valid[j] >= 12:
            assert int(within.sum()) == int(baseline.loc[sid, "n_cand"]), (sid, "candidate count")
        else:
            assert int(baseline.loc[sid, "n_cand"]) == 0
        pool = pools.get(sid, np.array([], int))
        outside = list(set(pool) - set(eligible))
        for donor in outside:
            pool_differences.append({"station_id": sid, "stored_top8_donor": ids[donor],
                                     "n_missing": nm})
        fixed = vis[pool].any(0) if len(pool) else np.zeros(432, bool)
        all_available = vis[eligible].any(0) if len(eligible) else np.zeros(432, bool)
        assert not (missing & fixed & ~all_available).any(), (sid, "stored fixed pool supports a currently unsupported month")
        masks = {"S": missing & fixed,
                 "U1": missing & ~all_available if not len(eligible) else np.zeros(432, bool),
                 "U2": missing & ~all_available if len(eligible) else np.zeros(432, bool),
                 "U3": missing & ~fixed & all_available}
        row = {"station_id": sid, "continent": continent, "country": country,
               "n_valid": int(n_valid[j]), "n_missing": nm, "n_qualified": len(eligible),
               "stored_baseline_n_qualified": stored_n_eligible,
               **{c: int(masks[c].sum()) for c in CATS}}
        row["supported"], row["unsupported"] = row["S"] + row["U3"], row["U1"] + row["U2"]
        assert sum(row[c] for c in CATS) == nm
        for c in ["n_valid", "n_missing", *CATS]:
            assert row[c] == int(old_station.loc[sid, c]), (sid, c, row[c], old_station.loc[sid, c])
        station_rows.append(row)
        for p, p_mask in zip(POSITIONS, position_masks):
            starts = np.flatnonzero(np.diff(np.r_[False, p_mask, False].astype(np.int8)) == 1)
            npos, nevents = int(p_mask.sum()), len(starts)
            source_event = event_counts.loc[(sid, p)] if (sid, p) in event_counts.index else {"n_missing": 0, "gap_events": 0}
            assert npos == source_event["n_missing"] and nevents == source_event["gap_events"], (sid, p)
            pos_row = {"station_id": sid, "continent": continent, "country": country,
                       "n_valid": int(n_valid[j]), "n_qualified": len(eligible), "position": p,
                       "n_missing": npos, "gap_events": nevents,
                       **{c: int((masks[c] & p_mask).sum()) for c in CATS}}
            pos_row["supported"] = pos_row["S"] + pos_row["U3"]
            pos_row["unsupported"] = pos_row["U1"] + pos_row["U2"]
            pos_rows.append(pos_row)
        if row["U1"]:
            if n_valid[j] < 24:
                reason = "target_history_lt24"
            elif not spatial_ok[j]:
                reason = "missing_target_coordinates"
            elif not within.any():
                reason = "no_candidate_within800_after_cap"
            elif not enough_overlap.any():
                reason = "all_candidates_overlap_lt24"
            elif not finite_corr.any():
                reason = "overlap_ge24_but_all_correlations_nonfinite"
            else:
                reason = "overlap_ge24_but_no_finite_correlation_ge0_2"
            u1_rows.append({**row, "reason": reason, "has_target_coordinates": bool(spatial_ok[j]),
                            "all_candidates_within800": int((distance <= 800. + 1e-8).sum()),
                            "baseline_candidates_within800": int(within.sum()),
                            "candidates_overlap_ge24": int(enough_overlap.sum()),
                            "candidates_overlap_ge24_finite_corr": int(finite_corr.sum()),
                            "max_candidate_overlap_months": int(overlap[within].max()) if within.any() else np.nan,
                            "max_corr_among_overlap_ge24": float(corr[finite_corr].max()) if finite_corr.any() else np.nan,
                            "short_history_is_sufficient_not_unique_failure_condition": bool(n_valid[j] < 24)})
        if nm:
            for name, radius, cap, min_overlap, min_corr in CASES:
                q = (distance <= radius + 1e-8) & (overlap >= min_overlap) & np.isfinite(corr) & (corr >= min_corr)
                if cap is not None:
                    q &= rank < cap
                selected = cand[q]
                available = vis[selected].any(0) if len(selected) else np.zeros(432, bool)
                absent = missing & ~available
                a = int(absent.sum())
                u1, u2 = (a, 0) if not len(selected) else (0, a)
                ref = sensitivity_ref.loc[(name, sid)]
                for field, value in [("n_missing", nm), ("n_qualified", len(selected)), ("U1", u1), ("U2", u2), ("unsupported", a)]:
                    assert int(ref[field]) == value, (name, sid, field, ref[field], value)
                counts["sensitivity_station_rows_checked"] += 1
                for p, p_mask in zip(POSITIONS, position_masks):
                    npos, apos = int(p_mask.sum()), int((p_mask & absent).sum())
                    u1p, u2p = (apos, 0) if not len(selected) else (0, apos)
                    for subset in ["all_incomplete_gauges", "target_n_valid_ge24" if n_valid[j] >= 24 else "target_n_valid_lt24"]:
                        for region in ["Global", continent]:
                            scenario_pos[(subset, name, region, p)] += [npos, u1p, u2p, int(npos > 0), int(apos > 0)]
        if seq % 2500 == 0:
            print(f"{seq:,}/{len(target_ids):,} gauges checked; {time.time()-began:.1f}s", flush=True)

    station = pd.DataFrame(station_rows)
    positions = pd.DataFrame(pos_rows)
    u1 = pd.DataFrame(u1_rows)
    for c, expected in EXPECTED.items():
        assert int(station[c].sum()) == expected, (c, station[c].sum(), expected)
    assert len(station.loc[station.n_missing.gt(0)]) == 22934
    assert len(u1) == 581
    assert int(u1.loc[u1.n_valid.lt(24), "U1"].sum()) == 230262
    assert int(u1.n_valid.lt(24).sum()) == 556
    assert int(positions.loc[positions.position.eq("internal"), "n_missing"].sum()) == 563059
    assert counts["sensitivity_station_rows_checked"] == len(sensitivity)
    reconstructed_events = int(positions.gap_events.sum())
    assert reconstructed_events == len(events)
    global_pos = aggregate_positions(positions, "global")
    region_pos = aggregate_positions(positions, "continent")
    old_continent = pd.read_csv(SOURCES["old_continent"])
    for r in old_continent.itertuples(index=False):
        assert int(region_pos.loc[region_pos.region.eq(r.region) & region_pos.position.eq("all"), r.category].iloc[0]) == int(r.station_months)
    for r in pd.read_csv(SOURCES["old_global"]).itertuples(index=False):
        assert int(station[r.category].sum()) == int(r.station_months)
    sensitivity = sensitivity.merge(station[["station_id", "continent", "n_valid"]], on="station_id", validate="many_to_one")
    regional_sensitivity = sensitivity_summary(sensitivity)
    table = pd.read_csv(SOURCES["sensitivity_table"]).set_index("scenario")
    check_global = regional_sensitivity.loc[regional_sensitivity.subset.eq("all_incomplete_gauges") & regional_sensitivity.region.eq("Global")].set_index("scenario")
    for c in ["n_gauges", "n_missing", "U1", "U2", "unsupported"]:
        assert np.array_equal(table[c], check_global.reindex(table.index)[c]), c
    for c in ["U1_pct", "U2_pct", "unsupported_pct"]:
        assert np.allclose(table[c], check_global.reindex(table.index)[c], rtol=0, atol=1e-12), c
    scenario_position_rows = []
    for (subset, scenario, region, position), values in scenario_pos.items():
        n, u1c, u2c, ng, nug = [int(x) for x in values]
        scenario_position_rows.append({"subset": subset, "scenario": scenario, "region": region, "position": position,
                                       "n_missing": n, "U1": u1c, "U2": u2c, "unsupported": u1c + u2c,
                                       "supported": n - u1c - u2c, "n_gauges_with_missing": ng,
                                       "n_gauges_with_unsupported": nug, "U1_pct": pct(u1c, n), "U2_pct": pct(u2c, n),
                                       "unsupported_pct": pct(u1c + u2c, n), "U1_share_of_unsupported_pct": pct(u1c, u1c + u2c)})
    scenario_position = pd.DataFrame(scenario_position_rows)
    sp_sum = scenario_position.groupby(["subset", "scenario", "region"])[["n_missing", "U1", "U2", "unsupported", "supported"]].sum().sort_index()
    sr = regional_sensitivity.set_index(["subset", "scenario", "region"])[sp_sum.columns].reindex(sp_sum.index)
    assert np.array_equal(sp_sum, sr)
    reasons = []
    for region, g0 in [("Global", u1), *list(u1.groupby("continent"))]:
        total = int(g0.U1.sum())
        for reason, g in g0.groupby("reason", sort=False):
            amount = int(g.U1.sum())
            reasons.append({"region": region, "reason": reason, "n_gauges": len(g), "U1_months": amount,
                            "region_U1_months": total, "share_of_region_U1_pct": pct(amount, total)})
    reason_summary = pd.DataFrame(reasons)
    sensitivity_range = regional_sensitivity.groupby(["subset", "region"]).agg(
        unsupported_min_pct=("unsupported_pct", "min"), unsupported_max_pct=("unsupported_pct", "max"),
        U1_share_min_pct=("U1_share_of_unsupported_pct", "min"), U1_share_max_pct=("U1_share_of_unsupported_pct", "max"),
        U1_dominant_rule_count=("dominant_unsupported_component", lambda s: int(s.eq("U1").sum())),
        U2_dominant_rule_count=("dominant_unsupported_component", lambda s: int(s.eq("U2").sum())),
        evaluated_rules=("scenario", "size")).reset_index()
    output_csv(station, "station_support_reproduction.csv")
    output_csv(positions, "station_position_support_counts.csv")
    output_csv(global_pos, "global_position_support.csv")
    output_csv(region_pos, "regional_position_support.csv")
    output_csv(u1, "U1_station_failure_conditions.csv")
    output_csv(reason_summary, "U1_failure_condition_summary.csv")
    output_csv(regional_sensitivity, "regional_rule_sensitivity.csv")
    output_csv(sensitivity_range, "regional_rule_sensitivity_ranges.csv")
    output_csv(scenario_position, "regional_position_rule_sensitivity.csv")
    output_csv(pd.DataFrame(eligibility_differences, columns=["station_id", "n_missing", "stored_baseline_n_eligible", "rebuilt_n_eligible", "existing_sensitivity_baseline_n_qualified"]), "baseline_eligibility_count_differences.csv")
    output_csv(pd.DataFrame(pool_differences, columns=["station_id", "stored_top8_donor", "n_missing"]), "stored_pool_eligibility_differences.csv")
    hashes_after = {str(p.relative_to(ROOT)): sha256(p) for p in SOURCES.values()}
    assert hashes_before == hashes_after, "A source changed during analysis"
    audit = {
        "period": ["1980-01", "2015-12"], "active_gauges": len(station), "incomplete_gauges": 22934,
        "missing_station_months": 4598259, "gap_events": reconstructed_events,
        "protocol": {"radius_km": 800, "search_radius_km": 1600, "nearest_candidate_cap": 200,
                     "minimum_visible_overlap": 24, "minimum_correlation": .2,
                     "support_definition": "All qualified references: supported=S+U3; unsupported=U1+U2",
                     "position_definition": "Before first finite observation; internal between first and last; after last, within 1980-2015",
                     "visibility": "Finite standardized anomaly; checked exactly equal to raw finite mask for all active targets",
                     "candidate_selection": "1600-km cKDTree query, exact distance filter, numpy argsort distance rank, nearest 200 then 800-km baseline filter",
                     "history": "Qualification uses all observed archive history; no new training or boundary performance test"},
        "reason_precedence": ["target_history_lt24", "missing_target_coordinates", "no_candidate_within800_after_cap",
                              "all_candidates_overlap_lt24", "overlap_ge24_but_all_correlations_nonfinite",
                              "overlap_ge24_but_no_finite_correlation_ge0_2"],
        "interpretation": ["Target history <24 is sufficient to fail baseline overlap qualification, not proof of a unique cause.",
                           "Scenario changes measure support classification sensitivity, not reconstruction skill or causal intervention effects.",
                           "Global task composition must not be replaced by statistics for the 2725-station common benchmark cohort."],
        "checks": {**counts, "every_active_station_old_counts_exact": True,
                   "stored_pool_donors_outside_rebuilt_eligible": len(pool_differences),
                   "stored_pool_supported_missing_months_also_supported_by_rebuilt_all_qualified": True,
                   "every_station_position_missing_month_and_event_count_matches": True,
                   "raw_and_standardized_visibility_match_active_targets": True,
                   "all_baseline_eligible_counts_exact": not eligibility_differences,
                   "baseline_candidate_counts_exact_for_n_valid_ge12": True,
                   "old_candidate_early_exit_below12_preserved_in_comparison": True,
                   "global_and_continent_old_categories_exact": True,
                   "TableS29_nine_rule_totals_exact": True, "scenario_position_sums_match_station_totals": True,
                   "source_hashes_unchanged": True},
        "global_support": {c: int(station[c].sum()) for c in ["n_missing", *CATS, "supported", "unsupported"]},
        "global_position": records(global_pos),
        "global_U1_reasons": records(reason_summary.loc[reason_summary.region.eq("Global")]),
        "regional_baseline": records(regional_sensitivity.loc[regional_sensitivity.scenario.eq("Baseline")]),
        "regional_sensitivity_ranges": records(sensitivity_range),
        "cases": CASES, "input_sha256": hashes_before,
        "script_sha256": sha256(Path(__file__)),
        "output_sha256": {p.name: sha256(p) for p in sorted(OUT.glob("*.csv"))},
        "runtime_seconds": time.time() - began,
        "runtime": {"python": sys.version, "numpy": np.__version__, "pandas": pd.__version__},
    }
    (OUT / "audit.json").write_text(json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8")
    print(global_pos.to_string(index=False), flush=True)
    print(reason_summary.loc[reason_summary.region.eq("Global")].to_string(index=False), flush=True)
    print(f"Completed in {time.time()-began:.1f}s. All source checks passed.", flush=True)


if __name__ == "__main__":
    main()
