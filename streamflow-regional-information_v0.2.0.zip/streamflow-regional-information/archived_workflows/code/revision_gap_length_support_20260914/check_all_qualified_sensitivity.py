"""One-factor support sensitivity; no change to reconstruction experiments."""
from __future__ import annotations
import json
import time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from recompute_all_qualified import old, ROOT, OUT

CASES = [
    ('Baseline',800.,200,24,.2),
    ('Radius 400 km',400.,200,24,.2),
    ('Radius 1200 km',1200.,200,24,.2),
    ('Nearest 50 candidates',800.,50,24,.2),
    ('All candidates within 800 km',800.,None,24,.2),
    ('Overlap 12 months',800.,200,12,.2),
    ('Overlap 60 months',800.,200,60,.2),
    ('Correlation 0.1',800.,200,24,.1),
    ('Correlation 0.4',800.,200,24,.4),
]

def main():
    began=time.time()
    ids=np.load(ROOT/'recoverability/ids.npy',allow_pickle=True).astype(str)
    id_to_i={s:i for i,s in enumerate(ids)}
    _,_,z0,vis=old.prepare_matrix(ids)
    meta=pd.read_csv(ROOT/'global_station_meta_kg.csv').set_index('gsim.no').reindex(ids)
    lat,lon=meta.latitude.to_numpy(float),meta.longitude.to_numpy(float)
    ok=np.isfinite(lat)&np.isfinite(lon)
    vectors=np.full((len(ids),3),np.nan); vectors[ok]=old.xyz(lat[ok],lon[ok])
    valid_idx=np.flatnonzero(ok); tree=cKDTree(vectors[valid_idx])
    active=pd.read_csv(ROOT/'recoverability/review_round2/global_recoverability_strict_strict_calibration_20260831_v3.csv')
    target_ids=active.gsim_no.astype(str).tolist()
    rows=[]
    for step,sid in enumerate(target_ids,1):
        j=id_to_i[sid]; missing=~vis[j]; n=int(missing.sum())
        if n==0:continue
        if ok[j]:
            cand=valid_idx[np.asarray(tree.query_ball_point(vectors[j],r=old.chord(1600.)),int)]
            cand=cand[cand!=j]; dist=old.great_circle_km(vectors[j],vectors[cand])
            keep=dist<=1600.+1e-8; cand,dist=cand[keep],dist[keep]
            near=np.argsort(dist)
            ranks=np.empty(len(cand),int);ranks[near]=np.arange(len(cand))
            use=(dist<=800.+1e-8)|(ranks<200)
            cand,dist,ranks=cand[use],dist[use],ranks[use]
            overlap,corr=old.correlations(j,cand,z0,vis)
        else:
            cand=np.array([],int);dist=overlap=corr=np.array([],float);ranks=np.array([],int)
        for name,radius,cap,minov,mincorr in CASES:
            eligible=(dist<=radius+1e-8)&(overlap>=minov)&np.isfinite(corr)&(corr>=mincorr)
            if cap is not None:eligible&=ranks<cap
            selected=cand[eligible]
            available=vis[selected].any(0) if len(selected) else np.zeros(432,bool)
            absent=int((missing&~available).sum())
            rows.append({'scenario':name,'station_id':sid,'n_missing':n,'n_qualified':len(selected),
                         'U1':absent if not len(selected) else 0,'U2':absent if len(selected) else 0,
                         'unsupported':absent})
        if step%2000==0:print(f'[sensitivity] {step}/{len(target_ids)} {time.time()-began:.1f}s',flush=True)
    frame=pd.DataFrame(rows)
    summary=frame.groupby('scenario',sort=False).agg(n_gauges=('station_id','size'),n_missing=('n_missing','sum'),
       U1=('U1','sum'),U2=('U2','sum'),unsupported=('unsupported','sum')).reset_index()
    for field in ['U1','U2','unsupported']:summary[field+'_pct']=100*summary[field]/summary.n_missing
    baseline=summary.loc[summary.scenario.eq('Baseline')].iloc[0]
    assert int(baseline.n_missing)==4598259
    assert int(baseline.unsupported)==611279,(int(baseline.unsupported),'baseline mismatch')
    assert int(baseline.U1)==237418 and int(baseline.U2)==373861
    frame.to_csv(OUT/'all_qualified_sensitivity_stations.csv',index=False)
    summary.to_csv(OUT/'TableS29_all_qualified_sensitivity.csv',index=False)
    (OUT/'sensitivity_audit.json').write_text(json.dumps({'baseline_reproduced':True,'runtime_seconds':time.time()-began,
        'scope':'All qualified references; one factor at a time; common global denominator',
        'cases':CASES},indent=2),encoding='utf-8')
    print(summary.to_string(index=False),flush=True)

if __name__=='__main__':main()
