#!/usr/bin/env python3
"""Final 12-method comparison; replace only isolated deep donor predictions. Historical filename retained for provenance."""
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(HERE))
from audit_exposure import sha,jwrite
from analyze_rerun_monthly import per_station as monthly_score
from analyze_caravan_daily_rerun import per_station as daily_score,spatial_block_ci,signed_rank

BASE=[('DA-transfer (DAT)','stratified_idw','dat'),
 ('Similarity reg','stratified_similarity_reg','similarity_reg'),
 ('GBM (+donor)','stratified_gbm_donor','gbm_donor'),
 ('RF (+donor)','stratified_rf_donor','rf_donor'),

 ('AR(1)','stratified_ar1','ar1'),('Seasonal mean','stratified_seasonal_mean','seasonal_mean')]
MODELS=['lstm','brits','saits']

def prediction_paths(scale):
    answer={name:ROOT/'results/raw'/(month if scale=='monthly' else 'caravan_daily_final_20260809_'+day)/'predictions_long.csv' for name,month,day in BASE}
    for arch in MODELS:
        answer[f'{arch.upper()} (single)']=ROOT/'results/raw'/(arch+'_single__unc' if scale=='monthly' else 'caravan_daily_final_20260809_'+arch+'_single')/'predictions_long.csv'
        p=HERE/'reruns'/scale/'isolated'/arch
        if not (p/'completion.json').exists():raise RuntimeError(f'Unfinished: {scale}/{arch}')
        answer[f'{arch.upper()} (+donor)']=(p/'results/raw'/f'leakage_v41_isolated_{arch}_none'/'predictions_long.csv' if scale=='monthly' else p/'predictions_long.csv')
    return answer

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--scale',choices=['monthly','daily','both'],default='both');args=parser.parse_args()
    out=HERE/'analysis';out.mkdir(exist_ok=True)
    allscores=[];allrank=[];allpaired=[];checks=[];sources={}
    for scale in (['monthly','daily'] if args.scale=='both' else [args.scale]):
        paths=prediction_paths(scale);scores={};rank=[]
        frozen=pd.read_csv(ROOT/f'V39.1/figures/source_data/Fig2/{scale}_ranking.csv')
        frozen['method']=frozen.method.replace({'DAT (donor-anomaly transfer)':'DA-transfer (DAT)'})
        frozen=frozen.set_index('method')
        for method,path in paths.items():
            d=pd.read_csv(path);assert not d.duplicated(['station_id','date']).any(),method
            assert np.isfinite(d.obs).all() and np.isfinite(d.pred).all(),f'Nonfinite raw prediction: {scale}/{method}'
            if scale=='monthly':
                ns,rs,alphas=monthly_score(d)
                s=pd.concat({'NSE':ns,'r':rs,'alpha':alphas},axis=1);s.index.name='station_id'
                s['n_obs']=d.groupby('station_id').size()
            else:s=daily_score(d)
            scores[method]=s
            row=dict(scale=scale,method=method,NSE_new=float(s.NSE.median()),r_median=float(s.r.median()),alpha_median=float(s.alpha.median()),
                n_stations=int(s.NSE.notna().sum()),n_r=int(s.r.notna().sum()),n_alpha=int(s.alpha.notna().sum()),
                n_station_rows=len(s),n_prediction_rows=len(d),prediction_sha256=sha(path))
            row['r_med']=row['r_median'];row['alpha_med']=row['alpha_median'];row['n']=row['n_stations']
            rank.append(row);sources[str(path.relative_to(ROOT))]=row['prediction_sha256']
            allscores.append(s.reset_index().assign(scale=scale,method=method))
            if not (method.endswith('(+donor)') and method.split()[0].lower() in MODELS):
                old=frozen.loc[method];tol=5.01e-5 if scale=='monthly' else 1.01e-8
                rc='r_med' if scale=='monthly' else 'r_median';ac='alpha_med' if scale=='monthly' else 'alpha_median'
                diffs={m:abs(row[new]-old[oldkey]) for m,new,oldkey in [('NSE','NSE_new','NSE_new'),('r','r_median',rc),('alpha','alpha_median',ac)]}
                passed=all(v<=tol for v in diffs.values()) and row['n_stations']==int(old.n_stations)
                checks.append(dict(scale=scale,method=method,unchanged_source_reproduced=bool(passed),**{k+'_absdiff':v for k,v in diffs.items()}))
                assert passed,checks[-1]
            print(f'{scale} {method}: n={row["n_stations"]} NSE={row["NSE_new"]:.6f}',flush=True)
        ranking=pd.DataFrame(rank).sort_values('NSE_new',ascending=False);ranking['rank']=np.arange(1,len(ranking)+1)
        ranking.to_csv(out/f'{scale}_ranking.csv',index=False);allrank.append(ranking)
        meta=(pd.read_csv(ROOT/'global_station_meta_kg.csv',low_memory=False).set_index('gsim.no') if scale=='monthly' else pd.read_csv(ROOT/'results_caravan_daily_test_stations_daily_final_20260809.csv').set_index('station_id'))
        rng=np.random.default_rng(0)
        for reference in ['DA-transfer (DAT)','Similarity reg']:
            for method,s in scores.items():
                if method==reference:continue
                joined=pd.concat({'method':s.NSE,'reference':scores[reference].NSE},axis=1).dropna()
                diff=(joined.method-joined.reference).to_numpy();coords=meta.reindex(joined.index)[['latitude','longitude']]
                assert np.isfinite(coords.to_numpy()).all(),'Do not silently assign missing coordinates a spatial cluster.'
                lo,hi,nb=spatial_block_ci(diff,joined.index.to_numpy(),meta,rng,2000)
                rb,p=signed_rank(diff)
                allpaired.append(dict(scale=scale,method=method,vs=reference,n=len(diff),median_diff=float(np.median(diff)),ci_lo=lo,ci_hi=hi,
                    win_pct=100*float(np.mean(diff>0)),n_blocks=nb,rank_biserial=rb,wilcoxon_p=p,bootstrap_replicates=2000,bootstrap_seed=0,
                    bootstrap_unit='5 degree latitude-longitude block',interval='percentile 95%'))
    pd.concat(allscores,ignore_index=True).to_csv(out/'ranking_station_scores.csv',index=False)
    ranking=pd.concat(allrank,ignore_index=True);ranking.to_csv(out/'r_alpha_cross_benchmark.csv',index=False)
    paired=pd.DataFrame(allpaired);paired.to_csv(out/'paired_vs_DAT_and_Similarity.csv',index=False)
    paired[paired.vs=='DA-transfer (DAT)'].to_csv(out/'paired_vs_DAT.csv',index=False)
    pd.DataFrame(checks).to_csv(out/'ranking_source_reproduction_checks.csv',index=False)
    artifacts=['ranking_station_scores.csv','r_alpha_cross_benchmark.csv','paired_vs_DAT.csv','paired_vs_DAT_and_Similarity.csv','ranking_source_reproduction_checks.csv']+[f'{s}_ranking.csv' for s in (['monthly','daily'] if args.scale=='both' else [args.scale])]
    jwrite(out/'ranking_manifest.json',dict(status='COMPLETED' if args.scale=='both' else 'ONE_SCALE_COMPLETED',scale=args.scale,method_count_per_scale=12,
        removed_shared_models=['GRIN (+donor)','MG-STGAI'],source_predictions_sha256=sources,output_sha256={p:sha(out/p) for p in artifacts},
        scoring='Original monthly/daily source scoring functions, including original r/alpha guards; NSE denominator guard 1e-12',
        interpretation='Descriptive method-specific station counts; contrasts use finite paired station intersection. Deep donor inputs isolated across train/validation/test; three target-only controls and seven per-target methods reused.',
        spatial_bootstrap='Original 5x5 degree blocks; 2000 replicates; seed 0 freshly initialized per scale. Method list changed, so bootstrap draws for individual contrasts need not equal legacy CI endpoints.'))

if __name__=='__main__':main()
