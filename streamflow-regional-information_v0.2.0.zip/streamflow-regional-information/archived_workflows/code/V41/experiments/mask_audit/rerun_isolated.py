#!/usr/bin/env python3
"""Execute the original matched deep trainers through isolated dataset views.

Frozen architecture, seeds, optimizer, losses, epochs and early stopping. Source
trainers stay read-only. Only device routing, output routing, memoization and
progress/checkpoint logging are adapted. --execute is required to train.
"""
from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse, importlib.util, inspect, json, sys, time
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(HERE))
from audit_exposure import jwrite,sha


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--scale',choices=['monthly','daily'],required=True)
    p.add_argument('--models',default='lstm,brits,saits')
    p.add_argument('--device',choices=['cpu','mps','cuda'],default='cpu')
    p.add_argument('--protocol',choices=['isolated','original'],default='isolated')
    p.add_argument('--execute',action='store_true');p.add_argument('--resume',action='store_true');p.add_argument('--cpu-threads',type=int,default=4)
    args=p.parse_args();names=args.models.split(',')
    assert all(n in ['lstm','brits','saits'] for n in names)
    dest=HERE/'reruns'/args.scale/args.protocol;dest.mkdir(parents=True,exist_ok=True)
    plan={'scale':args.scale,'models':names,'device':args.device,'protocol':args.protocol,
        'seed':0,'hidden':64,'learning_rate':0.001,'batch_size':32,
        'epochs_upper_limit':50 if args.scale=='monthly' else 80,
        'early_stopping_patience':10 if args.scale=='monthly' else 12,
        'checkpoint_selection':'validation_loss' if args.scale=='monthly' else 'validation_station_median_NSE',
        'monthly_uncertainty_loss_enabled':args.scale=='monthly','target_only_source_predictions_reused':True,
        'training_started':False}
    jwrite(dest/'run_plan.json',plan)
    if not args.execute:print(json.dumps(plan,indent=2));return
    import torch
    assert args.device!='mps' or torch.backends.mps.is_available(),'MPS unavailable (run in approved GPU-enabled host context).'
    assert args.device!='cuda' or torch.cuda.is_available()
    torch.set_num_threads(args.cpu_threads)
    from isolated_data import build
    ds,cfg,roles=build(args.scale,args.protocol)
    start=time.time()
    for name in names:
        folder=dest/name;folder.mkdir(exist_ok=True)
        if (folder/'completion.json').exists():
            print(f'Skip completed {name}; outputs preserved',flush=True);continue
        began=time.time()
        jwrite(folder/'status.json',dict(plan,model=name,status='RUNNING',torch_version=torch.__version__,started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())))
        try:
            def resume(model,opt,rng,best_value,best_state,bad,history):
                checkpoint=folder/'epoch_checkpoint.pth'
                if not args.resume or not checkpoint.exists():return 0,best_value,best_state,bad,history
                saved=torch.load(checkpoint,map_location='cpu',weights_only=False)
                assert saved['configuration']==cfg and saved['model_name']==name
                for key in ['scale','device','protocol','seed','hidden','learning_rate','batch_size','epochs_upper_limit','early_stopping_patience']:
                    assert saved['plan'][key]==plan[key],(key,saved['plan'][key],plan[key])
                model.load_state_dict(saved['model']);opt.load_state_dict(saved['optimizer'])
                rng.bit_generator.state=saved['batch_shuffle_rng'];torch.set_rng_state(saved['torch_cpu_rng'])
                if args.device=='mps':torch.mps.set_rng_state(saved['torch_mps_rng'])
                print(f'Resumed {args.scale}/{name} after epoch {saved["epoch"]}',flush=True)
                next_epoch=saved['epoch']
                if saved['bad_epochs']>=plan['early_stopping_patience']:
                    next_epoch=plan['epochs_upper_limit']
                return next_epoch,saved['best_value'],saved['best_state'],saved['bad_epochs'],saved['history']
            def periodic(ep,model,opt,best_value,best_state,bad,rng,history):
                payload={'epoch':ep,'model':{k:v.detach().cpu() for k,v in model.state_dict().items()},
                    'optimizer':opt.state_dict(),'best_value':best_value,'best_state':best_state,'bad_epochs':bad,
                    'batch_shuffle_rng':rng.bit_generator.state,'torch_cpu_rng':torch.get_rng_state(),
                    'torch_mps_rng':torch.mps.get_rng_state() if args.device=='mps' else None,
                    'history':history,'configuration':cfg,'plan':plan,'model_name':name}
                tmp=folder/'epoch_checkpoint.tmp';torch.save(payload,tmp);tmp.replace(folder/'epoch_checkpoint.pth')
                jwrite(folder/'training_curve.json',history)
                print(f'{args.scale} {name} checkpoint epoch={ep} best={best_value:.6f} bad={bad} elapsed={time.time()-began:.1f}s',flush=True)
            if args.scale=='monthly':
                source=ROOT/'scripts/train_baseline_deep.py';text=source.read_text()
                old='device = "cuda" if torch.cuda.is_available() else "cpu"'
                assert text.count(old)==1
                text=text.replace(old,f'device = {args.device!r}')
                text=text.replace('print("[saved] %s" % _csv)',f'print("[saved] %s" % {str(folder / "results_summary.csv")!r})')
                needle='best_val = float("inf"); best_state = None; bad = 0; history = []'
                assert text.count(needle)==1
                text=text.replace(needle,needle+'\n    resume_epoch,best_val,best_state,bad,history = audit_resume(model,opt,rng,best_val,best_state,bad,history)')
                text=text.replace('for ep in range(1, args.epochs + 1):','for ep in range(resume_epoch + 1, args.epochs + 1):')
                needle='print("   early stop at ep %d (best val=%.4f)" % (ep, best_val)); break'
                assert text.count(needle)==1
                text=text.replace(needle,'audit_periodic(ep,model,opt,best_val,best_state,bad,rng,history); '+needle)
                needle='    if best_state is not None:\n'
                assert text.count(needle)==1
                text=text.replace(needle,'        audit_periodic(ep,model,opt,best_val,best_state,bad,rng,history)\n'+needle)
                namespace={'__name__':'v41_monthly_trainer','__file__':str(source)}
                exec(compile(text,str(source),'exec'),namespace)
                namespace['audit_periodic']=periodic;namespace['audit_resume']=resume
                namespace['load_station_matrix']=lambda *a,**k:ds.flow_df
                namespace['drop_gsim_twins']=lambda flow:flow
                namespace['load_static']=lambda *a,**k:ds.static_df
                def factory(flow,static,actual_cfg):
                    assert actual_cfg==cfg
                    return ds
                namespace['GapImputationDataset']=factory
                save=namespace['save_run_outputs'];append=namespace['append_result']
                namespace['save_run_outputs']=lambda root,tag,records,df=None,summary=None:save(str(folder),tag,records,df,summary)
                namespace['append_result']=lambda path,row:append(str(folder/'results_summary.csv'),row)
                oldargv=sys.argv
                sys.argv=[str(source),'--model',name,'--series_dir','CACHE_PROVIDED_BY_V41',
                          '--static',str(ROOT/'global_station_meta_kg.csv'),'--use_donor','--uncertainty',
                          '--epochs','50','--patience','10','--seed','0','--lr','0.001','--hidden','64',
                          '--run_id',f'v41_{args.protocol}','--out',str(folder/'checkpoints')]
                try:namespace['main']()
                finally:sys.argv=oldargv
            else:
                import exp_caravan_full_benchmark as original
                source=ROOT/'exp_caravan_full_benchmark.py'
                code=inspect.getsource(original.train_eval_deep)
                old='dev = "cuda" if torch.cuda.is_available() else "cpu"; seed_torch(0)'
                assert code.count(old)==1
                code=code.replace(old,f'dev = {args.device!r}; seed_torch(0)')
                needle='best, bad, bs = -1e9, 0, None; rng = np.random.default_rng(0); epmax = 6 if args.smoke else args.epochs'
                assert code.count(needle)==1
                code=code.replace(needle,needle+'\n    resume_epoch,best,bs,bad,restored_history = audit_resume(model,opt,rng,best,bs,bad,audit_history)\n    audit_history[:] = restored_history')
                code=code.replace('for ep in range(1, epmax + 1):','for ep in range(resume_epoch + 1, epmax + 1):')
                needle='v, _, _ = ev(va)'
                assert code.count(needle)==1
                code=code.replace(needle,needle+'\n        audit_epoch(ep, v)')
                needle='if bad >= args.patience: break'
                assert code.count(needle)==1
                code=code.replace(needle,'if bad >= args.patience:\n                audit_periodic(ep,model,opt,best,bs,bad,rng,audit_history)\n                break')
                needle='if bs is not None: model.load_state_dict(bs)'
                assert code.count(needle)==1
                code=code.replace(needle,'    audit_periodic(ep,model,opt,best,bs,bad,rng,audit_history)\n    '+needle+'\n    audit_checkpoint(model, best)')
                namespace=dict(vars(original));history=[]
                def audit_epoch(ep,value):
                    history.append({'epoch':ep,'validation_station_median_NSE':float(value)})
                    jwrite(folder/'training_curve.json',history)
                    print(f'daily {name} epoch={ep} val_median_NSE={value:.6f} elapsed={time.time()-began:.1f}s',flush=True)
                def audit_checkpoint(model,best):
                    torch.save({'model':model.state_dict(),'model_name':name,'hidden':64,'use_donor':True,
                                'config':cfg,'seed':0,'protocol':args.protocol,'best_validation_median_nse':best},folder/'best_model.pth')
                def dump(tag,recs,run_id=''):
                    import pandas as pd
                    pd.DataFrame(recs,columns=['station_id','date','obs','pred']).to_csv(folder/'predictions_long.csv',index=False)
                namespace.update(audit_epoch=audit_epoch,audit_checkpoint=audit_checkpoint,audit_periodic=periodic,audit_resume=resume,audit_history=history,_dump=dump)
                exec(compile(code,str(source),'exec'),namespace)
                tr=[i for i,g in enumerate(ds.gaps) if roles[g.station_id]=='train']
                va=[i for i,g in enumerate(ds.gaps) if roles[g.station_id]=='validation']
                te=[i for i,g in enumerate(ds.gaps) if roles[g.station_id]=='test']
                score,summary,n=namespace['train_eval_deep'](name,True,ds,tr,va,te,cfg,SimpleNamespace(smoke=False,epochs=80,patience=12),tag=name,dump=True,run_id=f'v41_{args.protocol}')
                jwrite(folder/'test_summary.json',{'station_median_NSE':score,'n':n,'summary':summary})
            complete=dict(plan,model=name,status='COMPLETED',training_started=True,elapsed_seconds=time.time()-began,
                torch_version=torch.__version__,source_trainer=str(source.relative_to(ROOT)),source_trainer_sha256=sha(source),
                adaptation='Read-only source execution; device/output routing and daily logging only; isolated dataset view; no epoch truncation.')
            jwrite(folder/'completion.json',complete);jwrite(folder/'status.json',complete)
        except BaseException as e:
            jwrite(folder/'status.json',dict(plan,model=name,status='FAILED',training_started=True,error=repr(e),elapsed_seconds=time.time()-began))
            raise
    print(f'All requested models completed in {time.time()-start:.1f}s',flush=True)


if __name__=='__main__':main()
