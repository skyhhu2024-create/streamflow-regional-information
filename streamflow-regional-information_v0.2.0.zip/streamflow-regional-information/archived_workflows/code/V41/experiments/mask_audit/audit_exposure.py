#!/usr/bin/env python3
"""Read-only reconstruction of benchmark train/validation donor exposure.

Only files below this script's directory may be created. No model is trained,
no input mask is changed, and no source file is modified.
"""
from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
import argparse, csv, gzip, hashlib, io, json, sys, time, warnings
from pathlib import Path
import numpy as np
import pandas as pd
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
from src.data.dataset import GapImputationDataset, split_stations
from src.data.gsim_io import load_static


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024), b''): h.update(b)
    return h.hexdigest()


def jwrite(p, obj):
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False)+'\n')


def monthly(out, sources):
    data=ROOT/'boundary_validation_20260922/data'
    audit=json.loads((data/'cache_audit.json').read_text())
    for n in ['flow_qc20_dedup.npy','station_ids.npy','dates.npy','station_metadata.csv']:
        p=data/n; sources[str(p.relative_to(ROOT))]=sha(p)
        assert sources[str(p.relative_to(ROOT))]==audit['outputs'][n]['sha256'], n
    sources[str((data/'cache_audit.json').relative_to(ROOT))]=sha(data/'cache_audit.json')
    flow=pd.DataFrame(np.load(data/'flow_qc20_dedup.npy'), index=pd.to_datetime(np.load(data/'dates.npy')),
                      columns=np.load(data/'station_ids.npy'))
    meta=ROOT/'global_station_meta_kg.csv'; sources[str(meta.relative_to(ROOT))]=sha(meta)
    summary=ROOT/'results/raw/lstm_donor__unc/summary.json'
    sources[str(summary.relative_to(ROOT))]=sha(summary)
    cfg=json.loads(summary.read_text())['config']
    return flow, load_static(meta), cfg, {'data_source':'frozen production-loader QC20 cache; all four cache payload hashes reverified',
        'expected_gap_counts':{'train':53192,'validation':11411,'test':11331}}


def daily(out, sources):
    """Use frozen eligibility/order, re-read every retained raw series in float64.

    The float32 cache is used for membership and verified against the re-read raw
    values; calculations use original CSV float64, as in the daily main runner.
    """
    cache=ROOT/'_cache_caravan_daily.npz'
    dup=ROOT/'caravan_duplicate_gauges.csv'
    manifest=ROOT/'results_caravan_daily_manifest_daily_final_20260809.json'
    testfile=ROOT/'results_caravan_daily_test_stations_daily_final_20260809.csv'
    for p in [cache,dup,manifest,testfile]: sources[str(p.relative_to(ROOT))]=sha(p)
    saved=json.loads(manifest.read_text()); cfg=saved['config']
    z=np.load(cache, allow_pickle=False)
    dates=pd.to_datetime(z['dates']); allids=z['sids']; source=z['src']; cached=z['flow']
    dropped=set(pd.read_csv(dup)['dropped'])
    assert len(allids)==5641 and len(dropped)==459
    keep=np.array([i for i,s in enumerate(allids) if s not in dropped])
    ids=allids[keep]; assert len(ids)==5182
    matrixfile=out/'flow_raw_float64.npy'
    q=np.lib.format.open_memmap(matrixfile, mode='w+', dtype='float64', shape=(len(dates),len(ids)))
    q[:]=np.nan
    latlon={}; base=ROOT/'Caravan/Caravan/Caravan'
    for dn in sorted(set(source)):
        p=base/'attributes'/dn/f'attributes_other_{dn}.csv'
        sources[str(p.relative_to(ROOT))]=sha(p)
        at=pd.read_csv(p).set_index('gauge_id')
        for s,row in at.iterrows():
            try:latlon[s]=(float(row.gauge_lat),float(row.gauge_lon))
            except (ValueError,TypeError,AttributeError):pass
    rawrows=[]; started=time.time()
    for j,old in enumerate(keep):
        sid=allids[old]; p=base/'timeseries/csv'/source[old]/f'{sid}.csv'
        state=(p.stat().st_size,p.stat().st_mtime_ns)
        b=p.read_bytes(); digest=hashlib.sha256(b).hexdigest()
        d=pd.read_csv(io.BytesIO(b),usecols=['date','streamflow'])
        series=d.set_index(pd.to_datetime(d['date']))['streamflow'].reindex(dates)
        q[:,j]=series.to_numpy(dtype=float)
        same=np.array_equal(q[:,j].astype(np.float32),cached[:,old],equal_nan=True)
        assert same, f'Cached membership/source mismatch: {sid}'
        assert state==(p.stat().st_size,p.stat().st_mtime_ns)
        rawrows.append({'station_id':sid,'path':str(p.relative_to(ROOT)),'bytes':state[0],
                        'mtime_ns':state[1],'sha256':digest,'raw_to_cached_float32_exact':same})
        if (j+1)%500==0:print(f'daily raw read {j+1}/{len(ids)} in {time.time()-started:.1f}s',flush=True)
    q.flush();pd.DataFrame(rawrows).to_csv(out/'raw_input_manifest.csv',index=False)
    np.save(out/'station_ids.npy',ids);np.save(out/'dates.npy',dates.to_numpy(dtype='datetime64[D]'))
    static=pd.DataFrame([latlon.get(s,(np.nan,np.nan)) for s in ids],index=ids,columns=['latitude','longitude'])
    static.to_csv(out/'static.csv',index_label='station_id')
    flow=pd.DataFrame(q,index=dates,columns=ids)
    train,val,test=split_stations(ids,cfg['split'])
    membership=pd.read_csv(testfile)
    assert set(membership.station_id)==test
    return flow,static,cfg,{'data_source':'frozen eligible-order/cache and duplicate list; every retained raw CSV reread in original float64',
        'all_5182_raw_series_roundtrip_to_eligibility_cache_exact':True,
        'saved_test_membership_exact':True,'raw_input_manifest_sha256':sha(out/'raw_input_manifest.csv'),
        'raw_file_n':len(rawrows),'raw_file_bytes':sum(r['bytes'] for r in rawrows),
        'expected_gap_counts':{'test':saved['n_test_gaps']}}


def select_vector(ds,gap):
    """Vectorized production formula, same nearest-200 shortlist and stable rank.

    Exact production selector is used near qualification/rank boundaries, and a
    deterministic audit sample compares complete donor identities and weights.
    """
    sel=ds.donor_selector;ti=ds.sid2idx[gap.station_id]
    cand,dist=sel._spatial_candidates(ti)
    if not len(cand):return [],cand,np.zeros(0,bool),False
    lo=max(0,gap.start-sel.cfg['precorr_window'])
    t=ds.z[lo:gap.start,ti];d=ds.z[lo:gap.start,cand]
    mask=np.isfinite(t[:,None])&np.isfinite(d);n=mask.sum(0)
    sync=np.isfinite(ds.z[gap.start:gap.end+1,cand]).any(0)
    tm=np.divide(np.where(mask,t[:,None],0).sum(0),n,out=np.zeros(len(cand)),where=n>0)
    dm=np.divide(np.where(mask,d,0).sum(0),n,out=np.zeros(len(cand)),where=n>0)
    a=np.where(mask,t[:,None]-tm,0);b=np.where(mask,d-dm,0)
    aa=(a*a).sum(0);bb=(b*b).sum(0)
    r=np.divide((a*b).sum(0),np.sqrt(aa*bb),out=np.full(len(cand),np.nan),where=(aa*bb)>0)
    tiny=(np.sqrt(np.divide(aa,np.maximum(n,1)))<1e-9)|(np.sqrt(np.divide(bb,np.maximum(n,1)))<1e-9)
    r[(n<6)|tiny]=np.nan
    good=sync&(n>=sel.cfg['min_overlap_months'])&np.isfinite(r)&(r>=sel.cfg['min_precorr'])
    weights=r*np.exp(-dist/sel.cfg['max_distance_km'])
    ordered=np.flatnonzero(good);ordered=ordered[np.argsort(-weights[ordered],kind='stable')]
    boundary=bool(np.any(sync&np.isfinite(r)&(np.abs(r-sel.cfg['min_precorr'])<1e-10)))
    k=sel.cfg['max_donors']
    if len(ordered)>k and weights[ordered[k-1]]-weights[ordered[k]]<1e-10:boundary=True
    if boundary:return sel.select(gap),cand,sync,True
    selected=ordered[:k];den=weights[selected].sum()+1e-9
    result=[{'donor_id':ds.station_ids[cand[i]],'precorr':float(r[i]),'dist_km':float(dist[i]),
             'sync_months':int(np.isfinite(ds.z[gap.start:gap.end+1,cand[i]]).sum()),'weight':float(weights[i]/den)} for i in selected]
    return result,cand,sync,False


def prediction_alignment(ds,scale,test,sources,out):
    rows=[];ids=ds.sid2idx;dateidx={str(d.date()):i for i,d in enumerate(ds.index)}
    for model in ['lstm','brits','saits']:
        for mode in ['single','donor']:
            tag=f'{model}_{mode}__unc' if scale=='monthly' else f'caravan_daily_final_20260809_{model}_{mode}'
            p=ROOT/'results/raw'/tag/'predictions_long.csv'
            if not p.exists():rows.append({'model':model,'mode':mode,'status':'MISSING'});continue
            sources[str(p.relative_to(ROOT))]=sha(p)
            v=pd.read_csv(p,usecols=['station_id','date','obs'])
            js=np.array([ids[s] for s in v.station_id]);ts=np.array([dateidx[str(d)[:10]] for d in v.date])
            exact=np.allclose(v.obs.to_numpy(),ds.flow[ts,js],rtol=1e-12,atol=1e-12,equal_nan=True)
            mask=ds.is_gap_month[ts,js]
            rows.append({'model':model,'mode':mode,'status':'PASS' if exact and mask.all() and set(v.station_id)<=test else 'MISMATCH',
                         'saved_rows':len(v),'saved_stations':v.station_id.nunique(),
                         'all_rows_in_regenerated_test_mask':bool(mask.all()),'original_truth_equal':bool(exact),
                         'all_stations_in_test_split':set(v.station_id)<=test})
    pd.DataFrame(rows).to_csv(out/'saved_prediction_alignment.csv',index=False)
    return rows


def run(scale):
    started=time.time();out=HERE/scale;out.mkdir(exist_ok=True)
    assert not (out/'summary.json').exists(),'Completed audit exists; do not overwrite.'
    sources={}
    sourcefiles=['src/data/dataset.py','src/data/donors.py','src/data/features.py','src/data/pseudo_gap.py',
                 'src/train/collate.py','src/models/baselines_deep.py','src/models/stage1.py',
                 'scripts/train_baseline_deep.py','scripts/train_full.py','exp_caravan_full_benchmark.py','exp_regulation.py']
    for n in sourcefiles:sources[n]=sha(ROOT/n)
    flow,static,cfg,provenance=(monthly if scale=='monthly' else daily)(out,sources)
    print(f'{scale}: creating production dataset {flow.shape}',flush=True)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',RuntimeWarning)
        ds=GapImputationDataset(flow,static,cfg)
    train,val,test=split_stations(ds.station_ids,cfg['split']);split={s:'train' if s in train else 'validation' if s in val else 'test' for s in ds.station_ids}
    testids=[s for s in ds.station_ids if s in test];testjs=np.array([ds.sid2idx[s] for s in testids]);tp={j:k for k,j in enumerate(testjs)}
    held=ds.is_gap_month[:,testjs]&np.isfinite(ds.z[:,testjs])
    scored=np.zeros_like(held)
    gaprows=[];groups={'train':[],'validation':[],'test':[]}
    for i,g in enumerate(ds.gaps):
        role=split[g.station_id];groups[role].append(i)
        gaprows.append({'gap_index':i,'station_id':g.station_id,'split':role,'start_index':g.start,'end_index':g.end,
                        'start_date':str(ds.index[g.start].date()),'end_date':str(ds.index[g.end].date()),'length':g.length,'stratum':g.stratum})
        if role=='test' and g.length>=2:scored[g.start:g.end+1,tp[ds.sid2idx[g.station_id]]]=True
    for role,n in provenance['expected_gap_counts'].items():assert len(groups[role])==n,(role,len(groups[role]),n)
    pd.DataFrame(gaprows).to_csv(out/'gap_membership.csv.gz',index=False)
    pd.DataFrame({'station_id':ds.station_ids,'split':[split[s] for s in ds.station_ids]}).to_csv(out/'station_membership.csv',index=False)
    alignment=prediction_alignment(ds,scale,test,sources,out)
    assert all(r['status']=='PASS' for r in alignment),alignment
    np.save(out/'test_hidden_mask.npy',held);np.save(out/'test_scored_mask.npy',scored)
    np.save(out/'test_station_ids.npy',np.asarray(testids))
    # stage, path, time, held-out station. Counts are per input sample, not epochs.
    paths=['synchronous_donor_input','donor_context_outside_gap','candidate_qualification_history']
    stages=['train','validation']
    counts=np.zeros((2,3,len(ds.index),len(testids)),dtype=np.uint16)
    impacted=np.zeros((2,3),dtype=np.int64);seen=[ [set() for _ in paths] for _ in stages]
    selected_by_gap=[];parity=[];boundary_n=0
    check_indices=set(np.linspace(0,len(ds.gaps)-1,min(300,len(ds.gaps)),dtype=int))
    fixture_rows=[]; pad=cfg['train']['seq_pad']
    for i,g in enumerate(ds.gaps):
        donors,cand,sync,boundary=select_vector(ds,g);boundary_n+=boundary
        if i in check_indices:
            exact=ds.donor_selector.select(g)
            same=[d['donor_id'] for d in donors]==[d['donor_id'] for d in exact]
            err=max([abs(a['weight']-b['weight']) for a,b in zip(donors,exact)],default=0.) if same else 1.
            assert same and err<1e-10,(i,same,err)
            parity.append({'gap_index':i,'n_donors':len(donors),'identities_equal':same,'max_weight_abs_difference':err})
        selected_by_gap.append({'gap_index':i,'donor_ids':json.dumps([d['donor_id'] for d in donors]),
                                'weights':json.dumps([d['weight'] for d in donors])})
        role=split[g.station_id]
        if role in stages:
            si=stages.index(role);had=np.zeros(3,bool)
            for donor in donors:
                dj=ds.sid2idx[donor['donor_id']]
                if dj not in tp:continue
                tj=tp[dj]
                for pi,slices in [(0,[(g.start,g.end+1)]),(1,[(max(0,g.start-pad),g.start),(g.end+1,min(ds.T,g.end+1+pad))])]:
                    for lo,hi in slices:
                        times=np.flatnonzero(held[lo:hi,tj])+lo
                        if len(times):
                            counts[si,pi,times,tj]+=1;had[pi]=True
                            if len(fixture_rows)<100:
                                t=int(times[0]);fixture_rows.append({'source_gap_index':i,'source_station':g.station_id,'source_split':role,
                                    'path':paths[pi],'test_station':donor['donor_id'],'time_index':t,'date':str(ds.index[t].date()),
                                    'held_truth_raw':float(ds.flow[t,dj]),'transformed_input_z':float(ds.z[t,dj]),'donor_weight':donor['weight']})
            lo=max(0,g.start-cfg['donors']['precorr_window']);valid_target=np.isfinite(ds.z[lo:g.start,ds.sid2idx[g.station_id]])
            for dj in cand[sync]:
                if dj not in tp:continue
                tj=tp[dj];times=np.flatnonzero(held[lo:g.start,tj]&valid_target)+lo
                if len(times):counts[si,2,times,tj]+=1;had[2]=True
            for pi in range(3):
                if had[pi]:impacted[si,pi]+=1;seen[si][pi].add(g.station_id)
        if (i+1)%2000==0:print(f'{scale}: audited {i+1}/{len(ds.gaps)} samples ({time.time()-started:.1f}s)',flush=True)
    pd.DataFrame(selected_by_gap).to_csv(out/'selected_donors.csv.gz',index=False)
    pd.DataFrame(parity).to_csv(out/'production_selector_parity.csv',index=False)
    pd.DataFrame(fixture_rows).to_csv(out/'verified_input_examples.csv',index=False)
    # Verify sample input tensors use exactly the reported held-out values.
    fixture_checks=[]
    for row in fixture_rows:
        if row['path']!='synchronous_donor_input':continue
        i=row['source_gap_index'];g=ds.gaps[i];sample=ds[i]
        donors=ds._donors(g);k=[d['donor_id'] for d in donors].index(row['test_station']);t=row['time_index']-g.start
        value=float(sample['donor_gap_z'][k,t]);expected=float(np.float32(row['transformed_input_z']))
        assert value==expected and sample['donor_mask'][k,t]==1
        fixture_checks.append({'gap_index':i,'test_station':row['test_station'],'time_index':row['time_index'],
                               'production_sample_input_exact':True,'donor_mask':1})
    pd.DataFrame(fixture_checks).to_csv(out/'actual_sample_input_checks.csv',index=False)
    np.savez_compressed(out/'exposure_counts.npz',counts=counts,test_station_ids=np.asarray(testids),dates=ds.index.to_numpy(dtype='datetime64[D]'),paths=np.asarray(paths),stages=np.asarray(stages))
    summaryrows=[]
    denominator=int(held.sum());scored_n=int((held&scored).sum())
    for si,stage in enumerate(stages):
        for pi,path in enumerate(paths):
            c=counts[si,pi];unique=c>0
            summaryrows.append({'stage':stage,'path':path,'read_occurrences':int(c.sum()),'unique_hidden_test_cells':int(unique.sum()),
                'unique_hidden_test_cell_pct':100*float(unique.sum())/denominator,'unique_scored_test_cells':int((unique&scored).sum()),
                'unique_scored_test_cell_pct':100*float((unique&scored).sum())/scored_n,
                'test_stations_exposed':int(unique.any(0).sum()),'recipient_samples':int(impacted[si,pi]),
                'recipient_sample_pct':100*float(impacted[si,pi])/len(groups[stage]),'recipient_stations':len(seen[si][pi])})
    combined=[]
    for label,idx in [('three_matched_architectures_direct_input',[0]),('three_matched_architectures_input_or_selection',[0,2]),('graph_attention_input_or_selection',[0,1,2])]:
        for stage,stageids in [('train',[0]),('validation',[1]),('train_or_validation',[0,1])]:
            u=np.any(counts[np.asarray(stageids)[:,None],np.asarray(idx)[None,:]]>0,axis=(0,1))
            combined.append({'architecture_scope':label,'stage':stage,'unique_hidden_test_cells':int(u.sum()),
                'unique_hidden_test_cell_pct':100*float(u.sum())/denominator,'unique_scored_test_cells':int((u&scored).sum()),
                'unique_scored_test_cell_pct':100*float((u&scored).sum())/scored_n,'test_stations_exposed':int(u.any(0).sum())})
    pd.DataFrame(summaryrows).to_csv(out/'exposure_summary.csv',index=False)
    pd.DataFrame(combined).to_csv(out/'architecture_exposure_summary.csv',index=False)
    # Long-form aggregate ledger identifies every exposed test station-date.
    with gzip.open(out/'exposed_test_cells.csv.gz','wt',newline='') as f:
        w=csv.writer(f);w.writerow(['stage','path','test_station','date','input_sample_occurrences','included_in_deep_scoring'])
        for si,stage in enumerate(stages):
            for pi,path in enumerate(paths):
                tt,jj=np.nonzero(counts[si,pi])
                w.writerows((stage,path,testids[j],str(ds.index[t].date()),int(counts[si,pi,t,j]),bool(scored[t,j])) for t,j in zip(tt,jj))
    changed=[n for n,h in sources.items() if sha(ROOT/n)!=h]
    assert not changed,changed
    report={'status':'COMPLETED_EXPOSURE_CONFIRMED','scale':scale,'scope':'CPU input-route audit; no retraining; no performance-effect estimate',
        'shape':list(flow.shape),'station_splits':{'train':len(train),'validation':len(val),'test':len(test)},
        'gap_counts':{r:len(v) for r,v in groups.items()},'hidden_test_cells':denominator,'scored_hidden_test_cells':scored_n,
        'test_stations_with_hidden_cells':int(held.any(0).sum()),'paths':paths,'exposure_summary':summaryrows,'architecture_summary':combined,
        'production_selector_parity_samples':len(parity),'production_selector_max_weight_difference':max(r['max_weight_abs_difference'] for r in parity),
        'near_boundary_exact_selector_fallback_n':boundary_n,'actual_production_input_checks':len(fixture_checks),
        'preprocessing_fit_excludes_all_generated_hidden_cells':True,'prediction_alignment':alignment,'provenance':provenance,
        'source_sha256':sources,'source_hashes_unchanged':True,'elapsed_seconds':time.time()-started,
        'caveats':['Counts establish value-read paths, not the change in fitted weights or NSE.',
                   'Read occurrences count sample-reference-time tuples once, not training epochs.',
                   'Qualification history counts numeric reads on common observed target/reference dates, including candidates subsequently rejected.',
                   'Availability-only candidate screening is not counted as exposure to numerical truth.',
                   'All original eligible observations, gap positions, donor rules and splits are preserved.',
                   'Vectorized production formula was checked against the original selector on the listed deterministic sample; near numerical boundaries use the original selector.']}
    jwrite(out/'summary.json',report)
    print(json.dumps({'scale':scale,'status':report['status'],'hidden_test_cells':denominator,'architecture_summary':combined},ensure_ascii=False),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--scale',choices=['monthly','daily'],required=True)
    run(p.parse_args().scale)
