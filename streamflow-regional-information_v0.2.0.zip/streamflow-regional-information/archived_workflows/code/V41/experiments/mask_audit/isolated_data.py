"""Split-aware held-out-label isolation, preserving target-wise test access.

Train inputs/ranking exclude all validation+test pseudo-gap cells. Validation
inputs/ranking exclude all final-test pseudo-gap cells. Test inputs are exactly
the original target-wise retrospective inputs. Original truth is retained only
for loss/evaluation. This does not simulate a network-wide observation outage.
"""
from __future__ import annotations
import copy, json, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT))
from src.data.dataset import GapImputationDataset, split_stations
from src.data.donors import DonorSelector
from src.data.gsim_io import load_static
from audit_exposure import select_vector, sha, jwrite


class SplitInputDataset:
    def __init__(self, original, training, validation, roles):
        self.original=original;self.training=training;self.validation=validation;self.roles=roles;self.sample_cache={}
    def __getattr__(self,name):return getattr(self.original,name)
    def __len__(self):return len(self.original)
    def view(self,g):
        role=self.roles[g.station_id]
        return self.training if role=='train' else self.validation if role=='validation' else self.original
    def __getitem__(self,i):
        # Dataset samples are deterministic and never mutated by collate_numpy.
        if i not in self.sample_cache:self.sample_cache[i]=self.view(self.original.gaps[i])[i]
        return self.sample_cache[i]


def build(scale,protocol='isolated'):
    out=HERE/scale
    report=json.loads((out/'summary.json').read_text())
    assert report['status']=='COMPLETED_EXPOSURE_CONFIRMED'
    if scale=='monthly':
        data=ROOT/'boundary_validation_20260922/data'
        flow=pd.DataFrame(np.load(data/'flow_qc20_dedup.npy'),index=pd.to_datetime(np.load(data/'dates.npy')),columns=np.load(data/'station_ids.npy'))
        static=load_static(ROOT/'global_station_meta_kg.csv')
        cfg=json.loads((ROOT/'results/raw/lstm_donor__unc/summary.json').read_text())['config']
    else:
        flow=pd.DataFrame(np.load(out/'flow_raw_float64.npy',mmap_mode='r'),index=pd.to_datetime(np.load(out/'dates.npy')),columns=np.load(out/'station_ids.npy'))
        static=pd.read_csv(out/'static.csv').set_index('station_id')
        cfg=json.loads((ROOT/'results_caravan_daily_manifest_daily_final_20260809.json').read_text())['config']
    ds=GapImputationDataset(flow,static,cfg)
    train,val,test=split_stations(ds.station_ids,cfg['split'])
    roles={s:'train' if s in train else 'validation' if s in val else 'test' for s in ds.station_ids}
    saved=pd.read_csv(out/'selected_donors.csv.gz')
    for row in saved.itertuples():
        g=ds.gaps[row.gap_index]
        ds.donor_cache[(g.station_id,g.start,g.end)]=[{'donor_id':s,'weight':w} for s,w in zip(json.loads(row.donor_ids),json.loads(row.weights))]
    if protocol=='original':return ds,cfg,roles
    views=[]
    for phase,forbidden in [('train',val|test),('validation',test)]:
        v=copy.copy(ds);v.z=ds.z.copy();js=np.array([ds.sid2idx[s] for s in forbidden])
        mask=np.zeros_like(ds.is_gap_month);mask[:,js]=ds.is_gap_month[:,js]
        v.z[mask]=np.nan
        assert not np.isfinite(v.z[mask]).any()
        allowed=~mask
        assert np.array_equal(v.z[allowed],ds.z[allowed],equal_nan=True)
        v.donor_selector=DonorSelector(v.z,v.station_ids,v.coords,cfg['donors']);v.donor_cache={}
        views.append(v)
    routed=SplitInputDataset(ds,*views,roles)
    changes=[];parity=[]
    sampled=set(np.linspace(0,len(ds.gaps)-1,150,dtype=int))
    for i,g in enumerate(ds.gaps):
        role=roles[g.station_id];v=routed.view(g);key=(g.station_id,g.start,g.end)
        if role!='test':
            donors,*_=select_vector(v,g);v.donor_cache[key]=donors
        else:donors=ds.donor_cache[key]
        orig=ds.donor_cache[key]
        def supported(view,refs):
            jj=[ds.sid2idx[d['donor_id']] for d in refs]
            return int(np.isfinite(view.z[g.start:g.end+1,jj]).any(1).sum()) if jj else 0
        changes.append({'gap_index':i,'split':role,'station_id':g.station_id,'length':g.length,
                        'original_donors':len(orig),'isolated_donors':len(donors),
                        'original_supported_times':supported(ds,orig),'isolated_supported_times':supported(v,donors),
                        'same_donor_ids':[d['donor_id'] for d in orig]==[d['donor_id'] for d in donors]})
        if i in sampled:
            original_sample=ds[i];new_sample=routed[i]
            # Target-only inputs and targets are invariant in every split.
            for name in ['ctx_pre_z','ctx_post_z','gap_phase','gap_truth_flow','gap_months']:
                assert np.array_equal(original_sample[name],new_sample[name],equal_nan=True),(i,name)
            if role=='test':
                for name in ['donor_gap_z','donor_mask','donor_ctx_z','donor_weight']:
                    assert np.array_equal(original_sample[name],new_sample[name],equal_nan=True),(i,name)
            parity.append({'gap_index':i,'split':role,'target_only_inputs_and_targets_exact':True,
                           'test_reference_inputs_exact':True if role=='test' else None})
    dest=out/'isolation_protocol';dest.mkdir(exist_ok=True)
    pd.DataFrame(changes).to_csv(dest/'support_change_by_gap.csv.gz',index=False)
    pd.DataFrame(parity).to_csv(dest/'input_invariance_checks.csv',index=False)
    grouped=pd.DataFrame(changes).groupby('split').agg(gaps=('gap_index','size'),same_reference_sets=('same_donor_ids','sum'),
            original_supported_times=('original_supported_times','sum'),isolated_supported_times=('isolated_supported_times','sum'),times=('length','sum')).reset_index()
    grouped.to_csv(dest/'support_change_summary.csv',index=False)
    jwrite(dest/'validation.json',{'status':'PASS','protocol':'train excludes validation+test pseudo-gaps; validation excludes test pseudo-gaps; test target-wise access unchanged',
                                 'mask_assertions_executed':True,'sampled_input_invariance_checks':len(parity),
                                 'target_only_input_and_loss_targets_invariant':True,'test_input_mask_unchanged':True,
                                 'models_retrained':False,'configuration':cfg,'support_change_summary':grouped.to_dict('records')})
    return routed,cfg,roles
