#!/usr/bin/env python3
"""Source-cohort matched NSE/event scoring for completed isolated reruns only."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import numpy as np
import pandas as pd
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(HERE))
from audit_exposure import sha,jwrite
from scripts import analyze_extreme_event_observability as event
from src.utils.metrics import nse,peak_metrics

FROZEN=ROOT/'V39.1/figures/source_data/Fig2'
SOURCE_EVENTS=ROOT/'figures/fig_nature/fig1_style_preview_20260905/source_data_final/TableS20_matched_station_final.csv'
METRICS=['nse','high_f1','low_f1','high_nmae','low_log_mae','high_abs_bias','peak_timing_error']
ERROR={'high_nmae','low_log_mae','high_abs_bias','peak_timing_error'}


def corrected_monthly_thresholds():
    data=ROOT/'boundary_validation_20260922/data'
    ids=np.load(data/'station_ids.npy');q=np.load(data/'flow_qc20_dedup.npy',mmap_mode='r')
    testids=np.load(HERE/'monthly/test_station_ids.npy');hidden=np.load(HERE/'monthly/test_hidden_mask.npy')
    lookup={s:i for i,s in enumerate(ids)};rows=[]
    for j,sid in enumerate(testids):
        values=np.asarray(q[:,lookup[sid]],dtype=float).copy();values[hidden[:,j]]=np.nan
        visible=values[np.isfinite(values)]
        if len(visible)<24:continue
        quant=np.quantile(visible,[.10,.25,.75,.90])
        rows.append(dict(station_id=sid,q10=quant[0],q25=quant[1],q75=quant[2],q90=quant[3],
                         n_visible_months=len(visible),n_hidden_months=int(hidden[:,j].sum())))
    return pd.DataFrame(rows)


def dump(scale,arch,mode):
    tag=f'{arch}_{mode}__unc' if scale=='monthly' else f'caravan_daily_final_20260809_{arch}_{mode}'
    return ROOT/'results/raw'/tag/'predictions_long.csv'


def prepare(single,donor,scale,thresholds):
    if scale=='daily':single=event.add_daily_gap_ids(single);donor=event.add_daily_gap_ids(donor)
    keys=['station_id','date'];need=keys+['obs','pred','gap_id']
    d=single[need].rename(columns={'pred':'pred_single','gap_id':'gap_id_single'}).merge(
        donor[need].rename(columns={'obs':'obs_donor','pred':'pred_donor','gap_id':'gap_id_donor'}),on=keys,how='outer',indicator=True,validate='one_to_one')
    assert (d._merge=='both').all(),d._merge.value_counts()
    assert np.allclose(d.obs,d.obs_donor,rtol=1e-12,atol=1e-12,equal_nan=True)
    d['gap_id']=d.gap_id_single;d['_date_dt']=pd.to_datetime(d.date)
    return d.merge(thresholds,on='station_id',how='inner')


def station_event_rows(merged,scale,arch):
    rows=[]
    for sid,g in merged.groupby('station_id',sort=False):
        a=event.station_metrics(g,'pred_single',scale);b=event.station_metrics(g,'pred_donor',scale)
        if not a or not b:continue
        # Preserve the final near-constant guard, including the previously fixed
        # hysets_10270940 case, without selecting on achieved prediction skill.
        if np.sum((g.obs.to_numpy()-g.obs.mean())**2)<1e-12:a['nse']=b['nse']=np.nan
        row={'scale':scale,'architecture':arch.upper(),'station_id':sid}
        for metric in METRICS:
            row[f'single_{metric}']=a[metric];row[f'donor_{metric}']=b[metric]
            row[f'improvement_{metric}']=(a[metric]-b[metric]) if metric in ERROR else (b[metric]-a[metric])
        rows.append(row)
    return pd.DataFrame(rows)


def main():
    p=argparse.ArgumentParser();p.add_argument('--source-audit-only',action='store_true');p.add_argument('--allow-partial',action='store_true');args=p.parse_args()
    out=HERE/'analysis';out.mkdir(exist_ok=True)
    old_access=pd.read_csv(FROZEN/'access_stations.csv');old_events=pd.read_csv(SOURCE_EVENTS)
    source_checks=[];thresholdnotes=[];eventframes=[];legacy_eventframes=[];event_change_frames=[];accessframes=[];newrows=[];unfinished=[];sources={}
    for pth in [FROZEN/'access_stations.csv',SOURCE_EVENTS,ROOT/'scripts/analyze_extreme_event_observability.py',ROOT/'src/utils/metrics.py']:
        sources[str(pth.relative_to(ROOT))]=sha(pth)
    for scale in ['monthly','daily']:
        keys=pd.read_csv(dump(scale,'lstm','single'),usecols=['station_id','date'])
        thresholds=(event.visible_thresholds_monthly if scale=='monthly' else event.visible_thresholds_daily)(keys)
        thresholds.to_csv(out/f'{scale}_original_event_thresholds.csv',index=False)
        strict_thresholds=corrected_monthly_thresholds() if scale=='monthly' else thresholds
        strict_thresholds.to_csv(out/f'{scale}_visible_event_thresholds.csv',index=False)
        if scale=='monthly':
            keyset={d.strftime('%Y-%m') for d in event.MONTH_IDX}
            matched=sum(str(x) in keyset for x in keys.date)
            thresholdnotes.append({'scale':scale,'original_threshold_function':'visible_thresholds_monthly',
                'stored_date_examples':keys.date.iloc[:3].tolist(),'source_lookup_format':'YYYY-MM','matched_hidden_keys':matched,
                'meaning':'Reproduces original scoring thresholds. Zero matches means the old function did not remove the YYYY-MM-DD prediction keys; this concerns evaluation label definition, not new model inputs.'})
        else:
            cache=np.load(ROOT/'_cache_caravan_daily.npz',allow_pickle=False)
            matched=int(keys.date.astype(str).isin(set(cache['dates'].astype(str))).sum())
            assert matched==len(keys)
            thresholdnotes.append({'scale':scale,'original_threshold_function':'visible_thresholds_daily','hidden_keys':len(keys),
                'matched_hidden_keys':matched,'all_hidden_keys_removed':True,'definition_changed':False})
        for ai,arch in enumerate(['lstm','brits','saits']):
            singlepath=dump(scale,arch,'single');oldpath=dump(scale,arch,'donor')
            for pth in [singlepath,oldpath]:sources[str(pth.relative_to(ROOT))]=sha(pth)
            single=pd.read_csv(singlepath);old=pd.read_csv(oldpath)
            oldmerged=prepare(single,old,scale,thresholds)
            reproduced=station_event_rows(oldmerged,scale,arch)
            frozen=old_events[(old_events.scale==scale)&(old_events.architecture==arch.upper())]
            compare=frozen.merge(reproduced,on=['scale','architecture','station_id'],suffixes=('_source','_recomputed'),validate='one_to_one')
            numeric=[c for c in frozen.columns if c not in ['scale','architecture','station_id']]
            exact=len(compare)==len(frozen)==len(reproduced)
            maxdiff=0.
            for c in numeric:
                a=compare[c+'_source'].to_numpy();b=compare[c+'_recomputed'].to_numpy()
                exact=exact and np.allclose(a,b,rtol=1e-10,atol=1e-10,equal_nan=True)
                ok=np.isfinite(a)&np.isfinite(b)
                if ok.any():maxdiff=max(maxdiff,float(np.max(np.abs(a[ok]-b[ok]))))
            source_checks.append({'scale':scale,'architecture':arch.upper(),'frozen_station_rows':len(frozen),
                'recomputed_station_rows':len(reproduced),'source_event_metrics_reproduced':bool(exact),'max_absolute_difference':maxdiff})
            assert exact,(scale,arch,source_checks[-1])
            if args.source_audit_only:continue
            folder=HERE/'reruns'/scale/'isolated'/arch
            if not (folder/'completion.json').exists():unfinished.append(f'{scale}/{arch}');continue
            if scale=='monthly':files=list((folder/'results/raw').glob('*/predictions_long.csv'));assert len(files)==1;predpath=files[0]
            else:predpath=folder/'predictions_long.csv'
            sources[str(predpath.relative_to(ROOT))]=sha(predpath)
            donor=pd.read_csv(predpath)
            legacy=prepare(single,donor,scale,thresholds)
            new_original_events=station_event_rows(legacy,scale,arch)
            legacy_eventframes.append(new_original_events)
            d=prepare(single,donor,scale,strict_thresholds)
            ev=station_event_rows(d,scale,arch);eventframes.append(ev)
            idcols=['scale','architecture','station_id']
            stages=[]
            for label,frame in [('old_predictions_original_events',reproduced),('new_predictions_original_events',new_original_events),('new_predictions_corrected_events',ev)]:
                stages.append(frame.rename(columns={c:label+'__'+c for c in frame.columns if c not in idcols}))
            event_change_frames.append(stages[0].merge(stages[1],on=idcols,how='outer',validate='one_to_one').merge(stages[2],on=idcols,how='outer',validate='one_to_one'))
            label='Monthly GSIM' if scale=='monthly' else 'Daily Caravan'
            cohort=old_access[(old_access.scale==label)&(old_access.architecture==arch.upper())]
            # NSE uses all prediction keys, independent of event threshold eligibility.
            merged=single[['station_id','date','obs','pred']].rename(columns={'pred':'single'}).merge(
                donor[['station_id','date','obs','pred']].rename(columns={'pred':'donor','obs':'obs_new'}),on=['station_id','date'],validate='one_to_one')
            assert len(merged)==len(single)==len(donor)
            scores=[]
            for sid,g in merged.groupby('station_id',sort=False):
                a=nse(g.obs,g.single);b=nse(g.obs,g.donor)
                peak=peak_metrics(g.obs,g.donor)
                scores.append({'station_id':sid,'NSE_single_recomputed':a,'NSE_donor_new':b,'n_scored_times':len(g),**peak})
            scores=pd.DataFrame(scores)
            paired=cohort.merge(scores,on='station_id',validate='one_to_one')
            assert len(paired)==len(cohort)
            assert np.allclose(paired.NSE_single,paired.NSE_single_recomputed,rtol=1e-10,atol=1e-10,equal_nan=True)
            assert np.isfinite(paired.NSE_donor_new).all(),'Do not silently remove failed rerun targets.'
            paired['old_NSE_donor']=paired.NSE_donor;paired['old_delta']=paired.delta
            paired['NSE_donor']=paired.NSE_donor_new;paired['delta']=paired.NSE_donor-paired.NSE_single
            paired['new_minus_old_donor_NSE']=paired.NSE_donor-paired.old_NSE_donor
            accessframes.append(paired)
            newrows.append({'scale':scale,'architecture':arch.upper(),'status':'COMPLETED_AND_SCORED','n_paired_stations':len(paired),
                'median_paired_gain':float(paired.delta.median()),'median_new_minus_old_donor_nse':float(paired.new_minus_old_donor_NSE.median()),
                'single_source_prediction_sha256':sources[str(singlepath.relative_to(ROOT))],
                'strict_donor_prediction_sha256':sources[str(predpath.relative_to(ROOT))]})
    pd.DataFrame(source_checks).to_csv(out/'source_event_reproduction_checks.csv',index=False)
    jwrite(out/'original_event_threshold_definition_audit.json',thresholdnotes)
    if args.source_audit_only:
        jwrite(out/'source_scoring_audit.json',{'status':'PASS','source_event_reproduction_checks':source_checks,'source_sha256':sources,
            'note':'Exact original evaluation reproduced; monthly date-format issue is explicitly recorded separately. No model result is produced by this audit.'})
        print('Source event scores reproduced for all six architecture/scale pairs.');return
    # DAT predictions and history-agreement features do not change; rescore their
    # event labels with the same corrected visible-history thresholds.
    dat_station,dat_quartiles,dat_selective=event.observability_risk_curve('strict_calibration_20260831_v3',corrected_monthly_thresholds())
    dat_station.to_csv(out/'DAT_observability_station.csv',index=False)
    dat_quartiles.to_csv(out/'quartiles.csv',index=False)
    dat_selective.to_csv(out/'DAT_selective_risk.csv',index=False)
    dat_counts=dat_station.groupby('information_quartile',observed=True).agg(**{f'n_{m}':(m,'count') for m in METRICS}).reset_index()
    dat_counts.to_csv(out/'quartile_metric_n.csv',index=False)
    dat_all=dat_station.groupby('information_quartile',observed=True).agg(**{f'median_{m}':(m,'median') for m in METRICS}).reset_index()
    dat_all.to_csv(out/'DAT_quartile_all_event_metrics.csv',index=False)
    if unfinished and not args.allow_partial:raise RuntimeError(f'Unfinished models: {unfinished}; no complete summary declared.')
    if not accessframes:print('No completed models yet.');return
    access=pd.concat(accessframes,ignore_index=True);events=pd.concat(eventframes,ignore_index=True)
    access.to_csv(out/'paired.csv',index=False);events.to_csv(out/'station_scores.csv',index=False)
    pd.concat(legacy_eventframes,ignore_index=True).to_csv(out/'audit_new_predictions_original_event_definition.csv',index=False)
    pd.concat(event_change_frames,ignore_index=True).to_csv(out/'audit_event_prediction_and_definition_changes.csv',index=False)
    access[['station_id','NSE_single','NSE_donor','delta','architecture','scale']].to_csv(out/'access_stations.csv',index=False)
    accesssummary=[];eventsummary=[]
    for si,label in enumerate(['Monthly GSIM','Daily Caravan']):
        for ai,arch in enumerate(['LSTM','BRITS','SAITS']):
            d=access[(access.scale==label)&(access.architecture==arch)]
            if not len(d):continue
            v=d.delta.to_numpy();seed=10+si*3+ai;rng=np.random.default_rng(seed)
            boot=np.median(rng.choice(v,size=(1000,len(v)),replace=True),axis=1)
            q=np.quantile(v,[.025,.25,.5,.75,.975]);ci=np.quantile(boot,[.025,.975])
            accesssummary.append(dict(benchmark=label,architecture=arch,n_paired_stations=len(d),n_finite_delta=len(v),
                target_only_median_nse=float(d.NSE_single.median()),donor_aware_median_nse=float(d.NSE_donor.median()),paired_delta_median=q[2],
                median_ci_lo=ci[0],median_ci_hi=ci[1],p025=q[0],q25=q[1],q75=q[3],p975=q[4],
                n_below_display=int((v<-.25).sum()),n_above_display=int((v>1.25).sum()),display_low=-.25,display_high=1.25,
                bootstrap_replicates=1000,bootstrap_seed=seed,bootstrap_unit='paired station',interval='percentile 95%'))
    for (scale,arch),d in events.groupby(['scale','architecture'],sort=False):
        ai=['LSTM','BRITS','SAITS'].index(arch)
        for mi,metric in enumerate(METRICS):
            v=d['improvement_'+metric].to_numpy(float);v=v[np.isfinite(v)]
            med,lo,hi=event.bootstrap_median(v,1000+ai*100+mi)
            eventsummary.append(dict(scale=scale,architecture=arch,metric=metric,orientation='positive = donor-aware better',
                n_stations=len(v),median_improvement=med,ci_lo=lo,ci_hi=hi,win_pct=100*float(np.mean(v>0))))
    pd.DataFrame(accesssummary).to_csv(out/'access_summary.csv',index=False)
    pd.DataFrame(eventsummary).to_csv(out/'event_summary.csv',index=False)
    jwrite(out/'rerun_analysis_manifest.json',{'status':'PARTIAL' if unfinished else 'COMPLETED','completed':newrows,'unfinished':unfinished,
        'source_sha256':sources,'old_scoring_reproduced':True,'original_NSE_cohorts_preserved':True,
        'monthly_event_thresholds':'QC20 benchmark raw flow; all generated target pseudo-gaps excluded; common fixed q10/q90/IQR for single and donor predictions',
        'daily_event_thresholds':'Original threshold function verified to remove all hidden prediction-date keys; unchanged',
        'nonfinite_predictions_not_silently_removed':True,'environment_caution':'The original Torch/device environment was not fully recorded or reproduced; new-minus-old changes may include execution-environment effects and include explicit monthly event-threshold correction, not an isolated causal estimate of mask contamination.'})
    print(pd.DataFrame(accesssummary)[['benchmark','architecture','n_paired_stations','paired_delta_median']].to_string(index=False))


if __name__=='__main__':main()
