# -*- coding: utf-8 -*-
"""FULL DAILY benchmark on the multi-region Caravan collection — the daily
analogue of monthly Table 1.  *** classical = CPU; deep = GPU; user-run ***

Routes Caravan daily through the SAME leakage-safe pipeline as the monthly benchmark
(src/data/dataset.GapImputationDataset with season_period=366), so all methods share the
same per-station leakage-safe normalization, donor pool, masks and per-station median NSE.

Methods: 15 ranked methods matching the monthly benchmark, plus one diagnostic-only
DAT + two-sided-context control.

Run (build daily matrix once, then all methods):
  python exp_caravan_full_benchmark.py --limit_per_dataset 0           # all regions/stations (heavy)
  python exp_caravan_full_benchmark.py --limit_per_dataset 200 --smoke # quick check
Writes results_caravan_full_master.csv (method, NSE_median, alpha_median, n).
"""
from __future__ import annotations
import os, sys, glob, time, argparse, csv, json, re
from dataclasses import dataclass
import numpy as np, pandas as pd

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from src.data.dataset import GapImputationDataset, split_stations
from src.train.collate import collate_numpy, to_torch
from src.utils.metrics import evaluate_by_station
from src.baselines.classical import seasonal_mean, idw, similarity_reg, ar1, donor_recursive, rf_donor, gbm_donor

def dat_context(ds, gap):
    """Training-free control: blend donor-anomaly transfer with a two-sided local
    interpolation from the target's own visible edges (trust local near the gap edges,
    donors in the middle). Isolates 'using two-sided context' from 'deep nonlinearity'."""
    L = gap.length; g0, g1 = gap.start, gap.end; ti = ds.sid2idx[gap.station_id]
    months = ds.months[g0:g1 + 1]; tr = ds.transformers[gap.station_id]
    donors = ds._donors(gap)
    if donors:
        idx = [ds.station_ids.index(d["donor_id"]) for d in donors]; w = np.array([d["weight"] for d in donors], float)
        Z = ds.z[g0:g1 + 1, idx]; M = np.isfinite(Z); W = M * w[None, :]; den = W.sum(1)
        zdon = np.where(den > 0, np.nansum(np.nan_to_num(Z) * W, 1) / np.maximum(den, 1e-9), 0.0)
    else:
        zdon = np.zeros(L)
    tz = ds.z[:, ti]; pre = tz[:g0]; post = tz[g1 + 1:]
    pidx = np.where(np.isfinite(pre))[0]; qidx = np.where(np.isfinite(post))[0]
    zL = pre[pidx[-1]] if pidx.size else 0.0; zR = post[qidx[0]] if qidx.size else 0.0
    t = np.arange(1, L + 1) / (L + 1.0); zloc = (1 - t) * zL + t * zR
    tau = max(2.0, L / 4.0); d_edge = np.minimum(np.arange(L), np.arange(L)[::-1])
    wloc = np.exp(-d_edge / tau); zhat = wloc * zloc + (1 - wloc) * zdon
    return tr.inverse_transform(zhat, months)

ROOT = os.path.dirname(os.path.abspath(__file__))


@dataclass(frozen=True)
class MethodSpec:
    name: str
    slug: str
    kind: str
    fn: object | None = None
    model_name: str | None = None
    use_donor: bool = False
    include_in_ranking: bool = True


def method_specs():
    """Stable method names/slugs shared by the runner and final audit."""
    return [
        MethodSpec("Seasonal mean", "seasonal_mean", "classical", seasonal_mean),
        MethodSpec("AR(1)", "ar1", "classical", ar1),
        MethodSpec("DTRR (recursive)", "dtrr_recursive", "classical", donor_recursive),
        MethodSpec("Similarity reg", "similarity_reg", "classical", similarity_reg),
        MethodSpec("DA-transfer (DAT)", "dat", "classical", idw),
        MethodSpec("RF (+donor)", "rf_donor", "classical", rf_donor),
        MethodSpec("GBM (+donor)", "gbm_donor", "classical", gbm_donor),
        MethodSpec("DAT + two-sided context", "dat_two_sided_context", "classical",
                   dat_context, include_in_ranking=False),
        MethodSpec("LSTM (single)", "lstm_single", "deep", model_name="lstm"),
        MethodSpec("LSTM (+donor)", "lstm_donor", "deep", model_name="lstm", use_donor=True),
        MethodSpec("BRITS (single)", "brits_single", "deep", model_name="brits"),
        MethodSpec("BRITS (+donor)", "brits_donor", "deep", model_name="brits", use_donor=True),
        MethodSpec("SAITS (single)", "saits_single", "deep", model_name="saits"),
        MethodSpec("SAITS (+donor)", "saits_donor", "deep", model_name="saits", use_donor=True),
        MethodSpec("GRIN (+donor)", "grin_donor", "deep", model_name="grin", use_donor=True),
        MethodSpec("MG-STGAI", "mgstgai", "mg"),
    ]


def safe_run_id(value):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value or "").strip("_")


def dump_tag(run_id, slug):
    rid = safe_run_id(run_id)
    return "caravan_%s%s" % ((rid + "_") if rid else "", slug)


def output_path(stem, run_id, suffix="csv"):
    rid = safe_run_id(run_id)
    tail = "_%s" % rid if rid else ""
    return os.path.join(ROOT, "%s%s.%s" % (stem, tail, suffix))

def _dump(tag, recs, run_id=""):
    try:
        import csv as _csv
        d = os.path.join(ROOT, "results", "raw", dump_tag(run_id, tag)); os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "predictions_long.csv"), "w", newline="") as f:
            w = _csv.writer(f); w.writerow(["station_id", "date", "obs", "pred"]); w.writerows(recs)
    except Exception as e:
        raise RuntimeError("failed to dump %s: %s" % (tag, e)) from e

def build_caravan_daily(limit_per_dataset=0):
    base = os.path.join(ROOT, "Caravan", "Caravan", "Caravan")
    tsroot = os.path.join(base, "timeseries", "csv"); attrroot = os.path.join(base, "attributes")
    dsets = sorted([d for d in os.listdir(tsroot) if os.path.isdir(os.path.join(tsroot, d))])
    print("[caravan] datasets:", dsets)
    series = {}; latlon = {}
    for dn in dsets:
        files = sorted(glob.glob(os.path.join(tsroot, dn, "*.csv")))
        if limit_per_dataset: files = files[:limit_per_dataset]
        for f in files:
            sid = os.path.basename(f)[:-4]
            try:
                d = pd.read_csv(f, usecols=["date", "streamflow"]); d["date"] = pd.to_datetime(d["date"])
                series[sid] = d.set_index("date")["streamflow"]
            except Exception: pass
        ap = os.path.join(attrroot, dn, f"attributes_other_{dn}.csv")
        if os.path.exists(ap):
            at = pd.read_csv(ap).set_index("gauge_id")
            for s in at.index:
                try: latlon[s] = (float(at.at[s, "gauge_lat"]), float(at.at[s, "gauge_lon"]))
                except Exception: pass
        print("  loaded %-12s total=%d" % (dn, len(series)))
    flow = pd.DataFrame(series).sort_index().loc["1990-01-01":"2020-12-31"]
    keep = [c for c in flow.columns if flow[c].notna().sum() >= 1825]; flow = flow[keep]
    n_before_dedup = flow.shape[1]
    # 2026-07 复核"必须修"第 2 项：剔除跨/内子集孪生站（camels↔hysets 同 USGS 编号等，
    # 否则 similarity 等拟合方法把"另一个自己"当 donor，NSE 虚高到 ~0.99）。
    from exp_regulation import dedup_stations
    src_map = {}
    for dn in dsets:
        for f in sorted(glob.glob(os.path.join(tsroot, dn, "*.csv"))):
            src_map[os.path.basename(f)[:-4]] = dn
    flow, _ = dedup_stations(flow, {c: src_map.get(c, "?") for c in flow.columns})
    n_dropped = n_before_dedup - flow.shape[1]
    if not limit_per_dataset and n_dropped != 459:
        raise RuntimeError("Caravan dedup acceptance failed: expected 459 drops, got %d" % n_dropped)
    print("[accept] dedup dropped=%d stations; retained=%d" %
          (n_dropped, flow.shape[1]))
    static = pd.DataFrame({"latitude": [latlon.get(s, (np.nan, np.nan))[0] for s in flow.columns],
                           "longitude": [latlon.get(s, (np.nan, np.nan))[1] for s in flow.columns]},
                          index=flow.columns)
    return flow, static

def make_cfg(smoke=False):
    return {"features": {"use_log1p": True, "deseasonalize": True, "per_station_standardize": True, "season_period": 366},
            "pseudo_gap": {"seed": 42, "gaps_per_station": 2 if smoke else 3,
                           "length_strata": [[7, 30], [31, 90], [91, 180]], "min_context": 365, "edge_margin": 30},
            "donors": {"max_donors": 8, "max_distance_km": 800, "min_overlap_months": 720, "min_precorr": 0.2, "precorr_window": 1800},   # = monthly (800 km, 24-mo overlap, 60-mo window) matched by physical duration
            "split": {"test_station_frac": 0.15, "val_station_frac": 0.15, "seed": 7},
            "classical": {"reg_window": 1825, "ar_window": 1825, "dtrr_window": 1825},  # daily ~5yr fit windows (scale-matched)
            "train": {"seq_pad": 14, "batch_size": 32}}

def iter_batches(ds, idx, bs, pad, shuffle=True, rng=None):
    idx = list(idx)
    if shuffle: (rng or np.random).shuffle(idx)
    for i in range(0, len(idx), bs): yield collate_numpy([ds[j] for j in idx[i:i + bs]], pad)

def seed_torch(seed=0):
    import torch
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True, warn_only=True)
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.benchmark = False
    if hasattr(torch.backends, "cuda"):
        if hasattr(torch.backends.cuda, "enable_flash_sdp"):
            torch.backends.cuda.enable_flash_sdp(False)
        if hasattr(torch.backends.cuda, "enable_mem_efficient_sdp"):
            torch.backends.cuda.enable_mem_efficient_sdp(False)
        if hasattr(torch.backends.cuda, "enable_math_sdp"):
            torch.backends.cuda.enable_math_sdp(True)


def mg_physical_kge_loss(z_hat, batch):
    """Physical-flow KGE term; kept separate so protocol tests can exercise it."""
    from src.train.inverse import inverse_transform_torch
    from src.train.losses import kge_decomposition_loss

    flow_hat = inverse_transform_torch(
        z_hat, batch["inv_sigma"], batch["inv_mu"], batch["inv_clim"], batch["_flags"]
    )
    mask = batch["gap_mask"] * batch["target_flow_valid"]
    return kge_decomposition_loss(flow_hat, batch["target_flow"], mask)

def eval_classical(ds, te_gaps, fn, tag=None, dump=False, run_id=""):
    ob, pb = {}, {}; recs = []
    for g in te_gaps:
        try: pr = fn(ds, g)
        except Exception: continue
        j = ds.sid2idx[g.station_id]; truth = ds.flow[g.start:g.end + 1, j]; ok = np.isfinite(truth)
        if ok.sum() < 2: continue
        ob.setdefault(g.station_id, []).append(truth[ok]); pb.setdefault(g.station_id, []).append(np.asarray(pr)[ok])
        if dump:
            dts = [d.strftime('%Y-%m-%d') for d in ds.index[g.start:g.end + 1]]
            pra = np.asarray(pr)
            for t in range(g.end - g.start + 1):
                if np.isfinite(truth[t]): recs.append([g.station_id, dts[t], float(truth[t]), float(pra[t])])
    if dump and tag: _dump(tag, recs, run_id)
    if not ob: return {}
    ob = {k: np.concatenate(v) for k, v in ob.items()}; pb = {k: np.concatenate(v) for k, v in pb.items()}
    _, s = evaluate_by_station(ob, pb, peak_quantile=0.9); return s

def train_eval_deep(model_name, use_donor, ds, tr, va, te, cfg, args, tag=None, dump=False, run_id=""):
    import torch
    from src.models.baselines_deep import get_model
    dev = "cuda" if torch.cuda.is_available() else "cpu"; seed_torch(0)
    model = get_model(model_name, hidden=64, use_donor=use_donor).to(dev); opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    import torch.nn.functional as F
    def mh(zh, b):
        z = b["target_z"]; mk = b["gap_mask"] * b["target_valid"]
        return (F.huber_loss(zh, z, delta=1.0, reduction="none") * mk).sum() / mk.sum().clamp(min=1.0)
    def ev(idx):
        model.eval(); ob, pb = {}, {}
        with torch.no_grad():
            for bn, meta in iter_batches(ds, idx, cfg["train"]["batch_size"], cfg["train"]["seq_pad"], False):
                zh = model(to_torch(bn, dev))["z_hat"].cpu().numpy()
                for bi, m in enumerate(meta):
                    L = m["length"]; fh = m["transformer"].inverse_transform(zh[bi, :L], m["gap_months"])
                    tr_ = m["gap_truth_flow"]; ok = np.isfinite(tr_)
                    if ok.sum() < 2: continue
                    ob.setdefault(m["station_id"], []).append(tr_[ok]); pb.setdefault(m["station_id"], []).append(fh[ok])
        if not ob: return float("nan"), {}, 0
        ob = {k: np.concatenate(v) for k, v in ob.items()}; pb = {k: np.concatenate(v) for k, v in pb.items()}
        _, s = evaluate_by_station(ob, pb, peak_quantile=0.9); return s.get("NSE_median", float("nan")), s, s.get("n_stations", 0)
    best, bad, bs = -1e9, 0, None; rng = np.random.default_rng(0); epmax = 6 if args.smoke else args.epochs
    for ep in range(1, epmax + 1):
        model.train()
        for bn, _ in iter_batches(ds, tr, cfg["train"]["batch_size"], cfg["train"]["seq_pad"], True, rng):
            b = to_torch(bn, dev); out = model(b); loss = mh(out["z_hat"], b)
            if "z_self_f" in out:
                loss = loss + 0.3 * ((out["z_self_f"] - out["z_self_b"]) ** 2 * b["gap_mask"]).sum() / b["gap_mask"].sum().clamp(min=1.0)
            opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0); opt.step()
        v, _, _ = ev(va)
        if v > best: best, bad, bs = v, 0, {k: vv.detach().cpu().clone() for k, vv in model.state_dict().items()}
        else:
            bad += 1
            if bad >= args.patience: break
    if bs is not None: model.load_state_dict(bs)
    if dump and tag:
        import torch; model.eval(); recs = []
        with torch.no_grad():
            for bn, meta in iter_batches(ds, te, cfg["train"]["batch_size"], cfg["train"]["seq_pad"], False):
                zh = model(to_torch(bn, dev))["z_hat"].cpu().numpy()
                for bi, m in enumerate(meta):
                    L = m["length"]; fh = m["transformer"].inverse_transform(zh[bi, :L], m["gap_months"])
                    tr_ = m["gap_truth_flow"]; dts = m.get("gap_dates") or [""] * L
                    for t in range(L):
                        if np.isfinite(tr_[t]): recs.append([m["station_id"], dts[t], float(tr_[t]), float(fh[t])])
        _dump(tag, recs, run_id)
    return ev(te)

def train_eval_mg(ds, tr, va, te, cfg, args, tag=None, dump=False, run_id=""):
    import torch
    from src.models.stage2 import TwoStageImputer
    from src.train.losses import stage1_loss
    dev = "cuda" if torch.cuda.is_available() else "cpu"; seed_torch(0)
    model = TwoStageImputer(hidden=64, use_stage2=True).to(dev); opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    def ev(idx):
        model.eval(); ob, pb = {}, {}
        with torch.no_grad():
            for bn, meta in iter_batches(ds, idx, cfg["train"]["batch_size"], cfg["train"]["seq_pad"], False):
                zh = model(to_torch(bn, dev))["z_hat"].cpu().numpy()
                for bi, m in enumerate(meta):
                    L = m["length"]; fh = m["transformer"].inverse_transform(zh[bi, :L], m["gap_months"])
                    tr_ = m["gap_truth_flow"]; ok = np.isfinite(tr_)
                    if ok.sum() < 2: continue
                    ob.setdefault(m["station_id"], []).append(tr_[ok]); pb.setdefault(m["station_id"], []).append(fh[ok])
        if not ob: return float("nan"), {}, 0
        ob = {k: np.concatenate(v) for k, v in ob.items()}; pb = {k: np.concatenate(v) for k, v in pb.items()}
        _, s = evaluate_by_station(ob, pb, peak_quantile=0.9); return s.get("NSE_median", float("nan")), s, s.get("n_stations", 0)
    best, bad, bs = -1e9, 0, None; rng = np.random.default_rng(0); epmax = 6 if args.smoke else args.epochs
    for ep in range(1, epmax + 1):
        model.train()
        for bn, _ in iter_batches(ds, tr, cfg["train"]["batch_size"], cfg["train"]["seq_pad"], True, rng):
            b = to_torch(bn, dev); out = model(b); loss, _ = stage1_loss(out, b)
            loss = loss + 0.5 * mg_physical_kge_loss(out["z_hat"], b)
            opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0); opt.step()
        v, _, _ = ev(va)
        if v > best: best, bad, bs = v, 0, {k: vv.detach().cpu().clone() for k, vv in model.state_dict().items()}
        else:
            bad += 1
            if bad >= args.patience: break
    if bs is not None: model.load_state_dict(bs)
    if dump and tag:
        import torch; model.eval(); recs = []
        with torch.no_grad():
            for bn, meta in iter_batches(ds, te, cfg["train"]["batch_size"], cfg["train"]["seq_pad"], False):
                zh = model(to_torch(bn, dev))["z_hat"].cpu().numpy()
                for bi, m in enumerate(meta):
                    L = m["length"]; fh = m["transformer"].inverse_transform(zh[bi, :L], m["gap_months"])
                    tr_ = m["gap_truth_flow"]; dts = m.get("gap_dates") or [""] * L
                    for t in range(L):
                        if np.isfinite(tr_[t]): recs.append([m["station_id"], dts[t], float(tr_[t]), float(fh[t])])
        _dump(tag, recs, run_id)
    return ev(te)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit_per_dataset", type=int, default=0)
    ap.add_argument("--epochs", type=int, default=80)
    ap.add_argument("--patience", type=int, default=12)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--skip_deep", action="store_true", help="classical only (CPU)")
    ap.add_argument("--dump", action="store_true", help="dump per-station predictions to results/raw/caravan_*")
    ap.add_argument("--run_id", default="", help="versioned output suffix used by the one-click runner")
    args = ap.parse_args()
    args.run_id = safe_run_id(args.run_id)
    t0 = time.time()

    flow, static = build_caravan_daily(args.limit_per_dataset)
    cfg = make_cfg(args.smoke)
    ds = GapImputationDataset(flow, static, cfg)
    tr_s, va_s, te_s = split_stations(flow.columns, cfg["split"])
    te_gaps = [g for g in ds.gaps if g.station_id in te_s]
    tr = [i for i, g in enumerate(ds.gaps) if g.station_id in tr_s]
    va = [i for i, g in enumerate(ds.gaps) if g.station_id in va_s]
    te = [i for i, g in enumerate(ds.gaps) if g.station_id in te_s]
    if not te:
        raise RuntimeError("no evaluable daily test gaps were generated")
    print("[build] stations=%d test_stations=%d gaps(train/val/test)=%d/%d/%d (%.0fs)" %
          (flow.shape[1], len(te_s), len(tr), len(va), len(te), time.time() - t0))

    test_meta = static.reindex(sorted(te_s)).copy()
    test_meta.insert(0, "station_id", test_meta.index)
    test_meta["has_test_gap"] = test_meta["station_id"].isin({g.station_id for g in te_gaps})
    meta_out = output_path("results_caravan_daily_test_stations", args.run_id)
    test_meta.to_csv(meta_out, index=False)

    rows = []
    specs = [s for s in method_specs() if not (args.skip_deep and s.kind != "classical")]
    for spec in specs:
        if spec.kind == "classical":
            s = eval_classical(ds, te_gaps, spec.fn, tag=spec.slug, dump=args.dump,
                               run_id=args.run_id)
            nse_med = s.get("NSE_median", float("nan"))
            n = int(s.get("n_stations", 0))
            label = "classical"
        elif spec.kind == "deep":
            nse_med, s, n = train_eval_deep(
                spec.model_name, spec.use_donor, ds, tr, va, te, cfg, args,
                tag=spec.slug, dump=args.dump, run_id=args.run_id
            )
            label = "deep"
        elif spec.kind == "mg":
            nse_med, s, n = train_eval_mg(
                ds, tr, va, te, cfg, args, tag=spec.slug, dump=args.dump,
                run_id=args.run_id
            )
            label = "deep"
        else:
            raise ValueError("unknown method kind: %s" % spec.kind)
        if n == 0 or not np.isfinite(nse_med):
            raise RuntimeError("%s produced no valid daily evaluation" % spec.name)
        rows.append({
            "method": spec.name,
            "NSE_median": float(nse_med),
            "alpha_median": float(s.get("alpha_median", float("nan"))),
            "n": n,
            "role": "ranking" if spec.include_in_ranking else "diagnostic",
            "dump_tag": dump_tag(args.run_id, spec.slug) if args.dump else "",
        })
        print("[%s] %-26s NSE_med=%.3f n=%d" % (label, spec.name, nse_med, n))

    out = output_path("results_caravan_full_master", args.run_id)
    table = pd.DataFrame(rows).sort_values("NSE_median", ascending=False)
    table.to_csv(out, index=False, encoding="utf-8-sig", float_format="%.8f")
    manifest = {
        "run_id": args.run_id,
        "timestamp": pd.Timestamp.now().isoformat(),
        "config": cfg,
        "n_stations_after_dedup": int(flow.shape[1]),
        "n_test_stations": int(len(te_s)),
        "n_test_gaps": int(len(te)),
        "master_csv": os.path.basename(out),
        "test_station_csv": os.path.basename(meta_out),
        "methods": rows,
    }
    manifest_out = output_path("results_caravan_daily_manifest", args.run_id, "json")
    with open(manifest_out, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    print("\n[done] wrote", out, "(%.0fs)" % (time.time() - t0))
    print(table[["method", "NSE_median", "alpha_median", "n", "role"]].to_string(
        index=False, float_format=lambda x: "%.4f" % x
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
