"""Directional adapter around the unchanged, tested boundary model kernels."""
from pathlib import Path
import importlib.util
import numpy as np

ORIGINAL = Path(__file__).resolve().parent.parent / "boundary_validation_20260922/models.py"
spec = importlib.util.spec_from_file_location("original_boundary_kernels", ORIGINAL)
kernel = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kernel)
MODELS = ("DAT", "Composite_regression", "AR1_reference_bridge")
SUPPORTS = ("observed", "far_outage", "all_outage")
KEYS = [(m, s) for m in MODELS for s in SUPPORTS]


def indexes(start, horizon, direction, train_months=120):
    end = start + horizon
    if direction == "forward":
        return np.arange(start-train_months, start), np.arange(start, end)
    if direction == "backward":
        return np.arange(end, end+train_months)[::-1], np.arange(start, end)[::-1]
    raise ValueError(direction)


def prepare_training(q, months):
    """Only the directional 120-month training matrix is accepted."""
    assert len(q) == len(months) == 120
    assert not np.any(np.asarray(q)[np.isfinite(q)] < 0)
    z, clim, mu, sigma, counts = kernel.fit_transform(q, months, 120)
    return dict(z=z, clim=clim, mu=mu, sigma=sigma, counts=counts)


def coherence(x, y, min_pairs):
    mask = np.isfinite(x) & np.isfinite(y)
    n = int(mask.sum())
    if n < min_pairs or np.std(x[mask]) <= 1e-10 or np.std(y[mask]) <= 1e-10:
        return np.nan, np.nan, n
    r = float(np.corrcoef(x[mask], y[mask])[0, 1])
    return r, max(r, 0.)**2, n


def fit_case(training, target, candidates, distances):
    z = training["z"]
    assert target not in candidates
    rank, weights, corr, overlap = kernel.rank_references(z[:, target], z[:, candidates], distances)
    refs = np.asarray(candidates)[rank]
    d, _ = kernel.composite(z[:, refs], weights)
    params = kernel.fit_models(z[:, target], d)
    r, r2, n = coherence(z[-60:, target], d[-60:], 24)
    return dict(params=params, refs=refs, weights=weights, corr=corr, overlap=overlap,
                distances=np.asarray(distances)[rank], target=target,
                left=float(z[-1, target]), clim=training["clim"][:, target].copy(),
                mu=float(training["mu"][target]), sigma=float(training["sigma"][target]),
                reference_clim=training["clim"][:, refs].copy(),
                reference_mu=training["mu"][refs].copy(),
                reference_sigma=training["sigma"][refs].copy(),
                n_reference_seasonal_fallback=int(np.any(training["counts"][:, refs] == 0, axis=0).sum()),
                train_coherence_r=r, train_coherence_r2=r2, train_coherence_pairs=n)


def transform_target_for_scoring(q, months, case):
    return (np.log1p(q) - case["clim"][months] - case["mu"]) / case["sigma"]


def predict_case(case, reference_q, gap_months):
    """No target truth, opposite-side target, or outside-gap donor input."""
    assert reference_q.shape == (len(gap_months), len(case["refs"]))
    z = (np.log1p(reference_q) - case["reference_clim"][gap_months] - case["reference_mu"]) / case["reference_sigma"]
    d, counts = kernel.composite(z, case["weights"])
    chosen = np.isfinite(z) & (np.cumsum(np.isfinite(z), axis=1) <= 4)
    predictions = {}
    for support in SUPPORTS:
        visible = d.copy()
        if support == "far_outage":
            visible[len(d)//2:] = np.nan
        elif support == "all_outage":
            visible[:] = np.nan
        pred_z = {
            "DAT": np.nan_to_num(visible, nan=0.),
            "Composite_regression": np.where(np.isfinite(visible), case["params"]["reg_intercept"] + case["params"]["reg_slope"]*visible, 0.),
            "AR1_reference_bridge": kernel.bridge(case["left"], visible, case["params"], right=None),
        }
        for model, value in pred_z.items():
            predictions[(model, support)] = kernel.inverse(value, gap_months, case["clim"], case["mu"], case["sigma"])
    baseline = kernel.inverse(np.zeros(len(d)), gap_months, case["clim"], case["mu"], case["sigma"])
    return predictions, d, counts, chosen, baseline
