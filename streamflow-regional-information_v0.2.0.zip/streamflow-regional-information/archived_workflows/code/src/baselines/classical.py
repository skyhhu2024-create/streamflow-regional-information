# -*- coding: utf-8 -*-
"""
经典基准方法（论文 5.6.2），全部 numpy 实现、无信息泄漏，可直接本地评估。

每个方法签名: predict(ds, gap) -> 物理流量 [L]（缺口月份）。
均在距平空间 z 生成预测，再用该站 transformer 反变换到物理流量。
无泄漏：只用缺口前的目标历史 + donor 在缺口期的同步观测（donor 由 ds 的无泄漏筛选给出）。

包含：
  seasonal_mean      季节均值（月气候态）        -> z=0
  idw                donor 反距离加权             -> donor z 加权
  similarity_reg     相似性多元回归(缺口前拟合)   -> 回归 donor z
  ar1                目标 AR(1) 递归外推
  donor_recursive    DTRR 近似：AR 自预测 + donor 信息递归融合
"""
from __future__ import annotations
import numpy as np


def _win(ds, key, default):
    try: return int(ds.cfg.get("classical", {}).get(key, default))
    except Exception: return default


def _donor_idx_weights(ds, gap):
    donors = ds._donors(gap)
    idx = [ds.station_ids.index(d["donor_id"]) for d in donors]
    w = np.array([d["weight"] for d in donors], dtype=np.float64)
    return idx, w


def _inv(ds, gap, z_gap):
    tr = ds.transformers[gap.station_id]
    months = ds.months[gap.start:gap.end + 1]
    return tr.inverse_transform(np.asarray(z_gap, dtype=np.float64), months)


def seasonal_mean(ds, gap):
    """z=0 → 反变换即月气候态。"""
    L = gap.length
    return _inv(ds, gap, np.zeros(L))


def idw(ds, gap):
    """donor 在缺口期同步距平的(先验权重)加权平均；缺该月 donor 时退化为 0(气候态)。"""
    L = gap.length
    idx, w = _donor_idx_weights(ds, gap)
    if not idx:
        return _inv(ds, gap, np.zeros(L))
    g0, g1 = gap.start, gap.end
    Z = ds.z[g0:g1 + 1, idx]                  # [L,D]
    M = np.isfinite(Z).astype(np.float64)
    W = M * w[None, :]
    denom = W.sum(1)
    zhat = np.where(denom > 0, np.nansum(np.nan_to_num(Z) * W, axis=1) / np.maximum(denom, 1e-9), 0.0)
    return _inv(ds, gap, zhat)


def similarity_reg(ds, gap):
    """用缺口前重叠期拟合 target_z ~ donors_z 的最小二乘，再在缺口期预测。"""
    L = gap.length
    idx, _ = _donor_idx_weights(ds, gap)
    if not idx:
        return _inv(ds, gap, np.zeros(L))
    g0 = gap.start
    ti = ds.station_ids.index(gap.station_id)
    lo = max(0, g0 - _win(ds, 'reg_window', 120))
    Xtr = ds.z[lo:g0, idx]                     # [n,D]
    ytr = ds.z[lo:g0, ti]                      # [n]
    m = np.isfinite(ytr) & np.isfinite(Xtr).all(1)
    if m.sum() < max(6, len(idx) + 2):
        return idw(ds, gap)                    # 样本不足回退 IDW
    X = np.column_stack([Xtr[m], np.ones(m.sum())])
    coef, *_ = np.linalg.lstsq(X, ytr[m], rcond=None)
    Xg = ds.z[g0:g0 + L, idx]
    Xg = np.where(np.isfinite(Xg), Xg, 0.0)
    zhat = np.column_stack([Xg, np.ones(L)]) @ coef
    return _inv(ds, gap, zhat)


def ar1(ds, gap):
    """目标 AR(1)：用缺口前历史估 phi，递归外推进入缺口。"""
    L = gap.length
    g0 = gap.start
    ti = ds.station_ids.index(gap.station_id)
    hist = ds.z[max(0, g0 - _win(ds, 'ar_window', 240)):g0, ti]
    hist = hist[np.isfinite(hist)]
    if hist.size < 12:
        return _inv(ds, gap, np.zeros(L))
    x0, x1 = hist[:-1], hist[1:]
    denom = np.sum(x0 * x0)
    phi = float(np.sum(x0 * x1) / denom) if denom > 1e-9 else 0.0
    phi = np.clip(phi, -0.99, 0.99)
    last = hist[-1]
    out = np.zeros(L)
    for t in range(L):
        last = phi * last
        out[t] = last
    return _inv(ds, gap, out)


def donor_recursive(ds, gap, alpha=0.5):
    """DTRR 近似：每步用 AR 自预测与 donor 同步信息凸组合，递归填补（演示其均值化倾向）。"""
    L = gap.length
    g0, g1 = gap.start, gap.end
    ti = ds.station_ids.index(gap.station_id)
    idx, w = _donor_idx_weights(ds, gap)
    hist = ds.z[max(0, g0 - _win(ds, 'dtrr_window', 240)):g0, ti]
    hist = hist[np.isfinite(hist)]
    if hist.size >= 2:
        x0, x1 = hist[:-1], hist[1:]
        d = np.sum(x0 * x0); phi = float(np.sum(x0 * x1) / d) if d > 1e-9 else 0.0
        phi = np.clip(phi, -0.99, 0.99); last = hist[-1]
    else:
        phi, last = 0.0, 0.0
    Z = ds.z[g0:g1 + 1, idx] if idx else None
    out = np.zeros(L)
    for t in range(L):
        self_pred = phi * last
        if Z is not None:
            zt = Z[t]; mt = np.isfinite(zt)
            if mt.any():
                dv = np.sum(np.nan_to_num(zt) * w * mt) / max(np.sum(w * mt), 1e-9)
                pred = alpha * self_pred + (1 - alpha) * dv
            else:
                pred = self_pred
        else:
            pred = self_pred
        out[t] = pred
        last = pred                            # 递归：用自身输出 → 误差累积/均值化
    return _inv(ds, gap, out)


def _tree_reg(ds, gap, make_model):
    """非线性 donor 组合器：在缺口前窗口拟合 target_z ~ donors_z(树模型),再在缺口期预测。
    与 similarity_reg 同一无泄漏协议(只用缺口前数据);样本不足时回退 IDW。"""
    L = gap.length
    idx, _ = _donor_idx_weights(ds, gap)
    if not idx:
        return _inv(ds, gap, np.zeros(L))
    g0 = gap.start
    ti = ds.station_ids.index(gap.station_id)
    lo = max(0, g0 - _win(ds, 'reg_window', 120))
    Xtr = ds.z[lo:g0, idx]
    ytr = ds.z[lo:g0, ti]
    m = np.isfinite(ytr) & np.isfinite(Xtr).all(1)
    if m.sum() < max(20, 3 * len(idx)):
        return idw(ds, gap)
    model = make_model()
    model.fit(Xtr[m], ytr[m])
    Xg = ds.z[g0:g0 + L, idx]
    Xg = np.where(np.isfinite(Xg), Xg, 0.0)
    zhat = model.predict(Xg)
    return _inv(ds, gap, zhat)


def rf_donor(ds, gap):
    """随机森林 donor 组合器(非线性、非神经)。"""
    from sklearn.ensemble import RandomForestRegressor
    return _tree_reg(ds, gap, lambda: RandomForestRegressor(
        n_estimators=200, min_samples_leaf=3, n_jobs=1, random_state=0))


def gbm_donor(ds, gap):
    """梯度提升 donor 组合器(非线性、非神经)。"""
    from sklearn.ensemble import GradientBoostingRegressor
    return _tree_reg(ds, gap, lambda: GradientBoostingRegressor(
        n_estimators=200, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=0))


ALL_BASELINES = {
    "seasonal_mean": seasonal_mean,
    "idw": idw,
    "similarity_reg": similarity_reg,
    "ar1": ar1,
    "donor_recursive(DTRR近似)": donor_recursive,
    "rf_donor": rf_donor,
    "gbm_donor": gbm_donor,
}
