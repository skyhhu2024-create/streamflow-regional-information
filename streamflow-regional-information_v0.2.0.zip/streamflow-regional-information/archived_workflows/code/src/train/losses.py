# -*- coding: utf-8 -*-
"""
Stage-1 losses (anomaly space):
  L = w_str * Huber(z_hat, z) + w_nll * GaussianNLL + w_bi * bidirectional-consistency

Plus a numerically-stable KGE-decomposition loss in physical flow space (Stage-2).
torch imported lazily so this module imports in a torch-free env for unit tests.
"""
from __future__ import annotations


def _masked_mean(x, mask):
    s = (x * mask).sum()
    n = mask.sum().clamp(min=1.0)
    return s / n


def stage1_loss(out, batch, w_str=1.0, w_nll=0.5, w_bi=0.3, huber_delta=1.0):
    import torch
    import torch.nn.functional as F
    z_hat = out["z_hat"]
    log_var = out["log_var"]
    z = batch["target_z"]
    mask = batch["gap_mask"] * batch["target_valid"]

    huber = F.huber_loss(z_hat, z, delta=huber_delta, reduction="none")
    l_str = _masked_mean(huber, mask)

    s = log_var
    nll = 0.5 * (torch.exp(-s) * (z - z_hat) ** 2 + s)
    l_nll = _masked_mean(nll, mask)

    bi = (out["z_self_f"] - out["z_self_b"]) ** 2
    l_bi = _masked_mean(bi, batch["gap_mask"])

    total = w_str * l_str + w_nll * l_nll + w_bi * l_bi
    return total, {"loss": float(total.detach()), "str": float(l_str.detach()),
                   "nll": float(l_nll.detach()), "bi": float(l_bi.detach())}


def kge_decomposition_loss(flow_hat, flow_obs, mask, min_points=4, flow_floor=1e-3,
                           w_r=1.0, w_alpha=1.0, w_beta=1.0, eps=1e-6, clip_ratio=20.0):
    """
    Numerically-stable KGE three-component loss in physical flow space, per sample.
    alpha/beta penalized as squared LOG-ratios (scale-free, symmetric, bounded);
    ratios clamped; degenerate samples (few points, near-zero obs mean/std) skipped.
    """
    import torch
    cnt = mask.sum(dim=1)
    cden = cnt.clamp(min=1.0)
    mo = (flow_obs * mask).sum(1) / cden
    mp = (flow_hat * mask).sum(1) / cden
    do = flow_obs - mo.unsqueeze(1)
    dp = flow_hat - mp.unsqueeze(1)
    so = torch.sqrt((do ** 2 * mask).sum(1) / cden + eps)
    sp = torch.sqrt((dp ** 2 * mask).sum(1) / cden + eps)
    cov = (do * dp * mask).sum(1) / cden
    r = (cov / (so * sp + eps)).clamp(-1.0, 1.0)

    inv = 1.0 / clip_ratio
    alpha = (sp / (so + eps)).clamp(inv, clip_ratio)
    beta = (mp / (mo + eps)).clamp(inv, clip_ratio)
    la = torch.log(alpha)
    lb = torch.log(beta)

    term = w_r * (1 - r) ** 2 + w_alpha * la ** 2 + w_beta * lb ** 2
    valid = (cnt >= min_points) & (mo > flow_floor) & (so > eps)
    vs = valid.float()
    if float(vs.sum()) < 1:
        return flow_hat.sum() * 0.0
    return (term * vs).sum() / vs.sum().clamp(min=1.0)
