# -*- coding: utf-8 -*-
"""
Differentiable inverse transform (torch): anomaly z -> physical flow (m3/s).

Same formula as features.StationTransformer.inverse_transform, but in torch so the
Stage-2 KGE-decomposition loss can be computed in physical flow space and backpropagated.
torch imported lazily so the package imports in a torch-free env.
"""
from __future__ import annotations


def inverse_transform_torch(z, inv_sigma, inv_mu, inv_clim, flags):
    """
    z         : [B,L] anomaly
    inv_sigma : [B]   per-station std
    inv_mu    : [B]   per-station mean (transform space)
    inv_clim  : [B,L] monthly climatology per gap month
    flags     : dict(use_log1p, deseasonalize, standardize)
    return    : [B,L] physical flow (>=0)
    """
    import torch
    x = z
    if flags.get("standardize", True):
        x = x * inv_sigma.unsqueeze(-1) + inv_mu.unsqueeze(-1)
    if flags.get("deseasonalize", True):
        x = x + inv_clim
    if flags.get("use_log1p", True):
        x = torch.clamp(x, max=50.0)
        x = torch.expm1(x)
    x = torch.clamp(x, min=0.0)
    return x
