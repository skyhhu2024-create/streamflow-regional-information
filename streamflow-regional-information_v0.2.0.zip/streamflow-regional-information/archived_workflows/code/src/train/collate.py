# -*- coding: utf-8 -*-
"""
变长 donor / 变长缺口的 batch 组装（纯 numpy，torch 无关，便于单测）。

把若干 dataset 样本（dict）padding 成统一形状的 batch（numpy 数组字典）。
训练脚本再用 to_torch() 转为张量。
"""
from __future__ import annotations
import numpy as np


def collate_numpy(samples, seq_pad):
    B = len(samples)
    Lmax = max(s["length"] for s in samples)
    Dmax = max(s["n_donors"] for s in samples) if any(s["n_donors"] > 0 for s in samples) else 1
    P = seq_pad
    W = P + Lmax + P  # donor 上下文窗宽（与 dataset 中 donor_ctx 对齐的最大值）

    def zeros(*shape):
        return np.zeros(shape, dtype=np.float32)

    ctx_pre = zeros(B, P); ctx_pre_m = zeros(B, P)
    ctx_post = zeros(B, P); ctx_post_m = zeros(B, P)
    gap_phase = zeros(B, Lmax, 2)
    gap_pos = zeros(B, Lmax)
    gap_mask = zeros(B, Lmax)
    length_norm = zeros(B)
    target_z = zeros(B, Lmax)          # 真值距平（训练监督；缺口处由 transformer.transform 得到）
    target_valid = zeros(B, Lmax)
    donor_gap = zeros(B, Dmax, Lmax)
    donor_mask = zeros(B, Dmax, Lmax)
    donor_ctx = zeros(B, Dmax, W)
    donor_ctx_m = zeros(B, Dmax, W)
    donor_w = zeros(B, Dmax)
    donor_valid = zeros(B, Dmax)
    # 反变换参数（供第二阶段在物理流量空间算 KGE 损失，可微）
    inv_sigma = np.ones(B, dtype=np.float32)
    inv_mu = zeros(B)
    inv_clim = zeros(B, Lmax)
    target_flow = zeros(B, Lmax)
    target_flow_valid = zeros(B, Lmax)

    meta = []
    for i, s in enumerate(samples):
        L = s["length"]; D = s["n_donors"]
        # 左对齐上下文（右端为最接近缺口的月份）
        cp = s["ctx_pre_z"]; ctx_pre[i, P - len(cp):] = np.nan_to_num(cp)
        ctx_pre_m[i, P - len(cp):] = np.isfinite(cp).astype(np.float32)
        co = s["ctx_post_z"]; ctx_post[i, :len(co)] = np.nan_to_num(co)
        ctx_post_m[i, :len(co)] = np.isfinite(co).astype(np.float32)

        gap_phase[i, :L] = s["gap_phase"]
        gap_mask[i, :L] = 1.0
        length_norm[i] = np.clip(L / 36.0, 0, 2.0)
        # 缺口内位置：到最近端点的归一化距离（端点=0，中心=1）
        idx = np.arange(L)
        d2end = np.minimum(idx + 1, L - idx) / max(L, 1)
        gap_pos[i, :L] = d2end

        # 真值距平（用该站 transformer 对真实流量做 transform；缺失置 valid=0）
        tr = s["transformer"]
        tz = tr.transform(s["gap_truth_flow"], s["gap_months"])
        valid = np.isfinite(tz)
        target_z[i, :L] = np.nan_to_num(tz)
        target_valid[i, :L] = valid.astype(np.float32)

        # 反变换参数
        inv_sigma[i] = tr.sigma_ if tr.standardize else 1.0
        inv_mu[i] = tr.mu_ if tr.standardize else 0.0
        if tr.deseasonalize:
            inv_clim[i, :L] = tr.clim_[s["gap_months"] - 1]
        tf = s["gap_truth_flow"]
        fv = np.isfinite(tf)
        target_flow[i, :L] = np.nan_to_num(tf)
        target_flow_valid[i, :L] = fv.astype(np.float32)

        if D > 0:
            dg = s["donor_gap_z"]; donor_gap[i, :D, :L] = dg
            dm = s["donor_mask"]; donor_mask[i, :D, :L] = dm
            dc = s["donor_ctx_z"]; donor_ctx[i, :D, :dc.shape[1]] = dc
            donor_ctx_m[i, :D, :dc.shape[1]] = (dc != 0).astype(np.float32)
            donor_w[i, :D] = s["donor_weight"]
            donor_valid[i, :D] = 1.0

        meta.append({"station_id": s["station_id"], "length": L,
                     "gap_months": s["gap_months"],
                     "gap_truth_flow": s["gap_truth_flow"], "gap_dates": s.get("gap_dates"),
                     "transformer": tr, "stratum": s["stratum"]})

    batch = {
        "ctx_pre_z": ctx_pre, "ctx_pre_mask": ctx_pre_m,
        "ctx_post_z": ctx_post, "ctx_post_mask": ctx_post_m,
        "gap_phase": gap_phase, "gap_pos": gap_pos, "gap_mask": gap_mask,
        "length_norm": length_norm,
        "target_z": target_z, "target_valid": target_valid,
        "donor_gap_z": donor_gap, "donor_mask": donor_mask,
        "donor_ctx_z": donor_ctx, "donor_ctx_mask": donor_ctx_m,
        "donor_weight": donor_w, "donor_valid": donor_valid,
        "inv_sigma": inv_sigma, "inv_mu": inv_mu, "inv_clim": inv_clim,
        "target_flow": target_flow, "target_flow_valid": target_flow_valid,
    }
    # 变换标志（整批一致，取首个样本）
    tr0 = samples[0]["transformer"]
    batch["_flags"] = {"use_log1p": tr0.use_log1p,
                       "deseasonalize": tr0.deseasonalize,
                       "standardize": tr0.standardize}
    return batch, meta


def to_torch(batch, device="cpu"):
    import torch
    out = {}
    for k, v in batch.items():
        if k.startswith("_"):
            out[k] = v          # 非数组元信息（如 _flags）原样保留
        else:
            out[k] = torch.as_tensor(v, dtype=torch.float32, device=device)
    return out
