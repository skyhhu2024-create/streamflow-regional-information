# -*- coding: utf-8 -*-
"""
第一阶段：时间结构恢复模型（MG-STGAI Stage-1）。

结构（对应论文 5.4）：
  - BiContextEncoder   : 双向编码缺口前/后上下文 → 目标上下文表示 h_ctx，
                         并给出前向/后向两个自记忆估计 z_self_fwd / z_self_bwd（5.4.2 双向一致性）。
  - DonorAttention     : 每个缺口月份对 donor 做缩放点积注意力，带静态相似性偏置（5.4.1）。
  - MemoryGate         : 由缺口位置/长度/donor 同步强度驱动的记忆门 g(t)，融合两条通路（5.4.1）。
  - ConfidenceHead     : 异方差置信头，输出 log σ²(t)，承接质量分级（5.4.3）。

输出（标准化距平空间 z）：
  z_hat     [B, L]   缺口内逐月结构估计
  log_var   [B, L]   逐月对数方差（置信度）
  z_self_f  [B, L], z_self_b [B, L]   前/后向自记忆估计（用于双向一致性损失）

所有张量按 batch 内最大缺口长度 Lmax / 最大 donor 数 Dmax 右侧 padding；
有效位置由 gap_mask [B,L] 与 donor_valid [B,D] 标记。
"""
from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F


class BiContextEncoder(nn.Module):
    """双向 GRU 编码缺口前/后上下文，输出 h_ctx 及前/后向自记忆解码。"""

    def __init__(self, hidden=64):
        super().__init__()
        self.hidden = hidden
        # 输入每个时间步特征：[anomaly_value, valid_flag]
        self.gru_pre = nn.GRU(input_size=2, hidden_size=hidden, batch_first=True)
        self.gru_post = nn.GRU(input_size=2, hidden_size=hidden, batch_first=True)
        # 自记忆解码：[h_ctx ; phase(2) ; pos(1)] -> z_self
        self.dec_fwd = nn.Sequential(nn.Linear(hidden + 3, hidden), nn.ReLU(),
                                     nn.Linear(hidden, 1))
        self.dec_bwd = nn.Sequential(nn.Linear(hidden + 3, hidden), nn.ReLU(),
                                     nn.Linear(hidden, 1))
        self.proj = nn.Linear(2 * hidden, hidden)

    def forward(self, ctx_pre, ctx_pre_mask, ctx_post, ctx_post_mask, phase, pos):
        # ctx_pre: [B,P], phase: [B,L,2], pos: [B,L]
        B, L, _ = phase.shape
        pre_in = torch.stack([ctx_pre, ctx_pre_mask], dim=-1)        # [B,P,2]
        post_in = torch.stack([ctx_post, ctx_post_mask], dim=-1)     # [B,P,2]
        _, h_pre = self.gru_pre(pre_in)        # h_pre: [1,B,H]
        # 后向上下文：把缺口后片段反序输入，得到"从未来回看"的记忆
        post_rev = torch.flip(post_in, dims=[1])
        _, h_post = self.gru_post(post_rev)
        h_pre = h_pre.squeeze(0)               # [B,H]
        h_post = h_post.squeeze(0)             # [B,H]
        h_ctx = self.proj(torch.cat([h_pre, h_post], dim=-1))   # [B,H]

        # 逐缺口月份解码自记忆估计
        h_exp = h_ctx.unsqueeze(1).expand(B, L, self.hidden)    # [B,L,H]
        dec_in = torch.cat([h_exp, phase, pos.unsqueeze(-1)], dim=-1)  # [B,L,H+3]
        z_self_f = self.dec_fwd(dec_in).squeeze(-1)             # [B,L]
        z_self_b = self.dec_bwd(dec_in).squeeze(-1)             # [B,L]
        return h_ctx, z_self_f, z_self_b


class DonorEncoder(nn.Module):
    """把每个 donor 的上下文统计 + 先验权重编码为 donor 表示。"""

    def __init__(self, emb=32):
        super().__init__()
        # donor 特征：[ctx_mean, ctx_std, ctx_last, prior_weight] -> emb
        self.net = nn.Sequential(nn.Linear(4, emb), nn.ReLU(), nn.Linear(emb, emb))

    def forward(self, donor_ctx, donor_ctx_mask, donor_weight):
        # donor_ctx: [B,D,W]
        valid = donor_ctx_mask
        cnt = valid.sum(-1).clamp(min=1.0)
        mean = (donor_ctx * valid).sum(-1) / cnt
        var = ((donor_ctx - mean.unsqueeze(-1)) ** 2 * valid).sum(-1) / cnt
        std = torch.sqrt(var + 1e-6)
        # 最后一个有效值（缺口前最近观测）
        last = donor_ctx[:, :, -1]
        feat = torch.stack([mean, std, last, donor_weight], dim=-1)  # [B,D,4]
        return self.net(feat)                                        # [B,D,emb]


class DonorAttention(nn.Module):
    """逐缺口月份对 donor 的缩放点积注意力（带相似性偏置 + 同步掩码）。"""

    def __init__(self, hidden=64, emb=32, dk=32):
        super().__init__()
        self.dk = dk
        self.q = nn.Linear(hidden + 3, dk)      # query: [h_ctx ; phase ; pos]
        self.k = nn.Linear(emb, dk)             # key: donor embedding
        self.scale = dk ** 0.5
        # 可学温度：初始 0 → softmax(log w_d)=IDW 权重，donor 通路开局即 IDW，再学温和修正
        self.tau = nn.Parameter(torch.tensor(0.0))

    def forward(self, h_ctx, phase, pos, donor_emb, donor_gap_z,
                donor_gap_mask, donor_valid, donor_weight):
        B, L, _ = phase.shape
        D = donor_emb.shape[1]
        h_exp = h_ctx.unsqueeze(1).expand(B, L, h_ctx.shape[-1])
        q = self.q(torch.cat([h_exp, phase, pos.unsqueeze(-1)], dim=-1))  # [B,L,dk]
        k = self.k(donor_emb)                                             # [B,D,dk]
        # 学习项乘以可学温度 τ（初始 0）；先验偏置=log 反距离权重。
        # τ=0 时 scores=bias → softmax=IDW 权重，z_donor 退化为 IDW。
        scores = self.tau * (torch.matmul(q, k.transpose(1, 2)) / self.scale)   # [B,L,D]
        bias = torch.log(donor_weight.clamp(min=1e-6)).unsqueeze(1)       # [B,1,D] 反距离先验
        scores = scores + bias
        # 掩码：该月 donor 无同步观测 或 donor 为 padding → -inf
        valid = donor_gap_mask.transpose(1, 2) * donor_valid.unsqueeze(1)  # [B,L,D]
        scores = scores.masked_fill(valid < 0.5, float("-inf"))
        # 全无有效 donor 的 (b,l) 行：置零权重，z_donor=0
        all_invalid = (valid.sum(-1) < 0.5)                                # [B,L]
        attn = torch.softmax(scores, dim=-1)
        attn = torch.nan_to_num(attn, nan=0.0)
        # donor 值 = donor 在该月的同步距平 [B,L,D]
        vals = donor_gap_z.transpose(1, 2)
        z_donor = (attn * vals).sum(-1)                                    # [B,L]
        z_donor = z_donor.masked_fill(all_invalid, 0.0)
        # donor 同步强度（用于记忆门 / 置信）：有效 donor 数的归一
        sync = valid.sum(-1) / max(D, 1)                                   # [B,L]
        return z_donor, sync, all_invalid


class MemoryGate(nn.Module):
    """记忆门 g(t)∈(0,1)：靠近端点/短缺口→偏自记忆；深入长缺口→偏 donor。"""

    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(hidden + 3, hidden), nn.ReLU(), nn.Linear(hidden, 1))
        # 初始偏向 donor (g≈0.12)：避免用弱自记忆稀释强 donor 信号
        self.bias = nn.Parameter(torch.tensor(-2.0))

    def forward(self, h_ctx, pos, length_norm, sync):
        B, L = pos.shape
        h_exp = h_ctx.unsqueeze(1).expand(B, L, h_ctx.shape[-1])
        feat = torch.cat([h_exp,
                          pos.unsqueeze(-1),
                          length_norm.view(B, 1, 1).expand(B, L, 1),
                          sync.unsqueeze(-1)], dim=-1)
        g = torch.sigmoid(self.net(feat).squeeze(-1) + self.bias)          # [B,L]
        return g


class ConfidenceHead(nn.Module):
    """异方差置信头：输出 log σ²(t)。"""

    def __init__(self, hidden=64):
        super().__init__()
        # 输入 = h_ctx(H) + phase(2) + pos(1) + g(1) + sync(1) = H+5
        self.net = nn.Sequential(
            nn.Linear(hidden + 5, hidden), nn.ReLU(), nn.Linear(hidden, 1))

    def forward(self, h_ctx, phase, pos, g, sync):
        B, L, _ = phase.shape
        h_exp = h_ctx.unsqueeze(1).expand(B, L, h_ctx.shape[-1])
        feat = torch.cat([h_exp, phase, pos.unsqueeze(-1),
                          g.unsqueeze(-1), sync.unsqueeze(-1)], dim=-1)
        log_var = self.net(feat).squeeze(-1)
        return log_var.clamp(-6.0, 6.0)


class Stage1Imputer(nn.Module):
    """第一阶段整体：返回 z_hat, log_var, z_self_f, z_self_b, g。"""

    def __init__(self, hidden=64, donor_emb=32, dk=32):
        super().__init__()
        self.encoder = BiContextEncoder(hidden)
        self.donor_encoder = DonorEncoder(donor_emb)
        self.donor_attn = DonorAttention(hidden, donor_emb, dk)
        self.gate = MemoryGate(hidden)
        self.conf = ConfidenceHead(hidden)

    def forward(self, batch):
        b = batch
        h_ctx, z_self_f, z_self_b = self.encoder(
            b["ctx_pre_z"], b["ctx_pre_mask"], b["ctx_post_z"], b["ctx_post_mask"],
            b["gap_phase"], b["gap_pos"])
        z_self = 0.5 * (z_self_f + z_self_b)

        donor_emb = self.donor_encoder(
            b["donor_ctx_z"], b["donor_ctx_mask"], b["donor_weight"])
        z_donor, sync, all_invalid = self.donor_attn(
            h_ctx, b["gap_phase"], b["gap_pos"], donor_emb,
            b["donor_gap_z"], b["donor_mask"], b["donor_valid"], b["donor_weight"])

        g = self.gate(h_ctx, b["gap_pos"], b["length_norm"], sync)
        # 无任何有效 donor 时强制使用自记忆 (g=1)
        g = torch.where(all_invalid, torch.ones_like(g), g)
        z_hat = g * z_self + (1.0 - g) * z_donor

        log_var = self.conf(h_ctx, b["gap_phase"], b["gap_pos"], g, sync)
        return {"z_hat": z_hat, "log_var": log_var,
                "z_self_f": z_self_f, "z_self_b": z_self_b,
                "g": g, "sync": sync}
