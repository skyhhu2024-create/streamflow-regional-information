# -*- coding: utf-8 -*-
"""
Deep baselines for monthly streamflow gap imputation, under the SAME leakage-safe
protocol and per-station evaluation as MG-STGAI (thesis 5.6.2).

All models consume the collate batch and output {"z_hat": [B,L]} in anomaly space,
plus a native heteroscedastic {"log_var": [B,L]} head (used only when trained with the
Gaussian-NLL term via --uncertainty; harmless otherwise). A shared timeline
[pre-context | gap | post-context] of width W = P + L + P is built; gap positions carry
value 0 with mask 0 (to be imputed). use_donor toggles whether donor synchronous
information is fed (single-station vs multi-station variants).

Models: lstm (bidirectional seq2seq), brits (bi-RNN imputation), saits (self-attention
imputation), grin (graph recurrent imputation; multi-station by nature).
"""
from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F


def build_timeline(batch, use_donor):
    """Return per-step features over W=P+L+P and the gap slice indices.

    feats: [B, W, F]  with F = 4 (+1 if use_donor)
    gap slice: [P : P+L]
    """
    pre = batch["ctx_pre_z"]; prem = batch["ctx_pre_mask"]      # [B,P]
    post = batch["ctx_post_z"]; postm = batch["ctx_post_mask"]  # [B,P]
    phase = batch["gap_phase"]                                  # [B,L,2]
    B, P = pre.shape
    L = phase.shape[1]
    z = torch.zeros(B, L, device=pre.device, dtype=pre.dtype)
    val = torch.cat([pre, z, post], dim=1)                      # [B,W]
    mask = torch.cat([prem, z, postm], dim=1)                   # [B,W]
    ph = torch.zeros(B, P + L + P, 2, device=pre.device, dtype=pre.dtype)
    ph[:, P:P + L, :] = phase
    feats = [val.unsqueeze(-1), mask.unsqueeze(-1), ph]         # [B,W,1],[B,W,1],[B,W,2]
    if use_donor:
        dg = batch["donor_gap_z"]; dm = batch["donor_mask"]; dw = batch["donor_weight"]
        wexp = dw.unsqueeze(-1) * dm                            # [B,D,L]
        denom = wexp.sum(1).clamp(min=1e-6)
        donor_agg_gap = (wexp * dg).sum(1) / denom             # [B,L]
        donor_agg = torch.zeros(B, P + L + P, device=pre.device, dtype=pre.dtype)
        donor_agg[:, P:P + L] = donor_agg_gap
        feats.append(donor_agg.unsqueeze(-1))
    return torch.cat(feats, dim=-1), P, L


class LSTMSeq2Seq(nn.Module):
    """Bidirectional LSTM seq2seq imputer."""
    def __init__(self, hidden=64, use_donor=False):
        super().__init__()
        self.use_donor = use_donor
        in_dim = 5 if use_donor else 4
        self.lstm = nn.LSTM(in_dim, hidden, num_layers=2, batch_first=True,
                            bidirectional=True, dropout=0.0)
        self.head = nn.Linear(2 * hidden, 1)
        self.head_lv = nn.Linear(2 * hidden, 1)   # native heteroscedastic log-variance head

    def forward(self, batch):
        feats, P, L = build_timeline(batch, self.use_donor)
        h, _ = self.lstm(feats)
        z = self.head(h).squeeze(-1)                            # [B,W]
        lv = self.head_lv(h).squeeze(-1)                        # [B,W]
        return {"z_hat": z[:, P:P + L], "log_var": lv[:, P:P + L]}


class BRITS(nn.Module):
    """Compact bidirectional RNN imputation (forward + backward, averaged)."""
    def __init__(self, hidden=64, use_donor=False):
        super().__init__()
        self.use_donor = use_donor
        in_dim = 5 if use_donor else 4
        self.fwd = nn.LSTM(in_dim, hidden, batch_first=True)
        self.bwd = nn.LSTM(in_dim, hidden, batch_first=True)
        self.hf = nn.Linear(hidden, 1)
        self.hb = nn.Linear(hidden, 1)
        self.lv = nn.Linear(2 * hidden, 1)        # native heteroscedastic log-variance head

    def forward(self, batch):
        feats, P, L = build_timeline(batch, self.use_donor)
        hf, _ = self.fwd(feats)
        hb, _ = self.bwd(torch.flip(feats, dims=[1]))
        hb = torch.flip(hb, dims=[1])
        zf = self.hf(hf).squeeze(-1)
        zb = self.hb(hb).squeeze(-1)
        z = 0.5 * (zf + zb)
        lv = self.lv(torch.cat([hf, hb], dim=-1)).squeeze(-1)
        out = {"z_hat": z[:, P:P + L], "log_var": lv[:, P:P + L]}
        out["z_self_f"] = zf[:, P:P + L]
        out["z_self_b"] = zb[:, P:P + L]
        return out


class SAITS(nn.Module):
    """Compact self-attention imputation (transformer encoder over the timeline)."""
    def __init__(self, hidden=64, heads=4, layers=2, use_donor=False):
        super().__init__()
        self.use_donor = use_donor
        in_dim = 5 if use_donor else 4
        self.proj = nn.Linear(in_dim, hidden)
        enc = nn.TransformerEncoderLayer(d_model=hidden, nhead=heads,
                                         dim_feedforward=2 * hidden, batch_first=True)
        self.enc = nn.TransformerEncoder(enc, num_layers=layers)
        self.head = nn.Linear(hidden, 1)
        self.head_lv = nn.Linear(hidden, 1)       # native heteroscedastic log-variance head
        self.pos = nn.Parameter(torch.zeros(1, 512, hidden))

    def forward(self, batch):
        feats, P, L = build_timeline(batch, self.use_donor)
        W = feats.shape[1]
        x = self.proj(feats) + self.pos[:, :W, :]
        h = self.enc(x)
        z = self.head(h).squeeze(-1)
        lv = self.head_lv(h).squeeze(-1)
        return {"z_hat": z[:, P:P + L], "log_var": lv[:, P:P + L]}


class GRIN(nn.Module):
    """Compact graph recurrent imputation (multi-station): bidir temporal encode of
    target + donors, cross-node attention at gap steps. Always uses donor info."""
    def __init__(self, hidden=64, use_donor=True):
        super().__init__()
        self.t_enc = nn.GRU(2, hidden, batch_first=True, bidirectional=True)   # target [val,mask]
        self.d_enc = nn.GRU(2, hidden, batch_first=True, bidirectional=True)   # donor  [val,mask]
        self.q = nn.Linear(2 * hidden, hidden)
        self.k = nn.Linear(2 * hidden, hidden)
        self.v = nn.Linear(2 * hidden, hidden)
        self.head = nn.Linear(2 * hidden + hidden, 1)
        self.head_lv = nn.Linear(2 * hidden + hidden, 1)   # native heteroscedastic log-variance head
        self.scale = hidden ** 0.5

    def forward(self, batch):
        pre = batch["ctx_pre_z"]; prem = batch["ctx_pre_mask"]
        post = batch["ctx_post_z"]; postm = batch["ctx_post_mask"]
        B, P = pre.shape
        L = batch["gap_phase"].shape[1]
        zL = torch.zeros(B, L, device=pre.device, dtype=pre.dtype)
        tval = torch.cat([pre, zL, post], dim=1)               # [B,W]
        tmask = torch.cat([prem, zL, postm], dim=1)
        W = P + L + P
        tin = torch.stack([tval, tmask], dim=-1)               # [B,W,2]
        th, _ = self.t_enc(tin)                                # [B,W,2H]
        th_gap = th[:, P:P + L, :]                             # [B,L,2H]

        dctx = batch["donor_ctx_z"]; dctxm = batch["donor_ctx_mask"]  # [B,D,Wd]
        D = dctx.shape[1]; Wd = dctx.shape[2]
        din = torch.stack([dctx, dctxm], dim=-1).reshape(B * D, Wd, 2)
        dh, _ = self.d_enc(din)                                # [B*D,Wd,2H]
        dh = dh.reshape(B, D, Wd, -1)
        # align donor temporal to gap region; donor window assumed [pre|gap|post] too
        dgap = dh[:, :, P:P + L, :] if Wd >= P + L else dh[:, :, :L, :]   # [B,D,L,2H]

        q = self.q(th_gap)                                     # [B,L,H]
        k = self.k(dgap)                                       # [B,D,L,H]
        v = self.v(dgap)
        # attention over donors per gap step: scores [B,L,D]
        scores = torch.einsum("blh,bdlh->bld", q, k) / self.scale
        dvalid = batch["donor_valid"].unsqueeze(1)             # [B,1,D]
        scores = scores.masked_fill(dvalid < 0.5, float("-inf"))
        allbad = (batch["donor_valid"].sum(1) < 0.5)          # [B]
        attn = torch.softmax(scores, dim=-1)
        attn = torch.nan_to_num(attn, nan=0.0)
        ctx = torch.einsum("bld,bdlh->blh", attn, v)          # [B,L,H]
        ctx = ctx.masked_fill(allbad.view(B, 1, 1), 0.0)
        feat = torch.cat([th_gap, ctx], dim=-1)
        z = self.head(feat).squeeze(-1)   # [B,L]
        lv = self.head_lv(feat).squeeze(-1)
        return {"z_hat": z, "log_var": lv}


def get_model(name, hidden=64, use_donor=False):
    name = name.lower()
    if name == "lstm":
        return LSTMSeq2Seq(hidden, use_donor)
    if name == "brits":
        return BRITS(hidden, use_donor)
    if name == "saits":
        return SAITS(hidden, use_donor=use_donor)
    if name == "grin":
        return GRIN(hidden, use_donor=True)   # GRIN is multi-station by nature
    raise ValueError("unknown model: %s" % name)
