# -*- coding: utf-8 -*-
"""
第二阶段：情境化尺度恢复头 + 两阶段封装（论文 5.5.1）。

第一阶段在距平空间最小化误差会压缩方差。ScaleHead 预测一个 >0 的方差膨胀系数 γ，
在距平空间对"偏离自身均值的波动分量"进行情境化放大，缓解削峰；γ 由 h_ctx、缺口长度、
donor 同步强度等情境量决定（初始 ≈1，不破坏第一阶段）。

分布尾部的精细恢复由推断期的分位数映射(postproc.quantile_map)完成；
本头负责训练期可微的尺度/变率恢复，与 KGE 分解损失配合。
"""
from __future__ import annotations
import torch
import torch.nn as nn

from .stage1 import Stage1Imputer


class ScaleHead(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        # 输入: 缺口聚合的上下文统计 [mean_g, mean_sync, length_norm] -> γ
        self.net = nn.Sequential(nn.Linear(3, hidden), nn.ReLU(), nn.Linear(hidden, 1))

    def forward(self, g, sync, length_norm, gap_mask):
        # 对缺口内做掩码平均，得到样本级标量情境
        cnt = gap_mask.sum(1).clamp(min=1.0)
        g_bar = (g * gap_mask).sum(1) / cnt
        sync_bar = (sync * gap_mask).sum(1) / cnt
        feat = torch.stack([g_bar, sync_bar, length_norm], dim=-1)   # [B,3]
        raw = self.net(feat).squeeze(-1)                             # [B]
        gamma = 1.0 + torch.tanh(raw) * 0.3   # γ∈(0.7,1.3)，更保守，避免过冲伤 NSE
        return gamma


class TwoStageImputer(nn.Module):
    """Stage1 + ScaleHead。返回 z_hat(校正后), z_hat_stage1, log_var, gamma 等。"""

    def __init__(self, hidden=64, donor_emb=32, dk=32, use_stage2=True):
        super().__init__()
        self.stage1 = Stage1Imputer(hidden, donor_emb, dk)
        self.scale = ScaleHead(hidden)
        self.use_stage2 = use_stage2          # 消融：False 则跳过尺度恢复头

    def forward(self, batch):
        out = self.stage1(batch)
        z1 = out["z_hat"]                              # [B,L] 距平
        if not self.use_stage2:
            out["z_hat_stage1"] = z1
            out["gamma"] = torch.ones(z1.shape[0], device=z1.device)
            return out
        sync = out.get("sync", torch.zeros_like(z1))  # stage1 返回的 donor 同步强度
        gamma = self.scale(out["g"], sync, batch["length_norm"], batch["gap_mask"])
        # 对距平做方差膨胀（绕样本自身缺口均值）
        cnt = batch["gap_mask"].sum(1).clamp(min=1.0)
        zbar = (z1 * batch["gap_mask"]).sum(1) / cnt
        z2 = zbar.unsqueeze(1) + gamma.unsqueeze(1) * (z1 - zbar.unsqueeze(1))
        out["z_hat_stage1"] = z1
        out["z_hat"] = z2
        out["gamma"] = gamma
        return out
