# -*- coding: utf-8 -*-
"""
无信息泄漏的伪缺口生成。

从完整/近完整的观测序列中人工挖去内部缺口，作为有监督插补样本。
被挖去的目标月份在训练与推断时均不可见；缺口必须是"内部"缺口（两侧都有上下文记忆）。
缺口长度按短/中/长分层采样，以匹配真实档案的缺失形态。
"""
from __future__ import annotations
import numpy as np


class GapSpec:
    """一个站点-缺口单元的描述。"""
    __slots__ = ("station_id", "start", "end", "length", "stratum")

    def __init__(self, station_id, start, end, stratum):
        self.station_id = station_id
        self.start = int(start)          # 缺口起始索引(含)
        self.end = int(end)              # 缺口结束索引(含)
        self.length = int(end - start + 1)
        self.stratum = stratum

    def slice(self):
        return slice(self.start, self.end + 1)

    def __repr__(self):
        return f"GapSpec({self.station_id}, [{self.start},{self.end}], L={self.length}, {self.stratum})"


def _contiguous_observed_runs(valid):
    """返回所有连续观测段的 (start, end_inclusive)。valid: [T] bool。"""
    runs = []
    T = len(valid)
    i = 0
    while i < T:
        if valid[i]:
            j = i
            while j + 1 < T and valid[j + 1]:
                j += 1
            runs.append((i, j))
            i = j + 1
        else:
            i += 1
    return runs


def sample_gaps_for_station(station_id, valid, rng, length_strata,
                            gaps_per_station=3, min_context=12, edge_margin=6):
    """
    在单个站点的观测序列上采样伪缺口。

    valid : [T] bool（True=有真实观测，可被挖；缺口将落在这些位置上）
    返回 : list[GapSpec]
    """
    runs = _contiguous_observed_runs(np.asarray(valid, dtype=bool))
    # 只在足够长的连续观测段里挖（需容纳：左上下文 + 缺口 + 右上下文）
    gaps = []
    strata = list(length_strata)
    attempts = 0
    max_attempts = gaps_per_station * 20
    while len(gaps) < gaps_per_station and attempts < max_attempts:
        attempts += 1
        lo, hi = strata[len(gaps) % len(strata)]          # 轮流覆盖各分层
        L = int(rng.integers(lo, hi + 1))
        # 候选连续观测段：只要求段本身足够长，能容纳 左上下文 + 缺口 + 右上下文。
        # 注意：edge_margin 的语义是"缺口不得落在整条序列的最开头/最末尾"，
        # 它必须作用在【缺口位置】上，而不是【观测段边界】上。旧实现写成
        #     and a >= edge_margin and b <= len(valid) - 1 - edge_margin
        # 会把任何"起点恰好在记录开头"的连续段整段丢弃——哪怕它长达数千个时刻、
        # 完全够在中间挖一个两侧上下文充足的内部缺口。由于 GSIM 从 1980 起、
        # Caravan 从 1990 起，绝大多数老站的观测段起点正好是 index 0，因此被系统性剔除
        # （实测：GSIM 月尺度可评估站 50.2% → 92.3%；美国 15% → 99%）。
        feasible = [(a, b) for (a, b) in runs
                    if (b - a + 1) >= (2 * min_context + L)]
        if not feasible:
            continue
        a, b = feasible[int(rng.integers(0, len(feasible)))]
        # 缺口起点：两侧保证 min_context，同时不落在整条序列的端点余量内
        s_lo = max(a + min_context, edge_margin)
        s_hi = min(b - min_context - L + 1, len(valid) - edge_margin - L)
        if s_hi < s_lo:
            continue
        start = int(rng.integers(s_lo, s_hi + 1))
        end = start + L - 1
        # 避免与已采样缺口重叠
        if any(not (end < g.start - 1 or start > g.end + 1)
               for g in gaps if g.station_id == station_id):
            continue
        stratum = f"{lo}-{hi}"
        gaps.append(GapSpec(station_id, start, end, stratum))
    return gaps


def generate_pseudo_gaps(flow_df, cfg_gap):
    """
    对宽表 flow_df [T x N] 生成所有站点的伪缺口。

    Returns
    -------
    gaps : list[GapSpec]
    """
    rng = np.random.default_rng(cfg_gap.get("seed", 42))
    length_strata = cfg_gap.get("length_strata", [[1, 3], [4, 12], [13, 36]])
    gaps = []
    for sid in flow_df.columns:
        valid = np.isfinite(flow_df[sid].values)
        gaps.extend(sample_gaps_for_station(
            sid, valid, rng, length_strata,
            gaps_per_station=cfg_gap.get("gaps_per_station", 3),
            min_context=cfg_gap.get("min_context", 12),
            edge_margin=cfg_gap.get("edge_margin", 6),
        ))
    return gaps
