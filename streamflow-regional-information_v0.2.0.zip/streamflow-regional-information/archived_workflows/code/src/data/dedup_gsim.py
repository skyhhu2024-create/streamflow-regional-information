# -*- coding: utf-8 -*-
"""
GSIM 月尺度孪生测站剔除。

复核报告（2026-07-26）在 GSIM 里查出 686 对坐标 <300 m 的候选站，其中 **136 对确认孪生**
（重叠 ≥24 月且 log 流量相关 >0.95；典型：加-美跨境双档案 21 对、波多黎各 US 双编码 18 对、
巴西 29 对）；196 对为真实相邻站保留，354 对无重叠、无法互为 donor。

对 donor 类方法而言，孪生副本就是"换了名字的目标站自己"，会把目标站的 NSE 虚高。
Caravan 日尺度的同类问题由 `exp_regulation.py::dedup_stations()` 处理（剔除 459 站）；
本模块是它的月尺度对应物，清单来自 `gsim_near_duplicates_checked.csv` 的 `dropped` 列
（每对保留记录较长的一份）。

用法：在 `load_station_matrix()` 之后立即调用。

    from src.data.dedup_gsim import drop_gsim_twins
    flow = drop_gsim_twins(flow)
"""
from __future__ import annotations
import os

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DEFAULT_LIST = os.path.join(ROOT, "gsim_near_duplicates_checked.csv")


def load_twin_ids(path: str | None = None) -> set[str]:
    """读取待剔除的孪生站 ID 集合（`dropped` 列的非空值）。"""
    path = path or DEFAULT_LIST
    if not os.path.exists(path):
        return set()
    d = pd.read_csv(path)
    if "dropped" not in d.columns:
        return set()
    return {str(s).strip() for s in d["dropped"].dropna() if str(s).strip()}


def drop_gsim_twins(flow: pd.DataFrame, path: str | None = None,
                    verbose: bool = True) -> pd.DataFrame:
    """从站点宽表中剔除孪生副本站（列 = 站点 ID）。

    Parameters
    ----------
    flow : DataFrame  [T x N]，列为 gsim.no
    path : 孪生清单 CSV，默认 code 根下的 gsim_near_duplicates_checked.csv
    """
    twins = load_twin_ids(path)
    if not twins:
        if verbose:
            print("[dedup-gsim][警告] 未找到孪生清单 %s，未剔除任何站" % (path or DEFAULT_LIST))
        return flow
    keep = [c for c in flow.columns if c not in twins]
    n_drop = flow.shape[1] - len(keep)
    if verbose:
        print("[dedup-gsim] twin list=%d -> dropped %d stations (%d -> %d)"
              % (len(twins), n_drop, flow.shape[1], len(keep)))
    return flow[keep]
