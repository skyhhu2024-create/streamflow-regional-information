# -*- coding: utf-8 -*-
"""
特征构造：log1p 变换、月气候态去季节化、按站标准化（→距平 z）、季节位相编码。

关键：所有"按站统计量"（月气候态、均值、标准差）都只能用**训练可见的观测**计算，
绝不能包含被挖去的缺口月份，否则会造成信息泄漏。本模块的拟合(fit)与变换(transform)分离，
fit 时由调用方传入"可见掩码"。
"""
from __future__ import annotations
import numpy as np


class StationTransformer:
    """对单个站点序列做 log1p → 去季节化 → 标准化 的可逆变换。

    Parameters
    ----------
    use_log1p, deseasonalize, standardize : bool
    """

    def __init__(self, use_log1p=True, deseasonalize=True, standardize=True, n_season=12, leak_mode="none"):
        # leak_mode: 'none' (visible-only, leakage-safe), 'mean' (location from full record),
        # 'var' (scale from full record), 'both' (full-record normalization). For the leakage ablation.
        self.leak_mode = leak_mode
        self.use_log1p = use_log1p
        self.deseasonalize = deseasonalize
        self.standardize = standardize
        self.n_season = int(n_season)                 # 12=月尺度, 366=日尺度(按 day-of-year)
        self.clim_ = np.zeros(self.n_season, dtype=np.float64)   # 季节气候态(变换空间)
        self.mu_ = 0.0
        self.sigma_ = 1.0
        self.fitted_ = False

    def _fwd_base(self, q):
        q = np.asarray(q, dtype=np.float64)
        if self.use_log1p:
            with np.errstate(invalid="ignore"):
                q = np.log1p(np.clip(q, 0, None))
        return q

    def fit(self, q, months, visible_mask):
        """
        q            : [T] 原始流量(可含 NaN)
        months       : [T] 1..12
        visible_mask : [T] bool，True 表示该月对拟合可见（即非缺口、有观测）
        """
        q = np.asarray(q, dtype=np.float64)
        months = np.asarray(months)
        vis = np.asarray(visible_mask, dtype=bool) & np.isfinite(q)
        allm = np.isfinite(q)
        loc_mask = allm if self.leak_mode in ("mean", "both") else vis   # leak location?
        scl_mask = allm if self.leak_mode in ("var", "both") else vis     # leak scale?
        x = self._fwd_base(q)

        if self.deseasonalize:
            for m in range(1, self.n_season + 1):
                sel = loc_mask & (months == m)
                self.clim_[m - 1] = np.nanmean(x[sel]) if sel.any() else np.nanmean(x[loc_mask])
            x_des = x - self.clim_[months - 1]
        else:
            x_des = x

        if self.standardize:
            self.mu_ = float(np.nanmean(x_des[loc_mask])) if loc_mask.any() else 0.0
            self.sigma_ = float(np.nanstd(x_des[scl_mask])) if scl_mask.any() else 1.0
            if not np.isfinite(self.sigma_) or self.sigma_ < 1e-6:
                self.sigma_ = 1.0
        self.fitted_ = True
        return self

    def transform(self, q, months):
        """原始流量 → 距平 z（缺口月份返回 NaN，由模型去填）。"""
        x = self._fwd_base(q)
        months = np.asarray(months)
        if self.deseasonalize:
            x = x - self.clim_[months - 1]
        if self.standardize:
            x = (x - self.mu_) / self.sigma_
        return x

    def inverse_transform(self, z, months):
        """距平 z → 物理流量(m³/s)。第二阶段尺度恢复的基础。"""
        z = np.asarray(z, dtype=np.float64)
        months = np.asarray(months)
        x = z * self.sigma_ + self.mu_ if self.standardize else z
        if self.deseasonalize:
            x = x + self.clim_[months - 1]
        if self.use_log1p:
            x = np.expm1(np.clip(x, None, 50.0))   # 防溢出
            x = np.clip(x, 0, None)
        return x


def season_phase(idx, period=12):
    """季节索引 → (sin, cos) 位相编码。idx: [T] 1..period → [T,2]。"""
    idx = np.asarray(idx)
    ang = 2.0 * np.pi * (idx - 1) / float(period)
    return np.stack([np.sin(ang), np.cos(ang)], axis=-1).astype(np.float32)


def season_index(index, period=12):
    """季节索引：月尺度(period=12)→月份1..12；其它→day-of-year 1..period。"""
    if period == 12:
        return np.asarray(index.month)
    return np.clip(np.asarray(index.dayofyear), 1, period)


def month_phase(months):
    """向后兼容：月份 → (sin, cos)。"""
    return season_phase(months, 12)


def months_of(index):
    """向后兼容：月份 1..12。"""
    return np.asarray(index.month)
