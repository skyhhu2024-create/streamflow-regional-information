# -*- coding: utf-8 -*-
"""
正确的水文评估指标。

修正旧 PG-STGCN/metrics.py 的两个问题：
  1) 旧 R² = corr(obs,pred)²（只反映线性相关，忽略偏差/方差） → 这里给出真·决定系数。
  2) 旧"整体指标"把所有站点、所有月份 flatten 后算 NSE（pooled），会被站点间量级差异
     主导而严重虚高 → 这里以"逐站指标 + 中位数/分位数"为 headline，并显式区分。

此外提供：
  - KGE 三分量 (r, alpha=变率比, beta=偏差比)
  - 峰值段指标（超过 q 分位的子集上的 NSE/PBIAS），专门检验削峰。
"""
from __future__ import annotations
import numpy as np
import pandas as pd


def _clean(obs, pred):
    obs = np.asarray(obs, dtype=np.float64)
    pred = np.asarray(pred, dtype=np.float64)
    m = np.isfinite(obs) & np.isfinite(pred)
    return obs[m], pred[m]


def nse(obs, pred):
    obs, pred = _clean(obs, pred)
    if obs.size < 2:
        return np.nan
    denom = np.sum((obs - obs.mean()) ** 2)
    if denom < 1e-12:
        return np.nan
    return 1.0 - np.sum((obs - pred) ** 2) / denom


def r2_true(obs, pred):
    """真·决定系数 R² = 1 - SS_res/SS_tot（与 NSE 同式，但保留区别命名以便对照旧实现）。"""
    return nse(obs, pred)


def pearson_r(obs, pred):
    obs, pred = _clean(obs, pred)
    if obs.size < 2 or obs.std() < 1e-12 or pred.std() < 1e-12:
        return np.nan
    return float(np.corrcoef(obs, pred)[0, 1])


def kge_components(obs, pred):
    """返回 (KGE, r, alpha, beta)。alpha=std_pred/std_obs, beta=mean_pred/mean_obs。"""
    obs, pred = _clean(obs, pred)
    if obs.size < 2:
        return np.nan, np.nan, np.nan, np.nan
    r = pearson_r(obs, pred)
    so, sp = obs.std(), pred.std()
    mo, mp = obs.mean(), pred.mean()
    if so < 1e-12 or abs(mo) < 1e-12:
        return np.nan, r, np.nan, np.nan
    alpha = sp / so
    beta = mp / mo
    kge = 1.0 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2)
    return float(kge), float(r), float(alpha), float(beta)


def pbias(obs, pred):
    """PBIAS = 100*sum(obs-pred)/sum(obs)。正=低估。"""
    obs, pred = _clean(obs, pred)
    so = np.sum(obs)
    if abs(so) < 1e-12:
        return np.nan
    return float(100.0 * np.sum(obs - pred) / so)


def rmse(obs, pred):
    obs, pred = _clean(obs, pred)
    if obs.size == 0:
        return np.nan
    return float(np.sqrt(np.mean((obs - pred) ** 2)))


def peak_metrics(obs, pred, quantile=0.9):
    """峰值段指标：取 obs 超过其 q 分位的子集，算 NSE 与 PBIAS。"""
    obs, pred = _clean(obs, pred)
    if obs.size < 4:
        return {"peak_NSE": np.nan, "peak_PBIAS": np.nan, "peak_n": 0}
    thr = np.quantile(obs, quantile)
    sel = obs >= thr
    if sel.sum() < 2:
        return {"peak_NSE": np.nan, "peak_PBIAS": np.nan, "peak_n": int(sel.sum())}
    return {"peak_NSE": nse(obs[sel], pred[sel]),
            "peak_PBIAS": pbias(obs[sel], pred[sel]),
            "peak_n": int(sel.sum())}


def station_metrics(obs, pred, peak_quantile=0.9):
    """单站全套指标。obs/pred: [T]（物理空间，m³/s）。"""
    kge, r, alpha, beta = kge_components(obs, pred)
    d = {
        "NSE": nse(obs, pred),
        "KGE": kge, "r": r, "alpha": alpha, "beta": beta,
        "R2_true": r2_true(obs, pred),
        "PBIAS": pbias(obs, pred),
        "RMSE": rmse(obs, pred),
        "n": int(_clean(obs, pred)[0].size),
    }
    d.update(peak_metrics(obs, pred, quantile=peak_quantile))
    return d


def evaluate_by_station(obs_by_station, pred_by_station, peak_quantile=0.9):
    """
    逐站评估并汇总。

    obs_by_station / pred_by_station : dict {station_id: 1D array}（仅评估缺口月份）
    Returns: (per_station_df, summary_dict)
    """
    rows = []
    for sid in obs_by_station:
        if sid not in pred_by_station:
            continue
        m = station_metrics(obs_by_station[sid], pred_by_station[sid], peak_quantile)
        m["station_id"] = sid
        rows.append(m)
    df = pd.DataFrame(rows)
    if df.empty:
        return df, {}
    cols = ["station_id"] + [c for c in df.columns if c != "station_id"]
    df = df[cols]

    # headline 用中位数（稳健），同时给均值与分位
    summary = {}
    for c in ["NSE", "KGE", "r", "alpha", "beta", "PBIAS", "peak_NSE", "peak_PBIAS"]:
        v = df[c].replace([np.inf, -np.inf], np.nan).dropna()
        if len(v):
            summary[f"{c}_median"] = float(v.median())
            summary[f"{c}_mean"] = float(v.mean())
    summary["n_stations"] = int(len(df))
    summary["frac_NSE_gt_0"] = float((df["NSE"] > 0).mean())
    summary["frac_NSE_gt_0.5"] = float((df["NSE"] > 0.5).mean())

    # 池化的高流量 NSE（稳健兜底：即使逐站峰值点不足也能给出整体削峰诊断）
    all_obs, all_pred = [], []
    for sid in obs_by_station:
        if sid in pred_by_station:
            o, p = _clean(obs_by_station[sid], pred_by_station[sid])
            all_obs.append(o); all_pred.append(p)
    if all_obs:
        ao = np.concatenate(all_obs); ap = np.concatenate(all_pred)
        if ao.size >= 10:
            thr = np.quantile(ao, peak_quantile)
            sel = ao >= thr
            if sel.sum() >= 3:
                summary["peak_NSE_pooled"] = float(nse(ao[sel], ap[sel]))
                summary["peak_PBIAS_pooled"] = float(pbias(ao[sel], ap[sel]))
    return df, summary
