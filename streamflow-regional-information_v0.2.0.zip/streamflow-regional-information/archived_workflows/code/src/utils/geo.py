# -*- coding: utf-8 -*-
"""ISO-2 国家代码 -> 大洲。注意 'NA' = Namibia（真实值），缺失用 'UNK'。"""
COUNTRY2CONT = {
 "US":"NorthAmerica","CA":"NorthAmerica","MX":"NorthAmerica","GL":"NorthAmerica","CR":"NorthAmerica",
 "PA":"NorthAmerica","GT":"NorthAmerica","HN":"NorthAmerica","NI":"NorthAmerica","CU":"NorthAmerica","DO":"NorthAmerica",
 "BR":"SouthAmerica","AR":"SouthAmerica","CL":"SouthAmerica","CO":"SouthAmerica","PE":"SouthAmerica",
 "VE":"SouthAmerica","BO":"SouthAmerica","EC":"SouthAmerica","PY":"SouthAmerica","UY":"SouthAmerica","GY":"SouthAmerica","SR":"SouthAmerica",
 "FR":"Europe","ES":"Europe","DE":"Europe","GB":"Europe","IT":"Europe","NO":"Europe","AT":"Europe","FI":"Europe",
 "CH":"Europe","SE":"Europe","IE":"Europe","PL":"Europe","UA":"Europe","NL":"Europe","BE":"Europe","PT":"Europe",
 "CZ":"Europe","SK":"Europe","HU":"Europe","RO":"Europe","BG":"Europe","GR":"Europe","RS":"Europe","HR":"Europe",
 "SI":"Europe","DK":"Europe","EE":"Europe","LV":"Europe","LT":"Europe","IS":"Europe","LU":"Europe","MD":"Europe","BA":"Europe","MK":"Europe","AL":"Europe",
 "JP":"Asia","RU":"Asia","IN":"Asia","CN":"Asia","TH":"Asia","KR":"Asia","KZ":"Asia","MN":"Asia","ID":"Asia",
 "MY":"Asia","VN":"Asia","PH":"Asia","BD":"Asia","PK":"Asia","AF":"Asia","IR":"Asia","IQ":"Asia","TR":"Asia",
 "LK":"Asia","NP":"Asia","KH":"Asia","LA":"Asia","MM":"Asia","UZ":"Asia","KG":"Asia","TJ":"Asia","GE":"Asia","AM":"Asia","AZ":"Asia","IL":"Asia","SY":"Asia","JO":"Asia",
 "ZA":"Africa","ZW":"Africa","TZ":"Africa","CD":"Africa","KE":"Africa","NG":"Africa","ET":"Africa","GH":"Africa",
 "CM":"Africa","CI":"Africa","SN":"Africa","ML":"Africa","MZ":"Africa","ZM":"Africa","AO":"Africa","MA":"Africa",
 "DZ":"Africa","TN":"Africa","EG":"Africa","SD":"Africa","UG":"Africa","MW":"Africa","BW":"Africa","NA":"Africa",
 "MG":"Africa","BF":"Africa","NE":"Africa","TD":"Africa","RW":"Africa","BI":"Africa","BJ":"Africa","TG":"Africa","GN":"Africa","LS":"Africa","SZ":"Africa","GA":"Africa","CG":"Africa",
 "AU":"Oceania","NZ":"Oceania","PG":"Oceania","FJ":"Oceania",
}

def continent_of_country(c):
    if c is None:
        return "UNK"
    cc = str(c).strip().upper()
    if cc in ("", "UNK", "NAN", "NONE"):
        return "UNK"
    return COUNTRY2CONT.get(cc, "Other")
