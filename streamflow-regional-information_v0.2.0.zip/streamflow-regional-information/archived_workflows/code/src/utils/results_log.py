# -*- coding: utf-8 -*-
"""Persistence helpers so every run is saved (not just printed).

append_result : headline metrics row -> shared results_summary.csv
save_run_outputs : RAW data of one run -> results/raw/<tag>/{predictions_long.csv,
                   per_station_metrics.csv, summary.json}. This是 HESS 复现/做图的原始数据。
"""
from __future__ import annotations
import os, csv, json, time


def append_result(csv_path, row):
    row = dict(row)
    row.setdefault("timestamp", time.strftime("%Y-%m-%d %H:%M:%S"))
    cols = ["timestamp", "tag", "split", "NSE_median", "KGE_median", "alpha_median",
            "peak_NSE_median", "peak_NSE_pooled", "n_stations", "epochs", "limit"]
    for k in row:
        if k not in cols:
            cols.append(k)
    exists = os.path.exists(csv_path)
    os.makedirs(os.path.dirname(os.path.abspath(csv_path)), exist_ok=True)
    enc = "utf-8" if exists else "utf-8-sig"
    with open(csv_path, "a", newline="", encoding=enc) as f:
        w = csv.DictWriter(f, fieldnames=cols)
        if not exists:
            w.writeheader()
        w.writerow({k: row.get(k, "") for k in cols})
    return csv_path


def save_run_outputs(root, tag, records, per_station_df=None, summary=None):
    """
    root        : 仓库根目录
    tag         : 运行标签(模型+配置)，作为子目录名
    records     : list[dict]，每行一个被填补月份，至少含
                  station_id, date, obs, pred, gap_id, stratum, climate
    per_station_df : pandas.DataFrame，逐站全指标(可选)
    summary     : dict，汇总指标+配置(可选)
    返回保存目录路径。
    """
    safe = tag.replace("[", "_").replace("]", "_").replace(",", "_").replace("(", "_").replace(")", "_").replace(" ", "")
    out_dir = os.path.join(root, "results", "raw", safe)
    os.makedirs(out_dir, exist_ok=True)

    # 1) 逐缺口 预测vs实测 长表（原始数据，复现与做图用）
    if records:
        cols = ["station_id", "date", "obs", "pred", "gap_id", "stratum", "climate"]
        for r in records:
            for k in r:
                if k not in cols:
                    cols.append(k)
        with open(os.path.join(out_dir, "predictions_long.csv"), "w",
                  newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=cols)
            w.writeheader()
            for r in records:
                w.writerow({k: r.get(k, "") for k in cols})

    # 2) 逐站指标
    if per_station_df is not None and len(per_station_df):
        per_station_df.to_csv(os.path.join(out_dir, "per_station_metrics.csv"),
                              index=False, encoding="utf-8-sig")

    # 3) summary + 配置
    if summary is not None:
        meta = dict(summary)
        meta["tag"] = tag
        meta["timestamp"] = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(os.path.join(out_dir, "summary.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
    return out_dir


def save_process_series(out_dir, rows):
    """保存测试集逐站完整时间线长表（过程线/散点作图用，自包含、可复现）。
    rows: list[dict] 含 station_id, date, obs, pred, is_gap, stratum, climate。
    存为 test_series_long.csv.gz（含全部观测月份；pred 仅在被填补的缺口月有值）。"""
    import csv, gzip, os
    if not rows:
        return None
    cols = ["station_id", "date", "obs", "pred", "is_gap", "stratum", "climate"]
    fp = os.path.join(out_dir, "test_series_long.csv.gz")
    with gzip.open(fp, "wt", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in cols})
    return fp
