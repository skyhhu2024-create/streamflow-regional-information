"""Independent R2-selected-pool DAT rerun on the frozen R3 directional cases.

The original R3 output is read only. Eligibility, dates, candidate ranking,
and directional fits are unchanged. As in R2, qualified donors that report at
least once in the hidden block are ranked and a fixed pool of at most eight is
selected; each month combines available members of that pool. Donor reporting
is observed without using hidden target truth. The original R3 top-four
prediction is recomputed and audited against the frozen scores.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / "V39.1/experiments/r3"))
import run_stress as old  # noqa: E402

SOURCE = ROOT / "V39.1/experiments/r3/outputs"
KEY = ["station_id", "year", "history", "horizon", "direction"]
GROUP = ["year", "horizon", "history", "direction"]


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def predict_dat(case: dict, reference_q: np.ndarray, months: np.ndarray, k: int):
    assert k in (4, 8)
    assert reference_q.shape == (len(months), len(case["refs"]))
    if k == 8:
        # R2 selector: the same eight qualifying gap-reporting donors are
        # selected for the entire block. Availability uses donors only.
        pool = np.flatnonzero(np.isfinite(reference_q).any(0))[:8]
    else:
        # Frozen R3 control: all qualified donors remain in the rank and the
        # first four currently reporting donors contribute in each month.
        pool = np.arange(len(case["refs"]))
    z = (np.log1p(reference_q[:, pool]) - case["reference_clim"][months][:, pool]
         - case["reference_mu"][pool]) / case["reference_sigma"][pool]
    composite, count = old.k.composite(z, case["weights"][pool], k=k)
    pred = old.k.inverse(np.nan_to_num(composite, nan=0.0), months,
                         case["clim"], case["mu"], case["sigma"])
    return pred, composite, count, pool


def main():
    started = time.time()
    assert not (HERE / "audit.json").exists(), "Completed independent rerun must not be overwritten"
    frozen = pd.read_csv(SOURCE / "case_parameters.csv", usecols=KEY)
    assert not frozen.duplicated(KEY).any()
    old_scores = pd.read_csv(SOURCE / "case_metrics.csv.gz")
    old_scores = old_scores[old_scores.prediction == "DAT_retained"][KEY + ["nse", "skill", "sse"]]
    assert len(old_scores) == len(frozen)

    q = np.load(old.DATA / "flow_qc20_dedup.npy", mmap_mode="r")
    ids = np.load(old.DATA / "station_ids.npy", allow_pickle=True).astype(str)
    id_to_i = {s: i for i, s in enumerate(ids)}
    dates = pd.to_datetime(np.load(old.DATA / "dates.npy", allow_pickle=True))
    months = dates.month.to_numpy() - 1
    days = dates.days_in_month.to_numpy()
    negative = (np.isfinite(q) & (q < 0)).any(0)
    meta = pd.read_csv(old.ROOT / "global_station_meta_kg.csv").set_index("gsim.no").reindex(ids)
    lat, lon = meta.latitude.to_numpy(float), meta.longitude.to_numpy(float)
    target_ids = frozen.station_id.unique()
    candidates = {}
    for sid in target_ids:
        ti = id_to_i[sid]
        dd = old.distance(lat[ti], lon[ti], lat, lon)
        ok = np.isfinite(dd) & (dd <= 800) & ~negative
        ok[ti] = False
        cc = np.flatnonzero(ok)
        cc = cc[np.argsort(dd[cc], kind="stable")[:200]]
        candidates[ti] = (cc, dd[cc])

    case_rows, band_rows, annual_rows = [], [], []
    for (year, L, H, direction), group in frozen.groupby(GROUP, sort=False):
        start = (int(year) - 1980) * 12
        ix, gap = old.adapter.indexes(start, int(L), direction, int(H))
        tq = np.asarray(q[ix], float).copy()
        tq[:, negative] = np.nan
        tr = old.training(tq, months[ix])
        ys, p4s, p8s, bs, d4s, d8s, ids_out = [], [], [], [], [], [], []
        for sid in group.station_id:
            ti = id_to_i[sid]
            cc, dd = candidates[ti]
            case, _ = old.fit_case(tr, ti, cc, dd)
            reference_q = np.asarray(q[np.ix_(gap, case["refs"])], float)
            p4, d4, c4, _ = predict_dat(case, reference_q, months[gap], 4)
            p8, d8, c8, pool8 = predict_dat(case, reference_q, months[gap], 8)
            y = np.asarray(q[gap, ti], float)
            raw_clim = np.array([np.nanmean(tq[months[ix] == m, ti]) for m in range(12)])
            b = raw_clim[months[gap]]
            assert np.isfinite(y).all() and np.isfinite(p4).all() and np.isfinite(p8).all()
            assert np.isfinite(b).all()
            base = dict(station_id=sid, year=year, history=H, horizon=L, direction=direction)
            m4 = old.metrics(y, p4, b, days[gap])
            m8 = old.metrics(y, p8, b, days[gap])
            case_rows.append(dict(**base, n_qualified=len(case["refs"]),
                                  n_selected8=len(pool8),
                                  selected_reference_ids8=json.dumps(ids[case["refs"][pool8]].tolist()),
                                  support4=int(np.isfinite(d4).sum()),
                                  support8=int(np.isfinite(d8).sum()),
                                  mean_donors4=float(c4.mean()), mean_donors8=float(c8.mean()),
                                  nse4=m4["nse"], nse8=m8["nse"],
                                  skill4=m4["skill"], skill8=m8["skill"],
                                  sse4=m4["sse"], sse8=m8["sse"],
                                  baseline_sse=m8["baseline_sse"],
                                  signed_volume_bias_pct4=m4["signed_volume_bias_pct"],
                                  signed_volume_bias_pct8=m8["signed_volume_bias_pct"]))
            # Equal 12-month lead bands within one fixed hidden block. In the
            # backward task gap is already reversed from its known boundary.
            for lo in range(0, int(L), 12):
                hi = lo + 12
                for k, p in ((4, p4), (8, p8)):
                    mm = old.metrics(y[lo:hi], p[lo:hi], b[lo:hi], days[gap[lo:hi]])
                    band_rows.append(dict(**base, donors=k, lead_start=lo + 1,
                                          lead_end=hi, nse=mm["nse"], skill=mm["skill"],
                                          sse=mm["sse"], baseline_sse=mm["baseline_sse"],
                                          mae=float(np.mean(np.abs(p[lo:hi] - y[lo:hi]))),
                                          signed_volume_bias_pct=mm["signed_volume_bias_pct"]))
            for yr in np.unique(dates[gap].year):
                mask = dates[gap].year == yr
                for k, p in ((4, p4), (8, p8)):
                    mm = old.metrics(y[mask], p[mask], b[mask], days[gap[mask]])
                    annual_rows.append(dict(**base, donors=k, calendar_year=int(yr),
                                            annual_volume_bias_pct=mm["signed_volume_bias_pct"],
                                            absolute_annual_volume_bias_pct=abs(mm["signed_volume_bias_pct"])))
            ys.append(y); p4s.append(p4); p8s.append(p8); bs.append(b)
            d4s.append(d4); d8s.append(d8); ids_out.append(sid)
        np.savez_compressed(HERE / f"pred_{year}_H{H}_L{L}_{direction}.npz",
                            station_id=np.array(ids_out), gap_index=gap,
                            truth=np.array(ys), dat_top4=np.array(p4s), dat_top8=np.array(p8s),
                            raw_monthly_baseline=np.array(bs), donor4=np.array(d4s), donor8=np.array(d8s))
        print(f"{year} H={H} L={L} {direction}: {len(group)} cases", flush=True)

    result = pd.DataFrame(case_rows)
    assert len(result) == len(frozen) and not result.duplicated(KEY).any()
    merged = result.merge(old_scores, on=KEY, how="left", validate="one_to_one")
    assert merged.nse.notna().sum() == merged.nse4.notna().sum()
    errors = {}
    for new, original in (("nse4", "nse"), ("skill4", "skill"), ("sse4", "sse")):
        a = merged[new].to_numpy(float)
        b = merged[original].to_numpy(float)
        finite = np.isfinite(a) & np.isfinite(b)
        assert np.array_equal(np.isfinite(a), np.isfinite(b))
        rel = np.abs(a[finite] - b[finite]) / (1 + np.abs(b[finite]))
        errors[f"{new}_max_relative"] = float(rel.max(initial=0))
        assert errors[f"{new}_max_relative"] < 1e-10
    result.to_csv(HERE / "case_metrics.csv.gz", index=False)
    pd.DataFrame(band_rows).to_csv(HERE / "lead_12month_metrics.csv.gz", index=False)
    pd.DataFrame(annual_rows).to_csv(HERE / "annual_volume_metrics.csv.gz", index=False)
    sources = [Path(__file__), SOURCE / "case_parameters.csv", SOURCE / "case_metrics.csv.gz",
               old.DATA / "flow_qc20_dedup.npy", old.DATA / "station_ids.npy",
               old.DATA / "dates.npy", old.ROOT / "global_station_meta_kg.csv",
               old.ROOT / "boundary_direction_validation_20260922/models.py",
               old.ROOT / "boundary_validation_20260922/models.py",
               old.HERE / "run_stress.py", old.ROOT / "src/data/donors.py"]
    audit = dict(status="PASS", n_cases=len(result), n_groups=len(result.groupby(GROUP)),
                 elapsed_seconds=time.time() - started, top4_reproduction=errors,
                 changed_parameter="R3 all-ranked/monthly-first-four -> R2 fixed pool of eight gap-reporting qualified donors",
                 reporting_selector="donor reports at least once in hidden block; donor visibility only, no hidden target flow",
                 cohort="frozen R3 per-start-duration eligible cases; original strict cohort can be joined",
                 source_sha256={str(p.relative_to(ROOT)): sha(p) for p in sources})
    (HERE / "audit.json").write_text(json.dumps(audit, indent=2, ensure_ascii=False))
    print(json.dumps({k: audit[k] for k in ("status", "n_cases", "elapsed_seconds", "top4_reproduction")}), flush=True)


if __name__ == "__main__":
    main()
