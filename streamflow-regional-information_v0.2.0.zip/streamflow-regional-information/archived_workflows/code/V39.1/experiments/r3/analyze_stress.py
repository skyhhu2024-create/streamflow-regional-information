"""Station-cluster summaries; cohort construction never uses scores."""
from pathlib import Path
import importlib.util,json
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];OUT=HERE/'outputs'
KEY=['station_id','year','history','horizon','direction']
BLOCK=['station_id','year','horizon']
GROUP=['history','horizon','direction','prediction']
BOOT=1000;SEED=20260923

def interval(values,kind='median'):
    x=np.asarray(values,float);x=x[np.isfinite(x)]
    if not len(x):return np.nan,np.nan,np.nan,0
    fn=np.median if kind=='median' else np.mean
    point=float(fn(x))
    if len(x)<30:return point,np.nan,np.nan,len(x)
    rng=np.random.default_rng(SEED)
    vals=fn(x[rng.integers(0,len(x),(BOOT,len(x)))],axis=1)
    lo,hi=np.quantile(vals,[.025,.975])
    return point,float(lo),float(hi),len(x)

def summarized(df,groups,metrics):
    rows=[]
    for key,g in df.groupby(groups,dropna=False,sort=True):
        key=key if isinstance(key,tuple) else (key,)
        base=dict(zip(groups,key));base['n_stations']=g.station_id.nunique();base['n_rows']=len(g)
        for metric in metrics:
            x=g.groupby('station_id')[metric].median()
            val,lo,hi,n=interval(x)
            rows.append(dict(**base,metric=metric,estimate=val,ci_lower=lo,ci_upper=hi,n_finite=n))
        if 'skill' in metrics:
            x=g.groupby('station_id').skill.median().dropna()
            val,lo,hi,n=interval((x<0).astype(float),'mean')
            rows.append(dict(**base,metric='worse_than_baseline_share',estimate=val,ci_lower=lo,ci_upper=hi,n_finite=n))
    return pd.DataFrame(rows)

def main():
    p=pd.read_csv(OUT/'case_parameters.csv');m=pd.read_csv(OUT/'case_metrics.csv.gz')
    assert not p.duplicated(KEY).any()
    full=p.groupby(BLOCK).full_support.agg(['all','size']).reset_index()
    full['matched_full_support']=full['all']&(full['size']==6)
    p=p.merge(full[BLOCK+['matched_full_support']],on=BLOCK,validate='many_to_one')
    # Four durations x three H x two directions, identical 1990 starts.
    strict=p[p.year==1990].groupby('station_id').agg(all_supported=('full_support','all'),n=('horizon','size'))
    strict_ids=set(strict.index[strict.all_supported & strict.n.eq(24)])
    p['strict_common_duration']=p.year.eq(1990)&p.station_id.isin(strict_ids)
    p.to_csv(OUT/'cohort_membership.csv',index=False)
    join=p[KEY+['matched_full_support','strict_common_duration']]
    m=m.merge(join,on=KEY,validate='many_to_one')
    cohort_counts=p.groupby(['year','horizon']).agg(n_cases=('station_id','size'),n_stations=('station_id','nunique'),
        matched_cases=('matched_full_support','sum'),strict_common_cases=('strict_common_duration','sum')).reset_index()
    cohort_counts['matched_stations']=cohort_counts.matched_cases//6
    cohort_counts.to_csv(OUT/'cohort_counts.csv',index=False)
    outputs=[]
    for cohort,keep in [('all_eligible',np.ones(len(m),bool)),('matched_support',m.matched_full_support),('strict_common',m.strict_common_duration)]:
        result=summarized(m[keep],GROUP,['nse','skill','signed_volume_bias_pct'])
        result.insert(0,'cohort',cohort);outputs.append(result)
    summary=pd.concat(outputs,ignore_index=True);summary.to_csv(OUT/'summary.csv',index=False)
    # Within-window paired differences, then median within station.
    primary=m[m.matched_full_support]
    differences=[]
    for key,g in primary.groupby(['history','horizon','prediction']):
        wide=g.pivot(index=['station_id','year'],columns='direction',values='nse').dropna()
        x=(wide.backward-wide.forward).groupby(level=0).median()
        val,lo,hi,n=interval(x)
        differences.append(dict(history=key[0],horizon=key[1],prediction=key[2],contrast='backward_minus_forward_nse',estimate=val,ci_lower=lo,ci_upper=hi,n_stations=n))
    for key,g in primary.groupby(['history','horizon','direction']):
        wide=g.pivot(index=['station_id','year'],columns='prediction',values='nse')
        for comparator in ['AR_removed','AR_far_removed','AR_original_threshold_retained']:
            x=(wide.AR_retained-wide[comparator]).dropna().groupby(level=0).median()
            val,lo,hi,n=interval(x)
            differences.append(dict(history=key[0],horizon=key[1],direction=key[2],prediction='AR_retained',contrast='retained_minus_'+comparator,estimate=val,ci_lower=lo,ci_upper=hi,n_stations=n))
    pd.DataFrame(differences).to_csv(OUT/'paired_contrasts.csv',index=False)
    lead=pd.read_csv(OUT/'lead_metrics.csv.gz').merge(join,on=KEY,validate='many_to_one')
    lead=lead[lead.matched_full_support & lead.prediction.isin(['AR_retained','AR_removed','AR_far_removed'])]
    summarized(lead,GROUP+['lead_start','lead_end'],['skill']).to_csv(OUT/'lead_summary.csv',index=False)
    ann=pd.read_csv(OUT/'annual_volume_metrics.csv.gz').merge(join,on=KEY,validate='many_to_one')
    ann['absolute_annual_volume_bias_pct']=ann.annual_volume_bias_pct.abs()
    summarized(ann[ann.matched_full_support],GROUP,['annual_volume_bias_pct','absolute_annual_volume_bias_pct']).to_csv(OUT/'annual_summary.csv',index=False)
    # Reuse the existing metadata rules as a READ-ONLY classification function.
    spec=importlib.util.spec_from_file_location('regulation_rules',ROOT/'boundary_direction_validation_20260922/regulation/analyze_regulation.py')
    reg=importlib.util.module_from_spec(spec);spec.loader.exec_module(reg)
    metadata=pd.read_csv(ROOT/'boundary_direction_validation_20260922/regulation/station_regulation_metadata.csv').set_index('station_id')
    for c in ['clean_mapping','timing_complete_90','timing_complete_all']:
        metadata[c]=metadata[c].astype(str).str.lower().eq('true')
    dams=pd.read_csv(ROOT/'gsim_dor_dams.csv').rename(columns={'gsim.no':'station_id'}).drop_duplicates(['station_id','gdw_id'])
    dated=dams[(dams.cap_mcm>0)&np.isfinite(dams.cap_mcm)&dams.year.between(1,2026)&dams.year.eq(dams.year.round())]
    damyears={sid:list(zip(g.gdw_id.astype(int),g.year.astype(int))) for sid,g in dated.groupby('station_id')}
    events=[]
    for row in p[p.matched_full_support].itertuples(index=False):
        lo=min(pd.Timestamp(row.qualification_start).year,pd.Timestamp(row.gap_start).year)
        hi=max(pd.Timestamp(row.qualification_end).year,pd.Timestamp(row.gap_end).year)
        target=reg.classify_event([row.station_id],lo,hi,metadata,damyears)
        refs=reg.classify_event(json.loads(row.used_reference_ids),lo,hi,metadata,damyears)
        both=reg.event_union([target[0],refs[0]])
        strictt=reg.classify_event([row.station_id],lo,hi,metadata,damyears,strict=True)
        strictr=reg.classify_event(json.loads(row.used_reference_ids),lo,hi,metadata,damyears,strict=True)
        events.append(dict(**{c:getattr(row,c) for c in KEY},target_event=target[0],reference_event=refs[0],
                           combined_event=both,strict_event=reg.event_union([strictt[0],strictr[0]]),
                           exposure_start_year=lo,exposure_end_year=hi))
    ev=pd.DataFrame(events)
    # Match event labels in a paired directional comparison: union of the two ranges.
    pair_event=ev.groupby(KEY[:-1]).combined_event.agg(reg.event_union).rename('paired_event').reset_index()
    ev=ev.merge(pair_event,on=KEY[:-1],validate='many_to_one')
    paired_strict=ev.groupby(KEY[:-1]).strict_event.agg(reg.event_union).rename('paired_strict_event').reset_index()
    ev=ev.merge(paired_strict,on=KEY[:-1],validate='many_to_one')
    ev.to_csv(OUT/'regulation_classification.csv',index=False)
    rm=primary[primary.prediction.eq('AR_retained')].merge(ev,on=KEY,validate='one_to_one')
    rsummary=summarized(rm,['history','horizon','direction','paired_event'],['nse','skill','signed_volume_bias_pct'])
    rsummary.to_csv(OUT/'regulation_summary.csv',index=False)
    ra=ann[ann.matched_full_support&ann.prediction.eq('AR_retained')].merge(ev,on=KEY,validate='many_to_one')
    summarized(ra,['history','horizon','direction','paired_event'],['annual_volume_bias_pct','absolute_annual_volume_bias_pct']).to_csv(OUT/'regulation_annual_summary.csv',index=False)
    sensitivity=summarized(rm,['history','horizon','direction','paired_strict_event'],['nse','skill','signed_volume_bias_pct'])
    sensitivity.to_csv(OUT/'regulation_timing_sensitivity.csv',index=False)
    audit=dict(status='PASS',n_fitted_cases=len(p),n_history_support_matched_stations=p.loc[p.matched_full_support,'station_id'].nunique(),
               n_strict_common_duration_stations=len(strict_ids),n_bootstrap=BOOT,seed=SEED,
               n_cases_without_full_support=int((~p.full_support).sum()),
               summary_rule='Within-station median over starts (and years for annual errors); median across stations. Failure share uses station median skill <0.',
               cohort_selected_using_prediction_scores=False,ci_type='station cluster percentile, conditional on predictions and cohort')
    (OUT/'analysis_audit.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps(audit,indent=2))

if __name__=='__main__':main()
