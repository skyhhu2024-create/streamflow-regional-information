"""History-by-horizon experiment using the existing streamflow-only kernels.

Only this revision directory is written. Target truth is passed to scoring,
never to fitting or prediction. Each direction is an independent retrospective
task, not a real-time forecast. Contemporary donor smoothing is permitted.
"""
from pathlib import Path
import importlib.util, json, hashlib, time, warnings
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
DATA=ROOT/'boundary_validation_20260922/data'
OUT=HERE/'outputs'
spec=importlib.util.spec_from_file_location('direction_adapter',ROOT/'boundary_direction_validation_20260922/models.py')
adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
k=adapter.kernel
HISTORY=(24,60,120)
HORIZONS=(12,36,120,180)
PREDICTIONS=('AR_retained','AR_removed','AR_far_removed','DAT_retained','Regression_retained','AR_original_threshold_retained','AR_original_threshold_removed')

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def distance(lat0,lon0,lat,lon):
    p=np.pi/180
    a=np.sin((lat-lat0)*p/2)**2+np.cos(lat0*p)*np.cos(lat*p)*np.sin((lon-lon0)*p/2)**2
    return 6371*2*np.arcsin(np.sqrt(np.clip(a,0,1)))

def training(q,months):
    z,clim,mu,sigma,counts=k.fit_transform(q,months,len(q))
    return dict(z=z,clim=clim,mu=mu,sigma=sigma,counts=counts)

def fit_case(tr,ti,cc,dist):
    case=adapter.fit_case(tr,ti,cc,dist)
    original=case['params'].copy()
    z=tr['z'][:,ti]
    ar,n=k.linear_fit(z[:-1],z[1:],min_pairs=12)
    if ar is not None:
        pair=np.isfinite(z[:-1])&np.isfinite(z[1:])
        phi=float(np.clip(ar[1],-.98,.98))
        c=float(np.mean(z[1:][pair])-phi*np.mean(z[:-1][pair]))
        qvar=float(np.mean((z[1:][pair]-c-phi*z[:-1][pair])**2))
        case['params'].update(c=c,phi=phi,qvar=max(qvar,1e-4),ar_pairs=n)
    return case,original

def predict(case,original,reference_q,months):
    assert reference_q.shape==(len(months),len(case['refs']))
    z=(np.log1p(reference_q)-case['reference_clim'][months]-case['reference_mu'])/case['reference_sigma']
    d,counts=k.composite(z,case['weights'])
    chosen=np.isfinite(z)&(np.cumsum(np.isfinite(z),axis=1)<=4)
    none=np.full(len(d),np.nan);far=d.copy();far[len(d)//2:]=np.nan
    zs=[k.bridge(case['left'],d,case['params']),k.bridge(case['left'],none,case['params']),
        k.bridge(case['left'],far,case['params']),np.nan_to_num(d,nan=0.),
        np.where(np.isfinite(d),case['params']['reg_intercept']+case['params']['reg_slope']*d,0.),
        k.bridge(case['left'],d,original),k.bridge(case['left'],none,original)]
    pred=np.stack([k.inverse(v,months,case['clim'],case['mu'],case['sigma']) for v in zs],axis=1)
    return pred,d,counts,chosen

def metrics(y,p,baseline,days):
    sse=float(np.sum((p-y)**2)); den=float(np.sum((y-y.mean())**2));bsse=float(np.sum((baseline-y)**2))
    volume=float(np.dot(y,days));pv=float(np.dot(p,days))
    return dict(n=len(y),sse=sse,baseline_sse=bsse,obs_variance_sum=den,
        nse=1-sse/den if den>1e-12 else np.nan,
        skill=1-sse/bsse if bsse>1e-12 else np.nan,
        signed_volume_bias_pct=100*(pv-volume)/volume if volume>1e-12 else np.nan)

def run_tests():
    # Short-history AR is estimable; default threshold is retained as sensitivity.
    z=np.random.default_rng(23).normal(size=24)
    assert k.linear_fit(z[:-1],z[1:])[0] is None
    assert k.linear_fit(z[:-1],z[1:],12)[0] is not None
    for direction in ('forward','backward'):
        tr,gap=adapter.indexes(120,180,direction,24)
        assert len(tr)==24 and len(gap)==180 and not set(tr)&set(gap)
        assert tr[-1]==(119 if direction=='forward' else 300)
    m=metrics(np.array([1.,2.]),np.array([1.,2.]),np.array([2.,2.]),np.array([31.,28.]))
    assert m['nse']==1 and m['skill']==1 and m['signed_volume_bias_pct']==0
    return {'short_ar_threshold':True,'disjoint_directional_indices':True,'hand_scored_metrics':True}

def main():
    started=time.time();OUT.mkdir(exist_ok=True)
    assert not (OUT/'run_audit.json').exists(), 'Completed run must not be overwritten'
    tests=run_tests()
    sources=[Path(__file__),HERE/'PROTOCOL.md',ROOT/'boundary_direction_validation_20260922/models.py',ROOT/'boundary_validation_20260922/models.py',DATA/'flow_qc20_dedup.npy',DATA/'station_ids.npy',DATA/'dates.npy',ROOT/'global_station_meta_kg.csv',ROOT/'results/raw/stratified_idw/predictions_long.csv']
    hashes={str(p.relative_to(ROOT)):sha(p) for p in sources}
    q=np.load(DATA/'flow_qc20_dedup.npy',mmap_mode='r');ids=np.load(DATA/'station_ids.npy',allow_pickle=True).astype(str)
    dates=pd.to_datetime(np.load(DATA/'dates.npy',allow_pickle=True));months=dates.month.to_numpy()-1;days=dates.days_in_month.to_numpy()
    negative=(np.isfinite(q)&(q<0)).any(0)
    target_ids=set(pd.read_csv(ROOT/'results/raw/stratified_idw/predictions_long.csv',usecols=['station_id']).station_id.unique())
    targets=np.array([i for i,s in enumerate(ids) if s in target_ids])
    meta=pd.read_csv(ROOT/'global_station_meta_kg.csv').set_index('gsim.no').reindex(ids)
    lat,lon=meta.latitude.to_numpy(float),meta.longitude.to_numpy(float)
    candidates={}
    for ti in targets:
        dd=distance(lat[ti],lon[ti],lat,lon);ok=np.isfinite(dd)&(dd<=800)&~negative;ok[ti]=False
        cc=np.flatnonzero(ok);cc=cc[np.argsort(dd[cc],kind='stable')[:200]];candidates[ti]=(cc,dd[cc])
    params=[];stats=[];segments=[];annual=[];selection=[];prediction_files=[]
    for year in (1990,1995):
      s=(year-1980)*12
      for L in HORIZONS:
        e=s+L
        if e+120>len(q):continue
        # Common target eligibility across all H and BOTH directions at this L.
        ok=np.isfinite(q[s:e,targets]).all(0)&~negative[targets]&np.isfinite(lat[targets]+lon[targets])
        for H in HISTORY:
          for direction in ('forward','backward'):
            ix,_=adapter.indexes(s,L,direction,H);v=np.isfinite(q[np.ix_(ix,targets)])
            ok&=v.sum(0)>=max(24,H//2)
            ok&=v[-1]
            for mo in range(12):ok&=v[months[ix]==mo].sum(0)>=2
        eligible=targets[ok]
        selection.append(dict(year=year,horizon=L,targets_considered=len(targets),eligible_history_truth=len(eligible)))
        for H in HISTORY:
          for direction in ('forward','backward'):
            ix,gap=adapter.indexes(s,L,direction,H)
            tq=np.asarray(q[ix],float).copy();tq[:,negative]=np.nan;tr=training(tq,months[ix])
            ys=[];ps=[];bs=[];ds=[];sids=[]
            for ti in eligible:
                sid=ids[ti];cc,dist=candidates[ti];case,original=fit_case(tr,ti,cc,dist)
                reference_q=np.asarray(q[np.ix_(gap,case['refs'])],float)
                pred,d,count,chosen=predict(case,original,reference_q,months[gap])
                y=np.asarray(q[gap,ti],float)
                raw_clim=np.array([np.nanmean(tq[months[ix]==m,ti]) for m in range(12)])
                baseline=raw_clim[months[gap]]
                assert np.isfinite(pred).all() and np.isfinite(baseline).all()
                key=dict(station_id=sid,year=year,history=H,horizon=L,direction=direction,continent=meta.iloc[ti].continent)
                refs_used=case['refs'][chosen.any(0)]
                params.append(dict(**key,train_start=str(dates[min(ix)].date()),train_end=str(dates[max(ix)].date()),
                    qualification_start=str(dates[min(ix[-60:])].date()),qualification_end=str(dates[max(ix[-60:])].date()),
                    gap_start=str(dates[s].date()),gap_end=str(dates[e-1].date()),n_valid_history=int(np.isfinite(tq[:,ti]).sum()),
                    min_calendar_count=int(tr['counts'][:,ti].min()),n_qualified=len(case['refs']),support_months=int(np.isfinite(d).sum()),
                    full_support=bool(np.isfinite(d).all()),train_coherence=case['train_coherence_r2'],
                    min_qualification_overlap=int(np.min(case['overlap'])) if len(case['overlap']) else 0,
                    used_reference_ids=json.dumps(ids[refs_used].tolist()),phi=case['params']['phi'],
                    ar_pairs=case['params']['ar_pairs'],original_phi=original['phi'],
                    sigma=case['sigma']))
                for pi,name in enumerate(PREDICTIONS):
                    stats.append(dict(**key,prediction=name,**metrics(y,pred[:,pi],baseline,days[gap])))
                    # Lead blocks partition distance from the single target boundary.
                    for lo,hi in ((0,1),(1,3),(3,12),(12,36),(36,60),(60,120),(120,180)):
                        hi=min(hi,L)
                        if lo>=hi:continue
                        segments.append(dict(**key,prediction=name,lead_start=lo+1,lead_end=hi,
                            **metrics(y[lo:hi],pred[lo:hi,pi],baseline[lo:hi],days[gap[lo:hi]])))
                    for yr in np.unique(dates[gap].year):
                        mask=dates[gap].year==yr
                        assert mask.sum()==12
                        am=metrics(y[mask],pred[mask,pi],baseline[mask],days[gap[mask]])
                        annual.append(dict(**key,prediction=name,calendar_year=yr,annual_volume_bias_pct=am['signed_volume_bias_pct']))
                ys.append(y);ps.append(pred);bs.append(baseline);ds.append(d);sids.append(sid)
            name=f'pred_{year}_H{H}_L{L}_{direction}.npz'
            np.savez_compressed(OUT/name,station_id=np.array(sids),gap_index=gap,truth=np.array(ys),prediction=np.array(ps),
                                raw_monthly_baseline=np.array(bs),reference_composite=np.array(ds),prediction_names=np.array(PREDICTIONS))
            prediction_files.append(name)
            print(f'{year} H={H} L={L} {direction}: {len(sids)} cases',flush=True)
    pd.DataFrame(params).to_csv(OUT/'case_parameters.csv',index=False)
    pd.DataFrame(stats).to_csv(OUT/'case_metrics.csv.gz',index=False)
    pd.DataFrame(segments).to_csv(OUT/'lead_metrics.csv.gz',index=False)
    pd.DataFrame(annual).to_csv(OUT/'annual_volume_metrics.csv.gz',index=False)
    pd.DataFrame(selection).to_csv(OUT/'selection_counts.csv',index=False)
    assert hashes=={str(p.relative_to(ROOT)):sha(p) for p in sources}
    audit=dict(status='PASS',elapsed_seconds=time.time()-started,tests=tests,source_sha256=hashes,
               sources_unchanged=True,n_cases=len(params),prediction_files=prediction_files,
               prediction_columns=PREDICTIONS,target_truth_prediction_argument=False)
    (OUT/'run_audit.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps({k:audit[k] for k in ('status','n_cases','elapsed_seconds')}),flush=True)

if __name__=='__main__':main()
