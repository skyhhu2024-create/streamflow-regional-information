# -*- coding: utf-8 -*-
"""
2026-08 重跑：月尺度全方法汇总 + 配对统计（无 scipy 依赖）

产出三张表：
  results_rerun_monthly_table.csv    全方法 NSE/KGE/r/alpha 中位数（对照旧值）
  results_rerun_monthly_paired.csv   逐站配对：vs DAT 与 vs Similarity（关键对照）
  results_rerun_monthly_leak.csv     严格 vs 泄漏

配对统计口径与 compute_stats.py 一致：逐站 NSE → 配对差中位数 + 胜率 +
空间块自助 95% CI（5×5 度块）+ Cliff's delta + Wilcoxon 符号秩（正态近似）。

用法：python analyze_rerun_monthly.py
"""
from __future__ import annotations
import os
from math import erfc, sqrt

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.abspath(__file__))
RNG = np.random.default_rng(0)
NBOOT = 2000

# 展示名 -> dump tag（本轮口径：深度模型均为 --uncertainty 版，带 _unc）
DUMPS = {
    "DAT (donor-anomaly transfer)": "stratified_idw",
    "Similarity reg":               "stratified_similarity_reg",
    "MG-STGAI":                     "MG-STGAI_no_qm_",
    "GRIN (+donor)":                "grin_donor__unc",
    "SAITS (+donor)":               "saits_donor__unc",
    "BRITS (+donor)":               "brits_donor__unc",
    "LSTM (+donor)":                "lstm_donor__unc",
    "GBM (+donor)":                 "stratified_gbm_donor",
    "RF (+donor)":                  "stratified_rf_donor",
    "DTRR (recursive)":             "stratified_donor_recursive",
    "AR(1)":                        "stratified_ar1",
    "Seasonal mean":                "stratified_seasonal_mean",
    "SAITS (single)":               "saits_single__unc",
    "BRITS (single)":               "brits_single__unc",
    "LSTM (single)":                "lstm_single__unc",
}

# 旧值（results_master_strict.csv / README 表，n≈1,630）
OLD = {
    "DAT (donor-anomaly transfer)": 0.827, "MG-STGAI": 0.818, "Similarity reg": 0.803,
    "BRITS (+donor)": 0.80, "GBM (+donor)": 0.775, "SAITS (+donor)": 0.78,
    "RF (+donor)": 0.759, "GRIN (+donor)": 0.738, "DTRR (recursive)": 0.707,
    "LSTM (+donor)": 0.655, "AR(1)": 0.361, "Seasonal mean": 0.325,
    "SAITS (single)": 0.297, "BRITS (single)": 0.263, "LSTM (single)": 0.11,
}

LEAK_PAIRS = [("DAT", "stratified_idw", "stratified_idw_leak"),
              ("Similarity reg", "stratified_similarity_reg", "stratified_similarity_reg_leak"),
              ("RF (+donor)", "stratified_rf_donor", "stratified_rf_donor_leak"),
              ("GBM (+donor)", "stratified_gbm_donor", "stratified_gbm_donor_leak")]


def load(tag: str) -> pd.DataFrame:
    d = pd.read_csv(os.path.join(ROOT, "results", "raw", tag, "predictions_long.csv"))
    d.columns = [c.strip().lstrip("﻿") for c in d.columns]
    return d


def nse(o, p):
    m = np.isfinite(o) & np.isfinite(p)
    o, p = o[m], p[m]
    if o.size < 2:
        return np.nan
    s = ((o - o.mean()) ** 2).sum()
    return np.nan if s < 1e-12 else 1.0 - ((o - p) ** 2).sum() / s


def ra(o, p):
    m = np.isfinite(o) & np.isfinite(p)
    o, p = o[m], p[m]
    if o.size < 3 or o.std() < 1e-9 or p.std() < 1e-12:
        return np.nan, np.nan
    return float(np.corrcoef(o, p)[0, 1]), float(p.std() / o.std())


def per_station(d: pd.DataFrame):
    ns, rs, als = {}, {}, {}
    for sid, g in d.groupby("station_id"):
        o = g["obs"].to_numpy(float); p = g["pred"].to_numpy(float)
        ns[sid] = nse(o, p)
        rs[sid], als[sid] = ra(o, p)
    return pd.Series(ns), pd.Series(rs), pd.Series(als)


def cliffs_delta(x, y):
    n = len(x); gt = lt = 0
    for i in range(0, n, 2000):
        xb = x[i:i + 2000][:, None]
        gt += int((xb > y[None, :]).sum()); lt += int((xb < y[None, :]).sum())
    return (gt - lt) / (n * n)


def wilcoxon_p(d):
    dz = d[d != 0]
    if len(dz) < 10:
        return np.nan
    r = pd.Series(np.abs(dz)).rank().to_numpy()
    n = len(dz)
    z = (r[dz > 0].sum() - n * (n + 1) / 4) / sqrt(n * (n + 1) * (2 * n + 1) / 24)
    return erfc(abs(z) / sqrt(2))


def block_ci(d: pd.Series, cell: pd.Series):
    g = d.groupby(cell)
    arrs = [g.get_group(k).to_numpy() for k in g.groups]
    bs = [np.median(np.concatenate([arrs[i] for i in RNG.integers(0, len(arrs), len(arrs))]))
          for _ in range(NBOOT)]
    return float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5)), len(arrs)


def main() -> None:
    print("载入 %d 个 dump ..." % len(DUMPS))
    NSE, R, A = {}, {}, {}
    for name, tag in DUMPS.items():
        n, r, a = per_station(load(tag))
        NSE[name], R[name], A[name] = n, r, a
        print("  %-30s n=%d" % (name, n.notna().sum()))

    # ---------- 表 1：全方法 ----------
    rows = []
    for name in DUMPS:
        new = NSE[name].median()
        rows.append({"method": name, "NSE_new": new, "NSE_old": OLD.get(name, np.nan),
                     "delta": new - OLD.get(name, np.nan),
                     "r_med": R[name].median(), "alpha_med": A[name].median(),
                     "n_stations": int(NSE[name].notna().sum())})
    t1 = pd.DataFrame(rows).sort_values("NSE_new", ascending=False).reset_index(drop=True)
    t1.to_csv(os.path.join(ROOT, "results_rerun_monthly_table.csv"),
              index=False, encoding="utf-8-sig", float_format="%.4f")
    print("\n" + "=" * 96)
    print("表 1  月尺度全方法（逐站中位 NSE，新 vs 旧）")
    print("=" * 96)
    print(t1.to_string(index=False, float_format=lambda v: "%.4f" % v))

    # ---------- 表 2：配对 ----------
    meta = pd.read_csv(os.path.join(ROOT, "global_station_meta_kg.csv"), low_memory=False)
    meta = meta.set_index("gsim.no")[["latitude", "longitude"]]

    def paired_vs(ref_name):
        out = []
        for name in DUMPS:
            if name == ref_name:
                continue
            c = pd.concat({"A": NSE[name], "B": NSE[ref_name]}, axis=1).dropna()
            d = c["A"] - c["B"]
            mm = meta.reindex(c.index)
            cell = (np.floor(mm.latitude / 5).astype("Int64").astype(str) + "_" +
                    np.floor(mm.longitude / 5).astype("Int64").astype(str)).fillna("NA")
            lo, hi, nb = block_ci(d, cell)
            out.append({"method": name, "vs": ref_name, "n": len(c),
                        "median_diff": d.median(), "ci_lo": lo, "ci_hi": hi,
                        "win_pct": 100 * (d > 0).mean(),
                        "cliffs_delta": cliffs_delta(c["A"].to_numpy(), c["B"].to_numpy()),
                        "wilcoxon_p": wilcoxon_p(d.to_numpy()), "n_blocks": nb})
        return pd.DataFrame(out)

    p1 = paired_vs("DAT (donor-anomaly transfer)")
    p2 = paired_vs("Similarity reg")
    t2 = pd.concat([p1, p2], ignore_index=True).sort_values(["vs", "median_diff"], ascending=[True, False])
    t2.to_csv(os.path.join(ROOT, "results_rerun_monthly_paired.csv"),
              index=False, encoding="utf-8-sig", float_format="%.5f")
    for ref, blk in t2.groupby("vs"):
        print("\n" + "=" * 96)
        print("表 2  逐站配对  vs  %s   （正 = 该方法更好；CI 为 5×5° 空间块自助）" % ref)
        print("=" * 96)
        print(blk.drop(columns="vs").to_string(index=False, float_format=lambda v: "%.4f" % v))

    # ---------- 表 3：泄漏 ----------
    rows = []
    for name, s_tag, l_tag in LEAK_PAIRS:
        s, _, _ = per_station(load(s_tag))
        l, _, _ = per_station(load(l_tag))
        c = pd.concat({"strict": s, "leak": l}, axis=1).dropna()
        rows.append({"method": name, "strict": c.strict.median(), "leak": c.leak.median(),
                     "inflation": c.leak.median() - c.strict.median(), "n": len(c)})
    t3 = pd.DataFrame(rows)
    t3.to_csv(os.path.join(ROOT, "results_rerun_monthly_leak.csv"),
              index=False, encoding="utf-8-sig", float_format="%.4f")
    print("\n" + "=" * 96)
    print("表 3  归一化泄漏消融（严格 vs 全记录归一化）")
    print("=" * 96)
    print(t3.to_string(index=False, float_format=lambda v: "%.4f" % v))

    print("\n[OK] results_rerun_monthly_table.csv / _paired.csv / _leak.csv")


if __name__ == "__main__":
    main()
