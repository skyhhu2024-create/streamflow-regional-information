"""Frozen DAT8 synchronous-month coverage replay; old artifacts are read only.

Only prediction-period availability changes. Fixed selected-reference composite
anomalies are retained at masked months and set to zero otherwise. Each result
is scored on the same full 120-month target truth. Repeated masks are averaged
within gauge before gauge summaries and spatial block bootstrap.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
CODE = HERE.parents[2]
sys.path.insert(0, str(CODE / "V39.1/experiments/r3"))
import run_stress as stress

SOURCE = CODE / "V39.1/R3_revision_proposal/dat_selected8_r2matched"
OLD_AUDIT = CODE / "V39.1/R3_revision_proposal/dat8_reference_input_ablation"
FRACTIONS = (0., .25, .5, .75, 1.)
SEEDS = tuple(range(20261014, 20261024))
BOOT = 2000


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for part in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


def masks(sid: str, chronological_months: np.ndarray) -> np.ndarray:
    """Nested exact coverage; random placements do not inspect flow values."""
    out = np.zeros((len(SEEDS), len(FRACTIONS), 120), dtype=bool)
    for ri, seed in enumerate(SEEDS):
        identity = int.from_bytes(hashlib.sha256(f"{seed}|{sid}".encode()).digest()[:8], "little")
        rng = np.random.default_rng(identity)
        extra25 = set(rng.permutation(12)[:6].tolist())
        extra75 = set(rng.permutation(12)[:6].tolist())
        for mo in range(12):
            ii = np.flatnonzero(chronological_months == mo)
            assert len(ii) == 10
            order = rng.permutation(ii)
            counts = (0, 2 + (mo in extra25), 5, 7 + (mo in extra75), 10)
            for fi, count in enumerate(counts):
                out[ri, fi, order[:count]] = True
    assert np.array_equal(out.sum(2), np.tile(np.array([0, 30, 60, 90, 120]), (len(SEEDS), 1)))
    assert (out[:, :-1] <= out[:, 1:]).all()
    return out


def main() -> None:
    started = time.time()
    assert not (HERE / "audit.json").exists(), "Completed run must not be overwritten"
    cohort = pd.read_csv(SOURCE / "strict691_station_ids.csv").station_id.astype(str).tolist()
    assert len(cohort) == len(set(cohort)) == 691
    paths = [Path(__file__), SOURCE / "strict691_station_ids.csv", SOURCE / "case_metrics.csv.gz",
             OLD_AUDIT / "case_metrics.csv", OLD_AUDIT / "audit.json",
             stress.DATA / "flow_qc20_dedup.npy", stress.DATA / "station_ids.npy", stress.DATA / "dates.npy",
             CODE / "global_station_meta_kg.csv", CODE / "boundary_validation_20260922/models.py",
             CODE / "boundary_direction_validation_20260922/models.py", stress.HERE / "run_stress.py"]
    paths += [SOURCE / f"pred_1990_H120_L120_{d}.npz" for d in ("forward", "backward")]
    hashes = {str(p.relative_to(CODE)): sha(p) for p in paths}
    protocol = dict(status="frozen_before_prediction_and_scoring", cohort_n=691,
                    year=1990, history_months=120, gap_months=120,
                    directions=["forward", "backward"], coverage_fractions=list(FRACTIONS),
                    repeats=10, seeds=list(SEEDS), selected_reference_cap=8,
                    reference_pool="original fixed ranked DAT8 pool; unchanged",
                    transformation="original permitted-side log-seasonal target fit; unchanged",
                    intervention="set synchronous composite anomaly to zero at excluded gap months; retain original composite otherwise",
                    coverage_definition="fraction of hidden target months with any synchronous reference input retained",
                    mask="nested, gauge-specific SHA256-seeded placements, calendar-month stratified; exactly 0/30/60/90/120 of 120 months",
                    target_truth_usage="scoring only; mask, training and prediction do not inspect gap target flows",
                    scoring="all 120 target months at every coverage; annual absolute volume error is gauge mean across calendar-year absolute percent errors with positive true volume; zero-volume years have undefined percent error and do not remove gauges",
                    aggregation="mean metric over ten masks within each gauge, then median over the same 691 gauges",
                    bootstrap="2000 resamples of occupied 5-degree spatial blocks; all gauges of each drawn block retained; mask repeats not independent gauges",
                    bootstrap_seed=20261014, source_sha256=hashes,
                    interpretation="controlled scattered synchronous-month availability, not a calibration-length, missing-block-length or reference-count experiment")
    (HERE / "protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    print("Frozen protocol and source hashes", flush=True)

    q = np.load(stress.DATA / "flow_qc20_dedup.npy", mmap_mode="r")
    ids = np.load(stress.DATA / "station_ids.npy", allow_pickle=True).astype(str)
    id_to_i = {sid: i for i, sid in enumerate(ids)}
    target_i = np.array([id_to_i[sid] for sid in cohort])
    dates = pd.to_datetime(np.load(stress.DATA / "dates.npy", allow_pickle=True))
    months = dates.month.to_numpy() - 1
    days = dates.days_in_month.to_numpy()
    meta = pd.read_csv(CODE / "global_station_meta_kg.csv").set_index("gsim.no").reindex(cohort)
    assert np.isfinite(meta[["latitude", "longitude"]].to_numpy(float)).all()
    blocks = list(zip(np.floor((meta.latitude.to_numpy(float) + 90) / 5).astype(int),
                      np.floor((meta.longitude.to_numpy(float) + 180) / 5).astype(int)))
    unique = sorted(set(blocks))
    groups = [np.array([i for i, b in enumerate(blocks) if b == key], dtype=int) for key in unique]
    bootstrap_rng = np.random.default_rng(20261014)
    draws = bootstrap_rng.integers(0, len(groups), size=(BOOT, len(groups)))
    bootstrap_indices = [np.concatenate([groups[j] for j in draw]) for draw in draws]
    old_cases = pd.read_csv(OLD_AUDIT / "case_metrics.csv")
    frozen_scores = pd.read_csv(SOURCE / "case_metrics.csv.gz")
    records = []
    endpoints = []
    mask_arrays = []
    summaries = []
    for direction in ("forward", "backward"):
        ix, gap = stress.adapter.indexes(120, 120, direction, 120)
        legal_q = np.asarray(q[np.ix_(ix, target_i)], dtype=float)
        assert not (np.isfinite(legal_q) & (legal_q < 0)).any()
        training = stress.training(legal_q, months[ix])
        frozen = np.load(SOURCE / f"pred_1990_H120_L120_{direction}.npz", allow_pickle=False)
        source_i = {sid: i for i, sid in enumerate(frozen["station_id"].astype(str))}
        take = np.array([source_i[sid] for sid in cohort])
        assert np.array_equal(gap, frozen["gap_index"])
        d8 = frozen["donor8"][take]
        assert np.isfinite(d8).all()
        # Replay inverse transformations using the original frozen composite.
        full_prediction = np.array([stress.k.inverse(d8[j], months[gap], training["clim"][:, j],
                              training["mu"][j], training["sigma"][j]) for j in range(691)])
        no_prediction = np.array([stress.k.inverse(np.zeros(120), months[gap], training["clim"][:, j],
                            training["mu"][j], training["sigma"][j]) for j in range(691)])
        assert np.allclose(full_prediction, frozen["dat_top8"][take], rtol=1e-12, atol=1e-12)
        # Hidden target truth is now read only for evaluation.
        truth = np.asarray(q[np.ix_(gap, target_i)], dtype=float).T
        assert np.array_equal(truth, frozen["truth"][take])
        assert np.isfinite(truth).all()
        denominator = np.square(truth - truth.mean(1)[:, None]).sum(1)
        assert (denominator > 1e-12).all()
        zero_sse = np.square(no_prediction - truth).sum(1)
        full_sse = np.square(full_prediction - truth).sum(1)
        zero_nse = 1 - zero_sse / denominator
        full_nse = 1 - full_sse / denominator
        expected = old_cases[(old_cases.year == 1990) & (old_cases.history == 120) &
                             (old_cases.horizon == 120) & (old_cases.direction == direction)].set_index("station_id").reindex(cohort)
        assert np.allclose(zero_nse, expected.no_reference_input_nse, atol=1e-10)
        assert np.allclose(full_nse, expected.dat8_nse, atol=1e-10)
        selected = frozen_scores[(frozen_scores.year == 1990) & (frozen_scores.history == 120) &
                                 (frozen_scores.horizon == 120) & (frozen_scores.direction == direction)].set_index("station_id").reindex(cohort)
        assert (selected.support8 == 120).all()
        endpoints.append(dict(direction=direction, n=691, no_input_nse_median=float(np.median(zero_nse)),
                              full_input_nse_median=float(np.median(full_nse)),
                              paired_gain_median=float(np.median(full_nse - zero_nse)),
                              max_full_prediction_absolute_error=float(np.max(np.abs(full_prediction - frozen["dat_top8"][take]))),
                              max_no_input_nse_absolute_error=float(np.max(np.abs(zero_nse - expected.no_reference_input_nse))),
                              max_full_input_nse_absolute_error=float(np.max(np.abs(full_nse - expected.dat8_nse)))))
        all_masks = np.array([masks(sid, months[gap]) for sid in cohort])
        mask_arrays.append(all_masks)
        annual_ix = [np.flatnonzero(dates[gap].year == year) for year in sorted(set(dates[gap].year))]
        assert len(annual_ix) == 10 and all(len(a) == 12 for a in annual_ix)
        for fi, fraction in enumerate(FRACTIONS):
            station_metrics = []
            for ri, seed in enumerate(SEEDS):
                composite = np.where(all_masks[:, ri, fi], d8, 0.)
                prediction = np.array([stress.k.inverse(composite[j], months[gap], training["clim"][:, j],
                                  training["mu"][j], training["sigma"][j]) for j in range(691)])
                sse = np.square(prediction - truth).sum(1)
                nse = 1 - sse / denominator
                yearly_error = []
                for ai in annual_ix:
                    true_volume = np.sum(truth[:, ai] * days[gap[ai]][None, :], axis=1)
                    pred_volume = np.sum(prediction[:, ai] * days[gap[ai]][None, :], axis=1)
                    yearly_error.append(np.divide(100 * np.abs(pred_volume - true_volume), true_volume,
                                        out=np.full(691, np.nan), where=true_volume > 0))
                annual_error = np.nanmean(yearly_error, axis=0)
                valid_years = np.isfinite(yearly_error).sum(axis=0)
                assert np.isfinite(annual_error).all()
                total_volume = np.sum(truth * days[gap][None, :], axis=1)
                predicted_volume = np.sum(prediction * days[gap][None, :], axis=1)
                block_error = 100 * np.abs(predicted_volume - total_volume) / total_volume
                gain = nse - zero_nse
                relative_rmse = 100 * (1 - np.sqrt(sse / zero_sse))
                station_metrics.append(np.stack([nse, gain, relative_rmse, annual_error, block_error], axis=1))
                for j, sid in enumerate(cohort):
                    records.append(dict(station_id=sid, direction=direction, fraction=fraction, repeat=ri, seed=seed,
                                        retained_synchronous_months=int(all_masks[j, ri, fi].sum()),
                                        nse=float(nse[j]), paired_nse_gain_vs_zero=float(gain[j]),
                                        relative_rmse_drop_pct_vs_zero=float(relative_rmse[j]),
                                        n_years_with_positive_true_volume=int(valid_years[j]),
                                        annual_mean_absolute_volume_error_pct=float(annual_error[j]),
                                        block_absolute_volume_error_pct=float(block_error[j])))
            averaged = np.mean(station_metrics, axis=0)
            summary = dict(direction=direction, fraction=fraction, n_gauges=691, repeats=10,
                           retained_synchronous_months_per_gauge=int(120 * fraction),
                           occupied_spatial_blocks=len(unique))
            for mi, name in enumerate(("nse", "paired_nse_gain_vs_zero", "relative_rmse_drop_pct_vs_zero",
                                       "annual_mean_absolute_volume_error_pct", "block_absolute_volume_error_pct")):
                values = averaged[:, mi]
                boot = np.array([np.median(values[ii]) for ii in bootstrap_indices])
                lo, hi = np.quantile(boot, [.025, .975])
                summary[f"median_{name}"] = float(np.median(values))
                summary[f"{name}_ci95_low"] = float(lo)
                summary[f"{name}_ci95_high"] = float(hi)
            summary["positive_gain_share"] = float(np.mean(averaged[:, 1] > 0))
            summaries.append(summary)
        print(f"{direction}: replay and full coverage ladder scored", flush=True)
    pd.DataFrame(records).to_csv(HERE / "replicate_station_metrics.csv.gz", index=False)
    station = pd.DataFrame(records).groupby(["station_id", "direction", "fraction"], sort=False).agg(
        nse=("nse", "mean"), paired_nse_gain_vs_zero=("paired_nse_gain_vs_zero", "mean"),
        relative_rmse_drop_pct_vs_zero=("relative_rmse_drop_pct_vs_zero", "mean"),
        annual_mean_absolute_volume_error_pct=("annual_mean_absolute_volume_error_pct", "mean"),
        block_absolute_volume_error_pct=("block_absolute_volume_error_pct", "mean"),
        retained_synchronous_months=("retained_synchronous_months", "first")).reset_index()
    station.to_csv(HERE / "station_metrics.csv", index=False)
    pd.DataFrame(summaries).to_csv(HERE / "summary.csv", index=False)
    np.savez_compressed(HERE / "availability_masks.npz", station_id=np.array(cohort),
                        directions=np.array(["forward", "backward"]), seeds=np.array(SEEDS),
                        fractions=np.array(FRACTIONS), available=np.array(mask_arrays))
    assert hashes == {str(p.relative_to(CODE)): sha(p) for p in paths}
    audit = dict(status="PASS", sources_unchanged=True, all_120_hidden_months_scored=True,
                 n_gauges=691, occupied_spatial_blocks=len(unique), n_records=len(records),
                 protocol_sha256=sha(HERE / "protocol.json"), endpoints=endpoints,
                 elapsed_seconds=time.time() - started,
                 limitation="Reference availability removed in season-balanced scattered months; does not establish an optimal investment or generalize to all unsupported actual gaps.")
    (HERE / "audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    print(json.dumps({"audit": audit, "summary": summaries}, indent=2), flush=True)


if __name__ == "__main__":
    main()
