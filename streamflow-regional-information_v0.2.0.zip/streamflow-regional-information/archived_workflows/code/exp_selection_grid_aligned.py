# -*- coding: utf-8 -*-
"""Strict monthly donor-selection x donor-combination experiment.

The operational cells use the same de-duplicated GSIM station split, visible-only
transformers, pseudo-gaps and donor constraints as the monthly benchmark.  The
in-gap oracle is retained only as an explicitly labelled diagnostic ceiling.

New outputs are run-id versioned and include per-station scores, repeated random
donor draws, paired effect decomposition, operational references and an audit.
No legacy CSV is overwritten.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd


ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

SELECTIONS = ["random_kNN", "nearest_dist", "attribute_sim", "corr_filtered", "oracle_ingap"]
OPERATIONAL_SELECTIONS = ["random_kNN", "nearest_dist", "attribute_sim", "corr_filtered"]
COMBINATIONS = ["equal", "distance_w", "corr_w", "OLS"]
K_VALUES = [1, 2, 4, 8, 16]


def safe_run_id(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_")
    if not value:
        raise ValueError("run-id cannot be empty")
    return value


def versioned_output_path(stem: str, run_id: str, suffix: str = "csv") -> str:
    return os.path.join(ROOT, "%s_%s.%s" % (stem, safe_run_id(run_id), suffix))


@dataclass
class NSEAccumulator:
    n: int = 0
    sum_obs: float = 0.0
    sum_obs2: float = 0.0
    sum_sq_error: float = 0.0

    def update(self, obs: np.ndarray, pred: np.ndarray) -> None:
        obs = np.asarray(obs, float)
        pred = np.asarray(pred, float)
        valid = np.isfinite(obs) & np.isfinite(pred)
        if not valid.any():
            return
        obs = obs[valid]
        pred = pred[valid]
        self.n += int(len(obs))
        self.sum_obs += float(obs.sum())
        self.sum_obs2 += float(np.square(obs).sum())
        self.sum_sq_error += float(np.square(obs - pred).sum())

    def nse(self) -> float:
        if self.n < 2:
            return np.nan
        denominator = self.sum_obs2 - self.sum_obs * self.sum_obs / self.n
        if denominator < 1e-12:
            return np.nan
        return 1.0 - self.sum_sq_error / denominator


def random_donor_sample(
    info: Sequence[tuple],
    k: int,
    seed: int,
    repeat: int,
    gap_key: str,
) -> list[tuple]:
    """Stable random draw that is independent of loop ordering and resumptions."""
    if not info:
        return []
    payload = "%d|%d|%s" % (seed, repeat, gap_key)
    local_seed = int.from_bytes(hashlib.sha256(payload.encode("utf-8")).digest()[:8], "little")
    rng = np.random.default_rng(local_seed)
    indices = rng.permutation(len(info))[:min(k, len(info))]
    return [info[int(i)] for i in indices]


def update_nested(
    store: Dict[tuple, Dict[str, NSEAccumulator]],
    cell: tuple,
    station_id: str,
    obs: np.ndarray,
    pred: np.ndarray,
) -> None:
    station = store.setdefault(cell, {}).setdefault(str(station_id), NSEAccumulator())
    station.update(obs, pred)


def accumulators_to_frame(
    store: Mapping[tuple, Mapping[str, NSEAccumulator]],
    dimensions: Sequence[str],
) -> pd.DataFrame:
    rows = []
    for cell, stations in store.items():
        cell = cell if isinstance(cell, tuple) else (cell,)
        labels = dict(zip(dimensions, cell))
        for station_id, accumulator in stations.items():
            rows.append({**labels, "station_id": station_id,
                         "n_records": accumulator.n, "NSE": accumulator.nse()})
    return pd.DataFrame(rows)


def build_config(gaps_per_station: int) -> dict:
    return {
        "features": {"use_log1p": True, "deseasonalize": True, "per_station_standardize": True},
        "pseudo_gap": {
            "seed": 42,
            "gaps_per_station": gaps_per_station,
            "length_strata": [[1, 3], [4, 12], [13, 36]],
            "min_context": 12,
            "edge_margin": 6,
        },
        "donors": {
            "max_donors": 8,
            "max_distance_km": 800,
            "min_overlap_months": 24,
            "min_precorr": 0.2,
            "precorr_window": 60,
        },
        "split": {"test_station_frac": 0.15, "val_station_frac": 0.15, "seed": 7},
        "train": {"seq_pad": 6, "batch_size": 32},
    }


def load_attribute_matrix(station_ids: Sequence[str]) -> np.ndarray:
    path = os.path.join(ROOT, "KG", "stations_full_static_with_climate_kg.csv")
    kg = pd.read_csv(path, encoding="latin-1", low_memory=False)
    kg.columns = [str(c).strip().lstrip("\ufeff") for c in kg.columns]
    features = ["altitude", "slope", "snd", "slt", "scl", "area_local"]
    kg["area_local"] = np.log1p(pd.to_numeric(kg["area_local"], errors="coerce"))
    kg = kg.drop_duplicates("gsim.no", keep="first").set_index("gsim.no")
    matrix = np.full((len(station_ids), len(features)), np.nan)
    for row, station_id in enumerate(station_ids):
        if station_id not in kg.index:
            continue
        for col, feature in enumerate(features):
            matrix[row, col] = pd.to_numeric(pd.Series([kg.at[station_id, feature]]), errors="coerce").iloc[0]
    mean = np.nanmean(matrix, axis=0)
    std = np.nanstd(matrix, axis=0)
    std[std < 1e-9] = 1.0
    return np.nan_to_num((matrix - mean) / std, nan=0.0)


def combine_donors(ds, gap, target_z: np.ndarray, selection: Sequence[tuple], mode: str) -> np.ndarray:
    transformer = ds.transformers[gap.station_id]
    months = ds.months[gap.start:gap.end + 1]
    length = gap.length
    if not selection:
        return transformer.inverse_transform(np.zeros(length), months)
    indices = [item[0] for item in selection]
    donors = ds.z[gap.start:gap.end + 1, indices]
    if mode == "equal":
        weights = np.ones(len(selection))
    elif mode == "distance_w":
        weights = np.array([np.exp(-item[1] / 800.0) for item in selection])
    elif mode == "corr_w":
        weights = np.array([max(item[2], 0.0) for item in selection])
    elif mode == "OLS":
        lower = max(0, gap.start - 120)
        x_train = ds.z[lower:gap.start, indices]
        y_train = target_z[lower:gap.start]
        valid = np.isfinite(y_train) & np.isfinite(x_train).all(axis=1)
        if valid.sum() >= max(6, len(indices) + 2):
            design = np.column_stack([x_train[valid], np.ones(valid.sum())])
            coefficients, *_ = np.linalg.lstsq(design, y_train[valid], rcond=None)
            filled = np.where(np.isfinite(donors), donors, 0.0)
            z_hat = np.column_stack([filled, np.ones(length)]) @ coefficients
            return transformer.inverse_transform(z_hat, months)
        weights = np.ones(len(selection))
    else:
        raise ValueError("unknown combination mode: %s" % mode)
    finite = np.isfinite(donors)
    weighted = finite * weights[None, :]
    denominator = weighted.sum(axis=1)
    z_hat = np.where(
        denominator > 0,
        np.nansum(np.nan_to_num(donors) * weighted, axis=1) / np.maximum(denominator, 1e-9),
        0.0,
    )
    return transformer.inverse_transform(z_hat, months)


def top_k(info: Sequence[tuple], key, reverse: bool, k: int, predicate=None) -> list[tuple]:
    pool = list(info) if predicate is None else [item for item in info if predicate(item)]
    return sorted(pool, key=key, reverse=reverse)[:k]


def station_blocks() -> pd.Series:
    meta = pd.read_csv(os.path.join(ROOT, "global_station_meta_kg.csv"), low_memory=False)
    meta.columns = [str(c).strip().lstrip("\ufeff") for c in meta.columns]
    meta = meta.drop_duplicates("gsim.no").set_index("gsim.no")
    lat = pd.to_numeric(meta["latitude"], errors="coerce")
    lon = pd.to_numeric(meta["longitude"], errors="coerce")
    block = (np.floor(lat / 5).astype("Int64").astype(str) + "_" +
             np.floor(lon / 5).astype("Int64").astype(str))
    return block.fillna("NA")


def paired_effect_summary(
    current: pd.Series,
    reference: pd.Series,
    blocks: pd.Series,
    n_boot: int,
    rng: np.random.Generator,
) -> dict:
    pair = pd.concat({"current": current, "reference": reference}, axis=1).dropna()
    difference = pair["current"] - pair["reference"]
    labels = blocks.reindex(pair.index).fillna("NA")
    grouped = [difference[labels == label].to_numpy(float) for label in labels.unique()]
    bootstrap = []
    if n_boot > 0 and grouped:
        for _ in range(n_boot):
            chosen = rng.integers(0, len(grouped), len(grouped))
            bootstrap.append(np.median(np.concatenate([grouped[i] for i in chosen])))
    return {
        "n_stations": int(len(difference)),
        "median_diff_NSE": float(difference.median()),
        "win_pct": float(100.0 * (difference > 0).mean()),
        "ci_lo": float(np.percentile(bootstrap, 2.5)) if bootstrap else np.nan,
        "ci_hi": float(np.percentile(bootstrap, 97.5)) if bootstrap else np.nan,
        "n_blocks": int(len(grouped)),
    }


def summarise_grid(stations: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    valid = stations.dropna(subset=["NSE"]).copy()
    repeats = (valid.groupby(["selection", "combination", "repeat"], as_index=False)
               .agg(NSE_med=("NSE", "median"), n_stations=("station_id", "nunique")))
    rows = []
    for (selection, combination), group in repeats.groupby(["selection", "combination"], sort=False):
        rows.append({
            "selection": selection,
            "combination": combination,
            "is_diagnostic": selection == "oracle_ingap",
            "n_repeats": int(group["repeat"].nunique()),
            "NSE_med": float(group["NSE_med"].median()),
            "NSE_q25_repeat": float(group["NSE_med"].quantile(0.25)),
            "NSE_q75_repeat": float(group["NSE_med"].quantile(0.75)),
            "n_stations_min": int(group["n_stations"].min()),
        })
    summary = pd.DataFrame(rows)

    collapsed = (valid.groupby(["selection", "combination", "station_id"], as_index=False)
                 .agg(NSE=("NSE", "median")))
    matrix = collapsed.set_index(["selection", "combination", "station_id"])["NSE"]
    blocks = station_blocks()
    rng = np.random.default_rng(20260811)
    effects = []
    for combination in COMBINATIONS:
        reference = matrix.loc[("random_kNN", combination)]
        for selection in SELECTIONS:
            if selection == "random_kNN":
                continue
            row = paired_effect_summary(matrix.loc[(selection, combination)], reference,
                                        blocks, summarise_grid.n_boot, rng)
            effects.append({"effect": "selection_vs_random", "selection": selection,
                            "combination": combination, "reference": "random_kNN",
                            "is_diagnostic": selection == "oracle_ingap", **row})
    for selection in SELECTIONS:
        reference = matrix.loc[(selection, "equal")]
        for combination in COMBINATIONS:
            if combination == "equal":
                continue
            row = paired_effect_summary(matrix.loc[(selection, combination)], reference,
                                        blocks, summarise_grid.n_boot, rng)
            effects.append({"effect": "combination_vs_equal", "selection": selection,
                            "combination": combination, "reference": "equal",
                            "is_diagnostic": selection == "oracle_ingap", **row})
    return summary, repeats, pd.DataFrame(effects)


summarise_grid.n_boot = 1000


def output_paths(run_id: str) -> dict:
    return {
        "grid": versioned_output_path("results_selection_grid", run_id),
        "grid_stations": versioned_output_path("results_selection_grid_stations", run_id),
        "grid_repeats": versioned_output_path("results_selection_grid_repeats", run_id),
        "effects": versioned_output_path("results_selection_grid_effects", run_id),
        "refs": versioned_output_path("results_grid_refs", run_id),
        "refs_stations": versioned_output_path("results_grid_refs_stations", run_id),
        "k_sweep": versioned_output_path("results_k_sweep", run_id),
        "k_sweep_stations": versioned_output_path("results_k_sweep_stations", run_id),
        "audit": versioned_output_path("results_selection_grid_audit", run_id, "json"),
    }


def ensure_outputs_available(paths: Mapping[str, str], force: bool) -> None:
    existing = [path for path in paths.values() if os.path.exists(path)]
    if existing and not force:
        raise FileExistsError("refusing to overwrite run-id outputs: %s" % existing)


def run_experiment(args: argparse.Namespace) -> dict:
    from src.baselines.classical import idw as dat_fn, seasonal_mean as seasonal_mean_fn
    from src.data.dataset import GapImputationDataset, split_stations
    from src.data.dedup_gsim import drop_gsim_twins
    from src.data.donors import _precorr
    from src.data.gsim_io import load_static, load_station_matrix

    paths = output_paths(args.run_id)
    ensure_outputs_available(paths, args.force)
    config = build_config(args.gaps_per_station)
    started = time.time()
    print("[load] GSIM monthly", flush=True)
    flow = load_station_matrix(
        os.path.join(ROOT, "GSIM_indices", "GSIM_indices", "TIMESERIES", "monthly"),
        "1980-01-01", "2015-12-31", min_valid_months=60, min_days_available=20,
        limit=(args.limit or None),
    )
    before_dedup = int(flow.shape[1])
    flow = drop_gsim_twins(flow)
    after_dedup = int(flow.shape[1])
    print("[dedup] stations %d -> %d" % (before_dedup, after_dedup), flush=True)
    dataset = GapImputationDataset(
        flow, load_static(os.path.join(ROOT, "global_station_meta_kg.csv")), config)
    _, _, test_stations = split_stations(flow.columns, config["split"])
    test_set = set(test_stations)
    test_gaps = [gap for gap in dataset.gaps if gap.station_id in test_set]
    print("[build] test stations=%d gaps=%d (%.1f min)" %
          (len(test_set), len(test_gaps), (time.time() - started) / 60.0), flush=True)

    attributes = load_attribute_matrix(dataset.station_ids)
    grid_acc: Dict[tuple, Dict[str, NSEAccumulator]] = {}
    ref_acc: Dict[tuple, Dict[str, NSEAccumulator]] = {}
    k_acc: Dict[tuple, Dict[str, NSEAccumulator]] = {}
    gaps_used = 0
    no_donor_gaps = 0

    for gap_index, gap in enumerate(test_gaps):
        target_index = dataset.sid2idx[gap.station_id]
        months = dataset.months[gap.start:gap.end + 1]
        truth = dataset.flow[gap.start:gap.end + 1, target_index]
        valid_truth = np.isfinite(truth)
        if valid_truth.sum() < 2:
            continue
        gaps_used += 1

        for name, function in (("Seasonal mean", seasonal_mean_fn), ("DAT", dat_fn)):
            prediction = function(dataset, gap)
            update_nested(ref_acc, (name,), gap.station_id,
                          truth[valid_truth], prediction[valid_truth])

        candidates, distances = dataset.donor_selector._spatial_candidates(target_index)
        target_z = dataset.z[:, target_index]
        target_gap_z = dataset.z[gap.start:gap.end + 1, target_index]
        info = []
        for donor_index, distance in zip(candidates, distances):
            donor_gap = dataset.z[gap.start:gap.end + 1, donor_index]
            if np.isfinite(donor_gap).sum() == 0:
                continue
            correlation, overlap = _precorr(target_z, dataset.z[:, donor_index], gap.start, 60)
            correlation = correlation if np.isfinite(correlation) and overlap >= 24 else -1.0
            attribute_distance = float(np.sqrt(np.sum(np.square(attributes[target_index] - attributes[donor_index]))))
            in_gap_correlation = np.nan
            if gap.length >= 4:
                valid = np.isfinite(target_gap_z) & np.isfinite(donor_gap)
                if (valid.sum() >= 4 and target_gap_z[valid].std() > 1e-9 and
                        donor_gap[valid].std() > 1e-9):
                    in_gap_correlation = float(np.corrcoef(target_gap_z[valid], donor_gap[valid])[0, 1])
            info.append((int(donor_index), float(distance), float(correlation),
                         attribute_distance, in_gap_correlation))
        if not info:
            no_donor_gaps += 1
            continue

        deterministic = {
            "nearest_dist": top_k(info, lambda item: item[1], False, args.k),
            "attribute_sim": top_k(info, lambda item: item[3], False, args.k),
            "corr_filtered": top_k(
                info, lambda item: item[2] * np.exp(-item[1] / 800.0), True, args.k,
                predicate=lambda item: item[2] >= 0.2),
            "oracle_ingap": top_k(
                info, lambda item: item[4] if np.isfinite(item[4]) else item[2], True, args.k),
        }
        for selection_name, selection in deterministic.items():
            for combination in COMBINATIONS:
                prediction = combine_donors(dataset, gap, target_z, selection, combination)
                update_nested(grid_acc, (selection_name, combination, -1), gap.station_id,
                              truth[valid_truth], prediction[valid_truth])

        gap_key = "%s|%s|%d" % (gap.station_id, str(months[0]), gap.length)
        for repeat in range(args.random_repeats):
            selection = random_donor_sample(info, args.k, args.seed, repeat, gap_key)
            for combination in COMBINATIONS:
                prediction = combine_donors(dataset, gap, target_z, selection, combination)
                update_nested(grid_acc, ("random_kNN", combination, repeat), gap.station_id,
                              truth[valid_truth], prediction[valid_truth])

        correlation_pool = sorted(
            [item for item in info if item[2] >= 0.2],
            key=lambda item: item[2] * np.exp(-item[1] / 800.0), reverse=True)
        for k_value in K_VALUES:
            prediction = combine_donors(dataset, gap, target_z, correlation_pool[:k_value], "equal")
            update_nested(k_acc, (k_value,), gap.station_id,
                          truth[valid_truth], prediction[valid_truth])

        if gap_index % 500 == 0:
            print("[progress] gap %d/%d (%.1f min)" %
                  (gap_index, len(test_gaps), (time.time() - started) / 60.0), flush=True)

    grid_stations = accumulators_to_frame(
        grid_acc, ["selection", "combination", "repeat"])
    summarise_grid.n_boot = args.n_boot
    grid_summary, repeat_summary, effects = summarise_grid(grid_stations)

    ref_stations = accumulators_to_frame(ref_acc, ["reference"])
    refs = (ref_stations.groupby("reference", as_index=False)
            .agg(NSE_med=("NSE", "median"), n_stations=("station_id", "nunique")))
    k_stations = accumulators_to_frame(k_acc, ["K"])
    k_summary = (k_stations.groupby("K", as_index=False)
                 .agg(NSE_med=("NSE", "median"), n_stations=("station_id", "nunique")))

    outputs = (
        (grid_summary, paths["grid"]),
        (grid_stations, paths["grid_stations"]),
        (repeat_summary, paths["grid_repeats"]),
        (effects, paths["effects"]),
        (refs, paths["refs"]),
        (ref_stations, paths["refs_stations"]),
        (k_summary, paths["k_sweep"]),
        (k_stations, paths["k_sweep_stations"]),
    )
    for frame, path in outputs:
        frame.to_csv(path, index=False, encoding="utf-8-sig", float_format="%.8g")

    audit = {
        "run_id": args.run_id,
        "created": datetime.now().isoformat(),
        "protocol": "strict monthly Table-1 split; visible-only transforms; aligned test gaps",
        "limit": args.limit,
        "before_dedup_stations": before_dedup,
        "after_dedup_stations": after_dedup,
        "test_stations": len(test_set),
        "test_gaps_total": len(test_gaps),
        "test_gaps_used": gaps_used,
        "gaps_without_candidates": no_donor_gaps,
        "random_repeats": args.random_repeats,
        "random_seed": args.seed,
        "spatial_block_bootstrap_repeats": args.n_boot,
        "oracle_is_diagnostic_only": True,
        "config": config,
        "outputs": paths,
        "elapsed_seconds": time.time() - started,
    }
    with open(paths["audit"], "w", encoding="utf-8") as handle:
        json.dump(audit, handle, ensure_ascii=False, indent=2)

    print("\n[grid]")
    print(grid_summary.to_string(index=False, float_format=lambda value: "%.4f" % value))
    print("\n[references]")
    print(refs.to_string(index=False, float_format=lambda value: "%.4f" % value))
    print("\n[saved] %s" % paths["grid"])
    return paths


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("legacy_limit", nargs="?", type=int,
                        help="backward-compatible positional station limit; prefer --limit")
    parser.add_argument("--limit", type=int, default=None,
                        help="0/all for the formal run; positive values are smoke tests only")
    parser.add_argument("--run-id", default="monthly_grid_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
    parser.add_argument("--k", type=int, default=8)
    parser.add_argument("--random-repeats", type=int, default=10)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--n-boot", type=int, default=1000)
    parser.add_argument("--gaps-per-station", type=int, default=4)
    parser.add_argument("--force", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.limit is None:
        args.limit = args.legacy_limit or 0
    elif args.legacy_limit is not None and args.legacy_limit != args.limit:
        raise ValueError("positional limit and --limit disagree")
    args.run_id = safe_run_id(args.run_id)
    if args.k < 1 or args.random_repeats < 1 or args.gaps_per_station < 1 or args.n_boot < 0:
        raise ValueError("k, random-repeats and gaps-per-station must be positive; n-boot non-negative")
    run_experiment(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
