# -*- coding: utf-8 -*-
"""build_gsim_dor.py — 月尺度 GSIM 站上游库容 / DOR 挂接（GDW × HydroBASINS，纯 Python，无 GIS 依赖）。

已在沙盒完整跑通并验证（2026-07-27），产物 gsim_dor.csv / gsim_dor_dams.csv 已在 code 根目录；
本脚本为可复现版本，重跑约 20–40 分钟。

数据（code 根目录下）：
  Grand/GDW_v1_0_shp/GDW_v1_0_shp/GDW_barriers_v1_0.*   全球坝/屏障点（GDW v1.0，自带 HYBAS_L12 预挂接）
  HydroBasin/hybas_XX_lev01-12_v1c/hybas_XX_lev12_v1c.* HydroBASINS level-12（当前 7 区，缺 ar/si →
                                                        俄罗斯/北美北极圈站未覆盖，建议补充后重跑）

方法（两阶段，第二阶段是吸取 JOH 站点-属性错配教训的关键）：
  阶段 1  站点坐标 → 点在多边形内（流式解析 shp，bbox 预筛）→ level-12 子流域；
          沿 NEXT_DOWN 反向 BFS 得上游子流域集合；上游库容 = 集合内 GDW 坝 CAP_MCM 之和；
          DOR% = 100 × 库容 / (月均流量均值 × 31.536e6 s)。
  阶段 2  面积一致性重分配：凡 上游面积/GSIM 报告面积 落在 [0.5, 2] 之外的站，
          在 ±0.06° 邻域内搜索 UP_AREA 与报告面积最接近（比值 [0.4, 2.5]、
          评分 |log 比| + 3×距离）的子流域重挂，重做 BFS。
  QC     仍不一致者标 qc_area=True —— 实测 10,429 站，100% 为报告面积 <300 km² 的
          微型流域（中位 1 km²，低于 level-12 分辨率），**分析时必须排除**；
          干净样本 19,454 站（面积比中位 1.04），受调控 7,058，建坝前后候选 339。
  哨兵值  GDW 用 -99 表示缺失（YEAR/CAP/CATCH/REM_YEAR 等），须转 NaN；REM_YEAR>0 的坝（已拆除）剔除。

输出：
  gsim_dor.csv        gsim.no, hybas_l12, n_dams, cap_mcm, mafv_mcm, dor_pc, dor_band,
                      up_area_km2, area_reported, area_ratio, reassigned, qc_*, cross_year,
                      candidate_prepost（cross_year∈[1985,2010] 且 qc_area=False）
  gsim_dor_dams.csv   站-坝对照（建成年、库容、坝集水区）
用法：
  python build_gsim_dor.py            # 全流程
  python build_gsim_dor.py --skip_pip # 跳过阶段 1 的点-面判断，直接用缓存（调试）
"""
from __future__ import annotations
import os, sys, glob, json, time, struct, argparse, pickle
from collections import defaultdict
import numpy as np, pandas as pd

ROOT = os.path.dirname(os.path.abspath(__file__))
HB = os.path.join(ROOT, "HydroBasin")
GDW = os.path.join(ROOT, "Grand", "GDW_v1_0_shp", "GDW_v1_0_shp", "GDW_barriers_v1_0")
SERIES = os.path.join(ROOT, "GSIM_indices", "GSIM_indices", "TIMESERIES", "monthly")
CACHE = os.path.join(ROOT, "_cache_gsim_dor")
SEC = 31.536e6
PAD = 0.06
BANDS = [(-.5, .5, "none"), (.5, 50, "10-50%"), (50, 150, "50-150%"),
         (150, 500, "150-500%"), (500, np.inf, ">500%")]


def band(v):
    if not np.isfinite(v):
        return "unknown"
    for lo, hi, nm in BANDS:
        if lo < v <= hi or (nm == "none" and v == 0):
            return nm
    return "unknown"


# ---------- 纯 Python dbf / shp 解析 ----------
def dbf_meta(path):
    with open(path, "rb") as f:
        hdr = f.read(32)
        n = struct.unpack("<I", hdr[4:8])[0]
        hlen = struct.unpack("<H", hdr[8:10])[0]
        rlen = struct.unpack("<H", hdr[10:12])[0]
        fields = []
        while True:
            fd = f.read(32)
            if fd[0:1] == b"\r":
                break
            fields.append((fd[:11].split(b"\x00")[0].decode("ascii", "ignore"), fd[16]))
    offs, o = {}, 1
    for name, L in fields:
        offs[name] = (o, L)
        o += L
    return n, hlen, rlen, offs


def dbf_column(path, name, dtype=float):
    n, hlen, rlen, offs = dbf_meta(path)
    o, L = offs[name]
    out = np.empty(n, np.float64)
    with open(path, "rb") as f:
        f.seek(hlen)
        buf = f.read(n * rlen)
    for i in range(n):
        s = buf[i * rlen + o:i * rlen + o + L].decode("ascii", "ignore").strip()
        try:
            out[i] = float(s)
        except ValueError:
            out[i] = np.nan
    return out


def iter_shp_records(path):
    """yield (recno0, bbox, get_points)；get_points() 惰性解析坐标。"""
    sz = os.path.getsize(path)
    with open(path, "rb") as f:
        f.seek(100)
        while f.tell() < sz:
            h = f.read(8)
            if len(h) < 8:
                break
            recno = struct.unpack(">i", h[:4])[0] - 1
            clen = struct.unpack(">i", h[4:8])[0] * 2
            pos = f.tell()
            head = f.read(44 if clen >= 44 else clen)
            if len(head) >= 36 and struct.unpack("<i", head[:4])[0] == 5:
                bbox = struct.unpack("<4d", head[4:36])

                def get_points(f=f, pos=pos, clen=clen, head=head):
                    body = head + f.read(clen - len(head))
                    npart, npt = struct.unpack("<2i", body[36:44])
                    parts = struct.unpack("<%di" % npart, body[44:44 + 4 * npart]) + (npt,)
                    pts = np.frombuffer(body[44 + 4 * npart:44 + 4 * npart + 16 * npt], "<f8").reshape(npt, 2)
                    return parts, pts
                yield recno, bbox, get_points
            f.seek(pos + clen)


def ring_crossings(xs, ys, px, py):
    n = 0
    for k in range(len(xs) - 1):
        x1, y1, x2, y2 = xs[k], ys[k], xs[k + 1], ys[k + 1]
        if (y1 > py) != (y2 > py):
            if x1 + (py - y1) * (x2 - x1) / (y2 - y1) > px:
                n += 1
    return n


def point_in_poly(parts, pts, px, py):
    cr = 0
    for pi in range(len(parts) - 1):
        seg = pts[parts[pi]:parts[pi + 1]]
        cr += ring_crossings(seg[:, 0], seg[:, 1], px, py)
    return cr % 2 == 1


def mafv(sid):
    f = os.path.join(SERIES, sid + ".mon")
    if not os.path.exists(f):
        return np.nan
    try:
        d = pd.read_csv(f, comment="#", skipinitialspace=True)
        d.columns = [x.strip().strip('"').strip() for x in d.columns]
        v = pd.to_numeric(d["MEAN"].astype(str).str.strip(), errors="coerce")
        return float(v.mean()) * SEC if v.notna().sum() >= 60 else np.nan
    except Exception:
        return np.nan


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip_pip", action="store_true")
    args = ap.parse_args()
    os.makedirs(CACHE, exist_ok=True)
    t0 = time.time()
    conts = sorted(os.path.basename(d).split("_")[1]
                   for d in glob.glob(os.path.join(HB, "hybas_*_lev01-12_v1c")))
    print("[init] continents:", conts, "(缺 ar/si 则北极圈/西伯利亚站不覆盖)")

    # —— GDW 坝表（-99 哨兵；剔除已拆除坝）——
    n, hlen, rlen, offs = dbf_meta(GDW + ".dbf")
    sen = lambda v: np.nan if (not np.isfinite(v)) or v <= -99 else v
    cols = {k: dbf_column(GDW + ".dbf", k) for k in
            ["GDW_ID", "HYBAS_L12", "CAP_MCM", "YEAR_DAM", "CATCH_SKM", "REM_YEAR"]}
    dam_by = defaultdict(list)
    nd = 0
    with open(GDW + ".dbf", "rb") as f:
        f.seek(hlen)
        buf = f.read(n * rlen)
    o, L = offs["DAM_NAME"]
    for i in range(n):
        hy = sen(cols["HYBAS_L12"][i])
        if not (np.isfinite(hy) and hy > 0) or sen(cols["REM_YEAR"][i]) and sen(cols["REM_YEAR"][i]) > 0:
            continue
        cap = sen(cols["CAP_MCM"][i])
        nm = buf[i * rlen + o:i * rlen + o + L].decode("ascii", "ignore").strip()
        dam_by[int(hy)].append((int(cols["GDW_ID"][i]), nm, sen(cols["YEAR_DAM"][i]),
                                cap if np.isfinite(cap) else 0.0, sen(cols["CATCH_SKM"][i])))
        nd += 1
    print("[gdw] dams linked=%d (%.0fs)" % (nd, time.time() - t0))

    # —— 站点 ——
    meta = pd.read_csv(os.path.join(ROOT, "global_station_meta_kg.csv"))
    meta = meta[np.isfinite(meta.latitude) & np.isfinite(meta.longitude)]
    kg = pd.read_csv(os.path.join(ROOT, "KG", "stations_full_static_with_climate_kg.csv"),
                     usecols=["gsim.no", "area_local"], encoding="latin-1"
                     ).drop_duplicates("gsim.no").set_index("gsim.no")
    meta = meta.join(kg, on="gsim.no").set_index("gsim.no")
    PID = list(meta.index)
    PLA, PLO = meta.latitude.values, meta.longitude.values
    AREA = meta.area_local.values
    grid = defaultdict(list)
    for i in range(len(PID)):
        grid[(int(PLA[i] // .5), int(PLO[i] // .5))].append(i)

    # —— 阶段 1：PIP ——
    ap1 = os.path.join(CACHE, "assigned.json")
    if args.skip_pip and os.path.exists(ap1):
        assigned = json.load(open(ap1))
    else:
        assigned = {}
        for c in conts:
            shp = os.path.join(HB, "hybas_%s_lev01-12_v1c" % c, "hybas_%s_lev12_v1c.shp" % c)
            for recno, (x0, y0, x1, y1), gp in iter_shp_records(shp):
                cand = [i for gy in range(int(y0 // .5), int(y1 // .5) + 1)
                        for gx in range(int(x0 // .5), int(x1 // .5) + 1)
                        for i in grid.get((gy, gx), ())
                        if x0 <= PLO[i] <= x1 and y0 <= PLA[i] <= y1 and PID[i] not in assigned]
                if cand:
                    parts, pts = gp()
                    for i in cand:
                        if point_in_poly(parts, pts, PLO[i], PLA[i]):
                            assigned[PID[i]] = [c, recno]
            print("[pip] %s done assigned=%d (%.0fs)" % (c, len(assigned), time.time() - t0))
        json.dump(assigned, open(ap1, "w"))

    # —— 图 + BFS ——
    def load_graph(c):
        p = os.path.join(HB, "hybas_%s_lev01-12_v1c" % c, "hybas_%s_lev12_v1c.dbf" % c)
        hid = dbf_column(p, "HYBAS_ID").astype(np.int64)
        nxt = dbf_column(p, "NEXT_DOWN").astype(np.int64)
        sar = np.nan_to_num(dbf_column(p, "SUB_AREA"))
        ua = dbf_column(p, "UP_AREA")
        ch = defaultdict(list)
        for i in range(len(hid)):
            if nxt[i] != 0:
                ch[int(nxt[i])].append(int(hid[i]))
        return hid, {int(h): i for i, h in enumerate(hid)}, sar, ua, ch

    def bfs(h0, pos, sar, ch):
        up, dq = {h0}, [h0]
        while dq:
            for c2 in ch.get(dq.pop(), ()):
                if c2 not in up:
                    up.add(c2)
                    dq.append(c2)
        ua = float(sum(sar[pos[h]] for h in up))
        gg = [d for h in up for d in dam_by.get(h, ())]
        return ua, sum(x[3] for x in gg), gg

    res, graphs = {}, {}
    for c in conts:
        graphs[c] = load_graph(c)
        hid, pos, sar, _, ch = graphs[c]
        for s, (cc, recno) in assigned.items():
            if cc == c:
                h0 = int(hid[recno])
                ua, cap, gg = bfs(h0, pos, sar, ch)
                res[s] = (h0, ua, cap, gg, False)
        print("[bfs] %s done (%.0fs)" % (c, time.time() - t0))

    # —— 阶段 2：面积一致性重分配 ——
    a_of = {s: float(meta.at[s, "area_local"]) if np.isfinite(meta.at[s, "area_local"]) else np.nan
            for s in res}
    tgt = {s: (float(meta.at[s, "latitude"]), float(meta.at[s, "longitude"]), a_of[s])
           for s, (h0, ua, cap, gg, _) in res.items()
           if np.isfinite(a_of[s]) and a_of[s] > 0 and not (0.5 <= ua / a_of[s] <= 2.0)}
    print("[stage2] mismatched=%d" % len(tgt))
    TID = sorted(tgt)
    TLA = np.array([tgt[s][0] for s in TID]); TLO = np.array([tgt[s][1] for s in TID])
    TAR = np.array([tgt[s][2] for s in TID])
    g2 = defaultdict(list)
    for i in range(len(TID)):
        g2[(int(TLA[i] // .5), int(TLO[i] // .5))].append(i)
    best = {}
    for c in conts:
        _, _, _, ua_arr, _ = graphs[c]
        shp = os.path.join(HB, "hybas_%s_lev01-12_v1c" % c, "hybas_%s_lev12_v1c.shp" % c)
        for recno, (x0, y0, x1, y1), _gp in iter_shp_records(shp):
            u = ua_arr[recno]
            if not (np.isfinite(u) and u > 0):
                continue
            cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
            for gy in range(int((y0 - PAD) // .5), int((y1 + PAD) // .5) + 1):
                for gx in range(int((x0 - PAD) // .5), int((x1 + PAD) // .5) + 1):
                    for i in g2.get((gy, gx), ()):
                        if x0 - PAD <= TLO[i] <= x1 + PAD and y0 - PAD <= TLA[i] <= y1 + PAD:
                            ratio = u / TAR[i]
                            if 0.4 <= ratio <= 2.5:
                                score = abs(np.log(ratio)) + 3.0 * max(abs(TLO[i] - cx), abs(TLA[i] - cy))
                                if TID[i] not in best or score < best[TID[i]][0]:
                                    best[TID[i]] = (score, c, recno)
        print("[stage2] %s scanned matched=%d (%.0fs)" % (c, len(best), time.time() - t0))
    for s, (_, c, recno) in best.items():
        hid, pos, sar, _, ch = graphs[c]
        h0 = int(hid[recno])
        ua, cap, gg = bfs(h0, pos, sar, ch)
        res[s] = (h0, ua, cap, gg, True)

    # —— MAFV + 输出 ——
    rows, drows = [], []
    for s, (h0, ua, cap, gg, reas) in res.items():
        mv = mafv(s) if cap > 0 else np.nan
        dor = 100.0 * cap * 1e6 / mv if (cap > 0 and np.isfinite(mv) and mv > 0) else (0.0 if cap == 0 else np.nan)
        al = a_of.get(s, np.nan)
        ratio = ua / al if (np.isfinite(al) and al > 0) else np.nan
        qa = bool(np.isfinite(ratio) and not (0.5 <= ratio <= 2.0))
        qd = any(np.isfinite(x[4]) and x[4] > 1.5 * ua for x in gg)
        qo = bool(np.isfinite(dor) and dor > 10000)
        cross = np.nan
        if gg and np.isfinite(mv) and mv > 0:
            cum = 0.0
            for y, c_ in sorted((x[2] if np.isfinite(x[2]) else 9999, x[3]) for x in gg):
                cum += c_
                if 100 * cum * 1e6 / mv > 50:
                    cross = y if y < 9999 else np.nan
                    break
        rows.append([s, h0, len(gg), cap, mv / 1e6 if np.isfinite(mv) else np.nan, dor, band(dor),
                     ua, al, round(ratio, 3) if np.isfinite(ratio) else np.nan, reas, qa, qd, qo, cross])
        for x in gg:
            drows.append([s, x[0], x[1], x[2], x[3], x[4]])
    out = pd.DataFrame(rows, columns=["gsim.no", "hybas_l12", "n_dams", "cap_mcm", "mafv_mcm",
                                      "dor_pc", "dor_band", "up_area_km2", "area_reported",
                                      "area_ratio", "reassigned", "qc_area", "qc_dam", "qc_dor",
                                      "cross_year"])
    out["candidate_prepost"] = (pd.to_numeric(out.cross_year, errors="coerce").between(1985, 2010)
                                & (~out.qc_area))
    out.to_csv(os.path.join(ROOT, "gsim_dor.csv"), index=False)
    pd.DataFrame(drows, columns=["gsim.no", "gdw_id", "dam_name", "year", "cap_mcm", "catch_skm"]
                 ).to_csv(os.path.join(ROOT, "gsim_dor_dams.csv"), index=False)
    print("[done] stations=%d regulated=%d reassigned=%d qc_area=%d prepost=%d (%.0fs)"
          % (len(out), int((out.dor_pc > 0).sum()), int(out.reassigned.sum()),
             int(out.qc_area.sum()), int(out.candidate_prepost.sum()), time.time() - t0))


if __name__ == "__main__":
    main()
