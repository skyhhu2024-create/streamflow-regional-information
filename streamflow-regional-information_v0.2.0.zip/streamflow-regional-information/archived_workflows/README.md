# Archived calculation workflows

This directory preserves the actual calculation source and its project-local import dependencies. Historical version names are retained solely to preserve provenance and paths. The final experiment mapping, input contracts and execution order are in [REPRODUCTION.md](../docs/REPRODUCTION.md) and [EXPERIMENT_MAP.csv](../docs/EXPERIMENT_MAP.csv).

These workflows require separately obtained observations, prepared matrices, identity/cohort manifests and new reviewed run registrations. They are not a stand-alone global data product. Start with the portable case in the root README; use `python archived_workflows/check_release.py --synthetic` for a data-free check of the archived numerical engine.

`manifest.json` records the SHA-256 of each original file and released file, plus path portability and final-roster changes. No production-state authorization files, observations, manuscripts or third-party packages are included.

The 2026-11-10 extension supplies calculation chains used by the 2026-11-08 manuscript: monthly reference-count and fixed-fit coverage controls; correlation-only ranking and anomaly audits; regional rainfall/reference summaries; common-history and nearest-location interventions; current NSE harmonization; and the complete water-resource input, metric and paired-summary workflow. Only filesystem adaptations are applied to these newly archived sources. The inherited final benchmark roster change remains documented separately in the manifest.

Some historical scripts contain additional analyses. Only the outputs identified in the experiment map belong to the current manuscript: the old GRDC task/archive script contributes its archive-retrieval summary, and the monthly rerun analyzer contributes its four transformation-leakage pairs. Their other legacy outputs do not redefine the current cohorts or twelve-system benchmark. Plot builders and generated figure files are outside this calculation archive.
