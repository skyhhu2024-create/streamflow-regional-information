"""Check archived hashes/syntax and optionally the original synthetic engine test."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--synthetic', action='store_true')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'manifest.json').read_text(encoding='utf8'))
    for item in manifest['files']:
        path = root.parent / item['release']
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != item['release_sha256']:
            raise AssertionError(f'Changed released source: {item["release"]}')
        compile(data.decode('utf8'), str(path), 'exec')
    result = {'source_files': len(manifest['files']), 'hashes': 'PASS',
              'syntax': 'PASS', 'observations_loaded': False,
              'global_experiments_rerun': False}
    if args.synthetic:
        directory = root / 'code/V45/experiments/r4_full_source_gradient_20261026/src'
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(directory))
        spec = importlib.util.spec_from_file_location('archival_engine_synthetic', directory / 'test_engine_synthetic.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        checks = module.test()
        if checks.get('passed') is not True or checks.get('project_data_read') is not False:
            raise AssertionError('Synthetic fixture did not confirm isolated execution')
        result['synthetic'] = checks
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
