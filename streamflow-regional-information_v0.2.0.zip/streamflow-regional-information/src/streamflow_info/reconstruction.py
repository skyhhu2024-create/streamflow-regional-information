"""Final fixed-source withdrawal experiment, with no target gap truth input.

The extracted engine retains H qualification/ranks and refits surviving inputs.
"""
import numpy as np
from . import primitives as C
from . import transfer as M

DLEVELS = (0, 100, 300, 800)
METHODS = ('ridge', 'rbf_ridge')
ARMS = ('Q', 'QP', 'QP_Gclim')
FLAG_NAMES = ('actual_fit', 'requested_fit', 'requested_source', 'fallback',
              'uses_P_H', 'uses_P_G_actual', 'uses_P_G_climatology')

class GuardedSourceAccessor:
    """Materialize source reports by row/date, rejecting target identity reads."""
    def __init__(self, values, raw, forbidden_raw, first_month, last_month):
        self.values = values
        self.raw = np.asarray(raw, dtype=int)
        self.forbidden = set(map(int, forbidden_raw))
        self.first, self.last = int(first_month), int(last_month)

    def __getitem__(self, index):
        source_position, months = index
        raw = int(self.raw[int(source_position)])
        if raw in self.forbidden:
            raise AssertionError('Forbidden physical target identity requested as a source')
        months = np.asarray(months, dtype=int)
        if not np.all((months >= self.first) & (months < self.last)):
            raise AssertionError('Source access outside fixed H/G windows')
        return np.asarray(self.values[raw, months], dtype=float)


def distances(lat, lon, source_lat, source_lon):
    a, b = np.deg2rad([float(lat), float(lon)])
    c, d = np.deg2rad(source_lat), np.deg2rad(source_lon)
    hav = np.sin((c-a)/2)**2+np.cos(a)*np.cos(c)*np.sin((d-b)/2)**2
    return 6371*2*np.arcsin(np.sqrt(np.clip(hav, 0, 1)))


def nearest_reporting_distance(source, qualified, distance, cl, months):
    """Minimum over ALL qualified synchronous reporters, not selected K4."""
    out = np.full(len(months), np.nan)
    # Stable raw-index tie handling is only bookkeeping; the minimum is invariant.
    order = qualified[np.lexsort((source['raw'][qualified], distance[qualified]))]
    for j in order:
        raw = source['Q'][j, months]
        valid = np.isfinite(raw) & (raw >= 0) & np.isfinite(cl[j, months % 12])
        take = ~np.isfinite(out) & valid
        out[take] = distance[j]
        if np.isfinite(out).all():
            break
    return out


def build_composites(source, source_h_calendar, source_h_sd, source_h_z,
                     target_h_z, target_physical_raw, distance, h, g):
    """Qualify/rank once on H, then mask source identities for each distance.

    Distances do NOT rerank surviving candidates. An outage withdraws their G
    reports; the same surviving subset is used to rebuild H predictors for a
    matched transfer fit (old survivor_recalibration semantics). H observations
    still define all original source seasonal transforms and ranks.
    """
    raw = source['raw']
    n, r = C.relation(source_h_z, target_h_z)
    forbidden = np.isin(raw, list(target_physical_raw))
    qualified = np.flatnonzero(np.isfinite(r) & (r > 0) & np.isfinite(source_h_sd) & ~forbidden)
    order = C.ordering(raw, qualified, r, distance)
    months = np.r_[h, g]
    comp = np.full((4, len(months)), np.nan)
    counts = np.zeros((4, len(months)), np.int8)
    ids = np.full((4, len(months), 4), -1, np.int32)
    selected_dist = np.full(ids.shape, np.nan)
    selected_r = np.full(ids.shape, np.nan)
    pos = {int(v): i for i, v in enumerate(raw)}
    eligible = np.zeros(4, np.int32)
    for di, cutoff in enumerate(DLEVELS):
        excluded = distance <= cutoff if cutoff else None
        eligible[di] = len(qualified) if excluded is None else np.sum(~excluded[qualified])
        comp[di], counts[di], ids[di] = C.combine(
            source, order, r, source_h_calendar, source_h_sd, months, excluded)
        active = ids[di] >= 0
        if active.any():
            jj = np.fromiter((pos[int(x)] for x in ids[di][active]), dtype=int)
            selected_dist[di][active] = distance[jj]
            selected_r[di][active] = r[jj]
        if cutoff:
            assert np.all(selected_dist[di][active] > cutoff)
    assert not np.isin(ids, list(target_physical_raw)).any()
    assert np.all(np.diff(counts.astype(int), axis=0) <= 0)
    nearest = nearest_reporting_distance(source, qualified, distance, source_h_calendar, g)
    return dict(composites=comp, counts=counts, selected_ids=ids,
                selected_distance=selected_dist, selected_r=selected_r,
                nearest_qualified_reporter_distance_G=nearest,
                eligible_source_counts=eligible)


def fit_arms(comp, target_h_z, target_calendar, target_sd, target_raw_calendar,
             target_estimable, p_h, p_g, p_g_climatology, p_available, g):
    """Exactly the old Q/QP/same-fit climate control at one source distance."""
    hlength = len(target_h_z)
    qh, qg = comp[:hlength, None], comp[hlength:, None]
    train = np.isfinite(qh[:, 0]) & np.isfinite(target_h_z)
    baseline = target_raw_calendar[g % 12]
    out = np.full((2, 3, len(g)), np.nan)
    model_z = np.full_like(out, np.nan)
    support = np.zeros(out.shape, bool)
    flags = np.zeros((2, 3, 7), bool)
    reasons = []
    if p_available:
        assert np.isfinite(p_h).all() and np.isfinite(p_g).all() and np.isfinite(p_g_climatology).all()
    for mi, method in enumerate(METHODS):
        q, qr = M.fit_transfer(qh[train], target_h_z[train], method=method,
                              target_estimable=bool(target_estimable))
        qp, pr = None, 'P_not_admitted'
        if p_available:
            qp, pr = M.fit_transfer(np.column_stack([qh, p_h])[train], target_h_z[train],
                                   method=method, target_estimable=bool(target_estimable))
        models = [q, qp if qp is not None else q, qp if qp is not None else q]
        features = [qg, np.column_stack([qg, p_g]) if qp is not None else qg,
                    np.column_stack([qg, p_g_climatology]) if qp is not None else qg]
        assert models[1] is models[2]
        for ai, model in enumerate(models):
            actual = model is not None
            requested = q is not None if ai == 0 else qp is not None
            usep = ai > 0 and qp is not None
            z = model.predict(features[ai]) if actual else np.full(len(g), np.nan)
            model_z[mi, ai] = z
            out[mi, ai], support[mi, ai] = C.transfer(z, target_h_z, target_calendar,
                target_sd, g, baseline, actual)
            flags[mi, ai] = [actual, requested, True if ai == 0 else p_available,
                            not requested, usep, usep and ai == 1, usep and ai == 2]
        reasons.append(dict(method=method, Q=qr, QP=pr))
    if not p_available:
        np.testing.assert_allclose(out[:, 0], out[:, 1], rtol=0, atol=0, equal_nan=True)
        np.testing.assert_allclose(out[:, 0], out[:, 2], rtol=0, atol=0, equal_nan=True)
    return dict(predictions=out, model_z=model_z, support=support, flags=flags,
                training_mask=train, reasons=reasons)
