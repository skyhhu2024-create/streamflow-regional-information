"""Array-only forward-extension entry point for a single registered target.

Target gap truth is deliberately absent from this interface. Identity resolution,
source safety screening and precipitation extraction happen before this call.
"""
import json
import warnings
import numpy as np
from . import primitives as C
from . import transfer as M
from . import reconstruction as E


class WindowSourceAccessor:
    """Map compact source rows and absolute calendar indices to guarded reports."""

    def __init__(self, values, raw, forbidden_raw, first_month):
        self.values = values
        self.raw = np.asarray(raw, dtype=int)
        self.forbidden = set(map(int, forbidden_raw))
        self.first = int(first_month)
        self.last = self.first + values.shape[1]

    def __getitem__(self, index):
        position, months = index
        position = int(position)
        if int(self.raw[position]) in self.forbidden:
            raise AssertionError('Forbidden physical target identity requested as a source')
        months = np.asarray(months, dtype=int)
        if not np.all((months >= self.first) & (months < self.last)):
            raise AssertionError('Source access outside fixed H/G windows')
        return np.asarray(self.values[position, months-self.first], dtype=float)


def run_forward_case(*, target_history, source_flows, source_ids,
                     source_distances_km, target_physical_ids,
                     history_start_month=0, precipitation=None,
                     excluded_source_ids=(), prepared_precipitation=None):
    """Reconstruct a contiguous forward gap under the fixed final experiment.

    ``source_flows`` is S by (H+G), with the H dates matching target_history.
    ``source_ids`` must be stable, unique nonnegative integer IDs; the identity
    set must include every known alias of the target, even if absent from S.
    Calendar index 0 is January. Precipitation, if supplied, covers H+G plus
    three antecedent months. See examples/README.md for the complete schema.

    The output dimensions are distance (0/100/300/800 km), processor
    (ridge/RBF), arm (Q/QP/QP_Gclim), gap month. This is a portable calculation
    core, not a reconstruction of the historical cohort registration pipeline.
    """
    th = np.asarray(target_history, dtype=float)
    values = np.asarray(source_flows, dtype=float)
    ids_input = np.asarray(source_ids)
    if th.ndim != 1 or len(th) < 1 or values.ndim != 2:
        raise ValueError('Target history must be 1-D and source flows 2-D.')
    if ids_input.ndim != 1 or not np.issubdtype(ids_input.dtype, np.integer):
        raise ValueError('Source IDs must be a 1-D integer array.')
    ids = ids_input.astype(np.int64)
    distance = np.asarray(source_distances_km, dtype=float)
    if len(ids) != len(values) or distance.shape != ids.shape:
        raise ValueError('One source ID and distance are required per source row.')
    if (len(np.unique(ids)) != len(ids) or np.any(ids < 0)
            or np.any(ids > np.iinfo(np.int32).max)):
        raise ValueError('Source IDs must be unique integers in [0, 2^31-1].')
    if not np.isfinite(distance).all() or np.any(distance < 0):
        raise ValueError('Source distances must be finite and nonnegative.')
    own = np.asarray(list(target_physical_ids))
    if own.ndim != 1 or len(own) == 0 or not np.issubdtype(own.dtype, np.integer):
        raise ValueError('Supply at least one integer target physical-identity ID.')
    own = set(map(int, own))
    hlength, glength = len(th), values.shape[1]-len(th)
    if glength < 1:
        raise ValueError('Source flows must include H and at least one G month.')
    if not isinstance(history_start_month, (int, np.integer)):
        raise ValueError('history_start_month must be an integer calendar index.')
    h = int(history_start_month)+np.arange(hlength)
    g = int(history_start_month)+hlength+np.arange(glength)
    keep = ~np.isin(ids, list(excluded_source_ids))
    ids, values, distance = ids[keep], values[keep], distance[keep]
    with warnings.catch_warnings():
        # Missing source calendar months remain NaN, never manufactured data.
        warnings.simplefilter('ignore', RuntimeWarning)
        tc, ts, tz = C.prep(th[None, :], h)
        cl, sd, zh = C.prep(np.asfortranarray(values[:, :hlength]), h)
        basecl = np.array([np.nanmean(th[h % 12 == m]) for m in range(12)])
    tc, ts, tz = tc[0], float(ts[0]), tz[0]
    estimable = bool(np.isfinite(th).all() and (th >= 0).all()
                     and np.isfinite(ts) and np.isfinite(tc).all())
    if not estimable:
        tz = np.full(hlength, np.nan)
    source = dict(raw=ids, Q=WindowSourceAccessor(values, ids, own, h[0]))
    built = E.build_composites(source, cl, sd, zh, tz, own, distance, h, g)
    if prepared_precipitation is not None:
        if precipitation is not None:
            raise ValueError('Supply raw or prepared precipitation, not both.')
        if not isinstance(prepared_precipitation, M.RainInputs):
            raise ValueError('prepared_precipitation must be a RainInputs object.')
        p = prepared_precipitation
        if (p.h.shape != (hlength, 4) or p.g.shape != (glength, 4)
                or p.g_climatology.shape != (glength, 4)):
            raise ValueError('Prepared precipitation dimensions do not match H/G.')
    else:
        raw_p = (np.full(3+hlength+glength, np.nan) if precipitation is None
                 else np.asarray(precipitation, dtype=float))
        p = M.prepare_precipitation_lags(raw_p, history_start_month=int(h[0]),
                                       h_length=hlength, g_length=glength)
    fitted = [E.fit_arms(comp, tz, tc, ts, basecl, estimable,
                        p.h, p.g, p.g_climatology, p.available, g)
              for comp in built['composites']]
    for name in ('predictions', 'model_z', 'support', 'flags', 'training_mask'):
        built[name] = np.stack([f[name] for f in fitted])
    built.update(target_log_calendar=tc, target_anomaly_sd=np.asarray(ts),
                 target_raw_calendar=basecl, target_estimable=np.asarray(estimable),
                 P_available=np.asarray(p.available), P_status=np.asarray(p.reason),
                 gap_months=g, seasonal_baseline=basecl[g % 12],
                 distances_km=np.asarray(E.DLEVELS),
                 methods=np.asarray(E.METHODS), arms=np.asarray(E.ARMS),
                 flag_names=np.asarray(E.FLAG_NAMES),
                 reasons=np.asarray([json.dumps(f['reasons']) for f in fitted]))
    return built
