"""Portable core of the streamflow regional-information experiments."""
__version__ = "0.2.0"
