# Changelog

## 0.2.0 — 10 November 2026

Aligned the code release to **Global data availability does not make nearby streamflow gauges dispensable**, using the audited main text and supplement dated 8 November 2026. The original 0.1.0 package is preserved separately.

- Updated the English and Chinese introductions, current five-subsection Results mapping, panel references and supplementary table numbering. The exact source manuscripts are identified by SHA-256 in `docs/MANUSCRIPT_VERSION.json`.
- Added the current production sources for correlation-only ranking, reference-history/gap agreement, rainfall gains and residual-reference conditions, observation-location comparisons, monthly reference-count/coverage controls, archive retrieval and the full water-resource summary chain, together with local code dependencies.
- Documented all-qualified natural-gap availability separately from monthly four-reference transfers and the older fixed-eight R2 design. Preserved fixed cohorts, success eligibility and the distinction between percentages and paired percentage-point changes.
- Aligned water-resource reporting to Fig. 3f–h and Note 11/S21A–D. Added an explicit 11-arm, 16-contrast study profile. Historical diagnostics removed from the final SI remain labelled optional legacy outputs in the stable metric API.
- Kept the portable reconstruction, reference-selection, transfer and water-metric formulas unchanged. Existing case and test implementations are unchanged. The numerical checks and real-case replay are reported in `docs/RELEASE_VERIFICATION.md`.

This release packages source code and examples. It does not contain provider observation arrays, study-specific frozen input manifests, cached global predictions, manuscripts or generated figures. Full global reproduction still requires the exact empirical inputs described in `docs/REPRODUCTION.md`; the new source coverage is not a claim that all global experiments were rerun.

## 0.1.0 — 30 October 2026

Initial portable reconstruction and water-resource evaluation package, archived calculation sources, English/Chinese documentation, synthetic example, and a locally reproducible registered river case. The local packaging and case verification did not constitute a successful GitHub upload.
