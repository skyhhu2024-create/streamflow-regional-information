# Release verification — 10 November 2026

Version **0.2.0** was aligned with the audited main text and supplement dated 8 November 2026. The current check results are in [RELEASE_CHECKS_20261110.json](RELEASE_CHECKS_20261110.json); source manuscript identities are in [MANUSCRIPT_VERSION.json](MANUSCRIPT_VERSION.json).

| Check repeated on 10 November | Result |
| --- | --- |
| Portable-core and water-metric unit/interface tests | 33 passed |
| Runnable synthetic example | Passed |
| Archived calculation source integrity | 142 files; checksum and Python syntax checks passed |
| Original archived engine synthetic check | Passed target-identity exclusion, H/G separation, source withdrawal and same-fit rainfall-climatology controls |
| Portable scientific core | Unchanged from 0.1.0; only package version updated |
| Registered observational case AR_0000001 | 16 arrays matched frozen outputs exactly, including all 2,880 predictions; target-gap truth not exported or supplied to reconstruction |
| Water-metric implementation | Still byte-identical to the corrected original metric source |
| Global empirical experiments | Not rerun during packaging |

The 91 original archived files retain their released hashes. Added sources preserve the original calculations; source hashes, released hashes and any filesystem adapters are recorded in `archived_workflows/manifest.json`. Adding the missing computation chains does not itself replay their global empirical results.

The real-case check used locally held observations. Only its configuration, exporter and data-free verification receipts are included in the release; the generated input/output arrays are kept outside the packaged repository. The synthetic example uses invented data.

The 30 October extraction audit compared 23 function/class syntax trees with the original implementations. That historical receipt remains in `CORE_EXTRACTION_AUDIT.json`. This release separately rechecked file equality and repeated the real-case calculation; it does not misdate the older extraction audit.

The actual tested environment is recorded in [TESTED_ENVIRONMENT.json](TESTED_ENVIRONMENT.json). Tests used the existing local scientific dependencies with no network installation. The full neural/global training environment was not recreated.

Run from the repository root after installing dependencies:

```bash
python -m unittest discover -s tests -v
python examples/run_synthetic_case.py --output-dir outputs/synthetic_case
python archived_workflows/check_release.py --synthetic
```

The final manuscript reports NSE ≥ 0.5 plus improvement over target seasonal climatology, with fitted/reference support, as its primary success measure. The preserved field `old_NSE_pass` supplies this criterion. Exact empirical reproduction additionally requires the frozen data, identity decisions, case registrations and resampling inputs listed in [REPRODUCTION.md](REPRODUCTION.md).
