# Alignment with the audited manuscript

This release follows **Global data availability does not make nearby streamflow gauges dispensable**, the Main and Supplementary Information labelled `Final_Audited_20261108`. Manuscripts remain outside this code package. The mapping below follows the delivered documents' actual contents, including the final figure rearrangement and SI deletions.

Historical directory names and experiment identifiers such as `R3`, `R4`, `S18H` or `ranking_13.py` retain their development-era meaning. They are not current section, table or method counts. The current Results has **five subsections**, although it still has four main figures. Use [EXPERIMENT_MAP.csv](EXPERIMENT_MAP.csv) for code entry points and [REPRODUCTION.md](REPRODUCTION.md) for input requirements.

| Current Results subsection | Principal evidence |
| --- | --- |
| 1. Most gaps extend beyond the record | Fig. 1; S10–S14; Figs S2–S3 |
| 2. Skill comes from synchronous nearby observations | Fig. 2; S3–S9; S15; S19; Figs S1, S4, S5 |
| 3. Available references do not substitute for nearby ones | Fig. 3a–d; S16A,B,D; S17A–D,G–I |
| 4. Distant references add error, not information | Fig. 3e–h; S17H; S17E,F and Fig. S6; S21A–D |
| 5. Rainfall and new gauges recover little | Fig. 4a–f; Fig. 3f–h; S18A–F; S20A–D; S21A–D |

## Current panel and table references

Fig. 2c is the synchronous-input versus history-length comparison; Fig. 2d is the reference-selection comparison. Fig. 3c contains the withdrawal transitions, Fig. 3d the reference history/gap correlations, and Fig. 3e reconstruction NSE against the target-history seasonal baseline. **Water-resource panels are Fig. 3f–h**: low-flow HSS, deficit within ±25%, and absolute relative ten-year volume error. Fig. 4d compares natural-gap distant dependence with controlled rainfall gains using two distinct populations. Fig. 4e is external-location duration; Fig. 4f compares three separately registered location designs.

The added Fig. 3e summarizes existing S17H results; it is not a new prediction experiment. Its finite-NSE cohort has 8,073 targets. It must not be replaced with the 8,068 supported-transfer cohort or with a correlation statistic.

| Current SI evidence | Meaning |
| --- | --- |
| S8A / S8B / S8C | Signed selection/combination contrasts; direct selector comparisons; same-rule reference-count sensitivity |
| S16A / S16B | Natural global support and regional reliance on distant reports |
| S16C | Earlier observation-existence audit at 596 matched gauges; formerly S16D |
| S16D | Natural-support correlation-threshold sensitivity; formerly S16E |
| S17G | Five transfer/candidate-pool configurations on 8,898 registrations |
| S17H | Reference history/gap agreement and reconstruction agreement/NSE against seasonality |
| S17I | Ranking solely by historical anomaly correlation |
| S18F | Remaining-reference conditions and retrospective rainfall-gain associations |
| S19A–C | Genuine-gap accounting, predictions and geography |
| S20A / S20B / S20C / S20D | External-location duration; nearest restoration; shared layouts; single-location selection/use |
| S21A / S21B / S21C / S21D | Eleven conditions and validity; low-flow/deficit; interval volume; sixteen paired contrasts |

## Reference pools and denominators

The initial archive audit uses 24,934 gauges, including 22,934 incomplete gauges and 4,598,259 missing station-months. Its regional shortlist contains at most 200 gauges within 800 km; the monthly qualification rule requires 24 common observations and anomaly correlation at least 0.2. All-qualified support accounting is distinct from the fixed-eight inputs used in controlled comparisons.

The natural forward-gap audit covers 19,418 targets and 2,612,522 missing months. It searches the global candidate domain **without a maximum distance and counts all qualifying reporting references without a four-reference cap**. Qualification uses up to 60 preceding calendar months, at least 12 common anomalies and positive correlation. Raw reporting availability and transformable support remain separate. This audit has no hidden truth and does not measure reconstruction accuracy. Its changed history, correlation and candidate rules mean that comparison with the initial regional audit does not isolate search distance alone.

Global reconstruction uses at most four reporting references per month, with positive-correlation weights. The main ranking combines past-agreement and distance ranks. The correlation-only sensitivity changes ranking alone. Withdrawal distances of 0, 100, 300 and 800 km remove references from the global pool; zero means no additional withdrawal. The eligible pool contains 24,714 candidates before per-target physical-identity exclusions. The primary 8,083 rainfall-admitted targets are a fixed subset of 8,898 registrations, with H = 60 and G = 120 months.

| Quantity | Denominator |
| --- | --- |
| Primary success and failure accounting | All 8,083 registrations, including unsupported or unevaluable cases |
| Complete-gap fitted reference input | 8,074 targets |
| Eligible supported reconstructions / reference history-gap correlation pairs | 8,068 targets |
| Finite raw prediction correlations | 8,069 targets |
| Finite deseasonalized prediction correlations | 8,068 targets |
| Finite reconstruction NSE and relative total-volume error | 8,073 targets |
| Water HSS, q20 / q10 | 8,059 / 7,995 targets |
| Water deficit ratios, q20 / q10 | 8,060 / 7,996 targets |

Success requires NSE ≥ 0.5, improvement over the target-history seasonal baseline, an actual fitted transfer and reference contribution. The historical key `old_NSE_pass` retains this primary definition. Finite seasonal fallback values may enter continuous and water metrics where those metrics are defined; they do not thereby become successful supported reconstructions. Pearson r > 0.7 is a separate supplementary diagnostic.

Reference–target composite correlations use history-derived standardized log-flow anomalies. Reconstruction deseasonalization instead subtracts the history-derived raw-flow seasonal baseline from both prediction and truth. These are different quantities. Paired changes summarize within-target differences, not differences of separately summarized medians.

The seasonal-history experiment is separate: 5,811 targets, H36 target history, H60 reference history and G120, with the target spatial fold excluded and 12 omission rotations averaged per target. It compares transfer formulations with differing representation, regularization and bounds; it is not an isolated seasonal-component intervention or a test of distant-reference substitution.

Genuine-gap validation retains 141 registrations, 102 history-estimable targets and 101 score pairs. Retrieved truth is partial; it is not a full 120-month replication. The 596-gauge record-existence audit in S16C is a different population. Location additions likewise retain four separate target populations: 80 South African targets with external-location duration, 8,898 nearest restorations, 5,905 shared-layout targets and 5,229 single-location targets. Their budgets, calendars and selection rules differ.

## Scope retained in the final SI

The final audit removed S14E1/E2 regional qualification tables, the former S16C natural-history calendar-coverage table, S21E regional water summaries, S21F ancillary water diagnostics, and the last two absolute-effect summary rows of S8B. The remaining global rule sensitivity, regional archive evidence, direct selector contrasts and all 24 signed S8A contrasts remain current.

Current water evidence is **S21A–D**, with all eleven frozen conditions, sixteen specified contrasts, q20/q10 thresholds and both fixed processors. The historical code can still calculate conditional-seasonal HSS, alternative deficit normalization, period-mean changes and regional water summaries. Those outputs are retained code capabilities, not current manuscript claims. Total-volume error remains the calendar-day-weighted error over the full 120-month interval. Water uncertainty uses 2,000 shared draws over 274 occupied 5° cells, retaining equal target weights and metric-specific valid intersections.

The history-based rainfall-use decision workflow (`r4_rain_compensation_20261026`) is marked legacy in the experiment map. It is not the current S18F analysis. The latter describes reference availability and associations with already frozen rainfall gains; it does not identify a causal density mechanism, and conditional reweighting is not used for inference. DTRR and unisolated neural outputs are not members of the current twelve-system benchmark.

S5 retains a separate four-method transformation sensitivity. Its preserved `results_rerun_monthly_leak.csv` matches all final-table values at 2,992 stations per method. The calculation chain is `scripts/eval_stratified.py` with history-only (`none`) and full-record (`both`) transformations, followed by the four `LEAK_PAIRS` in `analyze_rerun_monthly.py`. This summarizer also contains historical benchmark outputs; only its four-method leakage summary maps to S5 here. Source and saved-summary correspondence was checked during packaging; the empirical predictions were not rerun. This is distinct from the shared-reference neural input-isolation audit.

One residual source-document cross-reference remains: the S1 overview water row says “S21A–F”, while the delivered table headings, detailed methods and main-text citations retain only S21A–D. This release records the discrepancy and maps the actual retained tables. It does not alter the manuscript.

Calculation sources under historical `manuscripts/.../evidence/` directories are included as analysis code where they score or aggregate frozen predictions. Their directory names and embedded old table labels do not imply that private manuscript files are distributed. Input observations, frozen registrations and original resampling arrays remain necessary for exact empirical reproduction.
