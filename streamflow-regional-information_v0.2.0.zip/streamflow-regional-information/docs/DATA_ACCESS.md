# Data access and provenance

Observations are obtained from the original providers. This code release does not redistribute their time series or change their terms. Record the downloaded version, access date, station catalogue and SHA-256 of each input before preprocessing. Links below were checked during release preparation on 30 October 2026.

| Dataset | Use in this study | Official access |
|---|---|---|
| GSIM time-series indices | Native monthly discharge, missingness, controlled targets and reference pool | [GSIM Part 2, PANGAEA 887470](https://doi.org/10.1594/PANGAEA.887470) |
| GSIM metadata and catchments | Station catalogue, coordinates, native catchment geometry and metadata checks | [GSIM Part 1, PANGAEA 887477](https://doi.org/10.1594/PANGAEA.887477) |
| GRDC | Retrieved observations used as independent target truth in genuine GSIM gaps, after identity/overlap checks | [GRDC data portal](https://grdc.bafg.de/data/data_portal/) and [policy guidelines](https://grdc.bafg.de/downloads/policy_guidelines.pdf) |
| Caravan | Independent daily-scale controlled benchmark | [Official Caravan repository and data instructions](https://github.com/kratzert/Caravan) |
| ERA5-Land precipitation | Basin-averaged monthly external forcing, including current and three antecedent months | [Copernicus ERA5-Land monthly means](https://cds.climate.copernicus.eu/datasets/reanalysis-era5-land-monthly-means?tab=download), DOI [10.24381/cds.68d2bb30](https://doi.org/10.24381/cds.68d2bb30) |

The GSIM repositories identify their dataset licence as CC BY-SA 3.0; retain the dataset citation and applicable licence when obtaining or redistributing permitted derivatives. GRDC access follows its request/download terms. This repository does not include a GRDC mirror or a credential-enabled downloader. Caravan and Copernicus versions must be recorded from the actual downloaded product, not inferred from today's landing page.

## Scientific input requirements

- **Dates and units:** the global archive audit is monthly January 1980–December 2015. Streamflow is discharge in m3/s. Precipitation model inputs are basin-average mm/month. Convert accumulated/mean precipitation according to the actual product metadata; the same variable name is not sufficient to infer units.
- **Raw and QC20 archives:** preserve both. QC20 removes months with fewer than 20 available daily observations. Raw availability, source-admission, fitted-model support and successful reconstruction are different quantities.
- **Station identity:** identifiers in two archives are not automatically independent gauges. Keep provider identifiers, coordinates, overlap comparisons and reviewed physical-identity components. Exclude the target and every alias from reference inputs. GRDC values used for evaluation must remain outside history fitting, qualification and prediction.
- **Catchment precipitation:** use the registered full-basin geometry, area weights, source-product identity, date axis, coverage and quality/admission ledger. The release includes extraction/preparation source, but not the study's prepared rainfall matrix or geometry audit decisions.
- **Exact cohorts:** download access does not recreate the study's frozen cohort by itself. The raw-file manifest, duplicate list, source admission, target calendar selection, spatial-fold assignments and precipitation admission are required to reconstruct the same denominator. See [REPRODUCTION.md](REPRODUCTION.md) for the required prepared products.

Additional reservoir/static-attribute sensitivity analyses depend on the provenance of the frozen catalogue fields used by their original code. The repository contains no topology experiment or claim that HydroRIVERS/graph models were used in the final main analysis.

## Local layout

Raw GSIM series are read from the documented relative `code/GSIM_indices/` path inside a separate archival working copy. Externally located precipitation/metadata inputs use `STREAMFLOW_DATA_ROOT`; preserve the registered relative subdirectories or adapt paths in a new, documented execution. Credentials, when a provider requires them, stay in the user's local provider configuration and must never be committed.

The release includes a runnable synthetic case and a registered observational-case configuration/exporter. Observed streamflow and precipitation values are not shipped. The synthetic case demonstrates equations, missingness handling and matched comparisons; it is not an observed river case or a global result. The observational case requires locally obtained inputs, with the same provenance and access rules as the full experiments.
