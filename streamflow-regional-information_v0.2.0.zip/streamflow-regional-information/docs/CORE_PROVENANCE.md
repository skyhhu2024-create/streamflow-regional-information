# Portable core and historical experiment provenance

This package extracts the final global-source distance-withdrawal and
precipitation experiment's calculations. It is not a newly tuned reconstruction
model and does not claim that a synthetic example reproduces global results.
The source paths below are relative to the historical project's `code/` folder.

| Portable module | Historical source | Retained calculation |
| --- | --- | --- |
| `primitives.py` | `V45/experiments/r3_conditional_stress_20261024/source_outage/run_outage.py` | H log1p calendar means, anomaly scaling, pairwise qualification, dual ranks, monthly K4 composite and guarded inverse transform |
| `transfer.py` | `V45/experiments/r4_global_information_20261025/design_review/transfer_model.py` | Fixed ridge / RBF processor, H feature standardization, P lag 0–3 and same-fit climate control |
| `reconstruction.py` | `V45/experiments/r4_full_source_gradient_20261026/src/engine.py` | Physical-identity guard, all-qualified nearest-source distance, fixed withdrawal masks, survivor H refits and Q/QP/control arms |
| `metrics.py` | `V45/experiments/r4_observation_locations_20261025/input_audit/trial_score_core.py` | r/α/δ/NSE, operational success flags, new/lost transitions and paired spatial-cell bootstrap |
| `case.py` | New wrapper around the retained definitions | Compact array input, mandatory identity metadata and explicit calendar indexing |

All 23 extracted function/class definitions were compared with the original
syntax trees and are unchanged. `CORE_EXTRACTION_AUDIT.json` records the
definition-level hashes. Only imports, module documentation and wrappers were
changed. Unused topology-experiment branches were not included in this core.
Scientific computations for water-resource outcomes have separate provenance.

## Numerical replay

`examples/export_registered_case.py` exports one case from a local copy of the
registered historical experiment. The first registered case, AR_0000001, was
replayed without loading target gap truth. Its source pool has 24,714 candidates
after the original 20 safety exclusions; target physical aliases are excluded
at selection and cannot be accessed as G sources.

The portable wrapper reproduced the final cached case exactly for all 16 checked
arrays: 2,880 predictions, standardized predictions, reference IDs and weights,
composites, support, fit flags, H training masks, seasonal transformations and
nearest-reporter diagnostics. `CORE_REPLAY_VERIFICATION.json` contains only
equality/shape information; no raw observational values. This check validates
code extraction on a real input, not population-wide scientific conclusions.

Synthetic tests separately exercise physical-alias exclusion, poisoning target
G without affecting predictions, H independence from changed safe-source G,
withdrawal boundaries, the same QP fit under the P climate control, the H/G lag
boundary, exact Q fallback when P is unavailable, complete source dropout,
undefined correlations, NSE decomposition and fixed-denominator bootstrapping.

## Fixed semantics

1. Source and target calendar transformations use H observations only. Log1p
   anomalies are divided by their H standard deviations. Invalid reports do
   not become zero observations.
2. H qualification requires at least 12 paired finite anomalies, positive
   correlation and finite source anomaly scale. Qualification is not a claim
   of accurate prediction in G.
3. Ranking uses the sum of correlation and distance ranks; ties use correlation
   rank, then stable source ID. For each date the first four reporting sources
   in this order are combined using positive H correlations as weights.
4. D=0 retains all distances. D=100/300/800 km withdraws sources at or inside
   that cutoff without reranking survivors. H composites are rebuilt from the
   surviving subset before refitting the transfer.
5. Ridge uses standardized H features, an unpenalized intercept and penalty
   `n * 0.1`. The RBF sensitivity uses `exp(-squared_distance / feature_count)`
   with the same penalty. Neither processor tunes against target G truth.
6. P contributes lag 0–3 log1p values. QP and QP_Gclim share a fitted model.
   Climate control replaces only G-dated P values with H calendar means;
   antecedent values still dated in H stay actual. P availability is frozen
   separately; unavailable P yields exact Q fallback. No P-only arm is implied.
7. Inverse predictions retain the historical anomaly clip, nonnegative raw
   output and raw target-H seasonal fallback. Fallback output alone is not
   counted as an actual supported model fit.
8. **Final-manuscript primary success:** NSE ≥ 0.5 and NSE above the target-H
   seasonal baseline, with a fitted model, positive G support, valid nonconstant
   truth and complete nonnegative predictions. The legacy field is named
   `old_NSE_pass`. Correlation-only `r07_pass` is supplementary in the final
   manuscript. Earlier experiment registration assigned these a different
   reporting hierarchy; the calculations themselves remain unchanged.

## What a full study replay additionally requires

Original GSIM parsing/QC, registered target windows, physical identity maps,
audited source exclusions, precipitation extraction and geometry checks,
fixed cohort membership, spatial bootstrap draws, and figure source tables
are distinct stages. They cannot be inferred from this single-case API.
Historical paths are documented for provenance, not silently read by the core.
GSIM/GRDC/ERA5 acquisition and redistribution remain governed by source terms.
Neither observational arrays nor manuscript documents are required to run the
synthetic example or core tests.
