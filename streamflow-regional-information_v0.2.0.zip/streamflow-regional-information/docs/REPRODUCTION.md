# Reproduction guide

This release contains a small reusable implementation and an archival copy of the calculation workflows used for the final manuscript. The archive preserves the original relative directory layout, including version/date labels, because the scripts import one another and refer to frozen experiment products by those paths. A directory named `R3` in an old version is not necessarily the current manuscript's R3; use `EXPERIMENT_MAP.csv` to identify the current role.

This release is aligned to the audited main text and SI dated **8 November 2026**. Their hashes are in [MANUSCRIPT_VERSION.json](MANUSCRIPT_VERSION.json); current panels, supplementary tables and denominators are in [MANUSCRIPT_ALIGNMENT.md](MANUSCRIPT_ALIGNMENT.md).

## What can be run from this checkout

The root README describes the portable synthetic case and tests. These examples require no GSIM, GRDC or ERA5 observations. They exercise the calculations; they do not reproduce the global numerical results. The registered observational-case configuration/exporter provides a second route when the original local inputs are available. Release preparation compared its 2,880 reconstructed values against the frozen case and obtained exact equality; see [CORE_REPLAY_VERIFICATION.json](CORE_REPLAY_VERIFICATION.json). This case-level replay is distinct from rerunning the global experiments.

The following check verifies every archived source hash, compiles every archived Python file without executing it, and runs the original full-source engine's synthetic identity/isolation test:

```sh
python archived_workflows/check_release.py --synthetic
```

The synthetic test uses invented arrays and checks own-station exclusion, source-withdrawal masks, history-only fitting, the precipitation-climatology control and the no-precipitation fallback. It does not inspect target observations or overwrite any original study files.

## What is required for the full manuscript calculations

The archival workflows require the observations obtained from their providers, their exact preprocessing versions, frozen station/physical-identity manifests, prepared rainfall arrays, and the corresponding experiment registrations. Those inputs and production-state receipts are not bundled here. Consequently, this checkout is **not a one-command reproduction of the global results**. The release preserves the numerical/source implementation and identifies the missing input contracts, rather than silently replacing the study cohort or generating replacement approval receipts.

Keep a separate working copy of `archived_workflows/code/` for full-data runs. Scripts write outputs beside their experiment directory, and some refuse to overwrite a completed registration. Do not disable these checks. Historical receipts bind original byte hashes and paths; a new execution needs a documented new registration and review after paths and inputs are installed. A copied historical `PASS`/authorization file is not evidence that a new run has passed.

Use Python 3.12 with NumPy, pandas, SciPy and scikit-learn; the archival dependency groups are listed in `archived_workflows/requirements.txt`. PyTorch is additionally required for the R2 neural benchmarks. The basin-precipitation preparation modules additionally require netCDF4, pyshp, shapely and pyproj. No third-party implementation or installed dependency directory is vendored. Historical GPU/device/software state was not completely captured, so neural training should not be described as bit-for-bit reproducible.

Most paths are relative to `archived_workflows/code/`. The few original paths to external data were replaced by `STREAMFLOW_DATA_ROOT`, defaulting to `archived_workflows/inputs/`. This variable is a data directory, not a credential. It does not redirect every internal prepared-product path: retain the relative layout listed below. Changes, original hashes and released hashes are recorded per file in `archived_workflows/manifest.json`.

## Input contracts

| Input | Required representation and role |
|---|---|
| Native GSIM monthly files | `code/GSIM_indices/GSIM_indices/TIMESERIES/monthly/*.mon`; station IDs from filenames, native monthly `MEAN` and `n.available`; original catalogue order and duplicate list retained. A frozen raw-file manifest is required by the global matrix builder. |
| Global matrix | `V45/experiments/r3_global_single_condition_20261022/global_data/{raw_Q.npy,QC20_Q.npy,station_ids.npy,station_metadata.csv}`. Rows follow the 30,959-entry catalogue; columns are the 432 months January 1980–December 2015. Raw versus QC20 values must remain distinct. QC20 uses at least 20 observed days in a month. Missing values are NaN; no implicit interpolation. |
| Station roles | `.../design/all_station_roles.csv`, independent target cases and outer-fold masks; `.../predictions/source_cache/source_raw_indices.npy`. These bind catalogue rows, history/gap dates, spatial groups and source admission. Do not regenerate a differently ordered list and reuse saved arrays. |
| Physical identity | `r4_global_siting_20261026/census/physical_identity_map.csv`, display metadata, and the full-source gradient's `design_review/recommended_source_exclusions.csv`. Exclude all aliases of the target physical station before constructing any source input. |
| Full-source cases | `r4_observation_locations_20261025/trial_predictions/{cases.csv,selected_ids.npy,composites.npy,training_mask.npy}` plus the prior bridge prediction/support/flag arrays. The current runner checks exact replay of the unchanged baseline; these are dependencies, not new observations. |
| Prepared target history | `r4_global_information_20261025/prepared_inputs/{target_Hz,target_H_log_calendar,target_H_anomaly_sd,target_H_raw_calendar,input_meta}.npy`. All transformations are estimated from each target's visible history, never its hidden gap. |
| Precipitation | `PRECIPITATION_H_ONLY_INPUTS.npz` in the same prepared-input directory, and the admitted full-basin monthly precipitation product used to build it. Supply monthly precipitation in mm/month with current and three antecedent months, exact dates, basin geometry/weights, coverage and admission flags. Missing or rejected precipitation must preserve the registered Q-only fallback. Do not substitute point rainfall, another ERA product or reconstructed streamflow. |
| R1 older matrix | `code/recoverability/{Z.mm,ids.npy}` plus frozen baseline station lists, pool edges, catalogue metadata and real/artificial gap-event tables. This is the R1 local qualification audit; its rules and denominator differ from the later global source-pool audit. |
| R2 benchmark inputs | `boundary_validation_20260922/data/` QC20/deduplicated matrix, dates/IDs, original configuration/split and gap masks, original target-only and classical predictions, and native Caravan data/cache. R2 isolation masks are applied differently to training, validation and test inputs. |
| Genuine gaps | `r3r4_real_forward_20261026/census/` registered cases, identity exclusions and `registered_evaluation_truth.npz`, plus independent precipitation admission products. GRDC truth belongs only to the evaluator; it must not repair target history or enter source inputs. |

The array builders and original validators enforce additional field names and shapes. Their input lists are the authoritative machine-level contract. Prepared matrices, registrations and identity decisions are part of the scientific provenance; public data-provider URLs alone are insufficient to reproduce the exact published sample.

## Calculation order and entry points

All paths below are relative to `archived_workflows/code/`. Commands are examples of the original interfaces **after** their inputs and new registration have been supplied. They are not instructions to bypass missing prerequisites.

### R1: archive gaps and reference availability

1. Load native observations and metadata, retain the original study period and station eligibility. `scripts/analyze_review_round2_robustness.py` supplies matrix, geodesic-distance, qualification and standardization helpers.
2. Run `revision_evidence_tightening_20260910/audits/unsupported_decomposition/run_unsupported_decomposition.py` and the `gap_structure/run_gap_structure_audit.py` audit with its registered real/artificial masks.
3. Run `revision_gap_length_support_20260914/recompute_all_qualified.py`, `check_all_qualified_sensitivity.py` and `manuscript_v39/analysis/analyze_support_task_composition.py`. These distinguish absence of any qualified relation from absence of synchronous reports. The older fixed-eight bookkeeping state must not be relabelled as absence of every qualified source.
4. `V42/experiments/history_scope/run_history_scope.py` supplies the supplementary pre-1980 history sensitivity; it is an availability audit, not independent reconstruction validation.

### R2: controlled input and processor comparisons

1. `scripts/run_baselines.py`, `scripts/train_baseline_deep.py` and `exp_caravan_full_benchmark.py` contain the original classical/deep model implementations. `exp_selection_grid_aligned.py` implements the controlled selection/combination grid.
2. Build the exposure audit with `V41/experiments/mask_audit/audit_exposure.py`, then use `isolated_data.py` via the isolated trainer. For example:

```sh
python V41/experiments/mask_audit/rerun_isolated.py --scale monthly --models lstm,brits,saits --device cpu --protocol isolated --execute
python V41/experiments/mask_audit/rerun_isolated.py --scale daily --models lstm,brits,saits --device cpu --protocol isolated --execute
python V41/experiments/mask_audit/summarize_retraining.py --help
python V41/experiments/mask_audit/ranking_13.py --scale both
```

The historical filename `ranking_13.py` is retained for provenance, but its released comparison roster has **12 systems**: DTRR was removed from the final manuscript and is excluded from this roster. Older shared implementation modules still contain unused historical functions; their presence does not add a method to the final comparison. Do not report the unisolated deep reruns as the final benchmark.

3. `V42.2/experiments/r2_monthly_count_20261014/run_r2_monthly_count.py` preserves the monthly reference-count sensitivity (current S8C and Fig. S4). This design is separate from the global natural-gap availability census, which counts all qualified reports.

4. The one-sided extension panel uses `V39.1/experiments/r3/run_stress.py`, then `V39.1/R3_revision_proposal/dat_selected8_r2matched/run_dat_selected8.py` and `analyze_direction_history_r2full.py`. Its fixed 691-target complete-support comparison is separate from the later full-source R3/R4 cohort.

### R3: natural availability, controlled withdrawal and seasonal identification

1. `V45/experiments/r3_global_single_condition_20261022/data_source/build_global_inputs.py` builds raw/QC20 matrices; `design_source/build_design.py` defines the corresponding station roles. This older directory is used here for its input products, not its discarded feature-ranking experiments.
2. Natural forward gaps: run `r3_confirmation_20261024/natural/run_calendar_audit.py register`, then the same script without an argument; `run_distance_audit.py register`; `run_distance_fast.py equivalence`; `run_distance_fast.py produce --workers 4`; `summarize_distance.py`. The fast calculation is accepted only after matching its direct implementation. The separate `r3_natural_correlation_sensitivity_20261028/run_threshold_audit.py` changes only the historical-correlation qualification threshold.
3. Controlled withdrawal and precipitation share `r4_full_source_gradient_20261026/src/engine.py`. The engine imports the unchanged history/source mathematics in `r3_conditional_stress_20261024/source_outage/run_outage.py` and the fixed transfer processors in `r4_global_information_20261025/design_review/transfer_model.py`. Production order is:

```sh
python V45/experiments/r4_full_source_gradient_20261026/src/test_engine_synthetic.py
# Supply inputs and reviewed PROTOCOL/registration; do not manufacture approval receipts.
python V45/experiments/r4_full_source_gradient_20261026/src/run_engine.py register
python V45/experiments/r4_full_source_gradient_20261026/src/run_engine.py produce --workers 4
python V45/experiments/r4_full_source_gradient_20261026/src/run_engine.py assemble
# Independently audit the frozen predictions before authorizing the evaluator.
python V45/experiments/r4_full_source_gradient_20261026/src/score_gradient.py freeze
python V45/experiments/r4_full_source_gradient_20261026/src/score_gradient.py score --authorized-after-QA
```

The primary comparison uses the same 8,083 precipitation-admitted cases from the 8,898-case mother cohort, H=60 and G=120 months. Withdraw sources at 0/100/300/800 km from the **global** candidate pool, refit survivors from H only, and preserve own-physical-station exclusions. The headline skill criterion in the final manuscript is `old_NSE_pass`: NSE >= 0.5, above the target-history seasonal baseline, with actual fitted/reference support. Historical `r07_pass` is a distinct correlation diagnostic; never substitute it for the final headline criterion. The full driver writes both.

4. Seasonal confirmation: `r3_confirmation_20261024/confirmation/preflight.py` → `run_confirmation.py register` → `run_confirmation.py smoke` → `run_confirmation.py produce` → `score_confirmation.py freeze/score/bootstrap`. The runner imports `r3_conditional_stress_20261024/history_season/run_history_season.py`. Its 5,811-target, H36 confirmation sample and seasonal/count-matched missingness conditions must remain distinct from the 8,083 full-source cases.
5. Current historical/gap agreement, correlation-only ranking and the five-processor control are produced by `V45/manuscripts/argument_revision_20261028/evidence/pure_correlation_sensitivity.py` and `audit_cached_and_reranked.py`. The `manuscripts` directory here contains computation source, not manuscript documents. Keep the primary 8,083-target success denominator separate from metric-valid subsets (8,068 composite correlations and 8,073 NSE).
6. Water-resource consequences are evaluated from frozen reconstructions, with both q20/q10 thresholds and all 16 registered contrasts across 11 arms. The archived production chain is in `V45.1/experiments/water_resource_consequences_20261029/`; the portable scorer is described in [WATER_METRICS.md](WATER_METRICS.md). This is scoring, not model selection or refitting. Current output destinations are Fig. 3f–h and Note 11/S21A–D. Extra historical diagnostics retained in the core are identified as legacy in that guide.

### R4: additional information and observation examples

The precipitation contrast is already part of the paired R3/R4 full-source engine: Q versus Q+P, plus an H-estimated precipitation-climatology control under the same fitted model, with ridge and the fixed kernel sensitivity. It must not be computed on a different convenience subset. `V45/experiments/r4_rain_density_20261029/` contains the additional residual-reference-abundance and rainfall-gain summaries used in S18F. Its spatial bootstrap draw file is also an input to the water-resource summary chain. Association/stratification in this analysis is not an intervention on observation density.

For the five-year observation example, `r4_global_network_gain_H60_20261026/source/prepare_design.py` defines pre-period station roles; `conditional_covariance.py` and `run_selection.py` implement information-based candidate ranking and greedy common layouts; `evaluate_added_information.py` performs subsequent prediction/scoring. `evaluate_filtered_information.py` and `evaluate_complete_information.py` preserve the alternative information-availability evaluations. Their interfaces are available through `--help`; the original evaluator explicitly requires a selection freeze, prediction QA and, for common layouts, the preselected layout CSV.

`r4_direct_single_site_20261026/run_experiment.py` and `engine/engine.py` implement the separate single-location development/validation check: `register` → `dev` → `assemble_dev` → `select` → `final` → `assemble_final`. Development and final target truth have different access roles. The historical `r4_rain_compensation_20261026/run_history.py` and `analyze_retrospective.py` are retained as archival context/dependencies; that history-based rainfall decision analysis is no longer a current main-text or SI result.

Current short-common-record observations are implemented in `r4_observation_locations_20261025/trial_source/run_trial.py` and summarized by `input_audit/analyze_observation_trial.py` (109 external locations, the 80-target South African comparison). Nearest withheld-location restoration uses `r4_global_siting_20261026/source/prepare_trial_v3.py`, `run_trial.py` and `score_trial.py` (8,898 targets and 4,930 withheld locations). The later NSE harmonization is preserved separately in `V45/manuscripts/review_revision_20261027/evidence/`.

These designs have different calendars/denominators from the 8,083-case withdrawal experiment; their percentages cannot be added together or interpreted as a validated universal optimal station network.

### Supplementary genuine-gap validation

`r3r4_real_forward_20261026/census/` defines actual GSIM forward gaps, checks physical aliases and registers cases before new predictions. `inputs_precip/prepare_precipitation.py` prepares independently admitted precipitation. `source/run_real_forward.py` generates frozen predictions without loading GRDC truth; `scoring/score_real_forward.py` evaluates against it after QA. Keep the 141 registered cases, the 102 fully history-qualified cases and the final metric-evaluable subset as different denominators. The prior 432/596-gauge archive-retrieval exercise is not this experiment.

## Release checks and exclusions

`archived_workflows/manifest.json` lists original source hashes, released hashes, their local import relationships, and every release edit. Changes are limited to path portability, line-ending/encoding normalization, and excluding the withdrawn DTRR roster entry. Numerical fitting, thresholds, random seeds, station-selection rules, target masks and metric formulas are retained.

No manuscripts, user work logs, raw or reconstructed observed series, station-identity review files, credentials, cloud tokens, giant caches, vendor packages, generated figures, or obsolete feature-ranking exploration outputs are included. Full-scale computations were **not rerun during release preparation**. Report synthetic/unit verification separately from scientific full-data reproduction.
