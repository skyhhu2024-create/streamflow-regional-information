# Regional information in global streamflow reconstruction

Computation and reproducibility code accompanying **Global data availability does not make nearby streamflow gauges dispensable** (audited main text and supplement: 8 November 2026; code release 0.2.0: 10 November 2026).

The study examines whether a global streamflow archive can compensate for the loss of regional observations. It separates the availability of reference records from their ability to reproduce a target's missing flows, then tests what precipitation and additional gauge records can contribute. The calculations also assess consequences for low-flow identification, cumulative water deficits and total water volume.

This repository provides the calculation core, the archived workflows underlying the paper, and runnable examples. Its purpose is to make the information comparisons and their evaluation reproducible. The source observation archives and a global reconstructed-discharge product are not distributed here.

## Start with a runnable example

Python 3.10 or later is required. From the repository root:

```bash
python -m venv .venv
# Activate the environment: .venv\Scripts\Activate.ps1 (Windows)
# or: source .venv/bin/activate (Linux/macOS)
python -m pip install -e .
python -m unittest discover -s tests -v
python examples/run_synthetic_case.py --output-dir outputs/synthetic_case
```

The example generates **synthetic** monthly observations and runs the same numerical core used for the source-withdrawal/precipitation comparison. Synthetic outputs illustrate how to run and inspect a case; they are not the paper's empirical results. No data downloads or credentials are needed for this example.

To use observations you are authorized to process:

```bash
python examples/run_array_case.py my_case.npz outputs/my_case_predictions.npz
```

The input schema and target-identity safeguards are documented in [examples/README.md](examples/README.md). Target observations inside the gap are excluded from the reconstruction interface and supplied separately for evaluation. The examples also include instructions for extracting and checking a registered real-station case from locally held study inputs.

## Reproduce a registered river case

The observational example is **the Paraná River at Posadas, Argentina** (GSIM station `AR_0000001`). It uses 60 months of visible history, February 1982–January 1987, followed by a 120-month evaluation interval, February 1987–January 1997. This is the first case in the frozen registration, selected for execution checking rather than favourable performance.

With the original study inputs available locally:

```bash
python examples/export_registered_case.py --project-code /path/to/code --station-id AR_0000001 --output outputs/posadas_inputs.npz
python examples/run_array_case.py outputs/posadas_inputs.npz outputs/posadas_predictions.npz
```

Replace `/path/to/code` with the historical project's `code` directory containing the inputs described in [REPRODUCTION.md](docs/REPRODUCTION.md). The exporter leaves target observations inside the gap out by default. A local replay reproduced all 2,880 frozen predictions and the reference selections, support masks and fitted-model states exactly. See the [verification receipt](docs/CORE_REPLAY_VERIFICATION.json) and [case documentation](examples/README.md). Observational arrays remain on the user's computer.

## Contents

| Location | Purpose |
| --- | --- |
| `src/streamflow_info/` | Portable historical transformation, reference qualification/ranking, monthly composites, transfer models, and evaluation metrics |
| `examples/` | Runnable cases, array-input contract, and example interpretation |
| `scripts/evaluate_water.py` | Evaluate frozen predictions for low-flow timing, cumulative deficit and interval water volume |
| `archived_workflows/` | Original experiment scripts and their required local code dependencies, with portable path configuration |
| `docs/REPRODUCTION.md` | Ordered reproduction instructions and required input artifacts |
| `docs/EXPERIMENT_MAP.csv` | Current manuscript analysis-to-code mapping |
| `docs/MANUSCRIPT_ALIGNMENT.md` | Current figure/SI mapping, denominators and historical-code interpretation |
| `docs/MANUSCRIPT_VERSION.json` | Identity and SHA-256 of the exact main text and SI checked |
| `docs/DATA_ACCESS.md` | Dataset access links and preparation requirements |
| `docs/WATER_METRICS.md` | Metric definitions, invalid cases and paired spatial summaries |
| `tests/` | Numerical and input-isolation checks using synthetic data |

## Analyses represented

1. **Archive diagnosis:** missing-record positions, task composition and reference-support conditions.
2. **Controlled information comparisons:** matched information inputs and reconstruction systems, including input-isolation checks.
3. **Global versus regional reference information:** natural-gap availability, forward-extension reconstruction and withdrawal of references within 0, 100, 300 and 800 km. Zero means no regional withdrawal, rather than a zero-radius candidate pool.
4. **Precipitation complementarity:** fixed ridge and RBF-ridge processors, reference-flow inputs, precipitation inputs and the same-fit precipitation-climatology control.
5. **Water-resource consequences:** historical q20/q10 thresholds, low-flow classification, cumulative deficit and calendar-day-weighted volume over the full evaluation interval.
6. **Observation-location examples:** short common-record tests, nearest-location restoration, a shared layout and a separately selected single location, with distinct target cohorts.
7. **Supplementary genuine-gap validation:** predictions evaluated against separately retrieved observations, with target truth kept outside the reconstruction inputs.

These are computation groups, not a one-to-one numbering of Results subsections. The current main text has five Results subsections. The updated mapping also includes correlation-only reference ranking, historical-versus-gap agreement, residual reference abundance and rainfall-gain stratification. Current water-resource panels are **Fig. 3f–h**, following the NSE panel in Fig. 3e; the water-resource supplement is **Note 11 and Tables S21A–D**.

The final manuscript's reconstruction-success criterion is **NSE ≥ 0.5 and improvement over target seasonal climatology, with fitted reference input**. The historical code key `old_NSE_pass` retains this criterion; its name reflects development history, not its priority in the final paper. Pearson r > 0.7 is a separate supplementary timing diagnostic. Input availability and reconstruction success have distinct denominators. The 800 km withdrawal is an experimental stress test; its result is not the fraction of natural gaps in the same situation.

## Exact study reproduction

Begin with [REPRODUCTION.md](docs/REPRODUCTION.md), rather than treating the synthetic example as a global replication. Exact reproduction requires the versioned monthly input arrays, station-identity exclusions, cohort/window registration, precipitation extraction and resampling files used by the original experiments. The archived workflows preserve those dependencies and distinguish them from the portable single-case interface. Access to a current archive alone does not recreate the study snapshot automatically.

The all-qualified natural-gap availability audit has no four-reference cap. The transfer comparison uses up to four reporting references per month. The earlier R2 fixed-eight controlled experiment is a separate design; neither its cohort nor its cap is silently substituted for the global experiment.

Source manifests record where the released scripts came from and their checksums. Path changes are documented separately from scientific calculations. Original private data, manuscripts, local credentials and model-output caches are not included.

## Water-resource evaluation

```bash
python scripts/evaluate_water.py --input cases.csv --output outputs/water
```

Use [WATER_METRICS.md](docs/WATER_METRICS.md) for required CSV columns, optional NPZ input and paired comparisons. The evaluator accepts predictions; it does not refit them. Interval water-volume error is calculated across the complete evaluation interval and must not be relabelled as annual error.

## Data and use

The principal data sources are:

| Source | Role | Access |
| --- | --- | --- |
| GSIM | Monthly streamflow archive and reference observations | [Monthly indices](https://doi.org/10.1594/PANGAEA.887470); [station metadata and catchments](https://doi.org/10.1594/PANGAEA.887477) |
| GRDC | Independent observations for genuine-gap evaluation and supplementary gauge records | [GRDC Data Portal](https://portal.grdc.bafg.de/) |
| ERA5-Land | Basin-averaged monthly precipitation | [Copernicus Climate Data Store](https://cds.climate.copernicus.eu/datasets/reanalysis-era5-land-monthly-means) |
| Caravan | Daily-scale controlled benchmark | [Official project and data instructions](https://github.com/kratzert/Caravan) |

Version and preparation requirements are in [DATA_ACCESS.md](docs/DATA_ACCESS.md). GRDC observations must not be redistributed through this repository. Generated synthetic examples contain no provider observations.

## Verification

Verification for this release is recorded in [RELEASE_VERIFICATION.md](docs/RELEASE_VERIFICATION.md), including core tests, the synthetic case, archival source integrity and the status of the real-case replay. Historical checks are dated separately from checks repeated for this release. The full global experiments were not rerun during repository packaging.

Version 0.2.0 adds missing production-analysis sources and aligns documentation to the saved final manuscript. It does not change the portable reconstruction or water-metric formulas. See [CHANGELOG.md](CHANGELOG.md).

## Citation and licence

No open-source licence has yet been assigned to the study code. Dataset terms remain those of their respective providers. A persistent software DOI and final paper citation can be added when available.

For a Chinese navigation guide, see [README_zh.md](README_zh.md).

